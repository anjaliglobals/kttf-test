<?php
class M_stage extends CI_Model{

  function accessPrivilege($appID){

		$where = array();
		if($this->admDesig)
			$where['ms.desig_id'] = $this->admDesig;

		if($this->admDistrict)
			$where['app.district_id'] = $this->admDistrict;		


		$this->db->select('wf.id workflow,app.status_code');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where('app.id' , $appID);
		$this->db->where($where);

		$result = $this->db->get()->result();
		
		if($result):
			$access = array('workflow'     => $result[0]->workflow,
					'admPrivilege' => ($result[0]->status_code == 0) ? TRUE : FALSE,		
				       );
		else:
			$access = array('workflow'     => '',
					'admPrivilege' => False,		
				       );
		endif;

	return $access;
  }
}
