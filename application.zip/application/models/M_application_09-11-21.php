<?php
class M_application extends CI_Model{
  	protected $_table_name	= 'application';
	protected $_primary_key = 'id';
	protected $_primary_filter = 'intval';
	protected $_order_by 	= 'id';
	public 	  $_rules 		= array ();
	protected $_timestamps 	= false;


	function getPendingApplication($data)
	{
		 //print_r($data);
	 	$curdate=($data['selval']);
	 	// print_r($curdate);

		$where = array('app.is_confirmed' => '1',										
			       'app.status_code'  => 0);
		//$where=date('Y-m-d',$data['selval']);

		// if($this->admDesig)
		// 	$where['ms.desig_id'] =$this->admDesig;
		// if($this->admDesig!=1 )		
		// 	$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
		// else
		// 	$where['app.district_id'] = $this->admDistrict;
		// if($this->admDistrict)
		// 	$where['app.district_id'] = $this->admDistrict;	

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['app.district_id'] = $this->admDistrict;	
		}	

		$this->db->select("app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,'%d-%m-%Y') confirmed_date, md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, atl.timeline,
			CASE  WHEN app.is_payment_approved = 1 && app.payment_id IS NULL THEN 'Waiting For Payment' WHEN app.stg_send_back_date IS NOT NULL && app.stg_send_back_submit_date IS NULL THEN '<span style=color:#b73425;font-weight:600>Resent For Verification</span>' when app.stage_id=0 && app.iteration IS NOT NULL && app.resent_verifi=1 then '<span style=color:#b73425;font-weight:600>Resent for Verification</span>'when app.stage_id=0 && app.iteration IS NOT NULL then '<span style=color:#d65470;font-weight:600>Resend for Clarification</span>' ELSE wf.flow_name  END appStatus,ABS(datediff(app.crtdate,now()))'diff',
			if(ABS(datediff(app.crtdate,now())) <= atl.timeline,ABS(datediff(app.crtdate,now())), '') as appro_timeline,
			if(ABS(datediff(app.crtdate,now())) <= atl.timeline,'Y', 'N') as status",false);
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER'); 
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->join('approval_timeline atl', 'app.app_status=atl.app_status_id','left');	
		$this->db->where($where);
		if($curdate!=0)
			$this->db->where("DATE_FORMAT(app.crtdate,'%Y-%m-%d')",$curdate);
		if($this->admDesig!=1)
			$this->db->where('ms.desig_id in (1,2,3)');
		else
			$this->db->where('ms.desig_id',$this->admDesig);	
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');

		$result = $this->db->get();
		$result = $result->result();
		// print_r($this->db->last_query());
		// die();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->appStatus,
								'status'	 => $res->status,
								'Timeline'   => $res->diff,
						'originalTimeline'   => $res->timeline,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id

							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}

	function getAppInfo($appID){
		// echo $appID;
		// die();
		$where = array('app.is_confirmed' => '1',
				'app.id' => $appID
				);
		

		$this->db->select('app.*');
		$this->db->from('application app');
		$this->db->where($where);

		$result = $this->db->get();
		$result = $result->result();
		// print_r($this->db->last_query());

		return $result;
	}

	function vehicleInfo($appID)
	{	
		$count = 0;
		$this->db->query("SET @cnt := 0");
		$where = array(
				'vd.app_id' => $appID
				);

		$this->db->select("(@cnt := @cnt + 1) AS slno,vd.vehicle_type,vd.registeration_no,vd.tourist_permit,
			vd.regitration_name, DATE_FORMAT(vd.permit_date, '%d-%m-%Y')'permitdate', DATE_FORMAT(vd.end_date, '%d-%m-%Y')'enddate',vd.permit_type");
		$this->db->from('vehicledetails vd');
		$this->db->where($where);

		$result = $this->db->get();
		$result = $result->result();
		//print_r($this->db->last_query());

		return $result;
	}

	function getUserApplications($usrID,$curdate)
	{
		// echo $usrID;
		// echo ($curdate);die();
		$count = 0;
		$this->db->query("SET @cnt := 0");
		
//		$this->db->select('(@cnt := @cnt + 1) AS slno,app.id  appID, app.application_id, mp.name productName, app.org_name orgName, app.confirmed_date, IF(is_confirmed = 1 , ms.order_stage , "Application not submited") appStatus');

		$this->db->select("(@cnt := @cnt + 1) AS slno,app.id  appID, app.application_id, mp.name productName, app.applicant_name orgName, DATE_FORMAT(app.confirmed_date, '%d-%m-%Y') confirmed_date, 
			CASE 
			WHEN app.status_code = 1 THEN '<span style=color:Red>Application Rejected</span>'
			WHEN app.licence_no IS NULL && app.status_code = 2 THEN '<span style=color:Red>Certificate Approval</span>'
			WHEN app.is_payment_approved = 1 && app.status_code = 0 && app.payment_id IS NULL THEN '<span style=color:blue;font-weight:600>Make payment</span>'
			WHEN app.licence_no IS NOT NULL && app.status_code = 2 THEN '<span style=color:#0f6105;font-weight:600>Registration Certificate Issued and Closed.</span>'
			WHEN app.is_confirmed = '0' && app.status_code = 0 && app.isdraft=0 THEN '<span style=color:#bc5f05;font-weight:600>Application Fee Pending</span>'
			when app.stage_id=0 && app.iteration IS NOT NULL && app.resent_verifi=1 then '<span style=color:#b73425;font-weight:600>Resent for Verification</span>'
			when app.stage_id=0 && app.iteration IS NOT NULL then '<span style=color:#d65470;font-weight:600>Resend for Clarification</span>'
			WHEN app.isdraft = '1' THEN '<span style=color:#feca05;font-weight:600>Save Draft</span>'
			ELSE wf.flow_name END appStatus",false);
		$this->db->from('application app');
		$this->db->join('usr_register ureg','app.register_id = ureg.id','left');
		$this->db->join('m_product mp','app.product_id = mp.id','left');
		$this->db->join('m_stage ms','app.stage_id = ms.order_stage','left');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','left');
		$this->db->where('ureg.id',$usrID);

		if($curdate!=0)
		{
			$this->db->where("DATE_FORMAT(app.crtdate,'%Y-%m-%d')",$curdate);	
		}
		$this->db->order_by("app.crtdate", "DESC"); 

		$result = $this->db->get();
		$result = $result->result();
		// echo $this->db->last_query();
		return $result;
	}
	
	function getAppComments($appID,$renwalNO='0'){
		$this->db->select("ac.subject, ac.cons_comm ,ac.inter_comm, DATE_FORMAT(ac.crtdate, '%d-%m-%Y %h:%i:%s') crtdate, wf.flow_name, md.designation_name,ac.crtname");
		$this->db->from('application_comment ac');
		$this->db->join('m_stage ms', 'ms.work_flow_id = ac.app_stage','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation md', 'md.id = ms.desig_id','INNER');
		$this->db->where('ac.application_id',$appID);
		$this->db->where('ac.licence_renewal_no',$renwalNO);
		$this->db->order_by("ac.id", "DESC"); 

		$result = $this->db->get()->result();

		return $result;
	}

	function adminDashboardInfo(){

//-------pending application
		$pendWhere = array('app.is_confirmed' => '1',
					   	   'app.status_code'  => 0,
						);

		if($this->admDesig==1)
		{
			if($this->admDesig)	
				$pendWhere['ms.desig_id'] = $this->admDesig;
			if($this->admDistrict)
				$pendWhere['app.district_id'] = $this->admDistrict;
		}
		

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		if($pendWhere)
			$this->db->where($pendWhere);

		$penResult = $this->db->get()->result();
		$appPending = $penResult[0]->total;
		//print_r($this->db->last_query());

//-------closed application
		$closedWhere = array('app.is_confirmed' => '1',
					   	     'app.status_code'  => 2
						);
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$closedWhere['app.district_id'] = $this->admDistrict;
		}
		

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($closedWhere))
			$this->db->where($closedWhere);

		$appClResult = $this->db->get()->result();
		$appClosed 	 = $appClResult[0]->total;

//---------------Total Received

		$totWhere = array('app.is_confirmed' => '1'
						);
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$totWhere['app.district_id'] = $this->admDistrict;	
		}
		
		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($totWhere))
			$this->db->where($totWhere);

		$totResult = $this->db->get()->result();
		$appTotal  = $totResult[0]->total;
		//print_r($this->db->last_query());

//---------------Rejected App
		$rejWhere = array('app.is_confirmed' => '1',
					   	   'app.status_code'  => 1
						);
		
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$rejWhere['app.district_id'] = $this->admDistrict;
		}

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($rejWhere))
			$this->db->where($rejWhere);

		$rejResult    = $this->db->get()->result();
		$appRejected  = $rejResult[0]->total;	

//---------------Total Payed
		$payWhere = array('app.is_confirmed' => '1',
						  'app.payment_id IS NOT NULL'
						);
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$payWhere['app.district_id'] = $this->admDistrict;
		}

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($payWhere))
			$this->db->where($payWhere);

		$payResult = $this->db->get()->result();
		//print_r($this->db->last_query());
		$appPayed  = $payResult[0]->total;		

		$dashResult = array('appPending'=> $appPending,
							'appClosed'	=> $appClosed,
							'appTotal'	=> $appTotal,
							'appRejected'=> $appRejected,
							'appPayed'	=> $appPayed,
							); 		
		return $dashResult;
	}

	
	function getAppDocVerify($appID,$renwalNO){
		$this->db->select("ad.*");
		$this->db->from('application_doc_verification ad');
		$this->db->where('ad.application_id',$appID);
		$this->db->where('ad.licence_renewal_no',$renwalNO);
		$this->db->order_by('ad.crtdate', 'desc');
		$this->db->limit(1);
		$result = $this->db->get()->result();
		return $result[0];
	}


	function getSummaryApplication($data)
	{
		$curdate=($data['selval']);
		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 0);

		if($this->admDesig)
			$where['ms.desig_id !='] = $this->admDesig;

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDistrict!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;
			else 
				$where['app.district_id'] = $this->admDistrict;	
		}
		
		$this->db->select('app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,"%d-%m-%Y") confirmed_date, md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, wf.flow_name');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where($where);
		if($curdate!=0)		
			$this->db->where("DATE_FORMAT(app.crtdate,'%Y-%m-%d')",$curdate);
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');
		
		$result = $this->db->get();
		//print_r($this->db->last_query());
		// die();
		$result = $result->result();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->flow_name,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}


	function getClosedApplication($data)
	{
		$curdate=($data['selval']);
		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 2);	

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['app.district_id'] = $this->admDistrict;	
		}
		
		$this->db->select('app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,"%d-%m-%Y") confirmed_date , md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, wf.flow_name');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where($where);
		if($curdate!=0)
		$this->db->where("DATE_FORMAT(app.crtdate,'%Y-%m-%d')",$curdate);
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');

		$result = $this->db->get();
		$result = $result->result();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->flow_name,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}

	function getRejectedApplication($data)
	{
		$curdate=($data['selval']);
		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 1);

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['app.district_id'] = $this->admDistrict;	
		}

		$this->db->select('app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,"%d-%m-%Y") confirmed_date, md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, wf.flow_name');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where($where);
		if($curdate!=0)
		$this->db->where("DATE_FORMAT(app.crtdate,'%Y-%m-%d')",$curdate);
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');

		$result = $this->db->get();
		//print_r($this->db->last_query());
		$result = $result->result();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->flow_name,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}
	function getreportData($data)
	{
		$fromdate = strtotime($data['fdate']);
		$newfdate = date('Y-m-d',$fromdate);
		$todate = strtotime($data['tdate']);
		$newtdate = date('Y-m-d',$todate);

		$where = array('a.is_confirmed' => '1');
		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['a.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['a.district_id'] = $this->admDistrict;
		}

		//Record mismatching while we use inner join that's y we used left join 

		$this->db->select('a.id,a.application_id,a.product_id,p.name as productname,a.applicant_name as org_name,a.org_type_id,o.name as organizationType,
			DATE_FORMAT(a.confirmed_date,"%d-%m-%Y") as org_commencement_date,a.gst_number,a.pan_number,a.website_name,a.official_email,a.associate_firm,a.member_recognised_trade,a.org_loc_add2 as org_add2,a.org_loc_add1 as org_add1,a.org_country,c.name as countryname ,a.org_state,s.name as StateName,a.org_district_id,d.name as districtname,a.org_pincode_id,a.org_mobile,a.org_telephone,a.org_total_build_sqft,a.off_international_membership,a.off_prog_arranged_foreign_tourist,a.register_id,a.confirmed_date,a.stage_id,ms.stage_description,a.licence_no,a.licence_issued_date,a.central_gov_approved,d.code,p.category_name,a.acg_id');
		$this->db->from('application a');
		$this->db->join('m_organization_nature o','o.id=a.org_type_id','left');
		$this->db->join('m_product p', 'p.id=a.product_id','left');
		$this->db->join('m_district d', 'd.id=a.district_id','left');
		$this->db->join('m_states s', 's.id=a.org_state','left');
		$this->db->join('m_countries c', 'c.id=a.org_country','left');
		$this->db->join('m_stage ms', 'ms.id=a.stage_id','left');		
		$this->db->where('date(a.confirmed_date) BETWEEN "'. $newfdate. '" and "'. $newtdate.'"');
		$this->db->where($where);
		if($data['prod_id']!='')
			$this->db->where('a.product_id ="'.$data['prod_id'].'"');
		if($data['status_id']!='')
			$this->db->where('a.status_code ="'.$data['status_id'].'"');

		$result = $this->db->get();
		//print_r($this->db->last_query());	
		$result = $result->result();
		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$appidd = "DOT".$res->code."/".$res->category_name."/00000".$res->acg_id;
			$addree = $res->org_add1.$res->org_add2;
			$application = array(
								'slno'		 =>	++$count,
								'id'	 =>$res->id,
								'application_id'=>$appidd,
								'productname'=> $res->productname,
								'orgtype' 	 => $res->organizationType,
								'orgstartdate' => $res->org_commencement_date,
								'governmentapproval'=>$res->central_gov_approved,
								'orgname' => $res->org_name,
								'gstnumber' => $res->gst_number,
								'pannumber' => $res->pan_number,
								'websitename'=> $res->website_name,
								'officialemail'=> $res->official_email,
								'tradedetail'=> $res->member_recognised_trade,
								'orgaddress'=> $addree,
								'districtname'=> $res->districtname,
								'statename'=> $res->StateName,
								'orgcountryname'=> $res->countryname,
								'pincode'=> $res->org_pincode_id,
								'orgmobile'=> $res->org_mobile,
								'telephone'=> $res->org_telephone,
								'buildingsqt'=> $res->org_total_build_sqft,
								'membership'=> $res->off_international_membership,
								'tourist'=> $res->off_prog_arranged_foreign_tourist,
								'licnese_issuedate'=>$res->licence_issued_date,
								'licnese_no'=>$res->licence_no
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}
	function getExportData($data)
    {
        $fromdate = strtotime($data['fdate']);
		$newfdate = date('Y-m-d',$fromdate);
		$todate = strtotime($data['tdate']);
		$newtdate = date('Y-m-d',$todate);

		$where = array('a.is_confirmed' => '1');
		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['a.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['a.district_id'] = $this->admDistrict;
		}		

		$query=$this->db->select('a.application_id,a.product_id,p.name as productname,a.applicant_name as org_name,a.org_type_id,o.name as organizationType,
			DATE_FORMAT(a.confirmed_date,"%d-%m-%Y") as org_commencement_date,a.gst_number,a.pan_number,a.website_name,a.official_email,a.associate_firm,a.member_recognised_trade,a.org_loc_add2 as org_add2,a.org_loc_add1 as org_add1,a.org_country,c.name as countryname ,a.org_state,s.name as StateName,a.org_district_id,d.name as districtname,a.org_pincode_id,a.org_mobile,a.org_telephone,a.org_total_build_sqft,a.off_international_membership,a.off_prog_arranged_foreign_tourist,a.register_id,a.confirmed_date,a.stage_id,ms.stage_description,a.licence_no,a.licence_issued_date,a.central_gov_approved,GROUP_CONCAT(ha.accommodation_type)"accommodation",
			GROUP_CONCAT(ha.other_facility)"other_facility",a.member_kts, a.member_hours, a.name_restaurant, a.restaurant_type,a.cat_restaurant, a.commencement_restaurant,a.mot,  a.no_bed, a.accommodation_provided, a.hotel_resort, a.hotel_mbl_no, a.email_id_hotel,a.total_hotel_build_area, a.visitor_capacity,a.hotel_name, a.org_registration_date, a.owner_name,a.owner_email,a.owner_mobile, a.restaurant_other,a.amusement_commencement_date, a.no_rooms,GROUP_CONCAT(hf.facility_type)"facility_type",GROUP_CONCAT(hf.other_facility)"other_facility",a.outsourced_emp_female,a.outsourced_emp_male,a.permanent_emp_female,a.permanent_emp_male,a.legal_name,a.category_type,a.trade_lic_date,d.code,p.category_name,a.acg_id');
		$this->db->from('application a');
		$this->db->join('m_organization_nature o','o.id=a.org_type_id','left');
		$this->db->join('m_product p', 'p.id=a.product_id','left');
		$this->db->join('m_district d', 'd.id=a.district_id','left');
		$this->db->join('m_states s', 's.id=a.org_state','left');
		$this->db->join('m_countries c', 'c.id=a.org_country','left');
		$this->db->join('m_stage ms', 'ms.id=a.stage_id','left');
		$this->db->join('hotel_accommodation ha', 'ha.app_id=a.id','left');
		$this->db->join('hotel_facility hf', 'hf.app_id=a.id','left');
		$this->db->where('date(a.confirmed_date) BETWEEN "'. $newfdate. '" and "'. $newtdate.'"');
		$this->db->where($where);
		$this->db->group_by('a.id');
		if($data['prod_id']!='')
			$this->db->where('a.product_id ="'.$data['prod_id'].'"');
		if($data['status_id']!='')
			$this->db->where('a.status_code ="'.$data['status_id'].'"');

        $header = array();

        if($data['prod_id']<=3 || $data['prod_id']>6)
        {
        	array_push($header, 'Application Id');
	        array_push($header, 'Product Name');
	        array_push($header, 'Organisation Type');
	        array_push($header, 'Date of Register');        
	        array_push($header, 'Register under Ministry'); 
	        array_push($header, 'Name of proprietor'); 
	        array_push($header, 'GST'); 
	        array_push($header, 'PAN'); 
	        array_push($header, 'Website URL'); 
	        array_push($header, 'Email Id'); 
	        array_push($header, 'Trade Body'); 
	        array_push($header, 'Address'); 
	        array_push($header, 'District'); 
	        array_push($header, 'City'); 
	        array_push($header, 'Pincode'); 
	        array_push($header, 'Mobile Number'); 
	        array_push($header, 'Telephone Number'); 
	        array_push($header, 'Build Area(sq.ft)');
	        array_push($header, 'International Membership');
	        array_push($header, 'Arrange Foreign Traders');
	        array_push($header, 'Licence Number');
	        array_push($header, 'Licence Issue Date');
        }
        elseif($data['prod_id']==4)
        {
        	array_push($header, 'Application Id');
        	array_push($header, 'Category Type');
        	array_push($header, 'Trade Name');
        	array_push($header, 'Legal Name');        	        	
	        array_push($header, 'Product Name');
	        array_push($header, 'Organisation Type');
	        array_push($header, 'Date of Register'); 
	        array_push($header, 'Date of Trade License');	        
	        array_push($header, 'Name of proprietor'); 
	        array_push($header, 'GST'); 
	        array_push($header, 'PAN'); 
	        array_push($header, 'Website URL'); 
	        array_push($header, 'Email Id');
	        array_push($header, 'Member of Karnataka Tourism Society');
	        array_push($header, 'Member of any recognized Hotel & Restaurant');
	        array_push($header, 'Address'); 
	        array_push($header, 'District'); 
	        array_push($header, 'City'); 
	        array_push($header, 'Pincode'); 
	        array_push($header, 'Mobile Number'); 
	        array_push($header, 'Telephone Number'); 
	        array_push($header, 'Build Area(sq.ft)');
	        array_push($header, 'Name of Hotel/Resort');
	        array_push($header, 'Is the Hotel/Resort star classified under Ministry of Tourism');
	        array_push($header, 'Name of the Owner/ Manager of the Hotel/Resort');
	        array_push($header, 'Total No. of Rooms in the Hotel/Resort');
	        array_push($header, 'Total No. of Beds in the Hotel/Resort');
	        array_push($header, 'Accommodation Provided');
	        array_push($header, 'Facilities Available in the Hotel & Resort');
	        array_push($header, 'Mobile Number');
	        array_push($header, 'Email Id of the Owner/Manager of the Hotel/Resort');
			array_push($header, 'Number of Permanent Employees- Males');
	        array_push($header, 'Number of Permanent Employees- Females');
	        array_push($header, 'Number of Outsourced Employees- Males');
	        array_push($header, 'Number of Outsourced Employees- Females');
	        array_push($header, 'Licence Number');
	        array_push($header, 'Licence Issue Date');
        }
        elseif($data['prod_id']==5)
        {
        	array_push($header, 'Application Id');        	
        	array_push($header, 'Trade Name');
        	array_push($header, 'Legal Name');         	       	
	        array_push($header, 'Product Name');
	        array_push($header, 'Organisation Type');
	        array_push($header, 'Date of Register'); 
	        array_push($header, 'Date of Trade License');	        
	        array_push($header, 'Name of proprietor'); 
	        array_push($header, 'GST'); 
	        array_push($header, 'PAN'); 
	        array_push($header, 'Website URL'); 
	        array_push($header, 'Email Id');
	        array_push($header, 'Member of Karnataka Tourism Society');
	        array_push($header, 'Member of any recognized Hotel & Restaurant');
	        array_push($header, 'Address'); 
	        array_push($header, 'District'); 
	        array_push($header, 'City'); 
	        array_push($header, 'Pincode'); 
	        array_push($header, 'Mobile Number'); 
	        array_push($header, 'Telephone Number'); 
	        array_push($header, 'Build Area(sq.ft)');
	        array_push($header, 'Name of Hotel/Resort');
	        array_push($header, 'Is the Hotel/Resort star classified under Ministry of Tourism');
	        array_push($header, 'Name of the Owner/ Manager of the Hotel/Resort');
	        array_push($header, 'Total No. of Rooms in the Hotel/Resort');
	        array_push($header, 'Total No. of Beds in the Hotel/Resort');
	        array_push($header, 'Accommodation Provided');
	        array_push($header, 'Facilities Available in the Hotel & Resort');
	        array_push($header, 'Mobile Number');
	        array_push($header, 'Email Id of the Owner/Manager of the Hotel/Resort');
			array_push($header, 'Number of Permanent Employees- Males');
	        array_push($header, 'Number of Permanent Employees- Females');
	        array_push($header, 'Number of Outsourced Employees- Males');
	        array_push($header, 'Number of Outsourced Employees- Females');
	        array_push($header, 'Licence Number');
	        array_push($header, 'Licence Issue Date');
        }
        elseif($data['prod_id']==6)
        {
        	array_push($header, 'Application Id');        	
        	array_push($header, 'Trade Name');
        	array_push($header, 'Legal Name');         	       	
	        array_push($header, 'Product Name');
	        array_push($header, 'Organisation Type');
	        array_push($header, 'Date of Register');         
	        array_push($header, 'Name of proprietor'); 
	        array_push($header, 'GST'); 
	        array_push($header, 'PAN'); 
	        array_push($header, 'Website URL'); 
	        array_push($header, 'Email Id');
	        array_push($header, 'Member of Karnataka Tourism Society');
	        array_push($header, 'Address'); 
	        array_push($header, 'District'); 
	        array_push($header, 'City'); 
	        array_push($header, 'Pincode'); 
	        array_push($header, 'Mobile Number'); 
	        array_push($header, 'Telephone Number'); 
	        array_push($header, 'Build Area(sq.ft)');
	        array_push($header, 'Name of Amusement Park');
	        array_push($header, 'Date of Commencement of Amusement Park');
	        array_push($header, 'Date of registration under Indian Association of Amusement Parks and Industries (IAAPI)');
	        array_push($header, 'Total Visitor Capacity of the Amusement Park');
	        array_push($header, 'Total Built up area of the Amusement Park ');
	        array_push($header, 'Facilities Provided');
	        array_push($header, 'Name of the Owner/ Manager of the Amusement Park');
	        array_push($header, 'Mobile Number');
	        array_push($header, 'Email Id of the Owner/ Manager of the Amusement Park');
			array_push($header, 'Number of Permanent Employees- Males');
	        array_push($header, 'Number of Permanent Employees- Females');
	        array_push($header, 'Number of Outsourced Employees- Males');
	        array_push($header, 'Number of Outsourced Employees- Females');
	        array_push($header, 'Licence Number');
	        array_push($header, 'Licence Issue Date');
        }
        if($query)
        {
            $raw_data=array();
            $result = $this->db->get();            
            $raw_data= $result->result();
			// print_r($this->db->last_query());	
			// die(); 
			$curr = date('d-m-Y');
            $filename = "Reports_".$curr.".xlsx";
            $fp = fopen('php://output', 'w');
            ob_start(); ob_end_flush();ob_end_clean();
            header('Content-type: application/csv');
            header('Content-Disposition: attachment; filename='.$filename);
            fputcsv($fp, $header);
            $jsonencode = json_encode($raw_data, true);
            $jsonDecoded = json_decode($jsonencode, true);

            foreach($jsonDecoded as $row)
            {
            	if($data['prod_id']<=3 || $data['prod_id']>6)
            	{
            		$appidd = "DOT".$row['code']."/".$row['category_name']."/00000".$row['acg_id'];
			$addree = $row['org_add1'].$row['org_add2'];

	            	$fet['application_id']=$appidd;    
	                $fet['productname']=$row['productname'];    
	                $fet['orgtype']=$row['organizationType'];
	                $fet['orgstartdate']=$row['org_commencement_date'];
	                $fet['governmentapproval']=$row['central_gov_approved'];
	                $fet['orgname']=$row['org_name'];
	                $fet['gstnumber']=$row['gst_number'];
	                $fet['pannumber']=$row['pan_number'];
	                $fet['websitename']=$row['website_name'];
	                $fet['officialemail']=$row['official_email'];
	                $fet['tradedetail']=$row['member_recognised_trade'];
	                $fet['orgaddress']=$addree;
	                $fet['districtname']=$row['districtname'];
	                $fet['statename']=$row['StateName'];
	                $fet['orgcountryname']=$row['countryname'];
					$fet['pincode']=$row['org_pincode_id'];
					$fet['orgmobile']=$row['org_mobile'];
					$fet['telephone']=$row['org_telephone'];
					$fet['buildingsqt']=$row['org_total_build_sqft'];
					$fet['membership']=$row['off_prog_arranged_foreign_tourist'];
					$fet['tourist']=$row['off_prog_arranged_foreign_tourist'];
					$fet['licnese_issuedate']=$row['licence_issued_date'];
					$fet['licnese_no']=$row['licence_no'];
				}
				if($data['prod_id']==4)
            	{
            		$appidd = "DOT".$row['code']."/".$row['category_name']."/00000".$row['acg_id'];
			$addree = $row['org_add1'].$row['org_add2'];

	            	$fet['application_id']=$appidd;
					$fet['category_type']=$row['category_type'];
					$fet['applicant_name']=$row['applicant_name'];
					$fet['legal_name']=$row['legal_name']    ;    	        	
					$fet['productname']=$row['productname'];
					$fet['organizationType']=$row['organizationType'];
					$fet['org_commencement_date']=$row['org_commencement_date'];
					$fet['trade_lic_date']=$row['trade_lic_date'];
					$fet['org_name']=$row['org_name'];
					$fet['gst_number']=$row['gst_number'];
					$fet['pan_number']=$row['pan_number'];
					$fet['website_name']=$row['website_name'];
					$fet['official_email']=$row['official_email'];	        
					$fet['member_kts']=$row['member_kts']	;	
					$fet['member_recognised_trade']=$row['member_recognised_trade']	;
					$fet['org_add1']=$addree;      
					$fet['districtname']=$row['districtname'];
					$fet['StateName']=$row['StateName'];
					$fet['org_pincode_id']=$row['org_pincode_id'];
					$fet['org_mobile']=$row['org_mobile'];
					$fet['org_telephone']=$row['org_telephone'];
					$fet['org_total_build_sqft']=$row['org_total_build_sqft'];
					$fet['name_restaurant']=$row['name_restaurant'];
					$fet['restaurant_type']=$row['restaurant_type'];
					$fet['owner_name']=$row['owner_name'];
					$fet['no_rooms']=$row['no_rooms'];
					$fet['no_bed']=$row['no_bed'];
					$fet['accommodation']=$row['accommodation'];
					$fet['other_facility']=$row['other_facility'];
					$fet['owner_mobile']=$row['owner_mobile'];
					$fet['owner_email']=$row['owner_email'];
					$fet['permanent_emp_male']=$row['permanent_emp_male'];
					$fet['permanent_emp_female']=$row['permanent_emp_female'];
					$fet['outsourced_emp_male']=$row['outsourced_emp_male'];
					$fet['outsourced_emp_female']=$row['outsourced_emp_female'];
					$fet['licence_issued_date']=$row['licence_issued_date'];
					$fet['licence_no']=$row['licence_no'];
				}
				if($data['prod_id']==5)
            	{
            		$appidd = "DOT".$row['code']."/".$row['category_name']."/00000".$row['acg_id'];
			$addree = $row['org_add1'].$row['org_add2'];

	            	$fet['application_id']=$appidd;					
					$fet['applicant_name']=$row['applicant_name'];
					$fet['legal_name']=$row['legal_name']    ;    	        	
					$fet['productname']=$row['productname'];
					$fet['organizationType']=$row['organizationType'];
					$fet['org_commencement_date']=$row['org_commencement_date'];
					// $fet['trade_lic_date']=$row['trade_lic_date'];
					$fet['org_name']=$row['org_name'];
					$fet['gst_number']=$row['gst_number'];
					$fet['pan_number']=$row['pan_number'];
					$fet['website_name']=$row['website_name'];
					$fet['official_email']=$row['official_email'];	        
					$fet['member_kts']=$row['member_kts']	;	
				$fet['member_recognised_trade']=$row['member_recognised_trade']	;
					$fet['org_add1']=$addree;      
					$fet['districtname']=$row['districtname'];
					$fet['StateName']=$row['StateName'];
					$fet['org_pincode_id']=$row['org_pincode_id'];
					$fet['org_mobile']=$row['org_mobile'];
					$fet['org_telephone']=$row['org_telephone'];
					$fet['org_total_build_sqft']=$row['org_total_build_sqft'];
					$fet['name_restaurant']=$row['name_restaurant'];
					$fet['restaurant_type']=$row['restaurant_type'];
					$fet['category_type']=$row['category_type'];
					$fet['org_registration_date']=$row['org_registration_date'];
					$fet['no_beds']=$row['no_beds'];
					$fet['total_hotel_build_area']=$row['total_hotel_build_area'];
					$fet['hotel_resort']=$row['hotel_resort'];
					$fet['hotel_mbl_no']=$row['hotel_mbl_no'];
					$fet['email_id_hotel']=$row['email_id_hotel'];
					$fet['ownername']=$row['ownername'];
					$fet['mobileNo']=$row['mobileNo'];
					$fet['owner_email']=$row['owner_email'];
					$fet['permanent_emp_male']=$row['permanent_emp_male'];
					$fet['permanent_emp_female']=$row['permanent_emp_female'];
					$fet['outsourced_emp_male']=$row['outsourced_emp_male'];
					$fet['outsourced_emp_female']=$row['outsourced_emp_female'];
					$fet['licence_issued_date']=$row['licence_issued_date'];
					$fet['licence_no']=$row['licence_no'];
				}
				if($data['prod_id']==6)
            	{
            		$appidd = "DOT".$row['code']."/".$row['category_name']."/00000".$row['acg_id'];
			$addree = $row['org_add1'].$row['org_add2'];

	            	$fet['application_id']=$appidd;
					$fet['category_type']=$row['category_type'];
					$fet['applicant_name']=$row['applicant_name'];
					$fet['legal_name']=$row['legal_name']    ;    	        	
					$fet['productname']=$row['productname'];
					$fet['organizationType']=$row['organizationType'];
					$fet['org_commencement_date']=$row['org_commencement_date'];
					$fet['trade_lic_date']=$row['trade_lic_date'];
					$fet['org_name']=$row['org_name'];
					$fet['gst_number']=$row['gst_number'];
					$fet['pan_number']=$row['pan_number'];
					$fet['website_name']=$row['website_name'];
					$fet['official_email']=$row['official_email'];	        
					$fet['member_kts']=$row['member_kts']	;
					$fet['org_add1']=$addree;      
					$fet['districtname']=$row['districtname'];
					$fet['StateName']=$row['StateName'];
					$fet['org_pincode_id']=$row['org_pincode_id'];
					$fet['org_mobile']=$row['org_mobile'];
					$fet['org_telephone']=$row['org_telephone'];
					$fet['org_total_build_sqft']=$row['org_total_build_sqft'];
					$fet['hotel_name']=$row['hotel_name'];
					$fet['amusement_commencement_date']=$row['amusement_commencement_date'];
					$fet['org_registration_date']=$row['org_registration_date'];
					$fet['visitor_capacity']=$row['visitor_capacity'];
					$fet['total_hotel_build_area']=$row['total_hotel_build_area'];
					$fet['accommodation']=$row['accommodation'];
					// $fet['accommodation_type']=$row['accommodation_type'];
					$fet['restaurant_type']=$row['restaurant_type'];
					$fet['owner_name']=$row['owner_name'];
					$fet['owner_mobile']=$row['owner_mobile'];
					$fet['owner_email']=$row['owner_email'];
					// $fet['other_facility']=$row['other_facility'];
					$fet['permanent_emp_male']=$row['permanent_emp_male'];
					$fet['permanent_emp_female']=$row['permanent_emp_female'];
					$fet['outsourced_emp_male']=$row['outsourced_emp_male'];
					$fet['outsourced_emp_female']=$row['outsourced_emp_female'];
					$fet['licence_issued_date']=$row['licence_issued_date'];
					$fet['licence_no']=$row['licence_no'];
				}
                fputcsv($fp, $fet);
            }  
        }
    }
/*	function getPaymentDetails($appID, $renwalNO){

		$this->db->select('app.id');
		$this->db->from('application app');
		$this->db->join('payment py', 'py. = app.stage_id','INNER');

	}*/
	function getsave_draft($appID,$desid){
		$this->db->select("ad.*");
		$this->db->from('application_doc_verification ad');
		$this->db->where('ad.application_id',$appID);
		$this->db->where('ad.desc_id',$desid);
		$this->db->where('ad.isdraft',1);
		$this->db->order_by('ad.id', 'desc');
		$this->db->limit(1);
		$result = $this->db->get()->result();
		return $result[0];
	}

	function getreturnfor($appID,$desid){
		// print_r($appID);
		// print_r($desid);
		$this->db->select("ad.*");
		$this->db->from('application_doc_verification ad');
		$this->db->where('ad.application_id',$appID);
		$this->db->where('ad.desc_id',$desid);
		$this->db->where('ad.isactive',1);
		$this->db->order_by('ad.id', 'desc');
		$this->db->limit(1);
		$result = $this->db->get()->result();
		// print_r($this->db->last_query());
		return $result[0];
	}

}
