<?php
class M_location extends CI_Model{

	function getListLocation($tbl,$where = NULL){
		
		$this->db->select('id,name');
		$this->db->from($tbl);

		if($where){
			$this->db->where('isactive','1');
		}

		$result = $this->db->get();
		$result = $result->result();


		$locDetail[''] = '';

		foreach ($result as $org) {
			$locDetail[$org->id] = $org->name;
		}

		return $locDetail;
	}
}