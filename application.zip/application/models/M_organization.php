<?php
class M_organization extends CI_Model{
  	protected $_table_name	= 'application';
	protected $_primary_key = 'id';

	function getListOrgType($where = NULL){
		
		$this->db->select('id,name orgtpe');
		$this->db->from('m_organization_nature');

		if($where){
			$this->db->where('isactive','1');
		}

		$result = $this->db->get();
		$result = $result->result();

		$orgDetail[''] = '';

		foreach ($result as $org) {
			$orgDetail[$org->id] = $org->orgtpe;
		}

		return $orgDetail;
	}
}