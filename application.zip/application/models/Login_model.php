<?php
class Login_model extends CI_Model{

  function validate($usrname,$usrpswd){
    $this->db->where('usrname',$usrname);
    $this->db->where('usrpassword',$usrpswd);
    $result = $this->db->get('admin');
    return $result;
  }

}
