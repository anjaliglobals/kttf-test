<?php
class M_masters extends CI_Model{

    function product(){

    $result = $this->db->get('m_product');
    return $result;
  }

    function getUserLogs(){	
		$this->db->query("SET @cnt := 0");
		$this->db->select("(@cnt := @cnt + 1) AS slno, lg.activity, lg.details, lg.crtdate, lg.ip_address, ad.usrname");
		$this->db->from('log lg');
		$this->db->join('admin ad','ad.id = lg.crtby','INNER');
		$this->db->order_by("lg.id", "DESC"); 

		$result = $this->db->get();
		$result = $result->result();

		return $result;
    }
		
	function prod_agree($tbl,array $where = NULL){		
		$this->db->select('*');
		$this->db->from($tbl);

		if($where){
			$this->db->where($where);
		}

		$result = $this->db->get();
		$result = $result->result();

		return $result;
	}

}
