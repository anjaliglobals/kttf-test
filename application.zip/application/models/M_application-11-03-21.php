<?php
class M_application extends CI_Model{
  	protected $_table_name	= 'application';
	protected $_primary_key = 'id';
	protected $_primary_filter = 'intval';
	protected $_order_by 	= 'id';
	public 	  $_rules 		= array ();
	protected $_timestamps 	= false;


	function getPendingApplication($data){

		// print_r($data);
		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 0);

		// if($this->admDesig)
		// 	$where['ms.desig_id'] =$this->admDesig;
		// if($this->admDesig!=1 )		
		// 	$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
		// else
		// 	$where['app.district_id'] = $this->admDistrict;
		// if($this->admDistrict)
		// 	$where['app.district_id'] = $this->admDistrict;	

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['app.district_id'] = $this->admDistrict;	
		}	

		$this->db->select("app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,'%d-%m-%Y') confirmed_date, md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, atl.timeline,
			CASE  WHEN app.is_payment_approved = 1 && app.payment_id IS NULL THEN 'Waiting For Payment' 
			WHEN app.stg_send_back_date IS NOT NULL && app.stg_send_back_submit_date IS NULL THEN '<span style=color:#b73425;font-weight:600>Resent For Verification</span>' ELSE wf.flow_name  END appStatus,ABS(datediff(app.crtdate,now()))'diff',
			if(ABS(datediff(app.crtdate,now())) <= atl.timeline,ABS(datediff(app.crtdate,now())), '') as appro_timeline,
			if(ABS(datediff(app.crtdate,now())) <= atl.timeline,'Y', 'N') as status",false);
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->join('approval_timeline atl', 'app.app_status=atl.app_status_id','left');	
		$this->db->where($where);
		if($this->admDesig!=1)
			$this->db->where('ms.desig_id in (1,2,3)');
		else
			$this->db->where('ms.desig_id',$this->admDesig);	
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');

		$result = $this->db->get();
		$result = $result->result();
		//print_r($this->db->last_query());
		// die();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->appStatus,
								'status'	 => $res->status,
								'Timeline'   => $res->diff,
						'originalTimeline'   => $res->timeline,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id

							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}

	function getAppInfo($appID){
		// echo $appID;
		// die();
		$where = array('app.is_confirmed' => '1',
				'app.id' => $appID
				);
		

		$this->db->select('app.*');
		$this->db->from('application app');
		$this->db->where($where);

		$result = $this->db->get();
		$result = $result->result();
		// print_r($this->db->last_query());

		return $result;
	}

	function getUserApplications($usrID)
	{
		$count = 0;
		$this->db->query("SET @cnt := 0");
//		$this->db->select('(@cnt := @cnt + 1) AS slno,app.id  appID, app.application_id, mp.name productName, app.org_name orgName, app.confirmed_date, IF(is_confirmed = 1 , ms.order_stage , "Application not submited") appStatus');

		$this->db->select("(@cnt := @cnt + 1) AS slno,app.id  appID, app.application_id, mp.name productName, app.applicant_name orgName, DATE_FORMAT(app.confirmed_date, '%d-%m-%Y') confirmed_date, 
CASE 
	WHEN app.status_code = 1 THEN '<span style=color:Red>Application Rejected</span>'
	WHEN app.status_code = 2 THEN '<span style=color:Red>Application Closed</span>'
	WHEN app.is_payment_approved = 1 && app.status_code = 0 && app.payment_id IS NULL THEN '<span style=color:blue;font-weight:600>Make payment</span>'
	WHEN app.licence_no IS NOT NULL && app.status_code = 0 THEN '<span style=color:#0f6105;font-weight:600>Licence Certificate Issued and Closed.</span>'
	WHEN app.is_confirmed = '0' && app.status_code = 0 THEN '<span style=color:#bc5f05;font-weight:600>Application Fee Pending</span>'
	ELSE wf.flow_name 
END appStatus",false);
		$this->db->from('application app');
		$this->db->join('usr_register ureg','app.register_id = ureg.id');
		$this->db->join('m_product mp','app.product_id = mp.id');
		$this->db->join('m_stage ms','app.stage_id = ms.order_stage');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->where('ureg.id',$usrID);
		$this->db->order_by("confirmed_date", "DESC"); 

		$result = $this->db->get();
		$result = $result->result();
//echo $this->db->last_query();

		return $result;

	}
	
	function getAppComments($appID,$renwalNO='0'){
		$this->db->select("ac.subject, ac.cons_comm ,ac.inter_comm, DATE_FORMAT(ac.crtdate, '%d-%m-%Y %h:%i:%s') crtdate, wf.flow_name, md.designation_name");
		$this->db->from('application_comment ac');
		$this->db->join('m_stage ms', 'ms.work_flow_id = ac.app_stage','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation md', 'md.id = ms.desig_id','INNER');
		$this->db->where('ac.application_id',$appID);
		$this->db->where('ac.licence_renewal_no',$renwalNO);
		$this->db->order_by("ac.id", "DESC"); 

		$result = $this->db->get()->result();

		return $result;
	}

	function adminDashboardInfo(){

//-------pending application
		$pendWhere = array('app.is_confirmed' => '1',
					   	   'app.status_code'  => 0,
						);

		if($this->admDesig==1)
		{
			if($this->admDesig)	
				$pendWhere['ms.desig_id'] = $this->admDesig;
			if($this->admDistrict)
				$pendWhere['app.district_id'] = $this->admDistrict;
		}
		

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		if($pendWhere)
			$this->db->where($pendWhere);

		$penResult = $this->db->get()->result();
		$appPending = $penResult[0]->total;
		//print_r($this->db->last_query());

//-------closed application
		$closedWhere = array('app.is_confirmed' => '1',
					   	     'app.status_code'  => 2
						);
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$closedWhere['app.district_id'] = $this->admDistrict;
		}
		

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($closedWhere))
			$this->db->where($closedWhere);

		$appClResult = $this->db->get()->result();
		$appClosed 	 = $appClResult[0]->total;

//---------------Total Received

		$totWhere = array('app.is_confirmed' => '1'
						);
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$totWhere['app.district_id'] = $this->admDistrict;	
		}
		
		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($totWhere))
			$this->db->where($totWhere);

		$totResult = $this->db->get()->result();
		$appTotal  = $totResult[0]->total;
		//print_r($this->db->last_query());

//---------------Rejected App
		$rejWhere = array('app.is_confirmed' => '1',
					   	   'app.status_code'  => 1
						);
		
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$rejWhere['app.district_id'] = $this->admDistrict;
		}

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($rejWhere))
			$this->db->where($rejWhere);

		$rejResult    = $this->db->get()->result();
		$appRejected  = $rejResult[0]->total;	

//---------------Total Payed
		$payWhere = array('app.is_confirmed' => '1',
						  'app.payment_id IS NOT NULL'
						);
		if($this->admDesig==1)
		{
			if($this->admDistrict)
			$payWhere['app.district_id'] = $this->admDistrict;
		}

		$this->db->select('count(app.id) total');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		if(!empty($payWhere))
			$this->db->where($payWhere);

		$payResult = $this->db->get()->result();
		//print_r($this->db->last_query());
		$appPayed  = $payResult[0]->total;		

		$dashResult = array('appPending'=> $appPending,
							'appClosed'	=> $appClosed,
							'appTotal'	=> $appTotal,
							'appRejected'=> $appRejected,
							'appPayed'	=> $appPayed,
							); 		
		return $dashResult;
	}

	
	function getAppDocVerify($appID,$renwalNO){
		$this->db->select("ad.*");
		$this->db->from('application_doc_verification ad');
		$this->db->where('ad.application_id',$appID);
		$this->db->where('ad.licence_renewal_no',$renwalNO);
		$this->db->order_by('ad.crtdate', 'desc');
		$this->db->limit(1);
		$result = $this->db->get()->result();
		return $result[0];
	}


	function getSummaryApplication($data)
	{

		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 0);

		if($this->admDesig)
			$where['ms.desig_id !='] = $this->admDesig;

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDistrict!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;
			else 
				$where['app.district_id'] = $this->admDistrict;	
		}
		
		$this->db->select('app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,"%d-%m-%Y") confirmed_date, md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, wf.flow_name');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where($where);
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');
		
		$result = $this->db->get();
		//print_r($this->db->last_query());
		// die();
		$result = $result->result();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->flow_name,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}


	function getClosedApplication($data){

		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 2);	

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['app.district_id'] = $this->admDistrict;	
		}
		
		$this->db->select('app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,"%d-%m-%Y") confirmed_date , md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, wf.flow_name');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where($where);
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');

		$result = $this->db->get();
		$result = $result->result();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->flow_name,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}



	function getRejectedApplication($data)
	{

		$where = array('app.is_confirmed' => '1',
			       'app.status_code'  => 1);

		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['app.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['app.district_id'] = $this->admDistrict;	
		}

		$this->db->select('app.id, app.applicant_name, app.application_id, DATE_FORMAT(app.confirmed_date,"%d-%m-%Y") confirmed_date, md.name distName, ms.stage_description, ms.approval_day_limit, mdes.designation_name, wf.flow_name');
		$this->db->from('application app');
		$this->db->join('m_stage ms', 'ms.order_stage = app.stage_id','INNER');
		$this->db->join('m_work_flow wf', 'wf.id = ms.work_flow_id','INNER');
		$this->db->join('m_designation mdes', 'mdes.id = ms.desig_id','INNER');
		$this->db->join('m_district md', 'md.id = app.district_id','INNER');
		$this->db->where($where);
		if($data['prod_id']!='')
			$this->db->where('app.product_id ="'.$data['prod_id'].'"');

		$result = $this->db->get();
		//print_r($this->db->last_query());
		$result = $result->result();

		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'appNumber'	 => $res->application_id,
								'appName' 	 => $res->applicant_name,
								'appDesgName' => $res->designation_name,
								'appDisName' => $res->distName,
								'appPenDays' => $res->approval_day_limit,
								'appStgDesc' => $res->flow_name,
								'appConfDate'=> $res->confirmed_date,
								'appID'		 => $res->id
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}
	function getreportData($data)
	{
		$fromdate = strtotime($data['fdate']);
		$newfdate = date('Y-m-d',$fromdate);
		$todate = strtotime($data['tdate']);
		$newtdate = date('Y-m-d',$todate);

		$where = array('a.is_confirmed' => '1');
		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['a.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['a.district_id'] = $this->admDistrict;
		}

		//Record mismatching while we use inner join that's y we used left join 

		$this->db->select('a.id,a.application_id,a.product_id,p.name as productname,a.org_name,a.org_type_id,o.name as organizationType,
			DATE_FORMAT(a.org_commencement_date,"%d-%m-%Y") as org_commencement_date,a.gst_number,a.pan_number,a.website_name,a.official_email,a.associate_firm,a.member_recognised_trade,a.org_add1,a.org_country,c.name as countryname ,a.org_state,s.name as StateName,a.org_district_id,d.name as districtname,a.org_pincode_id,a.org_mobile,a.org_telephone,a.org_total_build_sqft,a.off_international_membership,a.off_prog_arranged_foreign_tourist,a.register_id,a.confirmed_date,a.stage_id,ms.stage_description,a.licence_no,a.licence_issued_date,a.central_gov_approved');
		$this->db->from('application a');
		$this->db->join('m_organization_nature o','o.id=a.org_type_id','left');
		$this->db->join('m_product p', 'p.id=a.product_id','left');
		$this->db->join('m_district d', 'd.id=a.district_id','left');
		$this->db->join('m_states s', 's.id=a.org_state','left');
		$this->db->join('m_countries c', 'c.id=a.org_country','left');
		$this->db->join('m_stage ms', 'ms.id=a.stage_id','left');		
		$this->db->where('date(a.confirmed_date) BETWEEN "'. $newfdate. '" and "'. $newtdate.'"');
		$this->db->where($where);
		if($data['prod_id']!='')
			$this->db->where('a.product_id ="'.$data['prod_id'].'"');
		if($data['status_id']!='')
			$this->db->where('a.status_code ="'.$data['status_id'].'"');

		$result = $this->db->get();
		//print_r($this->db->last_query());	
		$result = $result->result();
		$count = 0;
		$appDetails = array();

		foreach ($result as $res) {
			$application = array(
								'slno'		 =>	++$count,
								'id'	 =>$res->id,
								'application_id'=>$res->application_id,
								'productname'=> $res->productname,
								'orgtype' 	 => $res->organizationType,
								'orgstartdate' => $res->org_commencement_date,
								'governmentapproval'=>$res->central_gov_approved,
								'orgname' => $res->org_name,
								'gstnumber' => $res->gst_number,
								'pannumber' => $res->pan_number,
								'websitename'=> $res->website_name,
								'officialemail'=> $res->official_email,
								'tradedetail'=> $res->member_recognised_trade,
								'orgaddress'=> $res->org_add1,
								'districtname'=> $res->districtname,
								'statename'=> $res->StateName,
								'orgcountryname'=> $res->countryname,
								'pincode'=> $res->org_pincode_id,
								'orgmobile'=> $res->org_mobile,
								'telephone'=> $res->org_telephone,
								'buildingsqt'=> $res->org_total_build_sqft,
								'membership'=> $res->off_international_membership,
								'tourist'=> $res->off_prog_arranged_foreign_tourist,
								'licnese_issuedate'=>$res->licence_issued_date,
								'licnese_no'=>$res->licence_no
							);
			$appDetails[] = $application;
		}

		return $appDetails;
	}
	function getExportData($data)
    {
        $fromdate = strtotime($data['fdate']);
		$newfdate = date('Y-m-d',$fromdate);
		$todate = strtotime($data['tdate']);
		$newtdate = date('Y-m-d',$todate);


		$where = array('a.is_confirmed' => '1');
		if($this->admDistrict!=null || $data['dist_id']!='')
		{
			if($this->admDesig!=1 )		
				$where['a.district_id'] =($data['dist_id']!='' ? $data['dist_id'] : $this->admDistrict) ;			
			else
				$where['a.district_id'] = $this->admDistrict;
		}		

		$query=$this->db->select('a.application_id,a.product_id,p.name as productname,a.org_name,a.org_type_id,o.name as organizationType,
			DATE_FORMAT(a.org_commencement_date,"%d-%m-%Y") as org_commencement_date,a.gst_number,a.pan_number,a.website_name,a.official_email,a.associate_firm,a.member_recognised_trade,a.org_add1,a.org_country,c.name as countryname ,a.org_state,s.name as StateName,a.org_district_id,d.name as districtname,a.org_pincode_id,a.org_mobile,a.org_telephone,a.org_total_build_sqft,a.off_international_membership,a.off_prog_arranged_foreign_tourist,a.register_id,a.confirmed_date,a.stage_id,ms.stage_description,a.licence_no,a.licence_issued_date,a.central_gov_approved');
		$this->db->from('application a');
		$this->db->join('m_organization_nature o','o.id=a.org_type_id','left');
		$this->db->join('m_product p', 'p.id=a.product_id','left');
		$this->db->join('m_district d', 'd.id=a.district_id','left');
		$this->db->join('m_states s', 's.id=a.org_state','left');
		$this->db->join('m_countries c', 'c.id=a.org_country','left');
		$this->db->join('m_stage ms', 'ms.id=a.stage_id','left');		
		$this->db->where('date(a.confirmed_date) BETWEEN "'. $newfdate. '" and "'. $newtdate.'"');
		$this->db->where($where);
		if($data['prod_id']!='')
			$this->db->where('a.product_id ="'.$data['prod_id'].'"');
		if($data['status_id']!='')
			$this->db->where('a.status_code ="'.$data['status_id'].'"');

        $header = array();
        
        array_push($header, 'Application Id');
        array_push($header, 'Product Name');
        array_push($header, 'Organisation Type');
        array_push($header, 'Date of Register');        
        array_push($header, 'Register under Ministry'); 
        array_push($header, 'Name of proprietor'); 
        array_push($header, 'GST'); 
        array_push($header, 'PAN'); 
        array_push($header, 'Website URL'); 
        array_push($header, 'Email Id'); 
        array_push($header, 'Trade Body'); 
        array_push($header, 'Address'); 
        array_push($header, 'District'); 
        array_push($header, 'City'); 
        array_push($header, 'Pincode'); 
        array_push($header, 'Mobile Number'); 
        array_push($header, 'Telephone Number'); 
        array_push($header, 'Build Area(sq.ft)');
        array_push($header, 'International Membership');
        array_push($header, 'Arrange Foreign Traders');
        array_push($header, 'Licence Number');
        array_push($header, 'Licence Issue Date');
        
        if($query)
        {
            $raw_data=array();
            $result = $this->db->get();            
            $raw_data= $result->result();
			// print_r($this->db->last_query());	
			// die(); 
            $filename = "Report.xls";
            $fp = fopen('php://output', 'w');
            ob_start(); ob_end_flush();ob_end_clean();
            header('Content-type: application/csv');
            header('Content-Disposition: attachment; filename='.$filename);           
            fputcsv($fp, $header);
            $jsonencode = json_encode($raw_data, true);
            $jsonDecoded = json_decode($jsonencode, true);

            foreach($jsonDecoded as $row)
            {
            	$fet['application_id']=$row['application_id'];    
                $fet['productname']=$row['productname'];    
                $fet['orgtype']=$row['organizationType'];
                $fet['orgstartdate']=$row['org_commencement_date'];
                $fet['governmentapproval']=$row['central_gov_approved'];
                $fet['orgname']=$row['org_name'];
                $fet['gstnumber']=$row['gst_number'];
                $fet['pannumber']=$row['pan_number'];
                $fet['websitename']=$row['website_name'];
                $fet['officialemail']=$row['official_email'];
                $fet['tradedetail']=$row['member_recognised_trade'];
                $fet['orgaddress']=$row['org_add1'];
                $fet['districtname']=$row['districtname'];
                $fet['statename']=$row['StateName'];
                $fet['orgcountryname']=$row['countryname'];
				$fet['pincode']=$row['org_pincode_id'];
				$fet['orgmobile']=$row['org_mobile'];
				$fet['telephone']=$row['org_telephone'];
				$fet['buildingsqt']=$row['org_total_build_sqft'];
				$fet['membership']=$row['off_prog_arranged_foreign_tourist'];
				$fet['tourist']=$row['off_prog_arranged_foreign_tourist'];
				$fet['licnese_issuedate']=$row['licence_issued_date'];
				$fet['licnese_no']=$row['licence_no'];
                fputcsv($fp, $fet);
            }  
        }
    }
/*	function getPaymentDetails($appID, $renwalNO){

		$this->db->select('app.id');
		$this->db->from('application app');
		$this->db->join('payment py', 'py. = app.stage_id','INNER');

	}*/
}
