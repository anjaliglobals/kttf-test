<?php
class M_user extends CI_Model{

  function validate($usrname,$usrpswd){
    $this->db->where('usremail',$usrname);
    $this->db->where('usrpassword',$usrpswd);
    $result = $this->db->get('usr_register');
    return $result;
  }

    function validatereg($usremail){
    $this->db->where('usremail',$usremail);
    $result = $this->db->get('usr_register');
    return $result;
  }
 //cd
  function verifyApprovalForPayment($appID){
    $count = 0;
    $this->db->query('SET @cnt := 0');
    $where = array('app.is_payment_approved' => '1',
            'app.id' => $appID, 'app.payment_id' => NULL
             );
    $this->db->select('(@cnt := @cnt + 1) AS slno');
    $this->db->from('application app');
    $this->db->where($where);

    $result = $this->db->get();
    $result = $result->result();
    return $result;

  }

  function verifyAfterPayment(){
    $this->db->query("select payment_id from application where id =".$appID." and payment_id != NULL");
    $result = $this->db->get();
    $result = $result->result();
    return $result;
  }

}
