<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Applications extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->helper('url');
  
    if($this->session->userdata('usrlogged_in') !== TRUE)
    {
      redirect('login');
    }
    $this->load->model('M_user','_user');

    $this->usrID = $this->session->userdata('usrID');
    $this->usrName = $this->session->userdata('usrName');

    $this->load->model('M_user','_user');
    $this->load->model('M_application','_application');
    $this->load->model('M_masters','_masters');
  }

  function index(){
    
  if($this->session->userdata('usrlogged_in') !== TRUE){
      redirect('login');
    }
  
    $data['menu'] = 'Application';

    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                             'user/js/script.js',
                             'admin/js/dataTables.min.js'
                                );

    //$data['callback_url']       = base_url().'applications/callback_app';
    $data['callback_urlnew']       = base_url().'applications/callback_appnew';
        $data['surl']               = base_url().'applications/success_app';
        $data['furl']               = base_url().'applications/failed_app';
        $data['currency_code']      = 'INR';
        $appid = $this->uri->segment(3);

        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
        $data['appdetails']   = $appdet;
        
        $this->load->view('user/application',$data);
  }

  function application_edit()
  {
       if($this->session->userdata('usrlogged_in') !== TRUE)
       {
          redirect('login');
       }
       $appid = $this->uri->segment(3);

       $sesdataa = array(
              'app_id'       => $appid,
          );
 
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
           //print_r($appdet);
        $data['menu'] = 'Application';
        $data['appdetails']   = $appdet;

        $data['arr_css'] = array('user/css/bootstrap.min.css',
                                 'user/css/style.css',
                                 'user/css/application.css',
                                );

        $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                                 'user/js/application.js',
                                    );


        $this->load->view('user/application_edit',$data);
  }

  function notification()
  {
           if($this->session->userdata('usrlogged_in') !== TRUE)
           {
              redirect('login');
           }
          //echo $this->usrID;
          $data['menu'] = 'Application';
          // print_r( $data['appdetails']);
          $data['arr_css'] = array('user/css/bootstrap.min.css',
                                   'user/css/style.css',
                                   'user/css/application.css',
                                  );
          $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                                   'user/js/application.js',
                                   'admin/js/dataTables.min.js'
                                  );
           $this->db->group_by('application_id');
           $this->db->order_by('id','desc');
           $this->db->query("SET sql_mode=(SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''));");
           $notifi_det = $this->db->get_where('application_notification', array('register_id'=>$this->usrID))->result();
           $data['note_det'] = $notifi_det;

          $this->load->view('user/notification',$data);
  }


  function application_view()
  {
       if($this->session->userdata('usrlogged_in') !== TRUE)
       {
        redirect('login');
       }
    
        $appid = $this->uri->segment(3);

        $sesdataa = array(
            'app_id'       => $appid,
        );
        $this->session->set_userdata($sesdataa);


       //echo $appid;
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
        $addressdet = $this->db->get_where('other_offices' , array('application_id'=>$appid))->result(); 
        $hotelfacility = $this->db->get_where('hotel_facility' , array('app_id'=>$appid))->result(); 
        $hotel_accomodation=$this->db->get_where('hotel_accommodation' , array('app_id'=>$appid))->result();
        // print_r( $hotel_accomodation);
        // print_r($appdet);
        // echo "test123";
        // print_r();
        $data['addressdet']   = $addressdet;
        $data['menu'] = 'Application';
        $data['appdetails']   = $appdet;
        $data['hotelaccomodation']=$hotel_accomodation;
        $data['hotelfacility']=$hotelfacility;
        
        // print_r( $data['appdetails']);
        $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

        $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                             'admin/js/dataTables.min.js'
                                );

        // $query_new=$this->db->query("call resend_data (".$appid.")");                 
        // $appverified_data = $query_new->result();
        // $data['appverifieddata']   = $appverified_data;

       if($appdet[0]->is_payment_approved == '1' && $appdet[0]->payment_id == '' && $appdet[0]->status_code == 0): 
             redirect('applications/application_payments/'.$appid);
       endif;
        if($appdet[0]->product_id==1 || $appdet[0]->product_id==2 || $appdet[0]->product_id==3)
            $this->load->view('user/application_view',$data);
        if($appdet[0]->product_id==4)
            $this->load->view('user/application_view_hotel',$data);
        if($appdet[0]->product_id==5)
            $this->load->view('user/application_view_restaurant',$data);
        if($appdet[0]->product_id==6)
            $this->load->view('user/application_view_amusement',$data);
        if($appdet[0]->product_id==7)
            $this->load->view('user/application_view_guest',$data);
        if($appdet[0]->product_id==8)
            $this->load->view('user/application_view_homestay',$data);
  }


  function application_noti_view()
  {
         if($this->session->userdata('usrlogged_in') !== TRUE)
         {
            redirect('login');
         }
         $appid = $this->uri->segment(3);
         $sesdataa = array(
              'app_id'       => $appid,
          );
          $this->session->set_userdata($sesdataa);
          //echo $appid;
          $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
          //print_r($appdet);
          $notiInfo = array(
                  'status'    => '1',
                  'statusviewed_date'    => date('Y-m-d H:i:s')
          );
         $this->db->where('application_id',$appid);
         $upstatusa = $this->db->update('application_notification',$notiInfo);
          $appnot_det = $this->db->get_where('application_notification' , array('application_id'=>$appid))->result();
          //echo $this->db->last_query();
          //print_r($appnot_det);
          //print_r($addressdet);
          $data['appnot_det']   = $appnot_det;
          $data['menu'] = 'Application';
          $data['appdetails']   = $appdet;
          // print_r( $data['appdetails']);
          $data['arr_css'] = array('user/css/bootstrap.min.css',
                                   'user/css/style.css',
                                   'user/css/application.css',
                                  );

          $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                                   'user/js/application.js',
                                      );
          $this->load->view('user/application_view',$data);
  }

  function certificate()
  {
        if($this->session->userdata('usrlogged_in') !== TRUE)
        {
           redirect('login');
        }
        $appid = $this->uri->segment(3);
        $sesdataa = array(
                  'app_id'       => $appid,
              );
        $this->session->set_userdata($sesdataa);

       //echo $appid;
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
        $data['menu'] = 'Certificate';
        $data['appdetails']   = $appdet;
  
        $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

        $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
               'user/js/multislider.js',
               'user/js/bootstrap.4.4.1.min.js');
        $this->load->view('user/certificate',$data);
  }


 function pay_acg()
  {
        if($this->session->userdata('usrlogged_in') !== TRUE)
        {
           redirect('login');
        }
        $appid = $this->uri->segment(3);
        $sesdataa = array(
                  'app_id'       => $appid,
              );
        $this->session->set_userdata($sesdataa);

       //echo $appid;
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();


        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $appdet_pay = $this->db->get_where('app_payment_new' , array('appid'=>$appid))->result();

        
        $data['menu'] = 'Payment Acknowledgement';
        $data['appdetails']   = $appdet;
        $data['appdet_pay']   = $appdet_pay;
  
        $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

        $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
               'user/js/multislider.js',
               'user/js/bootstrap.4.4.1.min.js');
        $this->load->view('user/pay_acg',$data);
  }


  //cd
function application_payments()
{
      if($this->session->userdata('usrlogged_in') !== TRUE)
      {
        redirect('login');
      }
      $data['title']              = 'Checkout payment';  
      $data['callback_url']       = base_url().'applications/callback';
      $data['surl']               = base_url().'applications/success';;
      $data['furl']               = base_url().'applications/failed';;
      $data['currency_code']      = 'INR';
    
      $appid = $this->uri->segment(3);
      $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
      $data['menu'] = 'Payments';
      $data['appdetails']   = $appdet;
 
      $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

      $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                );
      $data['appId'] = $appid;
      // echo $appid;
      $approvalForPayment = $this->_user->verifyApprovalForPayment($appid);
      if(!isset($approvalForPayment[0]->slno))
      {
         $data['approvalForPayment'] = 0;
      }
      else
      {
        $data['approvalForPayment'] = $approvalForPayment[0]->slno; 
      }
      $this->load->view('user/payment',$data);
  }

  public function application_makepay() 
  {
            if($this->session->userdata('usrlogged_in') !== TRUE)
            {
                redirect('login');
            }
            $data['title']              = 'Make Payment';  
       //$data['callback_url']       = base_url().'applications/callback_app';
             $data['callback_urlnew']       = base_url().'applications/callback_appnew';
            $data['surl']               = base_url().'applications/success_app';
            $data['furl']               = base_url().'applications/failed_app';
            $data['currency_code']      = 'INR';
            $appid = $this->uri->segment(3);
            // $appid = $this->session->flashdata('appid');
            $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
            $data['appId'] = $appid;
            $data['menu'] = 'Application Make Payment';
            $data['appdetails']   = $appdet;
            //  print_r($$appdet);
            $data['approvalForPayment'] = 0;
            $data['arr_css'] = array('user/css/bootstrap.min.css',
                                     'user/css/style.css',
                                     'user/css/application.css',
                                );
            $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                                        'user/js/script.js',
                                     'user/js/application.js',
                                    ); 
            //$this->session->set_flashdata('msg','Payment succesfull');
            $this->load->view('user/application_makepay',$data);
  }

 // initialized cURL Request
    private function curl_handler($payment_id, $amount)  
    {
        $url            = 'https://api.razorpay.com/v1/payments/'.$payment_id.'/capture';
        $key_id         = "rzp_test_8ITHhhrlaWgT4p";
        $key_secret     = "0w4o4s3zx3ogJ9xYqNmWHir1";
        $fields_string  = "amount=$amount";
        //cURL Request
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERPWD, $key_id.':'.$key_secret);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        return $ch;
    }   
        
    // callback method
    public function callback() 
    {   
         $reqParam =$this->input->post(); 
         $status = "fail"; 
         $response_array1 = array('test' => 'test' );
         if (!empty($this->input->post('razorpay_payment_id')) && !empty($this->input->post('merchant_order_id'))) 
         {
                  $razorpay_payment_id = $this->input->post('razorpay_payment_id');
                  $merchant_order_id = $this->input->post('merchant_order_id');
                  $this->session->set_flashdata('razorpay_payment_id', $this->input->post('razorpay_payment_id'));
                  $this->session->set_flashdata('merchant_order_id', $this->input->post('merchant_order_id'));
                  $currency_code = 'INR';
                  $amount = $this->input->post('merchant_total');
                  $success = false;
                  $error = '';
                  try 
                  {                
                      $ch = $this->curl_handler($razorpay_payment_id, $amount);
                      //execute post
                      $result = curl_exec($ch);
                      $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                      if ($result === false) 
                      {
                          $success = false;
                          $error = 'Curl error: '.curl_error($ch);
                      } 
                      else 
                      {
                          $response_array = json_decode($result, true);
                          $response_array1 = json_decode($result, true);
                          if ($http_status === 200 and isset($response_array['error']) === false) 
                          {
                                  $success = true;
                                  $status ="success";
                          } 
                          else 
                          {
                            $success = false;
                            if (!empty($response_array['error']['code'])) 
                            {
                                $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                            } 
                            else 
                            {
                                $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                            }
                          }
                      }
                      //close curl connection
                      curl_close($ch);
                  } 
                  catch (Exception $e) 
                  {
                      $success = false;
                      $error = 'Request to Razorpay Failed';
                      /*echo $success."2";
                          exit();*/
                  }

                //Db save
                $appid = $reqParam['merchant_product_info_id'];
                $data['appID'] = $appid;
                $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
                //print_r($appdet);
                $licence_renewal_count = $appdet[0]->licence_renewal_count;
                //$register_id = $appdet[0]->register_id;
                $saveCert = array(
                'appid' => $reqParam['merchant_product_info_id'],
                'payment_id'  => $response_array1['id'],
                'merchant_order_id'  => $reqParam['merchant_order_id'],
                'merchant_trans_id' => $reqParam['merchant_trans_id'],
                'licence_renewal_count' => $licence_renewal_count,
                'crtdate' => date('Y-m-d H:i:s'),
                'crtby' => "Razorpay",
                'status' => $status
                );
                $upStatus = $this->db->insert('payment',$saveCert);
                $insert_id = $this->db->insert_id(); 
                $amount = $response_array1['amount']/100;
                $saveApp = array( 
                  'payment_id' => $insert_id,
                  'payment_payed_date' => date('Y-m-d H:i:s'),
                  'payment_payed_amount' => $amount
                );
                //$this->db->set($saveApp);
                $this->db->where('id', $reqParam['merchant_product_info_id']);
                $upStatus = $this->db->update('application',$saveApp);
            
                if ($success === true) 
                {
                    if(!empty($this->session->userdata('ci_subscription_keys'))) 
                    {
                        $this->session->unset_userdata('ci_subscription_keys');
                    }
                   // $this->session->set_data($data);
                    $this->session->set_flashdata('appID',$response_array1['id']);
                    if (!isset($order_info['order_status_id'])) 
                    {
                                  // Start Alert & Notification Code
                                  // Mail For Alert
                                  $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
                                  $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;
                                  $mail_config = $this->config->item('mail_conf');
                                  $user = $mail_config['username'];
                                  $pass = $mail_config['password'];
                                  $url  = $mail_config['url'];
                                  $fromname  = $mail_config['from'];
                                  $fromid  = $mail_config['admin_mail'];
                                      
                                  $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Successfull and Application is processing to Payment Verification in 'Karnataka Tourism Trade Facilitation'.</p><p><h4>
                                    <br>
                                    Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                                    </h4>
                                    </p>";
                                  $subject = "Application Payment Successfull";
                                  $fromname = "support@karnatakatourism.org";
                                  $bodya=str_replace(';', ',', $body);
                                  $bodyb=str_replace(' ', '%20', $bodya);
                                  $body = str_replace(array("\n", "\r"), '', $bodyb);
                                  $params = array(
                                      'api_user'  => $user,
                                      'api_key'   => $pass,
                                      'to'        => $official_email,
                                      'subject'   => $subject,
                                      'html'      => $body,
                                      'text'      => '',
                                      'from'      => $fromname
                                  ); 

                                  //$request =  $url.'api/mail.send.json';
                                  $ton=str_replace(' ', '%20', $params['to']);
                                  $subjectn=str_replace(' ', '%20', $params['subject']);
                                  $htmln=str_replace(' ', '%20', $params['html']);
                                  $fromn=str_replace(' ', '%20', $params['from']);
                                   /* $session = curl_init($request);
                                    curl_setopt ($session, CURLOPT_POST, true);
                                    curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                                    curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                                    curl_setopt($session, CURLOPT_HEADER, false);
                                    curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                                    curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
                                    //obtain response
                                    $response = curl_exec($session); 
                                    curl_close($session);
                                    $respMsg =  json_decode($response);
                                    $response = $respMsg->message;*/
                                  $curl = curl_init();
                                  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
                                  $headers = array(
                                            "MIME-Version: 1.0\r\n",
                                            "Content-type: text/html; application/json;charset=\"utf-8\"",
                                            "Cache-Control: no-cache",
                                            "Pragma: no-cache"
                                        ); 
                                  curl_setopt_array(
                                  $curl, array(
                                      CURLOPT_POST=>1,
                                      CURLOPT_URL =>$url_value,
                                      CURLOPT_RETURNTRANSFER => true,
                                      CURLOPT_ENCODING => '',
                                      CURLOPT_MAXREDIRS => 10,
                                      CURLOPT_TIMEOUT => 0,
                                      CURLOPT_FOLLOWLOCATION => true,
                                      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                      CURLOPT_CUSTOMREQUEST => 'POST',
                                      CURLOPT_HEADER=>false,
                                      CURLOPT_SSL_VERIFYPEER=> false,
                                      CURLOPT_SAFE_UPLOAD=>true,
                                      CURLOPT_HTTPHEADER => array(
                                        'Authorization: Bearer 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',$headers
                                      ),
                                  ));
                                  $response = curl_exec($curl);
                                  $err = curl_error($curl);
                                  curl_close($curl);
                                  if ($err) 
                                  {
                                    echo "cURL Error #:" . $err;    
                                  } 
                                  else 
                                  {
                                       $respMsg =  json_decode($response);
                                       $response = $respMsg->message;    
                                  }
                                  //-----insert into email status
                                  $notimsg = "Application Payment has been Successfull and Moved to AD/DD for Payment Verification";
                                  $emailInfo = array(
                                        'register_id'    => $this->usrID,
                                        'application_id'    => $appid,
                                        'subject'    => $subject,
                                        'message'    => $notimsg,
                                        'app_stage'    => '0',
                                        'status'    => '0',
                                        'mail_status'    => ($response=='success') ? '0' : '1',
                                        'crtdate'    => date('Y-m-d H:i:s'),
                                        'crtby'     => $this->usrID,
                                        'crtname'     => 'applicant'
                                    );
                                  $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
                                  // End Alert & Notification Code
                                  redirect($this->input->post('merchant_surl_id'));
                                  // $this->success($data);
                    } 
                    else 
                    {
                      // Start Alert & Notification Code
                      // Mail For Alert

                        $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
                        $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;

                        $mail_config = $this->config->item('mail_conf');
                        $user = $mail_config['username'];
                        $pass = $mail_config['password'];
                        $url  = $mail_config['url'];
                        $fromname  = $mail_config['from'];
                        $fromid  = $mail_config['admin_mail'];
                            
                        $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Successfull and Application is processing to Payment Verification in 'Karnataka Tourism Trade Facilitation'.</p><p><h4>     
                        <br>
                         Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                          </h4>
                          </p>";
                          $bodya=str_replace(';', ',', $body);
                          $bodyb=str_replace(' ', '%20', $bodya);
                          $body = str_replace(array("\n", "\r"), '', $bodyb);
                          $subject = "Application Payment Successfull";
                          $fromname = "support@karnatakatourism.org";
                          
                          $params = array(
                              'api_user'  => $user,
                              'api_key'   => $pass,
                              'to'        => $official_email,
                              'subject'   => $subject,
                              'html'      => $body,
                              'text'      => '',
                              'from'      => $fromname
                          ); 

                          $ton=str_replace(' ', '%20', $params['to']);
                          $subjectn=str_replace(' ', '%20', $params['subject']);
                          $htmln=str_replace(' ', '%20', $params['html']);
                          $fromn=str_replace(' ', '%20', $params['from']);

                          $curl = curl_init();
                          $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
                          $headers = array(
                                    "MIME-Version: 1.0\r\n",
                                    "Content-type: text/html; application/json;charset=\"utf-8\"",
                                    "Cache-Control: no-cache",
                                    "Pragma: no-cache"
                          );

                          curl_setopt_array($curl, 
                            array(
                              CURLOPT_POST=>1,
                              CURLOPT_URL =>$url_value,
                              CURLOPT_RETURNTRANSFER => true,
                              CURLOPT_ENCODING => '',
                              CURLOPT_MAXREDIRS => 10,
                              CURLOPT_TIMEOUT => 0,
                              CURLOPT_FOLLOWLOCATION => true,
                              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                              CURLOPT_CUSTOMREQUEST => 'POST',
                              CURLOPT_HEADER=>false,
                              CURLOPT_SSL_VERIFYPEER=> false,
                              CURLOPT_HTTPHEADER => array(
                                'Authorization: Bearer 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',$headers
                              ),
                          ));
                          $response = curl_exec($curl);
                          $err = curl_error($curl);
                          curl_close($curl);  
                          if ($err) 
                          {
                             echo "cURL Error #:" . $err;  
                          } 
                          else 
                          {
                             $respMsg =  json_decode($response);
                             $response = $respMsg->message;       
                          }
                        /*$request =  $url.'api/mail.send.json';

                        $session = curl_init($request);
                        curl_setopt ($session, CURLOPT_POST, true);
                        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                        curl_setopt($session, CURLOPT_HEADER, false);
                        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                        // obtain response
                        $response = curl_exec($session); 
                        curl_close($session);
                        $respMsg =  json_decode($response);
                        $response = $respMsg->message; */ 

                        //-----insert into email status
                        $notimsg = "Application Payment has been Successfull and Moved to AD/DD for Payment Verification";
                        $emailInfo = array(
                         'register_id'    => $this->usrID,
                         'application_id'    => $appid,
                         'subject'    => $subject,
                         'message'    => $notimsg,
                         'app_stage'    => '0',
                         'status'    => '0',
                         'mail_status'    => ($response=='success') ? '0' : '1',
                         'crtdate'    => date('Y-m-d H:i:s'),
                         'crtby'     => $this->usrID,
                         'crtname'     => 'applicant'
                          );

                        $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
                        // End Alert & Notification Code
                        //$this->success($data);
                        redirect($this->input->post('merchant_surl_id'));
                    }
                } 
                else 
                {
                        // Start Alert & Notification Code
                        // Mail For Alert
                        $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
                        $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;
                        $mail_config = $this->config->item('mail_conf');
                        $user = $mail_config['username'];
                        $pass = $mail_config['password'];
                        $url  = $mail_config['url'];
                        $fromname  = $mail_config['from'];
                        $fromid  = $mail_config['admin_mail'];
                        $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Failed a. Please Update the Application Payment for Futher Process in 'Karnataka Tourism Trade Facilitation'.</p><p><h4> <br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
                        $bodya=str_replace(';', ',', $body);
                        $bodyb=str_replace(' ', '%20', $bodya);
                        $body = str_replace(array("\n", "\r"), '', $bodyb);
                        $subject = "Application Payment Failed";
                        $fromname = "support@karnatakatourism.org";
                        $params = array(
                            'api_user'  => $user,
                            'api_key'   => $pass,
                            'to'        => $official_email,
                            'subject'   => $subject,
                            'html'      => $body,
                            'text'      => '',
                            'from'      => $fromname
                        ); 

                        //$request =  $url.'api/mail.send.json';
                        $ton=str_replace(' ', '%20', $params['to']);
                        $subjectn=str_replace(' ', '%20', $params['subject']);
                        $htmln=str_replace(' ', '%20', $params['html']);
                        $fromn=str_replace(' ', '%20', $params['from']);

                        $curl = curl_init();
                        $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
                        $headers = array(
                                  "MIME-Version: 1.0\r\n",
                                  "Content-type: text/html; application/json;charset=\"utf-8\"",
                                  "Cache-Control: no-cache",
                                  "Pragma: no-cache"
                        ); 
                        curl_setopt_array($curl, 
                          array(
                            CURLOPT_POST=>1,
                            CURLOPT_URL =>$url_value,
                            CURLOPT_RETURNTRANSFER => true,
                            CURLOPT_ENCODING => '',
                            CURLOPT_MAXREDIRS => 10,
                            CURLOPT_TIMEOUT => 0,
                            CURLOPT_FOLLOWLOCATION => true,
                            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                            CURLOPT_CUSTOMREQUEST => 'POST',
                            CURLOPT_HEADER=>false,
                            CURLOPT_SSL_VERIFYPEER=> false,
                            CURLOPT_HTTPHEADER => array(
                              'Authorization: Bearer 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',$headers
                            ),
                          ));

                        $response = curl_exec($curl);
                        $err = curl_error($curl);
                        curl_close($curl);
                        if ($err) 
                        {
                          echo "cURL Error #:" . $err;  
                        } 
                        else 
                        {
                             $respMsg =  json_decode($response);
                             $response = $respMsg->message;    
                        }

                           /* $session = curl_init($request);
                            curl_setopt ($session, CURLOPT_POST, true);
                            curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                            curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                            curl_setopt($session, CURLOPT_HEADER, false);
                            curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                            curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                            // obtain response
                            $response = curl_exec($session); 
                            curl_close($session);
                            $respMsg =  json_decode($response);
                            $response = $respMsg->message;*/
                      
                            //-----insert into email status
                            $notimsg = "Application Payment has been Failed and Please Update the Application Payment for Futher Process";
                            $emailInfo = array(
                                'register_id'    => $this->usrID,
                                'application_id'    => $appid,
                                'subject'    => $subject,
                                'message'    => $notimsg,
                                'app_stage'    => '0',
                                'status'    => '0',
                                'mail_status'    => ($response=='success') ? '0' : '1',
                                'crtdate'    => date('Y-m-d H:i:s'),
                                'crtby'     => $this->usrID,
                                'crtname'     => 'applicant'
                              );
                            $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
                            // End Alert & Notification Code
                            redirect($this->input->post('merchant_furl_id'));
                }
          } 
    else 
    {
            echo 'An error occured. Contact site administrator, please!';
    }
} 



    public function callback_appnew() 
    {   

      // following files need to be included
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$checkSum = "";
$paramList = array();


$insertidd = $_POST["insertidd"];
$ORDER_ID = $_POST["ORDER_ID"];
$CUST_ID = $_POST["CUST_ID"];
$INDUSTRY_TYPE_ID = $_POST["INDUSTRY_TYPE_ID"];
$CHANNEL_ID = $_POST["CHANNEL_ID"];
$TXN_AMOUNT = $_POST["TXN_AMOUNT"];

$orderidcon = $ORDER_ID.'-'.$insertidd;
// Create an array having all required parameters for creating checksum.
$paramList["MID"] = PAYTM_MERCHANT_MID;
$paramList["ORDER_ID"] = $orderidcon;
$paramList["CUST_ID"] = $CUST_ID;
$paramList["INDUSTRY_TYPE_ID"] = $INDUSTRY_TYPE_ID;
$paramList["CHANNEL_ID"] = $CHANNEL_ID;
$paramList["TXN_AMOUNT"] = $TXN_AMOUNT;
$paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
$paramList["CALLBACK_URL"] = base_url().'applications/newresp/'.$insertidd;

//echo $paramList["ORDER_ID"];
//echo $paramList["CALLBACK_URL"];
//die;

/*
$paramList["CALLBACK_URL"] = "http://localhost/PaytmKit/pgResponse.php";
$paramList["MSISDN"] = $MSISDN; //Mobile number of customer
$paramList["EMAIL"] = $EMAIL; //Email ID of customer
$paramList["VERIFIED_BY"] = "EMAIL"; //
$paramList["IS_USER_VERIFIED"] = "YES"; //

*/

//Here checksum string will return by getChecksumFromArray() function.
$checkSum = getChecksumFromArray($paramList,PAYTM_MERCHANT_KEY);

?>
    <form method="post" action="<?php echo PAYTM_TXN_URL ?>" name="f1">
    <table border="1">
      <tbody>
      <?php
      foreach($paramList as $name => $value) {
        echo '<input type="hidden" name="' . $name .'" value="' . $value . '">';
      }
      ?>
      <input type="hidden" name="CHECKSUMHASH" value="<?php echo $checkSum ?>">
      </tbody>
    </table>
    <script type="text/javascript">
      document.f1.submit();
    </script>
  </form>
<?php

//echo"<script>alert('Thank You $parfirstname.Your Details has been Successfully Saved. For Further Details Use this Mobile Number - $otpmobile to Check Status...')";



//echo "testt";
//die;
    }

     function newresp()
  {

        
require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$paytmChecksum = "";
$paramList = array();
$isValidChecksum = "FALSE";

$paramList = $_POST;
        //print_r($paramList);


$orderid = $paramList['ORDERID'];
$mid = $paramList['MID'];
$txnid = $paramList['TXNID'];
$txnamount = $paramList['TXNAMOUNT'];
$paymentmode = $paramList['PAYMENTMODE'];
$currency = $paramList['CURRENCY'];
$txndate = $paramList['TXNDATE'];
$status = $paramList['STATUS'];
$respcode = $paramList['RESPCODE'];
$respmsg = $paramList['RESPMSG'];
$gateway = $paramList['GATEWAYNAME'];
$banktxn = $paramList['BANKTXNID'];
$bankname = $paramList['BANKNAME'];
$checksum = $paramList['CHECKSUMHASH'];

$appid = $this->uri->segment(3);

$appdet = $this->db->get_where('application' , array('id'=>$appid))->result();

$saveCertnew = array(
                'appid' => $appid,
                'order_id'  => $orderid,
                'mid'  => $mid,
                'txnid' => $txnid,
                'txnamount' => $txnamount,
                'paymentmode' => $paymentmode,
                'currency' => $currency,
                'txndate' => $txndate,
                'paystatus' => $status,
                'respcode' => $respcode,
                'respmsg' => $respmsg,
                'gatewayname' => $gateway,
                'banktxnid' => $banktxn,
                'bankname' => $bankname,
                'checksumhash' => $checksum,
                'status' => $status,
                'crtdate' => date('Y-m-d H:i:s'),
                'crtby' => $appdet[0]->register_id,
                'status' => $status
                );
                  //print_r($saveCert);
                  //echo "testt";
                  //die;
                $upStatus = $this->db->insert('app_payment_new',$saveCertnew);

//die;

    if ($status == "TXN_SUCCESS") {

           $amount = $txnamount;
                $saveApp = array( 
                  'app_payment_id' => $orderid,
                  'app_payment_payed_date' => $txndate,
                  'is_confirmed' => '1'
                );
            
              //$this->db->set($saveApp);
              $this->db->where('id', $appid);
              $upStatus = $this->db->update('application',$saveApp);


$applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
          $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;
          

            $mail_config = $this->config->item('mail_conf');
            $user = $mail_config['username'];
            $pass = $mail_config['password'];
            $url  = $mail_config['url'];
            $fromname  = $mail_config['from'];
            $fromid  = $mail_config['admin_mail'];
                    
            $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Successfull and Application is processing to Field Verification in 'Karnataka Tourism Trade Facilitation'.</p><p><h4>       
            <br> Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
            
            $bodya=str_replace(';', ',', $body);
            $bodyb=str_replace(' ', '%20', $bodya);
            $body = str_replace(array("\n", "\r"), '', $bodyb);

            $subject = "Application Payment Successfull";
            $fromname = "support@karnatakatourism.org";
            $params = array(
                'api_user'  => $user,
                'api_key'   => $pass,
                'to'        => $official_email,
                'subject'   => $subject,
                'html'      => $body,
                'text'      => '',
                'from'      => $fromname
            ); 

            $ton=str_replace(' ', '%20', $params['to']);
            $subjectn=str_replace(' ', '%20', $params['subject']);
            $htmln=str_replace(' ', '%20', $params['html']);
            $fromn=str_replace(' ', '%20', $params['from']);



            $curl = curl_init();
            $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
            $headers = array(
                      "MIME-Version: 1.0\r\n",
                      "Content-type: text/html; application/json;charset=\"utf-8\"",
                      "Cache-Control: no-cache",
                      "Pragma: no-cache"
                  ); 
            curl_setopt_array($curl, array(
            CURLOPT_POST=>1,
            CURLOPT_URL =>$url_value,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HEADER=>false,
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
              'Authorization: Bearer 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',$headers
            ),
          ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            //print_r($response);    
            curl_close($curl);  
            if ($err) {
              echo "cURL Error #:" . $err;  
            } else {
                 $respMsg =  json_decode($response);
                 $response = $respMsg->message;   
            }
              
            //-----insert into email status
              $notimsg = "Application Payment has been Successfull and Moved to AD/DD for Field Verification";
              $emailInfo = array(
                'register_id'    => $this->usrID,
                'application_id'    => $appid,
                'subject'    => $subject,
                'message'    => $notimsg,
                'app_stage'    => '0',
                'status'    => '0',
                'mail_status'    => ($response=='success') ? '0' : '1',
                'crtdate'    => date('Y-m-d H:i:s'),
                'crtby'     => $this->usrID,
                'crtname'     => 'applicant'
                );

          $upStatusnoti = $this->db->insert('application_notification',$emailInfo);


          $org_loc_district_id = $this->db->get_where('application', array('id' => $appid))->row()->org_loc_district_id;
          $adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;
          $adm_id=($adm_id=='' ? 0 : $adm_id);
          //-----insert into email status
              $adm_noti = "New Application Received.";
              $new_appli = array(
                'register_id'    => $this->usrID,
                'application_id'    => $appid,
                'district_id'     => $org_loc_district_id,
                'adm_id'     => $adm_id,
                'subject'    => $subject,
                'message'    => $adm_noti,
                'app_stage'    => '0',
                'status'    => '0',
                'mail_status'    => ($response=='success') ? '0' : '1',
                'crtdate'    => date('Y-m-d H:i:s'),
                'crtby'     => $this->usrID,
                'crtname'     => 'applicant'
                );
              
                $upStatusnoti = $this->db->insert('adm_notification',$new_appli);
                
                $this->session->set_flashdata('msg','Your Application Payment has been Successfull');
                // End Alert & Notification Code 
        }
        else{

// Start Alert & Notification Code
  // Mail For Alert
  $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
  $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;

  $mail_config = $this->config->item('mail_conf');
  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        
  $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Failed and Application Saved in Dashboard. Please Update the Application Fee for Futher Process in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
  $bodya=str_replace(';', ',', $body);
  $bodyb=str_replace(' ', '%20', $bodya);
  $body = str_replace(array("\n", "\r"), '', $bodyb);

  $subject = "Application Payment Failed";
  $fromname = "support@karnatakatourism.org";
  $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $official_email,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 
  $ton=str_replace(' ', '%20', $params['to']);
  $tonamen=str_replace(' ', '%20', $tonamea);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);



  //-----insert into email status
    $notimsg = "Application Payment has been Failed and Please Update the Application Fee for Futher Process";
    $emailInfo = array(
     'register_id'    => $this->usrID,
     'application_id'    => $appid,
     'subject'    => $subject,
     'message'    => $notimsg,
     'app_stage'    => '0',
     'status'    => '0',
     'mail_status'    => ($response=='success') ? '0' : '1',
     'crtdate'    => date('Y-m-d H:i:s'),
     'crtby'     => $this->usrID,
     'crtname'     => 'applicant'
      );

$upStatusnoti = $this->db->insert('application_notification',$emailInfo);

$this->session->set_flashdata('msg','Your Application Payment has been Failed and Application Saved in Dashboard');
// End Alert & Notification Code
   
        }

                

        //die;
        //$appid = $this->uri->segment(3);
         
        $sesdataa = array(
                  'app_id'       => $appid,
              );
        $this->session->set_userdata($sesdataa);

       //echo $appid;
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();

        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $appdet_pay = $this->db->get_where('app_payment_new' , array('appid'=>$appid))->result();


        $data['menu'] = 'Payment Response';
        $data['appdetails']   = $appdet;
        $data['appdet_pay']   = $appdet_pay;
  
        $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

        $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
               'user/js/multislider.js',
               'user/js/bootstrap.4.4.1.min.js');
        $this->load->view('user/newresp',$data);
  }





function callback_app_paytm()
  {

 $paytm_orderid = $this->input->post('pg_orderid');
 $appl_id = $this->input->post('insertidd');

                $saveApp_make = array( 
                  'paytm_orderid' => $paytm_orderid
                );
            
              //$this->db->set($saveApp);
              $this->db->where('id', $appl_id);
              $upStatus_make = $this->db->update('application',$saveApp_make);

 if($upStatus_make):
    echo "Paytm Orderid Updated Successfully";     
  else:    
    echo "Orderid Not Updated";
  endif;

}



function paytmjs()
  {

if(!empty($_POST)){


$paramList = $_POST;
        //print_r($paramList);


$orderid = $paramList['ORDERID'];
$mid = $paramList['MID'];
$txnid = $paramList['TXNID'];
$txnamount = $paramList['TXNAMOUNT'];
$paymentmode = $paramList['PAYMENTMODE'];
$currency = $paramList['CURRENCY'];
$txndate = $paramList['TXNDATE'];
$status = $paramList['STATUS'];
$respcode = $paramList['RESPCODE'];
$respmsg = $paramList['RESPMSG'];
$gateway = $paramList['GATEWAYNAME'];
$banktxn = $paramList['BANKTXNID'];
$bankname = $paramList['BANKNAME'];
$checksum = $paramList['CHECKSUMHASH'];

$appid = $this->db->get_where('application', array('paytm_orderid' => $orderid))->row()->id;


if(empty($appid)){
    $this->session->set_flashdata('msg','Your Application Payment has been Pending and Application Saved in Dashboard. Please Check it.');
    $redirr = base_url().'user/newresp';
redirect($redirr);
}


$appdet = $this->db->get_where('application' , array('id'=>$appid))->result();

$saveCertnew = array(
                'appid' => $appid,
                'order_id'  => $orderid,
                'mid'  => $mid,
                'txnid' => $txnid,
                'txnamount' => $txnamount,
                'paymentmode' => $paymentmode,
                'currency' => $currency,
                'txndate' => $txndate,
                'paystatus' => $status,
                'respcode' => $respcode,
                'respmsg' => $respmsg,
                'gatewayname' => $gateway,
                'banktxnid' => $banktxn,
                'bankname' => $bankname,
                'checksumhash' => $checksum,
                'status' => $status,
                'crtdate' => date('Y-m-d H:i:s'),
                'crtby' => $appdet[0]->register_id,
                'status' => $status
                );
                  //print_r($saveCert);
                  //echo "testt";
                  //die;
                $upStatus = $this->db->insert('app_payment_new',$saveCertnew);
                //echo $this->db->last_query();

//die;

    if ($status == "TXN_SUCCESS") {

           $amount = $txnamount;
                $saveApp = array( 
                  'app_payment_id' => $orderid,
                  'app_payment_payed_date' => $txndate,
                  'is_confirmed' => '1'
                );
            
              //$this->db->set($saveApp);
              $this->db->where('id', $appid);
              $upStatus = $this->db->update('application',$saveApp);


$applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
          $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;
          

            $mail_config = $this->config->item('mail_conf');
            $user = $mail_config['username'];
            $pass = $mail_config['password'];
            $url  = $mail_config['url'];
            $fromname  = $mail_config['from'];
            $fromid  = $mail_config['admin_mail'];
                    
            $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Successfull and Application is processing to Field Verification in 'Karnataka Tourism Trade Facilitation'.</p><p><h4>       
            <br> Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
            
            $bodya=str_replace(';', ',', $body);
            $bodyb=str_replace(' ', '%20', $bodya);
            $body = str_replace(array("\n", "\r"), '', $bodyb);

            $subject = "Application Payment Successfull";
            $fromname = "support@karnatakatourism.org";
            $params = array(
                'api_user'  => $user,
                'api_key'   => $pass,
                'to'        => $official_email,
                'subject'   => $subject,
                'html'      => $body,
                'text'      => '',
                'from'      => $fromname
            ); 

            $ton=str_replace(' ', '%20', $params['to']);
            $subjectn=str_replace(' ', '%20', $params['subject']);
            $htmln=str_replace(' ', '%20', $params['html']);
            $fromn=str_replace(' ', '%20', $params['from']);



            $curl = curl_init();
            $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
            $headers = array(
                      "MIME-Version: 1.0\r\n",
                      "Content-type: text/html; application/json;charset=\"utf-8\"",
                      "Cache-Control: no-cache",
                      "Pragma: no-cache"
                  ); 
            curl_setopt_array($curl, array(
            CURLOPT_POST=>1,
            CURLOPT_URL =>$url_value,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HEADER=>false,
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
              'Authorization: Bearer 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',$headers
            ),
          ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            //print_r($response);    
            curl_close($curl);  
            if ($err) {
              echo "cURL Error #:" . $err;  
            } else {
                 $respMsg =  json_decode($response);
                 $response = $respMsg->message;   
            }
              
            //-----insert into email status
              $notimsg = "Application Payment has been Successfull and Moved to AD/DD for Field Verification";
              $emailInfo = array(
                'register_id'    => $this->usrID,
                'application_id'    => $appid,
                'subject'    => $subject,
                'message'    => $notimsg,
                'app_stage'    => '0',
                'status'    => '0',
                'mail_status'    => ($response=='success') ? '0' : '1',
                'crtdate'    => date('Y-m-d H:i:s'),
                'crtby'     => $this->usrID,
                'crtname'     => 'applicant'
                );

          $upStatusnoti = $this->db->insert('application_notification',$emailInfo);


          $org_loc_district_id = $this->db->get_where('application', array('id' => $appid))->row()->org_loc_district_id;
          $adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;
          $adm_id=($adm_id=='' ? 0 : $adm_id);
          //-----insert into email status
              $adm_noti = "New Application Received.";
              $new_appli = array(
                'register_id'    => $this->usrID,
                'application_id'    => $appid,
                'district_id'     => $org_loc_district_id,
                'adm_id'     => $adm_id,
                'subject'    => $subject,
                'message'    => $adm_noti,
                'app_stage'    => '0',
                'status'    => '0',
                'mail_status'    => ($response=='success') ? '0' : '1',
                'crtdate'    => date('Y-m-d H:i:s'),
                'crtby'     => $this->usrID,
                'crtname'     => 'applicant'
                );
              
                $upStatusnoti = $this->db->insert('adm_notification',$new_appli);
                
                $this->session->set_flashdata('msg','Your Application Payment has been Successfull');
                // End Alert & Notification Code 
        }
        else{

// Start Alert & Notification Code
  // Mail For Alert
  $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
  $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;

  $mail_config = $this->config->item('mail_conf');
  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        
  $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Failed and Application Saved in Dashboard. Please Update the Application Fee for Futher Process in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
  $bodya=str_replace(';', ',', $body);
  $bodyb=str_replace(' ', '%20', $bodya);
  $body = str_replace(array("\n", "\r"), '', $bodyb);

  $subject = "Application Payment Failed";
  $fromname = "support@karnatakatourism.org";
  $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $official_email,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 
  $ton=str_replace(' ', '%20', $params['to']);
  $tonamen=str_replace(' ', '%20', $tonamea);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);



  //-----insert into email status
    $notimsg = "Application Payment has been Failed and Please Update the Application Fee for Futher Process";
    $emailInfo = array(
     'register_id'    => $this->usrID,
     'application_id'    => $appid,
     'subject'    => $subject,
     'message'    => $notimsg,
     'app_stage'    => '0',
     'status'    => '0',
     'mail_status'    => ($response=='success') ? '0' : '1',
     'crtdate'    => date('Y-m-d H:i:s'),
     'crtby'     => $this->usrID,
     'crtname'     => 'applicant'
      );

$upStatusnoti = $this->db->insert('application_notification',$emailInfo);

$this->session->set_flashdata('msg','Your Application Payment has been Failed and Application Saved in Dashboard');
// End Alert & Notification Code
   
        }

                

        //die;
        //$appid = $this->uri->segment(3);
         
        $sesdataa = array(
                  'app_id'       => $appid,
              );
        $this->session->set_userdata($sesdataa);

       //echo $appid;
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();

        $this->db->order_by('id', 'desc');
        $this->db->limit(1);
        $appdet_pay = $this->db->get_where('app_payment_new' , array('appid'=>$appid))->result();


        $data['menu'] = 'Payment Response';
        $data['appdetails']   = $appdet;
        $data['appdet_pay']   = $appdet_pay;
  
        $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

        $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
               'user/js/multislider.js',
               'user/js/bootstrap.4.4.1.min.js');
        $this->load->view('user/newresp',$data);
    }
else{
    $this->session->set_flashdata('msg','Your Application Payment has been Failed and Application Saved in Dashboard. Please Check it.');
$this->load->view('user/newresp',$data);
}

  }








    // callback method for Application
    public function callback_app() 
    {   
        $reqParam =$this->input->post(); 
        //$status = "fail"; 
        $status = "success";
        $response_array1 = array('test' => 'test' );
        if (!empty($this->input->post('razorpay_payment_id')) && !empty($this->input->post('merchant_order_id'))) {
            $razorpay_payment_id = $this->input->post('razorpay_payment_id');
            $merchant_order_id = $this->input->post('merchant_order_id');
            $this->session->set_flashdata('razorpay_payment_id', $this->input->post('razorpay_payment_id'));
            $this->session->set_flashdata('merchant_order_id', $this->input->post('merchant_order_id'));
            $currency_code = 'INR';
            $amount = $this->input->post('merchant_total');
            $success = false;
            $error = '';
            try {                
                $ch = $this->curl_handler($razorpay_payment_id, $amount);
                //execute post
                $result = curl_exec($ch);
                $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        
        
                if ($result === false) {
                    $success = false;
                    $error = 'Curl error: '.curl_error($ch);
                } else {

                    $response_array = json_decode($result, true);
                    $response_array1 = json_decode($result, true);
          
          //print_r($response_array1);
          //echo $http_status;
          //die;
                        if ($http_status === 200 and isset($response_array['error']) === false) {
                            $success = true;
                            $status ="success";
                        } else {
                            //$success = false;
              $success = true;
                            if (!empty($response_array['error']['code'])) {
                                $error = $response_array['error']['code'].':'.$response_array['error']['description'];
                            } else {
                                $error = 'RAZORPAY_ERROR:Invalid Response <br/>'.$result;
                            }
                        }
                }
                //close curl connection
                
                curl_close($ch);
            } catch (Exception $e) {
        //$success = false;
                $success = true;
                $error = 'Request to Razorpay Failed';
                /*echo $success."2";
                    exit();*/
            }

      
            //Db save
                $appid = $reqParam['merchant_product_info_id'];
                $data['appID'] = $appid;
                $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
                //print_r($appdet);
                
     if($status=="success")
     {           
                //$register_id = $appdet[0]->register_id;
                $saveCert = array(
                'appid' => $reqParam['merchant_product_info_id'],
                'payment_id'  => $response_array1['id'],
                'merchant_order_id'  => $reqParam['merchant_order_id'],
                'merchant_trans_id' => $reqParam['merchant_trans_id'],
                'crtdate' => date('Y-m-d H:i:s'),
                'crtby' => $appdet[0]->register_id,
                'pay_type' => "Razorpay",
                'status' => $status
                );
                  //print_r($saveCert);
                  //echo "testt";
                  //die;
                $upStatus = $this->db->insert('app_payment',$saveCert);

                $insert_id = $this->db->insert_id(); 
                $amount = $response_array1['amount']/100;
                $saveApp = array( 
                  'app_payment_id' => $insert_id,
                  'app_payment_payed_date' => date('Y-m-d H:i:s'),
                  'is_confirmed' => '1'
                );
            
              //$this->db->set($saveApp);
              $this->db->where('id', $reqParam['merchant_product_info_id']);
              $upStatus = $this->db->update('application',$saveApp);
     }
      $success = true;
      if ($success === true) 
      {
                if(!empty($this->session->userdata('ci_subscription_keys'))) {
                    $this->session->unset_userdata('ci_subscription_keys');
      }
      // $this->session->set_data($data);
      $this->session->set_flashdata('appID',$appid);
      if (!isset($order_info['order_status_id'])) 
      {
          // Start Alert & Notification Code
          // Mail For Alert
          $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
          $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;
          //print_r($official_email);
          //$official_email ='brabhavathy.g@globalsinc.com';

            $mail_config = $this->config->item('mail_conf');
            $user = $mail_config['username'];
            $pass = $mail_config['password'];
            $url  = $mail_config['url'];
            $fromname  = $mail_config['from'];
            $fromid  = $mail_config['admin_mail'];
                    
            $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Successfull and Application is processing to Field Verification in 'Karnataka Tourism Trade Facilitation'.</p><p><h4>       
            <br> Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
            
            $bodya=str_replace(';', ',', $body);
            $bodyb=str_replace(' ', '%20', $bodya);
            $body = str_replace(array("\n", "\r"), '', $bodyb);

            $subject = "Application Payment Successfull";
            $fromname = "support@karnatakatourism.org";
            $params = array(
                'api_user'  => $user,
                'api_key'   => $pass,
                'to'        => $official_email,
                'subject'   => $subject,
                'html'      => $body,
                'text'      => '',
                'from'      => $fromname
            ); 

            $ton=str_replace(' ', '%20', $params['to']);
            $subjectn=str_replace(' ', '%20', $params['subject']);
            $htmln=str_replace(' ', '%20', $params['html']);
            $fromn=str_replace(' ', '%20', $params['from']);


            /*$request =  $url.'api/mail.send.json';

            $session = curl_init($request);
            curl_setopt ($session, CURLOPT_POST, true);
            curl_setopt($session, CURLOPT_SAFE_UPLOAD , true);
            curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
            curl_setopt($session, CURLOPT_HEADER, false);
                  curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
            curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

            // obtain response
            $response = curl_exec($session); 
            curl_close($session);
            $respMsg =  json_decode($response);
            $response = $respMsg->message;
            */

            //prabha - mailer working

            $curl = curl_init();
            $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
            $headers = array(
                      "MIME-Version: 1.0\r\n",
                      "Content-type: text/html; application/json;charset=\"utf-8\"",
                      "Cache-Control: no-cache",
                      "Pragma: no-cache"
                  ); 
            curl_setopt_array($curl, array(
            CURLOPT_POST=>1,
            CURLOPT_URL =>$url_value,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HEADER=>false,
            CURLOPT_SSL_VERIFYPEER=> false,
            CURLOPT_HTTPHEADER => array(
              'Authorization: Bearer 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',$headers
            ),
          ));

            $response = curl_exec($curl);
            $err = curl_error($curl);
            //print_r($response);    
            curl_close($curl);  
            if ($err) {
              echo "cURL Error #:" . $err;  
            } else {
                 $respMsg =  json_decode($response);
                 $response = $respMsg->message;   
            }
              
            //-----insert into email status
              $notimsg = "Application Payment has been Successfull and Moved to AD/DD for Field Verification";
              $emailInfo = array(
                'register_id'    => $this->usrID,
                'application_id'    => $appid,
                'subject'    => $subject,
                'message'    => $notimsg,
                'app_stage'    => '0',
                'status'    => '0',
                'mail_status'    => ($response=='success') ? '0' : '1',
                'crtdate'    => date('Y-m-d H:i:s'),
                'crtby'     => $this->usrID,
                'crtname'     => 'applicant'
                );

          $upStatusnoti = $this->db->insert('application_notification',$emailInfo);


          $org_loc_district_id = $this->db->get_where('application', array('id' => $appid))->row()->org_loc_district_id;
          $adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;
          $adm_id=($adm_id=='' ? 0 : $adm_id);
          //-----insert into email status
              $adm_noti = "New Application Received.";
              $new_appli = array(
                'register_id'    => $this->usrID,
                'application_id'    => $appid,
                'district_id'     => $org_loc_district_id,
                'adm_id'     => $adm_id,
                'subject'    => $subject,
                'message'    => $adm_noti,
                'app_stage'    => '0',
                'status'    => '0',
                'mail_status'    => ($response=='success') ? '0' : '1',
                'crtdate'    => date('Y-m-d H:i:s'),
                'crtby'     => $this->usrID,
                'crtname'     => 'applicant'
                );
              
                $upStatusnoti = $this->db->insert('adm_notification',$new_appli);

                
                // End Alert & Notification Code
                redirect($this->input->post('merchant_surl_id'));
                // $this->success($data);
 } 
 else 
 {
    // Start Alert & Notification Code
    // Mail For Alert
    $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
    $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;

    $mail_config = $this->config->item('mail_conf');
    $user = $mail_config['username'];
    $pass = $mail_config['password'];
    $url  = $mail_config['url'];
    $fromname  = $mail_config['from'];
    $fromid  = $mail_config['admin_mail'];

    $bodya=str_replace(';', ',', $body);
    $bodyb=str_replace(' ', '%20', $bodya);
    $body = str_replace(array("\n", "\r"), '', $bodyb);

          
    $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Successfull and Application is processing to Field Verification in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
    $subject = "Application Payment Successfull";
    $fromname = "support@karnatakatourism.org";
    $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $official_email,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
    ); 

    $ton=str_replace(' ', '%20', $params['to']);
    $tonamen=str_replace(' ', '%20', $tonamea);
    $subjectn=str_replace(' ', '%20', $params['subject']);
    $htmln=str_replace(' ', '%20', $params['html']);
    $fromn=str_replace(' ', '%20', $params['from']);
    // $textn=str_replace(' ', '%20', $texta);

    $curl = curl_init();
    $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
    $headers = array(
              "MIME-Version: 1.0\r\n",
              "Content-type: text/html; application/json;charset=\"utf-8\"",
              "Cache-Control: no-cache",
              "Pragma: no-cache"
          ); 
    curl_setopt_array($curl, array(
    CURLOPT_POST=>1,
    CURLOPT_URL =>$url_value,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_HEADER=>false,
    CURLOPT_SSL_VERIFYPEER=> false,
    CURLOPT_HTTPHEADER => array(
      'Authorization: Bearer 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',$headers
    ),
  ));

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);  
    if ($err) {
      echo "cURL Error #:" . $err;  
    } else {
         $respMsg =  json_decode($response);
         $response = $respMsg->message;       
    }

    /*$request =  $url.'api/mail.send.json';
    $session = curl_init($request);
        curl_setopt ($session, CURLOPT_POST, true);
        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
        curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

        // obtain response
        $response = curl_exec($session); 
        curl_close($session);
        $respMsg =  json_decode($response);
        $response = $respMsg->message;
  */


  //-----insert into email status
    $notimsg = "Application Payment has been Successfull and Moved to AD/DD for Field Verification";
    $emailInfo = array(
     'register_id'    => $this->usrID,
     'application_id'    => $appid,
     'subject'    => $subject,
     'message'    => $notimsg,
     'app_stage'    => '0',
     'status'    => '0',
     'mail_status'    => ($response=='success') ? '0' : '1',
     'crtdate'    => date('Y-m-d H:i:s'),
     'crtby'     => $this->usrID,
     'crtname'     => 'applicant'
      );
    $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
    // End Alert & Notification Code
    //$this->success($data);
    redirect($this->input->post('merchant_surl_id'));
    //echo "else 1st part";
  }
} 
else 
{
  // Start Alert & Notification Code
  // Mail For Alert
  $applicant_name = $this->db->get_where('application', array('id' => $appid))->row()->applicant_name;
  $official_email = $this->db->get_where('application', array('id' => $appid))->row()->official_email;

  $mail_config = $this->config->item('mail_conf');
  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        
  $body = "<h3>Dear ".$applicant_name.",</h3><p><br> Your Application Payment has been Failed and Application Saved in Dashboard. Please Update the Application Fee for Futher Process in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
  $bodya=str_replace(';', ',', $body);
  $bodyb=str_replace(' ', '%20', $bodya);
  $body = str_replace(array("\n", "\r"), '', $bodyb);

  $subject = "Application Payment Failed";
  $fromname = "support@karnatakatourism.org";
  $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $official_email,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 
  $ton=str_replace(' ', '%20', $params['to']);
  $tonamen=str_replace(' ', '%20', $tonamea);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);

 /* $request =  $url.'api/mail.send.json';
  $session = curl_init($request);
  curl_setopt ($session, CURLOPT_POST, true);
  curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
  curl_setopt($session, CURLOPT_HEADER, false);
  curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

  // obtain response
  $response = curl_exec($session); 
  curl_close($session);
  $respMsg =  json_decode($response);
  $response = $respMsg->message;
  */


  //-----insert into email status
    $notimsg = "Application Payment has been Failed and Please Update the Application Fee for Futher Process";
    $emailInfo = array(
     'register_id'    => $this->usrID,
     'application_id'    => $appid,
     'subject'    => $subject,
     'message'    => $notimsg,
     'app_stage'    => '0',
     'status'    => '0',
     'mail_status'    => ($response=='success') ? '0' : '1',
     'crtdate'    => date('Y-m-d H:i:s'),
     'crtby'     => $this->usrID,
     'crtname'     => 'applicant'
      );

$upStatusnoti = $this->db->insert('application_notification',$emailInfo);
// End Alert & Notification Code
    redirect($this->input->post('merchant_furl_id'));
  }
} 
else 
{
    echo 'An error occured. Contact site administrator, please!';
}
} 


// Start Application - Razorpay Success & Failure
public function success_app() {
  if($this->session->userdata('usrlogged_in') !== TRUE){
      redirect('login');
    }
        $data['title']              = 'Checkout payment';  
        $data['callback_url']       = base_url().'applications/callback_app';
        $data['surl']               = base_url().'applications/success_app';
        $data['furl']               = base_url().'applications/failed_app';
        $data['currency_code']      = 'INR';
       // $appid = $this->uri->segment(3);
        $appid = $this->session->flashdata('appID');
    //echo $appid;
    //die;
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();




        $data['appId'] = $appid;
        $data['menu'] = 'Application';
        $data['appdetails']   = $appdet;
        $data['approvalForPayment'] = 0;
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                ); 
    $this->session->set_flashdata('msg','Application Fees has been succesfully Received');
    $this->load->view('user/payment_app',$data);
    }  
    public function failed_app() {
    
        $data['title']              = 'Checkout Failed payment';  
        $data['callback_url']       = base_url().'applications/callback_app';
        $data['surl']               = base_url().'applications/success_app';
        $data['furl']               = base_url().'applications/failed_app';
        $data['currency_code']      = 'INR';
    
     $appid = $this->session->flashdata('appid');
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
        $data['appId'] = $appid;
        $data['menu'] = 'Application';
        $data['appdetails']   = $appdet;
       
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                ); 
    $this->session->set_flashdata('msg','Applicant Details has been Saved.Payment Failed try it again.');
    $this->load->view('user/payment_app_fail',$data);
  
      //echo "fail";
      //exit();
       
    }

    // End Application - Razorpay Success & Failure

public function success() {
  if($this->session->userdata('usrlogged_in') !== TRUE){
      redirect('login');
    }
        $data['title']              = 'Checkout payment';  
        $data['callback_url']       = base_url().'applications/callback';
        $data['surl']               = base_url().'applications/success';;
        $data['furl']               = base_url().'applications/failed';;
        $data['currency_code']      = 'INR';
       // $appid = $this->uri->segment(3);
        $appid = $this->session->flashdata('appid');
        $appdet = $this->db->get_where('application' , array('id'=>$appid))->result();
        $data['appId'] = $appid;
        $data['menu'] = 'Application';
        $data['appdetails']   = $appdet;
        $data['approvalForPayment'] = 0;
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                ); 
    $this->session->set_flashdata('msg','Payment succesfull');
    $this->load->view('user/payment',$data);
    }  
    public function failed() {
      echo "fail";
      exit();
        $data['title'] = 'Razorpay Failed | TechArise';  
        echo "<h4>Your transaction got Failed</h4>";            
        echo "<br/>";
        echo "Transaction ID: ".$this->session->flashdata('razorpay_payment_id');
        echo "<br/>";
        echo "Order ID: ".$this->session->flashdata('merchant_order_id');
    }


  function application_msg(){
     if($this->session->userdata('usrlogged_in') !== TRUE){
      redirect('login');
    }
    
       $appid = $this->uri->segment(3);
       //echo $appid;
        $appdet = $this->db->get_where('application_comment' , array('application_id'=>$appid))->result();
        //print_r($appdet);

    $data['menu'] = 'Application_msg';
    $data['appdetails']   = $appdet;
 
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                );

    $this->load->view('user/application_msg',$data);
  }


 function application_agree()
 {
     if($this->session->userdata('usrlogged_in') !== TRUE)
     {
        redirect('login');
     }
      
    $data['menu'] = 'Application_agreement';
  //$data['appdetails']   = $appdet;
 
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                             'user/js/multislider.js',
                             'user/js/bootstrap.4.4.1.min.js'
                                );


    if(isset($_POST['btnsearch'])){
  $searchfi = $this->input->post('searchfi'); 
//echo $searchfi;
//die;
    $data['pro_agree'] = $this->_masters->prod_agree_search('m_product',$searchfi);
}
else{
      $data['pro_agree'] = $this->_masters->prod_agree('m_product');
}



    //$data['pro_agree'] = $this->_masters->prod_agree('m_product');
    //print_r($data['pro_agree']);
    $this->load->view('user/application_agree',$data);
  }




  function img_upload($folderName){
        $config['upload_path'] = './upload/'.$folderName.'/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        $config['max_size'] = 20000000000000;
        $config['max_width'] = 1500000000000;
        $config['max_height'] = 150000000000;

 // print_r(pathinfo($_FILES[$folderName]['name']);
  $ext = pathinfo($_FILES[$folderName]['name'], PATHINFO_EXTENSION);
  $filename = rand(10000, 990000) . '_' . time() . '.' . $ext;
  $config['file_name'] = $filename;

  $this->load->library('upload', $config);
  $this->upload->initialize($config);

  $response = '';
  // print_r($folderName);
        if (!$this->upload->do_upload($folderName)) {
            $error = array('error' => $this->upload->display_errors());
             // print_r($error);
     $response = NULL;
        } else {
            $data = array('image_metadata' => $this->upload->data());
         // print_r($data);
     $response = $filename;
       // sleep(10); 
        }      
   return $response;
  }

//  function application_save()
// {

//     // echo "application_save";
//     // print_r($this->input->post());
//     // die();

//     // if(!empty($this->input->post('off_international_membership')) and !empty($this->input->post('off_prog_arranged_foreign_tourist')) and !empty($this->input->post('off_promote_domestic_activity')))
//     // {}
 

// if($this->input->post('product_id')==4 || $this->input->post('product_id')==7)
// {
//    $distt_id = $this->input->post('org_district_id');
//     $dist_id = $distt_id[0];
//      // echo "Test ==> org_district_id" .  $dist_id;
// }
// else
// {
//  $dist_id = $this->input->post('org_loc_district_id');
//   // echo "Test ==> org_loc_district_id" .  $dist_id;   
// }

//  $prodd = $this->input->post('product_id');
//    $countquery=$this->db->query("select count(*)`total` from application where is_confirmed='1' and product_id='".$prodd."'");
//                           $query_cnt = $countquery->result();                         
//                           $total_applicant =$query_cnt[0]->total;
//                           $newtotal=($total_applicant+1);

//         $pan=$this->input->post('pan_number');
//         $saveCert = array(
//           'applicant_name'  => $this->input->post('applicant_name'),
//           'central_gov_approved'  => $this->input->post('central_gov_approved'),
//           'org_commencement_date'  => $this->input->post('org_commencement_date'),
//           'org_type_id'   => $this->input->post('org_type_id'),
//           'category_type'   => $this->input->post('category_type'),
//           'acg_id'   => $newtotal,
//           'proprietor_name'     => $this->input->post('proprietor_name'),
//           'gst_number'    => !empty($this->input->post('gst_number')) ? $this->input->post('gst_number') : NULL,
//           'pan_number'    => !empty($this->input->post('pan_number')) ? $this->input->post('pan_number') : NULL,
//           'website_name'    => !empty($this->input->post('website_name')) ? $this->input->post('website_name') : NULL,
//           'official_email'    => $this->input->post('official_email'),
//           'member_recognised_trade'  => $this->input->post('member_recognised_trade'),
//           'member_recognised_trade_details'  => $this->input->post('member_recognised_trade_details'),
//          /* 'org_add1'   => !empty($this->input->post('org_add1')) ? $this->input->post('org_add1') : NULL,
//           'org_add2'     => !empty($this->input->post('org_add2')) ? $this->input->post('org_add2') : NULL,
//           'org_district_id'     => !empty($this->input->post('org_district_id')) ? $this->input->post('org_district_id') : NULL,
//           'org_taluk'     => !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : NULL,
//           'org_city'  => !empty($this->input->post('org_city')) ? $this->input->post('org_city') : NULL,
//           'org_pincode_id'  => !empty($this->input->post('org_pincode_id')) ? $this->input->post('org_pincode_id') : NULL,
//           'org_mobile'  => !empty($this->input->post('org_mobile')) ? $this->input->post('org_mobile') : NULL,*/
//           'org_add1'   => "NULL",
//           'org_add2'     =>  "NULL",
//           'org_district_id'     =>  "NULL",
//           'org_taluk'     =>  "NULL",
//           'org_city'  =>  "NULL",
//           'org_pincode_id'  =>  "NULL",
//           'org_mobile'  =>  "NULL",
//           'org_loc_add1'  => !empty($this->input->post('org_loc_add1')) ? $this->input->post('org_loc_add1') : NULL,
//           'org_loc_add2'=> !empty($this->input->post('org_loc_add2')) ? $this->input->post('org_loc_add2') : NULL,
//           'org_loc_district_id'     => !empty($this->input->post('org_loc_district_id')) ? $this->input->post('org_loc_district_id') : NULL,
//           'org_loc_taluk_id'     => !empty($this->input->post('org_loc_taluk_id')) ? $this->input->post('org_loc_taluk_id') : NULL,
//           // 'org_loc_taluk_id'     => !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : NULL,          
//           // 'org_loc_taluk_id'  => !empty($this->input->post('org_loc_taluk_id')) ? $this->input->post('org_loc_taluk_id') : NULL,
//           'org_loc_city'     => !empty($this->input->post('org_loc_city')) ? $this->input->post('org_loc_city') : NULL,
//           'org_loc_pincode_id'     => !empty($this->input->post('org_loc_pincode_id')) ? $this->input->post('org_loc_pincode_id') : NULL,
//           'org_loc_mobile'     => !empty($this->input->post('org_loc_mobile')) ? $this->input->post('org_loc_mobile') : NULL,
//           'org_loc_telephone'     => !empty($this->input->post('org_loc_telephone')) ? $this->input->post('org_loc_telephone') : NULL,
//           'org_loc_landmark'     => $this->input->post('org_loc_landmark'),
//           'org_total_build_sqft'     => $this->input->post('org_total_build_sqft'),
//           //'org_acc_toilet_mtrs'     => $this->input->post('org_acc_toilet_mtrs'),
//           'off_activity'     => $this->input->post('off_activity'),
//           'off_international_membership'     => $this->input->post('off_international_membership'),
//           'off_international_membership_details'     => $this->input->post('off_international_membership_details'),
//           'off_promote_domestic_activity'     => $this->input->post('off_promote_domestic_activity'),
//           'off_prog_arranged_foreign_tourist'     => $this->input->post('off_prog_arranged_foreign_tourist'),
//           'off_prog_arranged_foreign_tourist_details'     => $this->input->post('off_prog_arranged_foreign_tourist_details'),      
//            'district_id'     => $dist_id,
//           'register_id'     => $this->usrID,
//           'product_id'     => $this->input->post('product_id'),
//            'paytm_orderid'     => $this->input->post('pg_orderid'),
//           'is_confirmed'     => '0',
//           'app_status'     => '1',
//           'stage_id'     => 0,
//           // 'isdraft'     =>0,
//           'other_office_count' =>$this->input->post('Nuumber_offices'),
//           'confirmed_date'    => date('Y-m-d H:i:s'),
//           'crtdate'    => date('Y-m-d H:i:s'),
//           'document_type'=>!empty($this->input->post('file_type')) ? $this->input->post('file_type') : 0,
//         'org_shop_date'=>!empty($this->input->post('org_shop_date')) ? $this->input->post('org_shop_date') : NULL,
//         'trade_lic_date'=>$this->input->post('trade_lic_date')  ,
//         'member_kts'=>$this->input->post('member_kts')  ,
//           'visitor_capacity'=>!empty($this->input->post('visitor_capacity')) ? $this->input->post('visitor_capacity') : 0,
//             'total_hotel_build_area'=>!empty($this->input->post('total_hotel_build_area')) ? $this->input->post('total_hotel_build_area') : 0,
//             'hotel_name'=>!empty($this->input->post('hotel_name')) ? $this->input->post('hotel_name') : NULL,
//             'restaurant_type'=>!empty($this->input->post('restaurant_type')) ? $this->input->post('restaurant_type') : NULL,        
//             'org_registration_date'=>!empty($this->input->post('org_registration_date')) ? $this->input->post('org_registration_date') : 0 ,
//             'owner_name'=>!empty($this->input->post('ownername')) ? $this->input->post('ownername') : null,
//             'no_bed'=>!empty($this->input->post('no_beds')) ? $this->input->post('no_beds') : 0,
//             'owner_mobile'=>!empty($this->input->post('mobileNo')) ? $this->input->post('mobileNo') : 0,
//             'owner_email'=>!empty($this->input->post('owner_email')) ? $this->input->post('owner_email') : null,
//             'amusement_commencement_date'=>!empty($this->input->post('amusement_commencement_date')) ? $this->input->post('amusement_commencement_date') : 0,
//             'cat_restaurant'=>!empty($this->input->post('cat_restaurant')) ? $this->input->post('cat_restaurant') : 0,
//             'no_rooms'=>!empty($this->input->post('no_rooms')) ? $this->input->post('no_rooms') : 0,
//             'email_id_hotel'=>!empty($this->input->post('email_id_hotel')) ? $this->input->post('email_id_hotel') : 0,
//             'hotel_mbl_no'=>!empty($this->input->post('hotel_mbl_no')) ? $this->input->post('hotel_mbl_no') : 0,
//             'hotel_resort'=>!empty($this->input->post('hotel_resort')) ? $this->input->post('hotel_resort') : 0,
//             'legal_name'=>!empty($this->input->post('legal_name')) ? $this->input->post('legal_name') : 0,
//             'outsourced_emp_female'=>!empty($this->input->post('outsourced_emp_female')) ? $this->input->post('outsourced_emp_female') : 0,
//             'outsourced_emp_male'=>!empty($this->input->post('outsourced_emp_male')) ? $this->input->post('outsourced_emp_male') : 0,
//             'permanent_emp_female'=>!empty($this->input->post('permanent_emp_female')) ? $this->input->post('permanent_emp_female') : 0,
//             'permanent_emp_male'=>!empty($this->input->post('permanent_emp_male')) ? $this->input->post('permanent_emp_male') : 0,
//             'certificate_name'=>!empty($this->input->post('certificate_name')) ? $this->input->post('certificate_name') : 0,
//              'member_recognised_trade_other'=>!empty($this->input->post('member_recognised_trade_other')) ? $this->input->post('member_recognised_trade_other') : 0,
//             'new_taluk'=>!empty($this->input->post('new_taluk')) ? $this->input->post('new_taluk') : null,
//             'new_district'=>!empty($this->input->post('new_district')) ? $this->input->post('new_district') : null,
//             'org_state'=>!empty($this->input->post('org_state')) ? $this->input->post('org_state') : null,
//             'entity_name'=>!empty($this->input->post('entity_name')) ? $this->input->post('entity_name') : 0,
//             'guest_name'=>!empty($this->input->post('guest_name')) ? $this->input->post('guest_name') : 0,
//             'org_license_date'  => $this->input->post('org_license_date'),
//             'guest_mbl_no'=>!empty($this->input->post('guest_mbl_no')) ? $this->input->post('guest_mbl_no') : 0,
//             'email_id_guest'=>!empty($this->input->post('email_id_guest')) ? $this->input->post('email_id_guest') : 0,
//             'total_guest_build_area'=>!empty($this->input->post('total_guest_build_area')) ? $this->input->post('total_guest_build_area') : 0,
//         );

 
//       //print_r($this->input->post('file_type'));
//       // print_r($_FILES);
//        // print_r("Hi".$_FILES);

      
//           foreach($_FILES as $key=>$val): //upload files
//              if($val['size'] > 0):
//                 $fileName = $this->img_upload($key);
//                  // print_r("test new ==>".$fileName);
//             if(!empty($fileName)):
//                 $saveCert[$key] = $fileName;
//             endif;
//              endif;
//           endforeach;

//           // echo "application_save";
//          // print_r("test".$saveCert);
//          // die();
  
//            //testing code
//         //testing code
//         $exist_id = !empty($this->input->post('insid_draft')) ? $this->input->post('insid_draft') : '' ;

//         if($exist_id == "" || $exist_id == 'undefined' )
//         {

//           // main correct code
         
//           $upStatus = $this->db->insert('application',$saveCert);
//             // echo $this->db->last_query();
//           $insert_id = $this->db->insert_id();
//            //print_r("testing==>".$insert_id);
//           echo "Application Saved Successfully/";


//           $org_loc_mobilef = $this->input->post('org_loc_mobile');
//           $official_emailf = $this->input->post('official_email');
//           $applicant_namef = $this->input->post('applicant_name');

//           $disttid = $dist_id;
//           $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
//           $appid = $insert_id.$dist_name;


//           $upAppData = array(
//                   'application_id'  => $appid
//                   );
//           $this->db->where('id',$insert_id);
//           $upstatusa = $this->db->update('application',$upAppData);

//           //Here we are including vehicles details
//             $cnt_reg_no=count($this->input->post('registration_no'));
//             $cnt_reg_name=count($this->input->post('registration_name'));
//             $cnt_reg_permit=count($this->input->post('tourist_permit'));
//             $cnt_reg_permit_date=count($this->input->post('tourist_permit_date'));
//             $cnt_reg_vehicle_type=count($this->input->post('vehicle_type'));
//             $cur_permit_type=count($this->input->post('permit_type'));
//             //print_r($this->input->post('tourist_permit_date'));
            
//             $vehicletype=$this->input->post('vehicle_type');
//             $reg_no=$this->input->post('registration_no');
//             $reg_name=$this->input->post('registration_name');
//             $reg_permit=$this->input->post('tourist_permit');
//             $reg_permit_date=$this->input->post('tourist_permit_date');
//             $reg_end_date=$this->input->post('tourist_permit_end_date');
//             $veh_other=$this->input->post('othervalue');
//             $permit=$this->input->post('permit_type');

//             for($i=0;$i<$cnt_reg_no;$i++)
//             {
//                     if($reg_no[$i]!=null)
//                     {
//                         $vehicledetails = array(
//                         'app_id'  => $insert_id,
//                         'no_of_vehicle'  => $this->input->post('veh_count'),
//                         'vehicle_type'  => $vehicletype[$i],
//                         'registeration_no' => $reg_no[$i],
//                         'regitration_name' =>$reg_name[$i],
//                         'tourist_permit' => $reg_permit[$i],
//                         'permit_date' => $reg_permit_date[$i],
//                         'end_date'=> $reg_end_date[$i],
//                         'other_vehicle'=>$veh_other[$i],
//                         'permit_type'=>$permit[$i]
//                         );
//                         $vehicle_details = $this->db->insert('vehicledetails',$vehicledetails);
                        
//                       }
//             }
//             $accommodation_type=$this->input->post('accommodation_type');
//             $accommodation_othertype=$this->input->post('accommodation_othertype');
//             $accommodation_count=count($accommodation_type); 
//             // print_r($accommodation_count);               
//             if($accommodation_count>0)
//             {
//                 for($i=0;$i<$accommodation_count;$i++)
//                 {
//                     if($accommodation_type[$i]=='other'){
// $accomodation_details = array(
//                         'app_id'  => $insert_id,
//                         'accommodation_type'  => $accommodation_type[$i],
//                         'other_facility'=>$accommodation_othertype[0]
//                       );
//                         }
//                         else{
//                           $accomodation_details = array(
//                         'app_id'  => $insert_id,
//                         'accommodation_type'  => $accommodation_type[$i]
                        
//                       );  
//                         }

//                      $upStatus = $this->db->insert('hotel_accommodation',$accomodation_details);
//                 }
//             }
//             $facility_available=$this->input->post('facility_available');
//             $facility_othertype=$this->input->post('otherfacility_available');
//             $facility_count=count($facility_available);
//             if($facility_count>0)
//             {                   
//                 for($i=0;$i<$facility_count;$i++)
//                 {

//                     if($facility_available[$i]=='other'){
//                         $accomodation_details = array(
//                         'app_id'  => $insert_id,
//                         'facility_type'  => $facility_available[$i],
//                          'other_facility'=>$facility_othertype[0]
//                       );


//                     }
//                     else{
//                         $accomodation_details = array(
//                         'app_id'  => $insert_id,
//                         'facility_type'  => $facility_available[$i]
//                       );

//                     }
                    
//                     $upStatus = $this->db->insert('hotel_facility',$accomodation_details);
//                 }
//             }
//             /*
//               if($upStatus):
//                       $this->session->set_flashdata('msg','Record updated successfully.');  
//               else:
//                       $this->session->set_flashdata('msg','Record Not updated.'); 
//               endif;

//               redirect('dashboard');

//               */

//           $officecount= $this->input->post('Nuumber_offices');
                    
//           // other office address
//           $org_add1      = $this->input->post('org_add1');
//           $org_add2        = $this->input->post('org_add2');  
//           $org_district_id = $this->input->post('org_district_id');
//           $org_taluk     = $this->input->post('org_taluk');
//           $org_city    = $this->input->post('org_city');
//           $org_pincode_id  = $this->input->post('org_pincode_id');
//           $org_mobile    = $this->input->post('org_mobile');
//           $email_hotel= !empty($this->input->post('emailhotel')) ? $this->input->post('emailhotel') : NULL;
//           $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
//           $tot_addr = count($org_add1);
//            $org_add1      = $this->input->post('org_add1');
//                 $org_add2        = $this->input->post('org_add2');  
//                 $org_district_id = $this->input->post('org_district_id');
//                 $org_taluk     = $this->input->post('org_taluk');
//                 $org_city    = $this->input->post('org_city');
//                 $org_pincode_id  = $this->input->post('org_pincode_id');
//                 $org_mobile    = $this->input->post('org_mobile');
            
//                 $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
//                 $tot_addr = count($org_add1);
                
//                 if($this->input->post('product_id')<=3)
//                 {
//                      if($officecount>0)
//                      {
//                             for($i=0;$i<$tot_addr;$i++)
//                             {
//                               $other_off_addr = array(
//                                 'application_id'  => $insert_id,
//                                 'other_off_addr1'  => $org_add1[$i],
//                                 'other_off_addr2'  => $org_add2[$i],
//                                 'other_off_state' => "KA",
//                                 'other_off_district_id' =>$org_district_id[$i],
//                                 'other_off_taluk' => $org_taluk[$i],
//                                 'other_off_city' => $org_city[$i],
//                                 'other_off_pincode_id' => $org_pincode_id[$i],
//                                 'other_off_contact' =>$org_mobile[$i]
//                               );
//                              //print_r( $other_off_addr);
//                              $upStatus = $this->db->insert('other_offices',$other_off_addr);
//                             }
//                      }  
//                 }               
//                 else if($this->input->post('product_id')==4 || $this->input->post('product_id')==5 || $this->input->post('product_id')==6 || $this->input->post('product_id')==7)
//                 {
//                     for($i=0;$i<$tot_addr;$i++)
//                     {
//                       $other_off_addr = array(
//                         'application_id'  => $insert_id,
//                         'other_off_addr1'  => $org_add1[$i],
//                         'other_off_addr2'  => $org_add2[$i],
//                         'other_off_state' => "KA",
//                         'other_off_district_id' =>$org_district_id[$i],
//                         'other_off_taluk' => $org_taluk[$i],
//                         'other_off_city' => $org_city[$i],
//                         'other_off_pincode_id' => $org_pincode_id[$i],
//                         'other_off_contact' =>$org_mobile[$i],
//                         'other_email'=>$email_hotel[$i],
//                         'org_landmark'=>$org_landmark[$i]
//                       );
//                      //print_r( $other_off_addr);
//                      $upStatus = $this->db->insert('other_offices',$other_off_addr);
//                     }
//                 }
//                 if($upStatus):
//                 // Start Alert & Notification Code

//                 // Mail For Alert

//                   $mail_config = $this->config->item('mail_conf');
//                   $user = $mail_config['username'];
//                   $pass = $mail_config['password'];
//                   $url  = $mail_config['url'];
//                   $fromname  = $mail_config['from'];
//                   $fromid  = $mail_config['admin_mail'];
                        
//                 $body = "<h3>Dear ".$applicant_namef.",</h3><p><br> You have Successfully Saved the Application Details in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
//                 $bodya=str_replace(';', ',', $body);
//                 $bodyb=str_replace(' ', '%20', $bodya);
//                 $body = str_replace(array("\n", "\r"), '', $bodyb);

//                 $subject = "Application Details Saved";
//                 $fromname = "support@karnatakatourism.org";
//                    $params = array(
//                       'api_user'  => $user,
//                       'api_key'   => $pass,
//                       'to'        => $official_emailf,
//                       'subject'   => $subject,
//                       'html'      => $body,
//                       'text'      => '',
//                       'from'      => $fromname
//                   ); 

//                   $ton=str_replace(' ', '%20', $params['to']);
//                   $subjectn=str_replace(' ', '%20', $params['subject']);
//                   $htmln=str_replace(' ', '%20', $params['html']);
//                   $fromn=str_replace(' ', '%20', $params['from']);

//                   $curl = curl_init();
//                   $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;
//                   $headers = array(
//                             "MIME-Version: 1.0\r\n",
//                             "Content-type: text/html; application/json;charset=\"utf-8\"",
//                             "Cache-Control: no-cache",
//                             "Pragma: no-cache"
//                         ); 
//                   curl_setopt_array($curl, array(
//                   CURLOPT_POST=>1,
//                   CURLOPT_URL =>$url_value,
//                   CURLOPT_RETURNTRANSFER => true,
//                   CURLOPT_ENCODING => '',
//                   CURLOPT_MAXREDIRS => 10,
//                   CURLOPT_TIMEOUT => 0,
//                   CURLOPT_FOLLOWLOCATION => true,
//                   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//                   CURLOPT_CUSTOMREQUEST => 'POST',
//                   CURLOPT_HEADER=>false,
//                   CURLOPT_SSL_VERIFYPEER=> false,
//                   CURLOPT_HTTPHEADER => array(
//                     'Authorization: Bearer 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',$headers
//                   ),
//                 ));

//                   $response = curl_exec($curl);
//                   $err = curl_error($curl);
//                   curl_close($curl);  
//                   if ($err) {
//                     echo "cURL Error #:" . $err;  
//                   } else {
//                        $respMsg =  json_decode($response);
//                        $response = $respMsg->message;       
//                   }




//                   /*$request =  $url.'api/mail.send.json';

//                   $session = curl_init($request);
//                   curl_setopt ($session, CURLOPT_POST, true);
//                         curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
//                   curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
//                   curl_setopt($session, CURLOPT_HEADER, false);
//                         curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
//                   curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

//                   // obtain response
//                   $response = curl_exec($session); 
//                   curl_close($session);
//                   $respMsg =  json_decode($response);
//                   $response = $respMsg->message;*/
                  

//                       //-----insert into email status
//                         $notimsg = "Your  Application Details has been Saved and Moved to Application Payment.";
//                         $emailInfo = array(
//                          'register_id'    => $this->usrID,
//                           'application_id'    => $insert_id,
//                            'subject'    => $subject,
//                             'message'    => $notimsg,
//                             'app_stage'    => '0',
//                               'status'    => '0',
//                               'mail_status'    => ($response=='success') ? '0' : '1',
//                               'crtdate'    => date('Y-m-d H:i:s'),
//                               'crtby'     => $this->usrID,
//                               'crtname'     => 'applicant'

//                           );

//                         $upStatusnoti = $this->db->insert('application_notification',$emailInfo);

// // END MAIL NOTI
//                         $productt_idd = $this->input->post('product_id');
//          $productt_name = $this->db->get_where('m_product', array('id' => $productt_idd))->row()->name;
//           $appid = $insert_id.$dist_name;
//                   $mail_config = $this->config->item('mail_conf');
//                   $user = $mail_config['username'];
//                   $pass = $mail_config['password'];
//                   $url  = $mail_config['url'];
//                   $fromname  = $mail_config['from'];
//                   $fromid  = $mail_config['admin_mail'];
                        
//                 $body = "<h3>Dear Team,</h3><p><br> You have Received the Application Details - ".$applicant_namef." - ".$productt_name." in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
//                 $bodya=str_replace(';', ',', $body);
//                 $bodyb=str_replace(' ', '%20', $bodya);
//                 $body = str_replace(array("\n", "\r"), '', $bodyb);

//                 $subject = "KTTF_New_Application";
//                 $fromname = "support@karnatakatourism.org";
// $tomaill=array('chandrasekar.t@globalsinc.com','sivakumar.p@globalsinc.com');
// $tolen = count($tomaill);
// for($m=0;$m<$tolen;$m++){
//                 //$tomaill = "chandrasekar.t@globalsinc.com";
//                    $params = array(
//                       'api_user'  => $user,
//                       'api_key'   => $pass,
//                       'to'        => $tomaill[$m],
//                       'subject'   => $subject,
//                       'html'      => $body,
//                       'text'      => '',
//                       'from'      => $fromname
//                   ); 

//                   $ton=str_replace(' ', '%20', $params['to']);
//                   $subjectn=str_replace(' ', '%20', $params['subject']);
//                   $htmln=str_replace(' ', '%20', $params['html']);
//                   $fromn=str_replace(' ', '%20', $params['from']);

//                   $curl = curl_init();
//                   $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;
//                   $headers = array(
//                             "MIME-Version: 1.0\r\n",
//                             "Content-type: text/html; application/json;charset=\"utf-8\"",
//                             "Cache-Control: no-cache",
//                             "Pragma: no-cache"
//                         ); 
//                   curl_setopt_array($curl, array(
//                   CURLOPT_POST=>1,
//                   CURLOPT_URL =>$url_value,
//                   CURLOPT_RETURNTRANSFER => true,
//                   CURLOPT_ENCODING => '',
//                   CURLOPT_MAXREDIRS => 10,
//                   CURLOPT_TIMEOUT => 0,
//                   CURLOPT_FOLLOWLOCATION => true,
//                   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//                   CURLOPT_CUSTOMREQUEST => 'POST',
//                   CURLOPT_HEADER=>false,
//                   CURLOPT_SSL_VERIFYPEER=> false,
//                   CURLOPT_HTTPHEADER => array(
//                     'Authorization: Bearer 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',$headers
//                   ),
//                 ));

//                   $response = curl_exec($curl);
//                   $err = curl_error($curl);
//                   curl_close($curl);  
//                   if ($err) {
//                     echo "cURL Error #:" . $err;  
//                   } else {
//                        $respMsg =  json_decode($response);
//                        $response = $respMsg->message;       
//                   }
//                 }

// // END MAIL NOTI


//                         // End Alert & Notification Code

//                             echo "Application Saved Successfully/".$insert_id."/".$org_loc_mobilef."/".$official_emailf."/".$applicant_namef;     
//                           else:    
//                             echo "Application Not Updated";
//                           endif;
//     }

   
//      else
//         {
//               // echo "else if";
//           // echo "new Application Not Updated";
//            // echo "else if";
//               $this->db->where('id',$exist_id);
//                 //print_r("Hello".$saveCert);
//                 // die();
//               $upStatus = $this->db->update('application',$saveCert);
//                //echo $this->db->last_query();
//               $insert_id = $exist_id;
//               // print_r("Hello".$insert_id);
//               if(!empty($this->input->post('org_loc_district_id')))
//               {
//                 $org_loc_district_id =  $this->input->post('org_loc_district_id');
//                 $disttid = $org_loc_district_id;
//                 $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
//                 $appid = $insert_id.$dist_name;
//                 // print_r("Hello1".$appid);
//               } 
//               else
//               {
//                 $org_loc_district_id =  ""; 
//                 $appid = $insert_id;
//                 // print_r("Hello2".$appid);
//               }
//                $upAppData = array(
//                       'application_id'  => $appid
//                       );


//               //print_r($upAppData);die();
//               if($org_loc_district_id!='')
//               {
//                 $this->db->where('id',$insert_id);
//                 $upstatusa = $this->db->update('application',$upAppData); 
//                 // echo $this->db->last_query(); 
//                 // echo "upstatusa" .$upstatusa;
//               }

//               // other office address
//                $org_add1      = $this->input->post('org_add1');
//                 $org_add2        = $this->input->post('org_add2');  
//                 $org_district_id = $this->input->post('org_district_id');
//                 $org_taluk     = $this->input->post('org_taluk');
//                 $org_city    = $this->input->post('org_city');
//                 $org_pincode_id  = $this->input->post('org_pincode_id');
//                 $org_mobile    = $this->input->post('org_mobile');
//                 $email_hotel= !empty($this->input->post('emailhotel')) ? $this->input->post('emailhotel') : NULL;
//                 $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
//                 $tot_addr = count($org_add1);
//                 // echo $tot_addr ;
//                 // echo"alliswell";
//                 // echo( $this->input->post('product_id'));
//                 if($tot_addr>0)
//                 {
//                     $delete_add="delete from other_offices where application_id='".$insert_id."' ";
//                     $result_add=$this->db->query($delete_add);
//                     // echo  "test==>".$result_add ;
//                 }

//                 if($this->input->post('product_id')<=3)
//                 {
//                      if($officecount>0)
//                      {
//                             for($i=0;$i<$tot_addr;$i++)
//                             {
//                               $other_off_addr = array(
//                                 'application_id'  => $insert_id,
//                                 'other_off_addr1'  => $org_add1[$i],
//                                 'other_off_addr2'  => $org_add2[$i],
//                                 'other_off_state' => "KA",
//                                 'other_off_district_id' =>$org_district_id[$i],
//                                 'other_off_taluk' => $org_taluk[$i],
//                                 'other_off_city' => $org_city[$i],
//                                 'other_off_pincode_id' => $org_pincode_id[$i],
//                                 'other_off_contact' =>$org_mobile[$i],
//                                 'other_email'=>$email_hotel[$i],
//                                 'org_landmark'=>$org_landmark[$i]
//                               );
//                               //print_r( $other_off_addr);
//                              $upStatus = $this->db->insert('other_offices',$other_off_addr);
//                              // echo $this->db->last_query();
//                             }
//                      }  
//                 }


//    }
// }

 function application_save()
{
    //print_r($this->input->post());

    // if(!empty($this->input->post('off_international_membership')) and !empty($this->input->post('off_prog_arranged_foreign_tourist')) and !empty($this->input->post('off_promote_domestic_activity')))
    // {}
if($this->input->post('product_id')==4)
{
   $distt_id = $this->input->post('org_district_id');
    $dist_id = $distt_id[0];
}
else
{
 $dist_id = $this->input->post('org_loc_district_id');   
}

 $prodd = $this->input->post('product_id');
   $countquery=$this->db->query("select count(*)`total` from application where is_confirmed='1' and product_id='".$prodd."'");
                          $query_cnt = $countquery->result();                         
                          $total_applicant =$query_cnt[0]->total;
                          $newtotal=($total_applicant+1);


        $saveCert = array(
          'applicant_name'  => $this->input->post('applicant_name'),
          'central_gov_approved'  => $this->input->post('central_gov_approved'),
          'org_commencement_date'  => $this->input->post('org_commencement_date'),
          'org_type_id'   => $this->input->post('org_type_id'),
          'category_type'   => $this->input->post('category_type'),
          'acg_id'   => $newtotal,
          'proprietor_name'     => $this->input->post('proprietor_name'),
          'gst_number'    => !empty($this->input->post('gst_number')) ? $this->input->post('gst_number') : NULL,
          'pan_number'    => !empty($this->input->post('pan_number')) ? $this->input->post('pan_number') : NULL,
          'website_name'    => !empty($this->input->post('website_name')) ? $this->input->post('website_name') : NULL,
          'official_email'    => $this->input->post('official_email'),
          'member_recognised_trade'  => $this->input->post('member_recognised_trade'),
          'member_recognised_trade_details'  => $this->input->post('member_recognised_trade_details'),
         /* 'org_add1'   => !empty($this->input->post('org_add1')) ? $this->input->post('org_add1') : NULL,
          'org_add2'     => !empty($this->input->post('org_add2')) ? $this->input->post('org_add2') : NULL,
          'org_district_id'     => !empty($this->input->post('org_district_id')) ? $this->input->post('org_district_id') : NULL,
          'org_taluk'     => !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : NULL,
          'org_city'  => !empty($this->input->post('org_city')) ? $this->input->post('org_city') : NULL,
          'org_pincode_id'  => !empty($this->input->post('org_pincode_id')) ? $this->input->post('org_pincode_id') : NULL,
          'org_mobile'  => !empty($this->input->post('org_mobile')) ? $this->input->post('org_mobile') : NULL,*/
          'org_add1'   => "NULL",
          'org_add2'     =>  "NULL",
          'org_district_id'     =>  "NULL",
          'org_taluk'     =>  "NULL",
          'org_city'  =>  "NULL",
          'org_pincode_id'  =>  "NULL",
          'org_mobile'  =>  "NULL",
          'org_loc_add1'  => !empty($this->input->post('org_loc_add1')) ? $this->input->post('org_loc_add1') : NULL,
          'org_loc_add2'=> !empty($this->input->post('org_loc_add2')) ? $this->input->post('org_loc_add2') : NULL,
          'org_loc_district_id'     => !empty($this->input->post('org_loc_district_id')) ? $this->input->post('org_loc_district_id') : NULL,
          'org_loc_taluk_id'     => !empty($this->input->post('org_loc_taluk_id')) ? $this->input->post('org_loc_taluk_id') : NULL,
          // 'org_loc_taluk_id'     => !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : NULL,          
          // 'org_loc_taluk_id'  => !empty($this->input->post('org_loc_taluk_id')) ? $this->input->post('org_loc_taluk_id') : NULL,
          'org_loc_city'     => !empty($this->input->post('org_loc_city')) ? $this->input->post('org_loc_city') : NULL,
          'org_loc_pincode_id'     => !empty($this->input->post('org_loc_pincode_id')) ? $this->input->post('org_loc_pincode_id') : NULL,
          'org_loc_mobile'     => !empty($this->input->post('org_loc_mobile')) ? $this->input->post('org_loc_mobile') : NULL,
          'org_loc_telephone'     => !empty($this->input->post('org_loc_telephone')) ? $this->input->post('org_loc_telephone') : NULL,
          'org_loc_landmark'     => $this->input->post('org_loc_landmark'),
          'org_total_build_sqft'     => $this->input->post('org_total_build_sqft'),
          //'org_acc_toilet_mtrs'     => $this->input->post('org_acc_toilet_mtrs'),
          'off_activity'     => $this->input->post('off_activity'),
          'off_international_membership'     => $this->input->post('off_international_membership'),
          'off_international_membership_details'     => $this->input->post('off_international_membership_details'),
          'off_promote_domestic_activity'     => $this->input->post('off_promote_domestic_activity'),
          'off_prog_arranged_foreign_tourist'     => $this->input->post('off_prog_arranged_foreign_tourist'),
          'off_prog_arranged_foreign_tourist_details'     => $this->input->post('off_prog_arranged_foreign_tourist_details'),      
           'district_id'     => $dist_id,
          'register_id'     => $this->usrID,
          'product_id'     => $this->input->post('product_id'),
           'paytm_orderid'     => $this->input->post('pg_orderid'),
          'is_confirmed'     => '0',
          'app_status'     => '1',
          'stage_id'     => 0,
          'other_office_count' =>$this->input->post('Nuumber_offices'),
          'confirmed_date'    => date('Y-m-d H:i:s'),
          'crtdate'    => date('Y-m-d H:i:s'),
          'document_type'=>!empty($this->input->post('file_type')) ? $this->input->post('file_type') : 0,
        'org_shop_date'=>!empty($this->input->post('org_shop_date')) ? $this->input->post('org_shop_date') : NULL,
        'trade_lic_date'=>$this->input->post('trade_lic_date')  ,
        'member_kts'=>$this->input->post('member_kts')  ,
          'visitor_capacity'=>!empty($this->input->post('visitor_capacity')) ? $this->input->post('visitor_capacity') : 0,
            'total_hotel_build_area'=>!empty($this->input->post('total_hotel_build_area')) ? $this->input->post('total_hotel_build_area') : 0,
            'hotel_name'=>!empty($this->input->post('hotel_name')) ? $this->input->post('hotel_name') : NULL,
            'restaurant_type'=>!empty($this->input->post('restaurant_type')) ? $this->input->post('restaurant_type') : NULL,        
            'org_registration_date'=>!empty($this->input->post('org_registration_date')) ? $this->input->post('org_registration_date') : 0 ,
            'owner_name'=>!empty($this->input->post('ownername')) ? $this->input->post('ownername') : null,
            'no_bed'=>!empty($this->input->post('no_beds')) ? $this->input->post('no_beds') : 0,
            'owner_mobile'=>!empty($this->input->post('mobileNo')) ? $this->input->post('mobileNo') : 0,
            'owner_email'=>!empty($this->input->post('owner_email')) ? $this->input->post('owner_email') : null,
            'amusement_commencement_date'=>!empty($this->input->post('amusement_commencement_date')) ? $this->input->post('amusement_commencement_date') : 0,
            'cat_restaurant'=>!empty($this->input->post('cat_restaurant')) ? $this->input->post('cat_restaurant') : 0,
            'no_rooms'=>!empty($this->input->post('no_rooms')) ? $this->input->post('no_rooms') : 0,
            'email_id_hotel'=>!empty($this->input->post('email_id_hotel')) ? $this->input->post('email_id_hotel') : 0,
            'hotel_mbl_no'=>!empty($this->input->post('hotel_mbl_no')) ? $this->input->post('hotel_mbl_no') : 0,
            'hotel_resort'=>!empty($this->input->post('hotel_resort')) ? $this->input->post('hotel_resort') : 0,
            'legal_name'=>!empty($this->input->post('legal_name')) ? $this->input->post('legal_name') : 0,
            'outsourced_emp_female'=>!empty($this->input->post('outsourced_emp_female')) ? $this->input->post('outsourced_emp_female') : 0,
            'outsourced_emp_male'=>!empty($this->input->post('outsourced_emp_male')) ? $this->input->post('outsourced_emp_male') : 0,
            'permanent_emp_female'=>!empty($this->input->post('permanent_emp_female')) ? $this->input->post('permanent_emp_female') : 0,
            'permanent_emp_male'=>!empty($this->input->post('permanent_emp_male')) ? $this->input->post('permanent_emp_male') : 0,
            'certificate_name'=>!empty($this->input->post('certificate_name')) ? $this->input->post('certificate_name') : 0,
             'member_recognised_trade_other'=>!empty($this->input->post('member_recognised_trade_other')) ? $this->input->post('member_recognised_trade_other') : 0,
            'new_taluk'=>!empty($this->input->post('new_taluk')) ? $this->input->post('new_taluk') : null,
            'new_district'=>!empty($this->input->post('new_district')) ? $this->input->post('new_district') : null,
            'org_state'=>!empty($this->input->post('org_state')) ? $this->input->post('org_state') : null,
            'entity_name'=>!empty($this->input->post('entity_name')) ? $this->input->post('entity_name') : 0,
            'guest_name'=>!empty($this->input->post('guest_name')) ? $this->input->post('guest_name') : 0,
            'org_license_date'  => $this->input->post('org_license_date'),
            'guest_mbl_no'=>!empty($this->input->post('guest_mbl_no')) ? $this->input->post('guest_mbl_no') : 0,
            'email_id_guest'=>!empty($this->input->post('email_id_guest')) ? $this->input->post('email_id_guest') : 0,
            'total_guest_build_area'=>!empty($this->input->post('total_guest_build_area')) ? $this->input->post('total_guest_build_area') : 0,
        );
        // print_r($_FILES);

        
          foreach($_FILES as $key=>$val): //upload files
             if($val['size'] > 0):
                $fileName = $this->img_upload($key);
                //print_r($fileName);
            if(!empty($fileName)):
                $saveCert[$key] = $fileName;
            endif;
             endif;
          endforeach;

        $exist_id = !empty($this->input->post('insid_draft')) ? $this->input->post('insid_draft') : '' ;

        if($exist_id == "" || $exist_id == 'undefined' )
        {
          $upStatus = $this->db->insert('application',$saveCert);
           //echo $this->db->last_query();
          $insert_id = $this->db->insert_id();

          $org_loc_mobilef = $this->input->post('org_loc_mobile');
          $official_emailf = $this->input->post('official_email');
          $applicant_namef = $this->input->post('applicant_name');

          $disttid = $dist_id;
          $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
          $appid = $insert_id.$dist_name;


          $upAppData = array(
                  'application_id'  => $appid
                  );
          $this->db->where('id',$insert_id);
          $upstatusa = $this->db->update('application',$upAppData);

          //Here we are including vehicles details
            $cnt_reg_no=count($this->input->post('registration_no'));
            $cnt_reg_name=count($this->input->post('registration_name'));
            $cnt_reg_permit=count($this->input->post('tourist_permit'));
            $cnt_reg_permit_date=count($this->input->post('tourist_permit_date'));
            $cnt_reg_vehicle_type=count($this->input->post('vehicle_type'));
            $cur_permit_type=count($this->input->post('permit_type'));
            //print_r($this->input->post('tourist_permit_date'));
            
            $vehicletype=$this->input->post('vehicle_type');
            $reg_no=$this->input->post('registration_no');
            $reg_name=$this->input->post('registration_name');
            $reg_permit=$this->input->post('tourist_permit');
            $reg_permit_date=$this->input->post('tourist_permit_date');
            $reg_end_date=$this->input->post('tourist_permit_end_date');
            $veh_other=$this->input->post('othervalue');
            $permit=$this->input->post('permit_type');

            for($i=0;$i<$cnt_reg_no;$i++)
            {
                    if($reg_no[$i]!=null)
                    {
                        $vehicledetails = array(
                        'app_id'  => $insert_id,
                        'no_of_vehicle'  => $this->input->post('veh_count'),
                        'vehicle_type'  => $vehicletype[$i],
                        'registeration_no' => $reg_no[$i],
                        'regitration_name' =>$reg_name[$i],
                        'tourist_permit' => $reg_permit[$i],
                        'permit_date' => $reg_permit_date[$i],
                        'end_date'=> $reg_end_date[$i],
                        'other_vehicle'=>$veh_other[$i],
                        'permit_type'=>$permit[$i]
                        );
                        $vehicle_details = $this->db->insert('vehicledetails',$vehicledetails);
                        
                      }
            }
            $accommodation_type=$this->input->post('accommodation_type');
            $accommodation_othertype=$this->input->post('accommodation_othertype');
            $accommodation_count=count($accommodation_type); 
            // print_r($accommodation_count);               
            if($accommodation_count>0)
            {
                for($i=0;$i<$accommodation_count;$i++)
                {
                    if($accommodation_type[$i]=='other'){
$accomodation_details = array(
                        'app_id'  => $insert_id,
                        'accommodation_type'  => $accommodation_type[$i],
                        'other_facility'=>$accommodation_othertype[0]
                      );
                        }
                        else{
                          $accomodation_details = array(
                        'app_id'  => $insert_id,
                        'accommodation_type'  => $accommodation_type[$i]
                        
                      );  
                        }

                     $upStatus = $this->db->insert('hotel_accommodation',$accomodation_details);
                }
            }
            $facility_available=$this->input->post('facility_available');
            $facility_othertype=$this->input->post('otherfacility_available');
            $facility_count=count($facility_available);
            if($facility_count>0)
            {                   
                for($i=0;$i<$facility_count;$i++)
                {

                    if($facility_available[$i]=='other'){
                        $accomodation_details = array(
                        'app_id'  => $insert_id,
                        'facility_type'  => $facility_available[$i],
                         'other_facility'=>$facility_othertype[0]
                      );


                    }
                    else{
                        $accomodation_details = array(
                        'app_id'  => $insert_id,
                        'facility_type'  => $facility_available[$i]
                      );

                    }
                    
                    $upStatus = $this->db->insert('hotel_facility',$accomodation_details);
                }
            }
            /*
              if($upStatus):
                      $this->session->set_flashdata('msg','Record updated successfully.');  
              else:
                      $this->session->set_flashdata('msg','Record Not updated.'); 
              endif;

              redirect('dashboard');

              */

          $officecount= $this->input->post('Nuumber_offices');
                    
          // other office address
          $org_add1      = $this->input->post('org_add1');
          $org_add2        = $this->input->post('org_add2');  
          $org_district_id = $this->input->post('org_district_id');
          $org_taluk     = $this->input->post('org_taluk');
          $org_city    = $this->input->post('org_city');
          $org_pincode_id  = $this->input->post('org_pincode_id');
          $org_mobile    = $this->input->post('org_mobile');
          $email_hotel= !empty($this->input->post('emailhotel')) ? $this->input->post('emailhotel') : NULL;
          $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
          $tot_addr = count($org_add1);
           $org_add1      = $this->input->post('org_add1');
                $org_add2        = $this->input->post('org_add2');  
                $org_district_id = $this->input->post('org_district_id');
                $org_taluk     = $this->input->post('org_taluk');
                $org_city    = $this->input->post('org_city');
                $org_pincode_id  = $this->input->post('org_pincode_id');
                $org_mobile    = $this->input->post('org_mobile');
            
                $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
                $tot_addr = count($org_add1);
                
                if($this->input->post('product_id')<=3)
                {
                     if($officecount>0)
                     {
                            for($i=0;$i<$tot_addr;$i++)
                            {
                              $other_off_addr = array(
                                'application_id'  => $insert_id,
                                'other_off_addr1'  => $org_add1[$i],
                                'other_off_addr2'  => $org_add2[$i],
                                'other_off_state' => "KA",
                                'other_off_district_id' =>$org_district_id[$i],
                                'other_off_taluk' => $org_taluk[$i],
                                'other_off_city' => $org_city[$i],
                                'other_off_pincode_id' => $org_pincode_id[$i],
                                'other_off_contact' =>$org_mobile[$i]
                              );
                             //print_r( $other_off_addr);
                             $upStatus = $this->db->insert('other_offices',$other_off_addr);
                            }
                     }  
                }               
                else if($this->input->post('product_id')==4 || $this->input->post('product_id')==5 || $this->input->post('product_id')==6 || $this->input->post('product_id')==7)
                {
                    for($i=0;$i<$tot_addr;$i++)
                    {
                      $other_off_addr = array(
                        'application_id'  => $insert_id,
                        'other_off_addr1'  => $org_add1[$i],
                        'other_off_addr2'  => $org_add2[$i],
                        'other_off_state' => "KA",
                        'other_off_district_id' =>$org_district_id[$i],
                        'other_off_taluk' => $org_taluk[$i],
                        'other_off_city' => $org_city[$i],
                        'other_off_pincode_id' => $org_pincode_id[$i],
                        'other_off_contact' =>$org_mobile[$i],
                        'other_email'=>$email_hotel[$i],
                        'org_landmark'=>$org_landmark[$i]
                      );
                     //print_r( $other_off_addr);
                     $upStatus = $this->db->insert('other_offices',$other_off_addr);
                    }
                }
                if($upStatus):
                // Start Alert & Notification Code

                // Mail For Alert

                  $mail_config = $this->config->item('mail_conf');
                  $user = $mail_config['username'];
                  $pass = $mail_config['password'];
                  $url  = $mail_config['url'];
                  $fromname  = $mail_config['from'];
                  $fromid  = $mail_config['admin_mail'];
                        
                $body = "<h3>Dear ".$applicant_namef.",</h3><p><br> You have Successfully Saved the Application Details in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
                $bodya=str_replace(';', ',', $body);
                $bodyb=str_replace(' ', '%20', $bodya);
                $body = str_replace(array("\n", "\r"), '', $bodyb);

                $subject = "Application Details Saved";
                $fromname = "support@karnatakatourism.org";
                   $params = array(
                      'api_user'  => $user,
                      'api_key'   => $pass,
                      'to'        => $official_emailf,
                      'subject'   => $subject,
                      'html'      => $body,
                      'text'      => '',
                      'from'      => $fromname
                  ); 

                  $ton=str_replace(' ', '%20', $params['to']);
                  $subjectn=str_replace(' ', '%20', $params['subject']);
                  $htmln=str_replace(' ', '%20', $params['html']);
                  $fromn=str_replace(' ', '%20', $params['from']);

                  $curl = curl_init();
                  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;
                  $headers = array(
                            "MIME-Version: 1.0\r\n",
                            "Content-type: text/html; application/json;charset=\"utf-8\"",
                            "Cache-Control: no-cache",
                            "Pragma: no-cache"
                        ); 
                  curl_setopt_array($curl, array(
                  CURLOPT_POST=>1,
                  CURLOPT_URL =>$url_value,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_HEADER=>false,
                  CURLOPT_SSL_VERIFYPEER=> false,
                  CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer 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',$headers
                  ),
                ));

                  $response = curl_exec($curl);
                  $err = curl_error($curl);
                  curl_close($curl);  
                  if ($err) {
                    echo "cURL Error #:" . $err;  
                  } else {
                       $respMsg =  json_decode($response);
                       $response = $respMsg->message;       
                  }




                  /*$request =  $url.'api/mail.send.json';

                  $session = curl_init($request);
                  curl_setopt ($session, CURLOPT_POST, true);
                        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                  curl_setopt($session, CURLOPT_HEADER, false);
                        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                  // obtain response
                  $response = curl_exec($session); 
                  curl_close($session);
                  $respMsg =  json_decode($response);
                  $response = $respMsg->message;*/
                  

                      //-----insert into email status
                        $notimsg = "Your  Application Details has been Saved and Moved to Application Payment.";
                        $emailInfo = array(
                         'register_id'    => $this->usrID,
                          'application_id'    => $insert_id,
                           'subject'    => $subject,
                            'message'    => $notimsg,
                            'app_stage'    => '0',
                              'status'    => '0',
                              'mail_status'    => ($response=='success') ? '0' : '1',
                              'crtdate'    => date('Y-m-d H:i:s'),
                              'crtby'     => $this->usrID,
                              'crtname'     => 'applicant'

                          );

                        $upStatusnoti = $this->db->insert('application_notification',$emailInfo);

// END MAIL NOTI
                        $productt_idd = $this->input->post('product_id');
         $productt_name = $this->db->get_where('m_product', array('id' => $productt_idd))->row()->name;
          $appid = $insert_id.$dist_name;
                  $mail_config = $this->config->item('mail_conf');
                  $user = $mail_config['username'];
                  $pass = $mail_config['password'];
                  $url  = $mail_config['url'];
                  $fromname  = $mail_config['from'];
                  $fromid  = $mail_config['admin_mail'];
                        
                $body = "<h3>Dear Team,</h3><p><br> You have Received the Application Details - ".$applicant_namef." - ".$productt_name." in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
                $bodya=str_replace(';', ',', $body);
                $bodyb=str_replace(' ', '%20', $bodya);
                $body = str_replace(array("\n", "\r"), '', $bodyb);

                $subject = "KTTF_New_Application";
                $fromname = "support@karnatakatourism.org";
$tomaill=array('chandrasekar.t@globalsinc.com','sivakumar.p@globalsinc.com');
$tolen = count($tomaill);
for($m=0;$m<$tolen;$m++){
                //$tomaill = "chandrasekar.t@globalsinc.com";
                   $params = array(
                      'api_user'  => $user,
                      'api_key'   => $pass,
                      'to'        => $tomaill[$m],
                      'subject'   => $subject,
                      'html'      => $body,
                      'text'      => '',
                      'from'      => $fromname
                  ); 

                  $ton=str_replace(' ', '%20', $params['to']);
                  $subjectn=str_replace(' ', '%20', $params['subject']);
                  $htmln=str_replace(' ', '%20', $params['html']);
                  $fromn=str_replace(' ', '%20', $params['from']);

                  $curl = curl_init();
                  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;
                  $headers = array(
                            "MIME-Version: 1.0\r\n",
                            "Content-type: text/html; application/json;charset=\"utf-8\"",
                            "Cache-Control: no-cache",
                            "Pragma: no-cache"
                        ); 
                  curl_setopt_array($curl, array(
                  CURLOPT_POST=>1,
                  CURLOPT_URL =>$url_value,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_HEADER=>false,
                  CURLOPT_SSL_VERIFYPEER=> false,
                  CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer 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',$headers
                  ),
                ));

                  $response = curl_exec($curl);
                  $err = curl_error($curl);
                  curl_close($curl);  
                  if ($err) {
                    echo "cURL Error #:" . $err;  
                  } else {
                       $respMsg =  json_decode($response);
                       $response = $respMsg->message;       
                  }
                }

// END MAIL NOTI


                        // End Alert & Notification Code

                          echo "Application Saved Successfully/".$insert_id."/".$org_loc_mobilef."/".$official_emailf."/".$applicant_namef;     
                          else:    
                            echo "Application Not Updated";
                          endif;
          }
    
    else
    {
            $this->db->where('id',$exist_id);
              $upStatus = $this->db->update('application',$saveCert);
            //echo $this->db->last_query();
            $insert_id = $exist_id;

            if(!empty($this->input->post('org_loc_district_id')))
            {
               $org_loc_district_id =  $this->input->post('org_loc_district_id');
               $disttid = $org_loc_district_id;
               $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
              $appid = $insert_id.$dist_name;
            } 
            else
            {
              $org_loc_district_id =  ""; 
              $appid = $insert_id;
            }

            $upAppData = array(
                    'application_id'  => $appid
                    );
            $this->db->where('id',$insert_id);
            $upstatusa = $this->db->update('application',$upAppData);

              $org_add1      = $this->input->post('org_add1');
              $org_add2        = $this->input->post('org_add2');  
              $org_district_id = $this->input->post('org_district_id');
              $org_taluk     = $this->input->post('org_taluk');
              $org_city    = $this->input->post('org_city');
              $org_pincode_id  = $this->input->post('org_pincode_id');
              $org_mobile    = $this->input->post('org_mobile');
              $tot_addr = count($org_add1);
              for($i=0;$i<$tot_addr;$i++)
              {
                  $other_off_addr = array(
                  'application_id'  => $insert_id,
                  'other_off_addr1'  => $org_add1[$i],
                  'other_off_addr2'  => $org_add2[$i],
                  'other_off_state' => "KA",
                  'other_off_district_id' =>$org_district_id[$i],
                  'other_off_taluk' => $org_taluk[$i],
                  'other_off_city' => $org_city[$i],
                  'other_off_pincode_id' => $org_pincode_id[$i],
                  'other_off_contact' =>$org_mobile[$i]
                  );
                 //print_r( $other_off_addr);
                 $upStatus = $this->db->insert('other_offices',$other_off_addr);
              }


              if($upStatus):
                echo "Record Updated Successfully/".$insert_id;     
              else:    
                echo "Record Not Updated";
              endif;

    } 
}

function application_editupdate()
{
    if(!empty($this->input->post('applicant_name')))
    {
      $saveCert = array(
        'applicant_name'  => !empty($this->input->post('applicant_name')) ? $this->input->post('applicant_name') : NULL,
        'central_gov_approved'  => !empty($this->input->post('central_gov_approved')) ? $this->input->post('central_gov_approved') : NULL,
        'org_commencement_date'  => !empty($this->input->post('org_commencement_date')) ? $this->input->post('org_commencement_date') : NULL,
        'org_type_id'   => !empty($this->input->post('org_type_id')) ? $this->input->post('org_type_id') : NULL,
        'category_type'   => !empty($this->input->post('category_type')) ? $this->input->post('category_type') : NULL,
        'proprietor_name'     => !empty($this->input->post('proprietor_name')) ? $this->input->post('proprietor_name') : NULL,
        'gst_number'    => !empty($this->input->post('gst_number')) ? $this->input->post('gst_number') : NULL,
        'pan_number'    => !empty($this->input->post('pan_number')) ? $this->input->post('pan_number') : NULL,
        'website_name'    => !empty($this->input->post('website_name')) ? $this->input->post('website_name') : NULL,
        'official_email'    => !empty($this->input->post('official_email')) ? $this->input->post('official_email') : NULL,
        'member_recognised_trade'  => !empty($this->input->post('member_recognised_trade')) ? $this->input->post('member_recognised_trade') : NULL,
        'member_recognised_trade_details'  => !empty($this->input->post('member_recognised_trade_details')) ? $this->input->post('member_recognised_trade_details') : NULL,
        'org_add1'   => !empty($this->input->post('org_add1')) ? $this->input->post('org_add1') : NULL,
        'org_add2'     => !empty($this->input->post('org_add2')) ? $this->input->post('org_add2') : NULL,
        'org_district_id'     => !empty($this->input->post('org_district_id')) ? $this->input->post('org_district_id') : NULL,
        'org_taluk'     => !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : NULL,
        'org_city'  => !empty($this->input->post('org_city')) ? $this->input->post('org_city') : NULL,
        'org_pincode_id'  => !empty($this->input->post('org_pincode_id')) ? $this->input->post('org_pincode_id') : NULL,
        'org_mobile'  => !empty($this->input->post('org_mobile')) ? $this->input->post('org_mobile') : NULL,
        'org_loc_add1'  => !empty($this->input->post('org_loc_add1')) ? $this->input->post('org_loc_add1') : NULL,
        'org_loc_add2'=> !empty($this->input->post('org_loc_add2')) ? $this->input->post('org_loc_add2') : NULL,
        'org_loc_district_id'     => !empty($this->input->post('org_loc_district_id')) ? $this->input->post('org_loc_district_id') : NULL,
         'org_loc_taluk_id'  => !empty($this->input->post('org_loc_taluk_id')) ? $this->input->post('org_loc_taluk_id') : NULL,
        'org_loc_city'     => !empty($this->input->post('org_loc_city')) ? $this->input->post('org_loc_city') : NULL,
        'org_loc_pincode_id'     => !empty($this->input->post('org_loc_pincode_id')) ? $this->input->post('org_loc_pincode_id') : NULL,
        'org_loc_mobile'     => !empty($this->input->post('org_loc_mobile')) ? $this->input->post('org_loc_mobile') : NULL,
        'org_loc_telephone'     => !empty($this->input->post('org_loc_telephone')) ? $this->input->post('org_loc_telephone') : NULL,
        'org_loc_landmark'     => !empty($this->input->post('org_loc_landmark')) ? $this->input->post('org_loc_landmark') : NULL,
        'org_total_build_sqft'     => !empty($this->input->post('org_total_build_sqft')) ? $this->input->post('org_total_build_sqft') : NULL,      
        'off_activity'     => !empty($this->input->post('off_activity')) ? $this->input->post('off_activity') : NULL,
        'off_international_membership'     => !empty($this->input->post('off_international_membership')) ? $this->input->post('off_international_membership') : NULL,
        'off_international_membership_details'     => !empty($this->input->post('off_international_membership_details')) ? $this->input->post('off_international_membership_details') : NULL,
        'off_promote_domestic_activity'     => !empty($this->input->post('off_promote_domestic_activity')) ? $this->input->post('off_promote_domestic_activity') : NULL,
        'off_prog_arranged_foreign_tourist'     => !empty($this->input->post('off_prog_arranged_foreign_tourist')) ? $this->input->post('off_prog_arranged_foreign_tourist') : NULL,
        'off_prog_arranged_foreign_tourist_details'     => !empty($this->input->post('off_prog_arranged_foreign_tourist_details')) ? $this->input->post('off_prog_arranged_foreign_tourist_details') : NULL,
         'district_id'     => !empty($this->input->post('org_loc_district_id')) ? $this->input->post('org_loc_district_id') : NULL,
        'register_id'     => $this->usrID,
        'product_id'     =>$this->input->post('product_id'),
        'paytm_orderid'     => $this->input->post('pg_orderid'),
        'enable_attoney'=>!empty($this->input->post('auth_rep_val')) ? $this->input->post('auth_rep_val') : 0,
        'mdfdate'    => date('Y-m-d H:i:s'),
        'mdfby'     => $this->usrID,
        'document_type'=>!empty($this->input->post('file_type')) ? $this->input->post('file_type') : 0,
        'entity_name'=>!empty($this->input->post('entity_name')) ? $this->input->post('entity_name') : 0,
        'guest_name'=>!empty($this->input->post('guest_name')) ? $this->input->post('guest_name') : 0,
        'org_license_date'  => $this->input->post('org_license_date'),
        'guest_mbl_no'=>!empty($this->input->post('guest_mbl_no')) ? $this->input->post('guest_mbl_no') : 0,
        'email_id_guest'=>!empty($this->input->post('email_id_guest')) ? $this->input->post('email_id_guest') : 0,
        'total_guest_build_area'=>!empty($this->input->post('total_guest_build_area')) ? $this->input->post('total_guest_build_area') : 0,
      );

        //print_r($_FILES);

        foreach($_FILES as $key=>$val): //upload files
           if($val['size'] > 0):
          $fileName = $this->img_upload($key);
          if(!empty($fileName)):
            $saveCert[$key] = $fileName;
          endif;
           endif;
        endforeach;

        $exist_id = $this->input->post('insid_draft');
        if($exist_id==""){


        }
        else
        {
            $this->db->where('id',$exist_id);
              $upStatus = $this->db->update('application',$saveCert);
            //echo $this->db->last_query();
            $insert_id = $exist_id;

            if(!empty($this->input->post('org_loc_district_id')))
            {
               $org_loc_district_id =  $this->input->post('org_loc_district_id');
               $disttid = $org_loc_district_id;
               $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
              $appid = $insert_id.$dist_name;
            } 
            else
            {
              $org_loc_district_id =  ""; 
              $appid = $insert_id;
            }

            $upAppData = array(
                    'application_id'  => $appid
                    );
            $this->db->where('id',$insert_id);
            $upstatusa = $this->db->update('application',$upAppData);

              $org_add1      = $this->input->post('org_add1');
              $org_add2        = $this->input->post('org_add2');  
              $org_district_id = $this->input->post('org_district_id');
              $org_taluk     = $this->input->post('org_taluk');
              $org_city    = $this->input->post('org_city');
              $org_pincode_id  = $this->input->post('org_pincode_id');
              $org_mobile    = $this->input->post('org_mobile');
              $tot_addr = count($org_add1);
              for($i=0;$i<$tot_addr;$i++)
              {
                  $other_off_addr = array(
                  'application_id'  => $insert_id,
                  'other_off_addr1'  => $org_add1[$i],
                  'other_off_addr2'  => $org_add2[$i],
                  'other_off_state' => "KA",
                  'other_off_district_id' =>$org_district_id[$i],
                  'other_off_taluk' => $org_taluk[$i],
                  'other_off_city' => $org_city[$i],
                  'other_off_pincode_id' => $org_pincode_id[$i],
                  'other_off_contact' =>$org_mobile[$i]
                  );
                 //print_r( $other_off_addr);
                 $upStatus = $this->db->insert('other_offices',$other_off_addr);
              }


              if($upStatus):
                echo "Record Updated Successfully/".$insert_id;     
              else:    
                echo "Record Not Updated";
              endif;
        }
    }
    else
    {
       echo "Record Not Updated. Please Enter Applicant Name.";
    }
}

function fil1upload(){
  //$_FILES['img_registration_certificate']['name'];
  //print_r($_FILES); print_r($_POST); exit();


  $appID=$_POST['id'];
  $key=$_POST['key'];  

  //$key = 'img_registration_certificate'; 
   $fileName = $this->img_upload($key);  
   
  $saveCert=array($key=>$fileName);
   $this->db->where('id',$appID);
    $upStatus = $this->db->update('application',$saveCert); 
    //echo $this -> db -> last_query();exit;
    echo $fileName ;
     
}



function application_savedraft()
{
 // echo $this->input->post('applicant_name'); exit;
    // print_r(($this->input->post()));
   // print_r($this->input->post('file_type'));
   // die();

  $remove_ids=json_decode($this->input->post('remove_ids'));
  $remove_count=(count($remove_ids)); 
  if($remove_count>0)
  {    
    foreach ($remove_ids as $key => $value) 
    {
      //echo ($value);
      $delete_address="delete from other_offices where id='".$value."' ";
      $result_address=$this->db->query($delete_address);
    }
  }

  $remove_veh_ids=json_decode($this->input->post('vehremove_ids'));
  $remove_veh_count=(count($remove_veh_ids)); 
  if($remove_veh_count>0)
  {    
    foreach ($remove_veh_ids as $key => $value) 
    {
      //echo ($value);
      $delete_vehicle="delete from vehicledetails where id='".$value."' ";
      $result_veh=$this->db->query($delete_vehicle);
    }
  }
  $officecount= $this->input->post('Nuumber_offices');

  if(!empty($this->input->post('applicant_name')))
  {    
    $saveCert = array(
        'applicant_name'  => $this->input->post('applicant_name'),
        'central_gov_approved'  => $this->input->post('central_gov_approved'),
        'org_commencement_date'  => !empty($this->input->post('org_commencement_date')) ? $this->input->post('org_commencement_date') : NULL,
        'org_type_id'   => !empty($this->input->post('org_type_id')) ? $this->input->post('org_type_id') : 0, 
        'category_type'   => !empty($this->input->post('category_type')) ? $this->input->post('category_type') : 0, 
        'proprietor_name' => !empty($this->input->post('proprietor_name')) ? $this->input->post('proprietor_name') : NULL,
        'gst_number'    => !empty($this->input->post('gst_number')) ? $this->input->post('gst_number') : NULL,
        'pan_number'    => !empty($this->input->post('pan_number')) ? $this->input->post('pan_number') : NULL,
        'website_name'    => !empty($this->input->post('website_name')) ? $this->input->post('website_name') : NULL,
        'official_email'    => !empty($this->input->post('official_email')) ? $this->input->post('official_email') : NULL,
        'member_recognised_trade'  => !empty($this->input->post('member_recognised_trade')) ? $this->input->post('member_recognised_trade') : 0,
        'member_recognised_trade_details'  => !empty($this->input->post('member_recognised_trade_details')) ? $this->input->post('member_recognised_trade_details') : NULL, 
        /*'org_add2'     => !empty($this->input->post('org_add2')) ? $this->input->post('org_add2') : NULL,
        'org_district_id'     => !empty($this->input->post('org_district_id')) ? $this->input->post('org_district_id') : NULL,
        'org_taluk'     => !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : NULL,
        'org_city'  => !empty($this->input->post('org_city')) ? $this->input->post('org_city') : NULL,
        'org_pincode_id'  => !empty($this->input->post('org_pincode_id')) ? $this->input->post('org_pincode_id') : NULL,
        'org_mobile'  => !empty($this->input->post('org_mobile')) ? $this->input->post('org_mobile') : NULL,*/
        'org_add1'   => "NULL",
        'org_add2'     =>  "NULL",
        'org_district_id'     =>  "0",
        'org_taluk'     =>  "0",
        'org_city'  =>  "NULL",
        'org_pincode_id'  =>  "0",
        'org_mobile'  =>  "0",
        'org_loc_add1'  => !empty($this->input->post('org_loc_add1')) ? $this->input->post('org_loc_add1') : NULL,
        'org_loc_add2'=> !empty($this->input->post('org_loc_add2')) ? $this->input->post('org_loc_add2') : NULL, 
        'org_loc_district_id'     => !empty($this->input->post('org_loc_district_id')) ? $this->input->post('org_loc_district_id') : NULL,
        'org_loc_taluk_id'     => !empty($this->input->post('org_loc_taluk_id')) ? $this->input->post('org_loc_taluk_id') : 0,
        'org_loc_city'         => !empty($this->input->post('org_loc_city')) ? $this->input->post('org_loc_city') : NULL,
        'org_loc_pincode_id'   => !empty($this->input->post('org_loc_pincode_id')) ? $this->input->post('org_loc_pincode_id') : 0,
        'org_loc_mobile'       => !empty($this->input->post('org_loc_mobile')) ? $this->input->post('org_loc_mobile') : 0, 
        'org_loc_telephone'    => !empty($this->input->post('org_loc_telephone')) ? $this->input->post('org_loc_telephone') : 0,
        'org_loc_landmark'     => !empty($this->input->post('org_loc_landmark')) ? $this->input->post('org_loc_landmark') : NULL, 
        'org_total_build_sqft' => !empty($this->input->post('org_total_build_sqft')) ? $this->input->post('org_total_build_sqft') : 0, 
        //'org_acc_toilet_mtrs'     => $this->input->post('org_acc_toilet_mtrs'),
        'off_activity'     => !empty($this->input->post('off_activity')) ? $this->input->post('off_activity') : 0,
        'off_international_membership'     => !empty($this->input->post('off_international_membership')) ? $this->input->post('off_international_membership') : 0, 
        'off_international_membership_details' => !empty($this->input->post('off_international_membership_details')) ? $this->input->post('off_international_membership_details') : NULL,
        'off_promote_domestic_activity'     => !empty($this->input->post('off_promote_domestic_activity')) ? $this->input->post('off_promote_domestic_activity') : NULL, 
        'off_prog_arranged_foreign_tourist'     => !empty($this->input->post('off_prog_arranged_foreign_tourist')) ? $this->input->post('off_prog_arranged_foreign_tourist') : NULL,
        'off_prog_arranged_foreign_tourist_details'=> !empty($this->input->post('off_prog_arranged_foreign_tourist_details')) ? $this->input->post('off_prog_arranged_foreign_tourist_details') : NULL,
         'district_id'     => !empty($this->input->post('org_loc_district_id')) ? $this->input->post('org_loc_district_id'): NULL,
        'register_id'     => $this->usrID,
        'product_id'     => !empty($this->input->post('product_id')) ? $this->input->post('product_id') : NULL,
        'paytm_orderid'     => !empty($this->input->post('pg_orderid')) ? $this->input->post('pg_orderid') : null,

         //'is_confirmed'     => '0',
        'app_status'     => '1',
        'stage_id'     => 0,
        'isdraft'     =>1,
        'enable_attoney'=>!empty($this->input->post('auth_rep_val')) ? $this->input->post('auth_rep_val') : 0,
        'other_office_count' =>$this->input->post('Nuumber_offices'),
        'confirmed_date'    => date('Y-m-d H:i:s'),
        'crtdate'    => date('Y-m-d H:i:s'),
        'crtby'     => $this->usrID,
        'document_type'=>!empty($this->input->post('file_type')) ? $this->input->post('file_type') : 0,
        'org_shop_date'=>!empty($this->input->post('org_shop_date')) ? $this->input->post('org_shop_date') : NULL,
        'trade_lic_date'=>$this->input->post('trade_lic_date')  ,
         'member_kts'=>$this->input->post('member_kts')  ,
          'visitor_capacity'=>!empty($this->input->post('visitor_capacity')) ? $this->input->post('visitor_capacity') : 0,
            'total_hotel_build_area'=>!empty($this->input->post('total_hotel_build_area')) ? $this->input->post('total_hotel_build_area') : 0,
            'hotel_name'=>!empty($this->input->post('hotel_name')) ? $this->input->post('hotel_name') : NULL,
            'restaurant_type'=>!empty($this->input->post('restaurant_type')) ? $this->input->post('restaurant_type') : NULL,        
            'org_registration_date'=>!empty($this->input->post('org_registration_date')) ? $this->input->post('org_registration_date') : 0 ,
            'owner_name'=>!empty($this->input->post('ownername')) ? $this->input->post('ownername') : null,
            'no_bed'=>!empty($this->input->post('no_beds')) ? $this->input->post('no_beds') : 0,
            'owner_mobile'=>!empty($this->input->post('mobileNo')) ? $this->input->post('mobileNo') : 0,
            'owner_email'=>!empty($this->input->post('owner_email')) ? $this->input->post('owner_email') : null,
            'amusement_commencement_date'=>!empty($this->input->post('amusement_commencement_date')) ? $this->input->post('amusement_commencement_date') : 0,
            'cat_restaurant'=>!empty($this->input->post('cat_restaurant')) ? $this->input->post('cat_restaurant') : 0,
            'no_rooms'=>!empty($this->input->post('no_rooms')) ? $this->input->post('no_rooms') : 0,
            'email_id_hotel'=>!empty($this->input->post('email_id_hotel')) ? $this->input->post('email_id_hotel') : 0,
            'hotel_mbl_no'=>!empty($this->input->post('hotel_mbl_no')) ? $this->input->post('hotel_mbl_no') : 0,
            'hotel_resort'=>!empty($this->input->post('hotel_resort')) ? $this->input->post('hotel_resort') : 0,
            'legal_name'=>!empty($this->input->post('legal_name')) ? $this->input->post('legal_name') : 0,
            'outsourced_emp_female'=>!empty($this->input->post('outsourced_emp_female')) ? $this->input->post('outsourced_emp_female') : 0,
            'outsourced_emp_male'=>!empty($this->input->post('outsourced_emp_male')) ? $this->input->post('outsourced_emp_male') : 0,
            'permanent_emp_female'=>!empty($this->input->post('permanent_emp_female')) ? $this->input->post('permanent_emp_female') : 0,
            'permanent_emp_male'=>!empty($this->input->post('permanent_emp_male')) ? $this->input->post('permanent_emp_male') : 0,
            'certificate_name'=>!empty($this->input->post('certificate_name')) ? $this->input->post('certificate_name') : 0,
             'member_recognised_trade_other'=>!empty($this->input->post('member_recognised_trade_other')) ? $this->input->post('member_recognised_trade_other') : 0,
            'new_taluk'=>!empty($this->input->post('new_taluk')) ? $this->input->post('new_taluk') : null,
            'new_district'=>!empty($this->input->post('new_district')) ? $this->input->post('new_district') : null,
            'org_state'=>!empty($this->input->post('org_state')) ? $this->input->post('org_state') : null,
            'entity_name'=>!empty($this->input->post('entity_name')) ? $this->input->post('entity_name') : 0,
            'guest_name'=>!empty($this->input->post('guest_name')) ? $this->input->post('guest_name') : 0,
            'org_license_date'  => $this->input->post('org_license_date'),
            'guest_mbl_no'=>

            !empty($this->input->post('guest_mbl_no')) ? $this->input->post('guest_mbl_no') : 0,
            'email_id_guest'=>!empty($this->input->post('email_id_guest')) ? $this->input->post('email_id_guest') : 0,
            'total_guest_build_area'=>!empty($this->input->post('total_guest_build_area')) ? $this->input->post('total_guest_build_area') : 0,
    );

 // print_r($saveCert);
 //             die(); 
      foreach($_FILES as $key=>$val): //upload files
         if($val['size'] > 0): 
        $fileName = $this->img_upload($key); 
        if(!empty($fileName)):
          $saveCert[$key] = $fileName;
        endif;
         endif;
      endforeach; 

        $exist_id = !empty($this->input->post('insid_draft')) ? $this->input->post('insid_draft') : '' ;
        
        if($exist_id == "" || $exist_id == 'undefined' )
        {
            // echo  "if";
            $upStatus = $this->db->insert('application',$saveCert);
            $insert_id = $this->db->insert_id();
            // echo $this->db->last_query();
            //print_r($insert_id);
           
            
            if(!empty($this->input->post('org_loc_district_id')))
            {
              $org_loc_district_id =  $this->input->post('org_loc_district_id');
              $disttid = $org_loc_district_id;
              $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
              $appid = $insert_id.$dist_name;
            } 
            else
            {
              $org_loc_district_id =  ""; 
              $appid = $insert_id;
            }
            // other office address
               $org_add1      = !empty( $this->input->post('org_add1')) ?  $this->input->post('org_add1') : 0 ;
                $org_add2        =!empty( $this->input->post('org_add2')) ?  $this->input->post('org_add2') : 0 ;  
                $org_district_id = !empty($this->input->post('org_district_id')) ? $this->input->post('org_district_id') : 0 ;
                $org_taluk     = !empty($this->input->post('org_taluk')) ? $this->input->post('org_taluk') : 0 ;
                $org_city    = !empty($this->input->post('org_city')) ? $this->input->post('org_city') : 0 ;
                $org_pincode_id  = !empty($this->input->post('org_pincode_id')) ? $this->input->post('org_pincode_id') : 0 ;
                $org_mobile    = !empty($this->input->post('org_mobile')) ? $this->input->post('org_mobile') : 0 ;
                $email_hotel= !empty($this->input->post('hotelemail')) ? $this->input->post('hotelemail') : NULL;
                $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
                $tot_addr = count($org_add1);
                //echo $tot_addr ;
                if($tot_addr>0)
                {
                    $delete_add="delete from other_offices where application_id='".$insert_id."' ";
                    $result_add=$this->db->query($delete_add);
                }
                if($this->input->post('product_id')<=3)
                {
                     if($officecount>0)
                     {

                            for($i=0;$i<$tot_addr;$i++)
                            {
                              $other_off_addr = array(
                                'application_id'  => $insert_id,
                                'other_off_addr1'  => $org_add1[$i],
                                'other_off_addr2'  => $org_add2[$i],
                                'other_off_state' => "KA",
                                'other_off_district_id' =>$org_district_id[$i],
                                'other_off_taluk' => $org_taluk[$i],
                                'other_off_city' => $org_city[$i],
                                'other_off_pincode_id' => $org_pincode_id[$i],
                                'other_off_contact' =>$org_mobile[$i]
                              );
                             //print_r( $other_off_addr);
                             $upStatus = $this->db->insert('other_offices',$other_off_addr);
                             // echo $this->db->last_query();
                            }
                     }  
                }               
                else if($this->input->post('product_id')==4 || $this->input->post('product_id')==5 || $this->input->post('product_id')==6 || $this->input->post('product_id')==7)
                {
                    for($i=0;$i<$tot_addr;$i++)
                    {
                      $other_off_addr = array(
                        'application_id'  => $insert_id,
                        'other_off_addr1'  => $org_add1[$i],
                        'other_off_addr2'  => $org_add2[$i],
                        'other_off_state' => "KA",
                        'other_off_district_id' =>$org_district_id[$i],
                        'other_off_taluk' => $org_taluk[$i],
                        'other_off_city' => $org_city[$i],
                        'other_off_pincode_id' => $org_pincode_id[$i],
                        'other_off_contact' =>$org_mobile[$i],
                        'other_email'=>$email_hotel[$i],
                        'org_landmark'=>$org_landmark[$i]
                      );
                     //print_r( $other_off_addr);
                     $upStatus = $this->db->insert('other_offices',$other_off_addr);
                     // echo $this->db->last_query();
                    }
                }
                
                $accommodation_type=$this->input->post('accommodation_type');
                $accommodation_othertype=$this->input->post('accommodation_othertype');
                $accommodation_count=count($accommodation_type); 
                // print_r($accommodation_count);               
                if($accommodation_count>0)
                {
                     $delete_acc="delete from hotel_accommodation where app_id='".$insert_id."' ";
                     $result_acc=$this->db->query($delete_acc);
                    for($i=0;$i<$accommodation_count;$i++)
                    {
                      $accomodation_details = array(
                        'app_id'  => $insert_id,
                        'accommodation_type'  => $accommodation_type[$i],
                        'other_facility'=>$accommodation_othertype[$i]
                      );
                     $upStatus = $this->db->insert('hotel_accommodation',$accomodation_details);
                     // echo $this->db->last_query();
                    }
                }
                $facility_available=$this->input->post('facility_available');
                $facility_othertype=$this->input->post('otherfacility_available');
                $facility_count=count($facility_available);
                if($facility_count>0)
                {        
                    $delete_acc="delete from hotel_facility where app_id='".$insert_id."' ";
                     $result_acc=$this->db->query($delete_acc);           
                    for($i=0;$i<$facility_count;$i++)
                    {
                      $accomodation_details = array(
                        'app_id'  => $insert_id,
                        'facility_type'  => $facility_available[$i],
                        'other_facility'=>$facility_othertype[$i]
                      );
                     $upStatus = $this->db->insert('hotel_facility',$accomodation_details);
                     // echo $this->db->last_query();
                    }
                }

            $cnt_reg_no=count($this->input->post('registration_no'));
            $cnt_reg_name=count($this->input->post('registration_name'));
            $cnt_reg_permit=count($this->input->post('tourist_permit'));
            $cnt_reg_permit_date=count($this->input->post('tourist_permit_date'));
            $cnt_reg_vehicle_type=count($this->input->post('vehicle_type'));
            $cur_permit_type=count($this->input->post('permit_type'));
            //print_r($this->input->post('tourist_permit_date'));
            
            $vehicletype=$this->input->post('vehicle_type');
            $reg_no=$this->input->post('registration_no');
            $reg_name=$this->input->post('registration_name');
            $reg_permit=$this->input->post('tourist_permit');
            $reg_permit_date=$this->input->post('tourist_permit_date');
            $reg_end_date=$this->input->post('tourist_permit_end_date');
            $veh_other=$this->input->post('othervalue');
            $permit=$this->input->post('permit_type');
            
            for($i=0;$i<$cnt_reg_no;$i++)
            {
                    if($reg_no[$i]!=null)
                    {
                      // print_r($permit[$i]);
                        $vehicledetails = array(
                        'app_id'  => $insert_id,
                        'no_of_vehicle'  => $this->input->post('veh_count'),
                        'vehicle_type'  => $vehicletype[$i],
                        'registeration_no' => $reg_no[$i],
                        'regitration_name' =>$reg_name[$i],
                        'tourist_permit' => $reg_permit[$i],
                        'permit_date' => $reg_permit_date[$i],
                        'end_date'=> $reg_end_date[$i],                        
                        'other_vehicle'=>$veh_other[$i],
                        'permit_type'=>$permit[$i]
                        );
                        $vehicle_details = $this->db->insert('vehicledetails',$vehicledetails);
                        //echo $this->db->last_query();
                    }
            }
             
            $upAppData = array(
                    'application_id'  => $appid
                    );
            $this->db->where('id',$insert_id);
            $upstatusa = $this->db->update('application',$upAppData);
            // echo $this->db->last_query();


// END MAIL NOTI
 $productt_idd = $this->input->post('product_id');
         $productt_name = $this->db->get_where('m_product', array('id' => $productt_idd))->row()->name;
            $applicant_namef = $this->input->post('applicant_name');

                  $mail_config = $this->config->item('mail_conf');
                  $user = $mail_config['username'];
                  $pass = $mail_config['password'];
                  $url  = $mail_config['url'];
                  $fromname  = $mail_config['from'];
                  $fromid  = $mail_config['admin_mail'];
                        
                $body = "<h3>Dear Team,</h3><p><br> You have Received the Application Details in Save as Draft - ".$applicant_namef." - ".$productt_name." in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
                $bodya=str_replace(';', ',', $body);
                $bodyb=str_replace(' ', '%20', $bodya);
                $body = str_replace(array("\n", "\r"), '', $bodyb);

                $subject = "KTTF_New_Application_Save_as_Draft";
                $fromname = "support@karnatakatourism.org";
$tomaill=array('chandrasekar.t@globalsinc.com');
$tolen = count($tomaill);
for($m=0;$m<$tolen;$m++){
                //$tomaill = "chandrasekar.t@globalsinc.com,sivakumar.p@globalsinc.com";
                   $params = array(
                      'api_user'  => $user,
                      'api_key'   => $pass,
                      'to'        => $tomaill[$m],
                      'subject'   => $subject,
                      'html'      => $body,
                      'text'      => '',
                      'from'      => $fromname
                  ); 

                  $ton=str_replace(' ', '%20', $params['to']);
                  $subjectn=str_replace(' ', '%20', $params['subject']);
                  $htmln=str_replace(' ', '%20', $params['html']);
                  $fromn=str_replace(' ', '%20', $params['from']);

                  $curl = curl_init();
                  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;
                  $headers = array(
                            "MIME-Version: 1.0\r\n",
                            "Content-type: text/html; application/json;charset=\"utf-8\"",
                            "Cache-Control: no-cache",
                            "Pragma: no-cache"
                        ); 
                  curl_setopt_array($curl, array(
                  CURLOPT_POST=>1,
                  CURLOPT_URL =>$url_value,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_HEADER=>false,
                  CURLOPT_SSL_VERIFYPEER=> false,
                  CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer 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',$headers
                  ),
                ));

                  $response = curl_exec($curl);
                  $err = curl_error($curl);
                  curl_close($curl);  
                  if ($err) {
                    echo "cURL Error #:" . $err;  
                  } else {
                       $respMsg =  json_decode($response);
                       $response = $respMsg->message;       
                  }
                }

// END MAIL NOTI





              if($upStatus):
                echo "Record Updated Successfully/".$insert_id;     
              else:    
                echo "Record Not Updated";
              endif;
        }
        else
        {
              // echo "else if";
              $this->db->where('id',$exist_id);
              // print_r($saveCert);die();
              $upStatus = $this->db->update('application',$saveCert);
              // echo $this->db->last_query();
              $insert_id = $exist_id;
              if(!empty($this->input->post('org_loc_district_id')))
              {
                $org_loc_district_id =  $this->input->post('org_loc_district_id');
                $disttid = $org_loc_district_id;
                $dist_name = $this->db->get_where('m_district', array('id' => $disttid))->row()->shortname;
                $appid = $insert_id.$dist_name;
              } 
              else
              {
                $org_loc_district_id =  ""; 
                $appid = $insert_id;
              }
              $upAppData = array(
                      'application_id'  => $appid
                      );
              //print_r($upAppData);die();
              if($org_loc_district_id!='')
              {
                $this->db->where('id',$insert_id);
                $upstatusa = $this->db->update('application',$upAppData); 
                // echo $this->db->last_query(); 
              }

              // other office address
               $org_add1      = $this->input->post('org_add1');
                $org_add2        = $this->input->post('org_add2');  
                $org_district_id = $this->input->post('org_district_id');
                $org_taluk     = $this->input->post('org_taluk');
                $org_city    = $this->input->post('org_city');
                $org_pincode_id  = $this->input->post('org_pincode_id');
                $org_mobile    = $this->input->post('org_mobile');
                $email_hotel= !empty($this->input->post('emailhotel')) ? $this->input->post('emailhotel') : NULL;
                $org_landmark=!empty($this->input->post('org_landmark')) ? $this->input->post('org_landmark') : NULL;
                $tot_addr = count($org_add1);
                // echo $tot_addr ;
                // echo"alliswell";
                // echo( $this->input->post('product_id'));
                if($tot_addr>0)
                {
                    $delete_add="delete from other_offices where application_id='".$insert_id."' ";
                    $result_add=$this->db->query($delete_add);
                }
                if($this->input->post('product_id')<=3)
                {
                     if($officecount>0)
                     {
                            for($i=0;$i<$tot_addr;$i++)
                            {
                              $other_off_addr = array(
                                'application_id'  => $insert_id,
                                'other_off_addr1'  => $org_add1[$i],
                                'other_off_addr2'  => $org_add2[$i],
                                'other_off_state' => "KA",
                                'other_off_district_id' =>$org_district_id[$i],
                                'other_off_taluk' => $org_taluk[$i],
                                'other_off_city' => $org_city[$i],
                                'other_off_pincode_id' => $org_pincode_id[$i],
                                'other_off_contact' =>$org_mobile[$i],
                                'other_email'=>$email_hotel[$i],
                                'org_landmark'=>$org_landmark[$i]
                              );
                             // print_r( $other_off_addr);
                             $upStatus = $this->db->insert('other_offices',$other_off_addr);
                             // echo $this->db->last_query();
                            }
                     }  
                }               
                else if($this->input->post('product_id')==4 || $this->input->post('product_id')==5 || $this->input->post('product_id')==6 || $this->input->post('product_id')==7)
                {
                    for($i=0;$i<$tot_addr;$i++)
                    {
                      $other_off_addr = array(
                        'application_id'  => $insert_id,
                        'other_off_addr1'  => $org_add1[$i],
                        'other_off_addr2'  => $org_add2[$i],
                        'other_off_state' => "KA",
                        'other_off_district_id' =>$org_district_id[$i],
                        'other_off_taluk' => $org_taluk[$i],
                        'other_off_city' => $org_city[$i],
                        'other_off_pincode_id' => $org_pincode_id[$i],
                        'other_off_contact' =>$org_mobile[$i],
                        'other_email'=>$email_hotel[$i],
                        'org_landmark'=>$org_landmark[$i]
                      );
                     // print_r( $other_off_addr);
                     $upStatus = $this->db->insert('other_offices',$other_off_addr);
                     // echo $this->db->last_query();
                    }
                }

              $cnt_reg_no=count($this->input->post('registration_no'));
              $cnt_reg_name=count($this->input->post('registration_name'));
              $cnt_reg_permit=count($this->input->post('tourist_permit'));
              $cnt_reg_permit_date=count($this->input->post('tourist_permit_date'));
              $cnt_reg_vehicle_type=count($this->input->post('vehicle_type'));
              $cur_permit_type=count($this->input->post('permit_type'));

              $existvehId=$this->input->post('vehicleId'); 
             // print_r($existvehId);             
              $vehicletype=$this->input->post('vehicle_type');
              $reg_no=$this->input->post('registration_no');
              $reg_name=$this->input->post('registration_name');
              $reg_permit=$this->input->post('tourist_permit');
              $reg_permit_date=$this->input->post('tourist_permit_date');
              $reg_end_date=$this->input->post('tourist_permit_end_date');
              $veh_other=$this->input->post('othervalue');
              $permit=$this->input->post('permit_type');

              //print_r($vehicletype);
              $vdsel_count="select * from vehicledetails where app_id='".$exist_id."'";
              $vd_count=$this->db->query($vdsel_count);
              $numRows=$vd_count->num_rows();

             
                for($i=0;$i<$cnt_reg_no;$i++)
                {
                      if($reg_no[$i]!=null)
                      {
                          $vehicledetails = array(
                          'no_of_vehicle'  => $this->input->post('veh_count'),
                          'vehicle_type'  => $vehicletype[$i],
                          'registeration_no' => $reg_no[$i],
                          'regitration_name' =>$reg_name[$i],
                          'tourist_permit' => $reg_permit[$i],
                          'permit_date' => $reg_permit_date[$i],
                          'end_date'=> $reg_end_date[$i],
                          'other_vehicle'=>$veh_other[$i],
                          'permit_type'=>$permit[$i]
                          );
                          /*$upAppData = array(
                                'gst_number'  => $gst,
                                'pan_number'  => $pan_no
                                );
                          $this->db->where('register_id',$Uid);
                          $updateApplication = $this->db->update('application',$upAppData);*/
                           //print_r($existvehId[$i]);
                           if($existvehId[$i] !=0)
                           {
                              //echo "if";
                              $this->db->where('id',$existvehId[$i]);
                              $vehicle_details = $this->db->update('vehicledetails',$vehicledetails);
                              //echo $this->db->last_query();
                          }
                          else
                          {
                             //echo "else";
                             $vehicledetails['app_id']=$exist_id;
                             $vehicle_details = $this->db->insert('vehicledetails',$vehicledetails);
                            //echo $this->db->last_query();                            
                          }
                          $vd=$this->db->query($vehicle_details);
                      } 
                }

                
                $accommodation_type=$this->input->post('accommodation_type');
                $accommodation_othertype=$this->input->post('accommodation_othertype');
                $accommodation_count=count($accommodation_type);

                 // print_r($accommodation_count);               
                if($accommodation_count>0)
                {
                     $delete_acc="delete from hotel_accommodation where app_id='".$exist_id."' ";
                     $result_acc=$this->db->query($delete_acc);
                     // echo $this->db->last_query();
                    for($i=0;$i<$accommodation_count;$i++)
                    {
                      $accomodation_details = array(
                        'app_id'  => $exist_id,
                        'accommodation_type'  => $accommodation_type[$i],
                        'other_facility'=>$accommodation_othertype[$i]
                      );
                     $upStatus = $this->db->insert('hotel_accommodation',$accomodation_details);
                     // echo $this->db->last_query();
                    }
                }
                $facility_available=$this->input->post('facility_available');
                $facility_othertype=$this->input->post('otherfacility_available');
                $facility_count=count($facility_available);
                if($facility_count>0)
                {        
                    $delete_acc="delete from hotel_facility where app_id='".$exist_id."' ";
                     $result_acc=$this->db->query($delete_acc);    
                     // echo $this->db->last_query();       
                    for($i=0;$i<$facility_count;$i++)
                    {
                      $accomodation_details = array(
                        'app_id'  => $exist_id,
                        'facility_type'  => $facility_available[$i],
                        'other_facility'=>$facility_othertype[$i]
                      );
                     $upStatus = $this->db->insert('hotel_facility',$accomodation_details);
                     // echo $this->db->last_query();
                    }
                }



// END MAIL NOTI
 $productt_idd = $this->input->post('product_id');
         $productt_name = $this->db->get_where('m_product', array('id' => $productt_idd))->row()->name;
            $applicant_namef = $this->input->post('applicant_name');

                  $mail_config = $this->config->item('mail_conf');
                  $user = $mail_config['username'];
                  $pass = $mail_config['password'];
                  $url  = $mail_config['url'];
                  $fromname  = $mail_config['from'];
                  $fromid  = $mail_config['admin_mail'];
                        
                $body = "<h3>Dear Team,</h3><p><br> You have Received the Application Details in Save as Draft - ".$applicant_namef." - ".$productt_name." in 'Karnataka Tourism Trade Facilitation'.</p><p><h4><br>Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
                $bodya=str_replace(';', ',', $body);
                $bodyb=str_replace(' ', '%20', $bodya);
                $body = str_replace(array("\n", "\r"), '', $bodyb);

                $subject = "KTTF_New_Application_Save_as_Draft";
                $fromname = "support@karnatakatourism.org";
$tomaill=array('chandrasekar.t@globalsinc.com');
$tolen = count($tomaill);
for($m=0;$m<$tolen;$m++){
                //$tomaill = "chandrasekar.t@globalsinc.com,sivakumar.p@globalsinc.com";
                   $params = array(
                      'api_user'  => $user,
                      'api_key'   => $pass,
                      'to'        => $tomaill[$m],
                      'subject'   => $subject,
                      'html'      => $body,
                      'text'      => '',
                      'from'      => $fromname
                  ); 

                  $ton=str_replace(' ', '%20', $params['to']);
                  $subjectn=str_replace(' ', '%20', $params['subject']);
                  $htmln=str_replace(' ', '%20', $params['html']);
                  $fromn=str_replace(' ', '%20', $params['from']);

                  $curl = curl_init();
                  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;
                  $headers = array(
                            "MIME-Version: 1.0\r\n",
                            "Content-type: text/html; application/json;charset=\"utf-8\"",
                            "Cache-Control: no-cache",
                            "Pragma: no-cache"
                        ); 
                  curl_setopt_array($curl, array(
                  CURLOPT_POST=>1,
                  CURLOPT_URL =>$url_value,
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_HEADER=>false,
                  CURLOPT_SSL_VERIFYPEER=> false,
                  CURLOPT_HTTPHEADER => array(
                    'Authorization: Bearer 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',$headers
                  ),
                ));

                  $response = curl_exec($curl);
                  $err = curl_error($curl);
                  curl_close($curl);  
                  if ($err) {
                    echo "cURL Error #:" . $err;  
                  } else {
                       $respMsg =  json_decode($response);
                       $response = $respMsg->message;       
                  }
                }

// END MAIL NOTI



              if($upStatus):
                echo "Record Updated Successfully/".$insert_id;     
              else:    
                echo "Record Not Updated";
              endif;
        }
  }
  else
  {
     echo "Record Not Updated. Please Enter Applicant Name.";
  }
}

function get_state()
{

  // $countryid=$_POST["countryid"];
  $countryid=101;
  print_r($countryid);die;
  $query = $this->db->query("SELECT * FROM m_states WHERE country_id ='$countryid' and isactive=1");
  //$query = $this->db->get_where('m_states', array('country_id' => $countryid));    
      //Count total number of rows
   echo '<option value="">Select State</option>';
      foreach ($query->result() as $row) {
    
      if($row->id > 0){
   echo '<option value="'.$row->id.'">'.$row->name.'</option>';      
      }else{
   echo '<option value="">No States Available</option>';
      }
  }
}

function get_district()
{
  $stateid=$_POST["stateid"];

  $query = $this->db->query("SELECT * FROM m_district WHERE state_id ='$stateid'");
  //$query = $this->db->get_where('m_states', array('country_id' => $countryid));    
      //Count total number of rows
   echo '<option value="">Select District</option>';
      foreach ($query->result() as $row) {
    
      if($row->id > 0){
   echo '<option value="'.$row->id.'">'.$row->name.'</option>';      
      }else{
   echo '<option value="">No District Available</option>';
      }
  }
}


function get_taluk()
{

    $districtid=$_POST["districtid"];
    $query = $this->db->query("SELECT * FROM m_taluk WHERE district_id ='$districtid'");
    //$query = $this->db->get_where('m_states', array('country_id' => $countryid));    
        //Count total number of rows
    //print_r($this->db->last_query());
    echo '<option value="">Select Taluk</option>';
    foreach ($query->result() as $row) 
    {
      if($row->id > 0)
      {
        echo '<option value="'.$row->id.'">'.$row->name.'</option>';      
      }
      else
      {
        echo '<option value="">No Taluk Available</option>';
      }
    } 
}

function get_talukloc()
{
    $districtid=$_POST["districtid"];
    $query = $this->db->query("SELECT * FROM m_taluk WHERE district_id ='$districtid'");
//$query = $this->db->get_where('m_states', array('country_id' => $countryid));    
    //Count total number of rows
 echo '<option value="">Select Taluk</option>';
    foreach ($query->result() as $row) {
  
    if($row->id > 0){
 echo '<option value="'.$row->id.'">'.$row->name.'</option>';      
    }else{
 echo '<option value="">No Taluk Available</option>';
    }
  }
}

  function reports(){

    $id = $this->uri->segment(4);

    $this->menu = 'Reports';

    $data['arr_css'] = array('admin/css/bootstrap.min.css');

    
    $appDettails = $this->_application->getAppInfo($id);

    $appDettails = array_shift($appDettails);

    $data['application'] = $appDettails;

    $payDet = $this->db->get_where('payment',array('id' => $appDettails->payment_id), true)->result_array();

    $payDet = array_shift($payDet);

    $data['payment'] = $payDet;
      
    $this->load->view('admin/reports',$data);
  }

  function logout()
  {      
      $this->session->sess_destroy();
      $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
    $this->output->set_header("Pragma: no-cache");
      //$this->load->view('login',$data);
      redirect('login');
  }
  function editprofile()
  {
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                );    
    $this->load->view('user/editprofile',$data);
  }

  function about()
  {
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                );    
    $this->load->view('user/about',$data);
  }
  
    function manual()
  {
    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/application.css',
                            );

    $data['arr_js']  = array('user/js/jquery.2.1.3.min.js',
                             'user/js/application.js',
                                );    
    $this->load->view('user/manual',$data);
  }



function putediteddata()
{
    $gst=$this->input->post('gst_number');
    $pan_no=$this->input->post('pan');
    $Uid=$this->input->post('Id');
    $upAppData = array(
          'gst_number'  => $gst,
          'pan_number'  => $pan_no
          );
    $this->db->where('register_id',$Uid);
    $updateApplication = $this->db->update('application',$upAppData);

    $this->db->where('id',$Uid);
    $updateUser = $this->db->update('usr_register',$upAppData);
    return $updateUser; 
}
function draftedit()
{ 
    $data['id']=$this->input->post('id');    
    $this->db->select("a.*,o.application_id'off_applicationId',o.id'office_id',o.other_off_addr1,o.other_off_addr2,o.other_off_city,o.other_off_contact,o.other_off_district_id,o.other_off_pincode_id,o.other_off_state,o.other_off_taluk,o.other_email,o.org_landmark");
    $this->db->from('application a');
    $this->db->join('other_offices o', 'o.application_id=a.id','left'); 
    // $this->db->join('hotel_accommodation ha', 'ha.app_id=a.id','left');
    // $this->db->join('hotel_facility hf','hf.app_id=a.id','left');    
    $this->db->where('a.id',$data['id']); 
    $appDetails['applicationDetails'] = $this->db->get()->result();
    // print_r($this->db->last_query());
    /*,vd.no_of_vehicle,vd.registeration_no,vd.regitration_name,vd.tourist_permit,vd.vehicle_type,vd.app_id,vd.id'vehicleId',DATE_FORMAT(vd.end_date, '%Y-%m-%d') 'end_date',DATE_FORMAT(vd.permit_date, '%Y-%m-%d')'permitdate',vd.no_of_vehicle*/

    $this->db->select("vd.no_of_vehicle,vd.registeration_no,vd.regitration_name,vd.tourist_permit,vd.vehicle_type,vd.app_id,vd.id'vehicleId',DATE_FORMAT(vd.end_date, '%Y-%m-%d') 'end_date',DATE_FORMAT(vd.permit_date, '%Y-%m-%d')'permitdate',vd.no_of_vehicle,vd.other_vehicle,vd.permit_type");
    $this->db->from('vehicledetails vd');
    $this->db->where('vd.app_id',$data['id']); 
    $appDetails['vehicleDetails'] = $this->db->get()->result();


    $this->db->select("*");
    $this->db->from('hotel_accommodation ha');
    $this->db->where('ha.app_id',$data['id']); 
    $appDetails['hotelaccomodation'] = $this->db->get()->result();
    //print_r($this->db->last_query());

    $this->db->select("*");
    $this->db->from('hotel_facility hf');
    $this->db->where('hf.app_id',$data['id']); 
    $appDetails['hotelfacility'] = $this->db->get()->result();

    // print_r($this->db->last_query());
    echo json_encode($appDetails);
}
function vehicledata()
{
        $id=$this->input->post('appId');
        $count = 0;
        $this->db->query("SET @cnt := 0");
        $where = array(
            'vd.app_id' => $id
            );

        $this->db->select("(@cnt := @cnt + 1) AS slno,vd.vehicle_type,vd.registeration_no,vd.tourist_permit,
          vd.regitration_name, DATE_FORMAT(vd.permit_date, '%d-%m-%Y')'permitdate', DATE_FORMAT(vd.end_date, '%d-%m-%Y')'enddate',vd.permit_type");
        $this->db->from('vehicledetails vd');
        $this->db->where($where);

        $result = $this->db->get();
        $result = $result->result();
        //print_r($this->db->last_query());

        $appvehicledata= $result;
        echo json_encode($appvehicledata);
}
function resenddate()
{
        $id=$this->input->post('appId');
        $query=$this->db->query("call resend_data (".$id.")"); 
        //print_r($this->db->last_query());
        if($query)
        {
            $appverifieddata = $query->result();         
        }
         
        echo json_encode($appverifieddata);
}
function reupload()
{  
      $exist_id=$this->input->post('appid');
      foreach($_FILES as $key=>$val): //upload files
         if($val['size'] > 0):          
        $fileName = $this->img_upload($key);
        if(!empty($fileName)):
          $saveCert[$key] = $fileName;
        endif;
         endif;
      endforeach;
       $saveCert['resent_verifi'] = 1;
      $this->db->where('id',$exist_id);
      $upStatus = $this->db->update('application',$saveCert);
      //print_r($this->db->last_query());      
}

  function application_filesave()
  {
    $url = $_SERVER['REQUEST_URI'];
    $host = explode('/',$url); 
    $host1=explode('=',$host[3]);
    $id=$host1[1];

        
      // $config['upload_path'] = './upload/'.$folderName.'/';
    //     $config['allowed_types'] = 'gif|jpg|png|pdf';
    //     $config['max_size'] = 20000000000000;
    //     $config['max_width'] = 1500000000000;
    //     $config['max_height'] = 150000000000;

    // print_r(pathinfo($_FILES[$folderName]['name']);
    // $ext = pathinfo($_FILES[$folderName]['name'], PATHINFO_EXTENSION);
     //  $filename = rand(10000, 990000) . '_' . time() . '.' . $ext;
     //  $config['file_name'] = $filename;

     //  $this->load->library('upload', $config);
     //  $this->upload->initialize($config);

     //  $response = '';
     //  // print_r($folderName);
     //        if (!$this->upload->do_upload($folderName)) {
     //            $error = array('error' => $this->upload->display_errors());
     //             // print_r($error);
     //     $response = NULL;
     //        } else {
     //            $data = array('image_metadata' => $this->upload->data());
     //         // print_r($data);
     //     $response = $filename;
     //        // sleep(10); 
     //        }      
     //   return $response;
      
  }
}
