<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller{
  function __construct(){
    parent::__construct();

    if($this->session->userdata('usrlogged_in') !== TRUE){
      redirect('login');
    }

    $this->usrID = $this->session->userdata('usrID');

    $this->load->model('M_application', '_application');

  }

  function index(){
  	$data['menu'] = 'Dashboard';

    $data['arr_css'] = array('user/css/bootstrap.min.css',
                             'user/css/style.css',
                             'user/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('user/js/DataTables/jquery-1.12.4.js',
                             'user/js/DataTables/jquery.dataTables.min.js'
                            );


      $pendWhere['note.register_id'] = $this->usrID;
      $pendWhere['note.status'] = '0';

    $this->db->select('count(note.id) total');
    $this->db->from('application_notification note');
    
    if($pendWhere)
      $this->db->where($pendWhere);

    $penResult = $this->db->get()->result();
    $appnote_count = $penResult[0]->total;

//echo $appnote_count;

    $data['appnote_count']    = $appnote_count;
    $data['appNewLink']    = 'applications';
    $data['appViewLink']   = 'applications/application_view/';
    $data['appGetDetails'] = 'userAjax/getUserAllApplications';

    $this->load->view('user/dashboard',$data);
    
  }

    

}
