<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Userajax extends CI_Controller {

	function __construct(){
		parent::__construct();

    if($this->session->userdata('usrlogged_in') !== TRUE){
      redirect('login');
    }

    	$this->usrID = $this->session->userdata('usrID');

		$this->load->model('M_application','_application');
	}

	function getUserAllApplications(){
		$appData = $this->_application->getUserApplications($this->usrID);

		echo json_encode($appData);
	}
	
	function pro_popup_desc(){
	$proid = $this->input->post('proid');
     $result= $this->db->get_where('m_product' , array('id'=>$proid))->result();
     $prodesc  = array_shift($result);
	 //print_r($prodesc);
	 //echo "++++";	 
     $response = '<div class="modal-body">'.$prodesc -> terms_conditions.'</div> <div class="modal-footer">' ;

     $response .= ($prodesc->isactive == 1 ) ? "<div class='agreecheck'><input type='checkbox' onchange='valueChanged()'' value='1' id='agreed' name='agreed' class='agreed'>I agree the Terms and Conditions with the Required Documents /  ನಿಯಮಗಳು ಮತ್ತು ಷರತ್ತುಗಳನ್ನು ಒಪ್ಪುತ್ತೇನೆ ಹಾಗೂ ಅಗತ್ಯ ದಾಖಲೆಗಳನ್ನು ಸಲ್ಲಿಸುತ್ತೇನೆ.</div>":"";
				$response .= ($prodesc->isactive == 1 ) ? "<a class='agent-pop disable-click' id='agentpop' href=".base_url().'applications/?apid='.$proid.">Continue</a>":"";
				$response .= '<p class="close button-agent">Cancel</p></div>'; 
     echo $response;
 
  }
}

