<?php defined('BASEPATH') OR exit('No direct script access allowed');

// class Khajane_ins extends CI_Controller{
//   function __construct(){
//     parent::__construct();

//   }

//   function index(){ 
//     echo "hi";
//   }

//   function demo(){ 
//     echo "demo fun";
//   }
    

// } 
 
class Khajane_ins extends CI_Controller {
  function __construct() {
    // Construct the parent class
    parent::__construct (); 
  }


  public function index(){ 
    echo "hi";
  }
 
  public function data_get() {

        echo "hi fhf"; 
    } 

  }
 
?>

