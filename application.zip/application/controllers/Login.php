<?php
class Login extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('M_user','_user');

  }

  function index(){
    $this->load->view('user/login');
  }

  function auth(){
    $usrname  = $this->input->post('user_name',TRUE);
    $usrpswd  = md5($this->input->post('user_password',TRUE));
    $validate = $this->_user->validate($usrname,$usrpswd);
    if($validate->num_rows() > 0){
        $usrdata  = $validate->row_array();
        if($usrdata['isactive'] == 0):
          $this->session->set_flashdata('msg-error','Sorry, your not a valid user.');
          redirect('login');
        endif;

         if($usrdata['activation_status'] != 1):
          $this->session->set_flashdata('msg-error','Your Account is Not Activated. Please Activate Your Account Before Login.');
          redirect('login');
        endif;



        $usrID       = $usrdata['id'];
        $usrName     = $usrdata['name'];

        $sesdata = array(
            'usrID'       => $usrID,
            'usrName'     => $usrName,
            'usrlogged_in'=> TRUE
        );
        $this->session->set_userdata($sesdata);
        redirect('dashboard');

    }else{
        $this->session->set_flashdata('msg-error','Username or Password is Wrong');
        redirect('login');
    }
  }


    function forget(){
    
        $this->session->set_userdata($sesdata);
        $this->load->view('user/forget_password');

    
  }


  function forget_password(){
    $email  = $this->input->post('user_email',TRUE);
   
// Mail For Activation Link


$user_id = $this->db->get_where('usr_register', array('usremail' => $email))->row()->id;

$user_name = $this->db->get_where('usr_register', array('usremail' => $email))->row()->name;

if($user_id==""){
$this->session->set_flashdata('msg-error',' The entered Email ID is Not Registered. Please check it.');
        redirect('login');
}
else{

  $mail_config = $this->config->item('mail_conf');

  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        
  $content="testt";

        $body = "<h3>Dear ".$user_name.",</h3><p><br> To Continue, Please click on the below link </p><p><br><a href='https://kttf.karnatakatourism.org/login/reset_password/$user_id' target='_blank'>Click Here to Reset Password</a></p><br><p><h4>


        <br><span style='color:tomato'><strong>Note: </strong></span>  <span style='color:blue,font-style: italic'><strong>The Above Link will Expire Within 24 Hours.</strong></span><br />
<br>

  Regards,<br> Karnataka Tourism Trade Facilitation.<br>

  </h4>
  </p>";
$body = str_replace(array("\n", "\r"), '', $body);
$subject = "Reset Password";
$fromname = "support@karnatakatourism.org";
   $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $email,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 

  $toname = "KSTDC";      
  $tonamen=str_replace(' ', '%20', $toname);
$ton=str_replace(' ', '%20', $params['to']);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);
  
/*
  $request =  $url.'api/mail.send.json';

  $session = curl_init($request);
  curl_setopt ($session, CURLOPT_POST, true);
        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
  curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

  // obtain response
  $response = curl_exec($session); 
  curl_close($session);
  $respMsg =  json_decode($response);
  $response = $respMsg->message;
  */


  $curl = curl_init();
  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
  $headers = array(
            "MIME-Version: 1.0\r\n",
            "Content-type: text/html; application/json;charset=\"utf-8\"",
            "Cache-Control: no-cache",
            "Pragma: no-cache"
        ); 
  curl_setopt_array($curl, array(
  CURLOPT_POST=>1,
  CURLOPT_URL =>$url_value,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HEADER=>false,
  CURLOPT_SSL_VERIFYPEER=> false,
  CURLOPT_SAFE_UPLOAD=>true,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer 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',$headers
  ),
));

  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);
  if ($err) {
    echo "cURL Error #:" . $err;    
  } else {
       $respMsg =  json_decode($response);
       $response = $respMsg->message;    
  }

  //print_r($params);
  //die;

  //-----end insert into email status

 // End Mail For Activation Link   


        $this->session->set_flashdata('msg',' You will Receive an Email Message to Reset Your Password.');
        redirect('login');
      }
   
  }




  function reset_password(){
    $useridd  = $this->uri->segment(3);
   //echo $useridd;
// Mail For Activation Link




 $user_email = $this->db->get_where('usr_register', array('id' => $useridd))->row()->usremail;
$data['useridd']   = $useridd;
$data['useremail']   = $user_email;

//print_r($data);
//die;
$this->load->view('user/reset_password',$data);

   
  }

  function reset_passwordsave(){

     $useridd  = $this->input->post('useridd',TRUE);
    $user_email  = $this->input->post('user_email',TRUE);
    $user_password  = md5($this->input->post('user_password',TRUE));
    $user_passworda  = md5($this->input->post('user_passworda',TRUE));


    $user_passwordf  = $this->input->post('user_password',TRUE);
    $user_passwordfa  = $this->input->post('user_passworda',TRUE);


if($user_passwordf==$user_passwordfa){

$upAppData = array(
        'usrpassword'  => $user_password,
        'mdfdate'  => date('Y-m-d H:i:s')
        );

$this->db->where('id',$useridd);
$upstatusa = $this->db->update('usr_register',$upAppData);


$user_name = $this->db->get_where('usr_register', array('usremail' => $user_email))->row()->name;


$mail_config = $this->config->item('mail_conf');

  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        


        $body = "<h3>Dear ".$user_name.",</h3><p><br> The Password has been Successfully Updated. Please Check the Below Login Credentials </p><p><br>User Name : ".$user_email."</p><p><br>Password : ".$user_passwordf."</p><p><h4>


        
<br>

  Regards,<br> Karnataka Tourism Trade Facilitation.<br>

  </h4>
  </p>";
$body = str_replace(array("\n", "\r"), '', $body);
$subject = "Password Successfully Updated";
$fromname = "support@karnatakatourism.org";
   $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $user_email,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 

  $toname = "KSTDC";      
  $tonamen=str_replace(' ', '%20', $toname);
$ton=str_replace(' ', '%20', $params['to']);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);

/*
  $request =  $url.'api/mail.send.json';

  $session = curl_init($request);
  curl_setopt ($session, CURLOPT_POST, true);
        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
  curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

  // obtain response
  $response = curl_exec($session); 
  curl_close($session);
  $respMsg =  json_decode($response);
  $response = $respMsg->message;
  */

  $curl = curl_init();
  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
  $headers = array(
            "MIME-Version: 1.0\r\n",
            "Content-type: text/html; application/json;charset=\"utf-8\"",
            "Cache-Control: no-cache",
            "Pragma: no-cache"
        ); 
  curl_setopt_array($curl, array(
  CURLOPT_POST=>1,
  CURLOPT_URL =>$url_value,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HEADER=>false,
  CURLOPT_SSL_VERIFYPEER=> false,
  CURLOPT_SAFE_UPLOAD=>true,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer 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',$headers
  ),
));

  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);
  if ($err) {
    echo "cURL Error #:" . $err;    
  } else {
       $respMsg =  json_decode($response);
       $response = $respMsg->message;    
  }


$this->session->set_flashdata('msg','Password Successfully Updated.');
redirect('login');
}
else{
  $this->session->set_flashdata('msg-error','Password and Confirm Password is Not Matched.');
        redirect('login/reset_password/'.$useridd);
}

    
  }


  function activate(){

    $useridd  = $this->uri->segment(3);

$activation_statusf = $this->db->get_where('usr_register', array('id' => $useridd))->row()->activation_status;

if($activation_statusf==1){

$this->session->set_flashdata('msg-error','You Account has been Already Activated. Please Login Here');
redirect('login');

}
else{

$cur_date = date('Y-m-d');
$acti_date = $this->db->get_where('usr_register', array('id' => $useridd))->row()->mailreceive_date;


$activatelink_date=date('Y-m-d', strtotime($acti_date));
$date1=date_create($activatelink_date);
$date2=date_create($cur_date);
$diff=date_diff($date1,$date2);
$count=$diff->format("%a");

if($count<='7'){


$upAppData = array(
        'activation_status'  => 1,
        'activation_date'  => date('Y-m-d H:i:s')
        );

$this->db->where('id',$useridd);
$upstatusa = $this->db->update('usr_register',$upAppData);

//print_r($data);
//die;
$this->session->set_flashdata('msg','You Account has been Activated Successfully. Please Login Here');
redirect('login');
}
else{
  $this->session->set_flashdata('msg-error','Your Account Activation link is Expired. Please Click Here.');
  $this->session->set_flashdata('msg-errorid','Your Account Activation link is Expired. Please <a href="'.base_url().'login/reactivate/'.$useridd.'" style="font-weight: 500;color: #053b76;text-decoration: underline;">Click Here to Activate</a>');
redirect('login');
}


}

   
  }


  function reactivate(){

$useridd  = $this->uri->segment(3);

$name = $this->db->get_where('usr_register', array('id' => $useridd))->row()->name;

$usremail = $this->db->get_where('usr_register', array('id' => $useridd))->row()->usremail;
      
// Mail For Activation Link

  $mail_config = $this->config->item('mail_conf');
  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        
$body = "<h3>Dear ".$name.",</h3><p><br> You have Successfully Registered in 'Karnataka Tourism Trade Facilitation'. Please Check the Below Link to Activate your Account.</p><p><br><a href='https://kttf.karnatakatourism.org/login/activate/$useridd' target='_blank'>Click Here to Activate</a></p><p><br>User Name : ".$usremail."</p><p><h4>


        
<br>
 Regards,<br> Karnataka Tourism Trade Facilitation.<br>
  </h4>
  </p>";
$body = str_replace(array("\n", "\r"), '', $body);
$subject = "Resent Account Activation Link";
$fromname = "support@karnatakatourism.org";
   $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $usremail,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 


  $toname = "KSTDC";      
  $tonamen=str_replace(' ', '%20', $toname);
$ton=str_replace(' ', '%20', $params['to']);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);


/*
  $request =  $url.'api/mail.send.json';

  $session = curl_init($request);
  curl_setopt ($session, CURLOPT_POST, true);
        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
  curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

  // obtain response
  $response = curl_exec($session); 
  curl_close($session);
  $respMsg =  json_decode($response);
  $response = $respMsg->message;
  */


  $curl = curl_init();
  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
  $headers = array(
            "MIME-Version: 1.0\r\n",
            "Content-type: text/html; application/json;charset=\"utf-8\"",
            "Cache-Control: no-cache",
            "Pragma: no-cache"
        ); 
  curl_setopt_array($curl, array(
  CURLOPT_POST=>1,
  CURLOPT_URL =>$url_value,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HEADER=>false,
  CURLOPT_SSL_VERIFYPEER=> false,
  CURLOPT_SAFE_UPLOAD=>true,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer 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',$headers
  ),
));

  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);
  if ($err) {
    echo "cURL Error #:" . $err;    
  } else {
       $respMsg =  json_decode($response);
       $response = $respMsg->message;    
  }


  //-----insert into email status
    
   $emailInfo = array(
          'response'    => $response,
          'status'    => ($response=='success') ? '0' : '1',
          'mailreceive_date'    => date('Y-m-d H:i:s')

      );

   $this->db->where('id',$useridd);
$upstatusa = $this->db->update('usr_register',$emailInfo);

  //-----end insert into email status

 // End Mail For Activation Link         

        $this->session->set_flashdata('msg','Account Activation Link has been sent to your Registered Email. Please check it.');
        redirect('login');
   
  }



  function logout(){
      $this->session->sess_destroy();
      redirect('login');
  }

}
