<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Masters extends CI_Controller{
  function __construct(){
    parent::__construct();

    if($this->session->userdata('admlogged_in') !== TRUE)
	redirect('admin/login');

    $this->admID       = $this->session->userdata('admID');
    $this->admName     = $this->session->userdata('admName');
    $this->admDesig    = $this->session->userdata('admDesig');
    $this->admDistrict = $this->session->userdata('admDistrict');

    

    $this->load->model('M_application','_application');
    $this->load->model('M_organization','_organization');
    $this->load->model('M_location','_location');
    $this->load->model('M_stage','_stage');
     $this->load->model('M_masters','_master');

    $this->menu = 'Product';
  }

  function index(){
    

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appPendingURL'] = 'admin/ajax/application_pending';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/products_view',$data);
  }

  function product_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'Product';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get('m_product')->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/products_view',$data);
  }

    function product_edit(){

   $prod_id = $_POST["employee_id"];


    $data['menu'] = 'Product';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get_where('m_product', array('id'=>$prod_id))->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/products_edit',$data);
  }


function save(){


    $saveCert = array(
      'name'  => $this->input->post('pro_name'),
      'short_description'  => $this->input->post('pro_desc'),
      'terms_conditions'    => $this->input->post('pro_general'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );



$upStatus = $this->db->insert('m_product',$saveCert);

$insert_id = $this->db->insert_id();


 $logDet = array('activity'=>'Product-Add','details'=>$this->input->post('pro_name'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);


  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/product_view');
}




function update(){


    $upAppData = array(
      'name'  => $this->input->post('pro_name'),
      'short_description'  => $this->input->post('pro_desc'),
      'terms_conditions'    => $this->input->post('pro_general'),
      'isactive'  => $this->input->post('status'),
      'mdfdate'    => date('Y-m-d H:i:s'),
      'mdfby'     => $this->admID
    );

$insert_id = $this->input->post('pro_id');

$this->db->where('id',$insert_id);
$upStatus = $this->db->update('m_product',$upAppData);

 $logDet = array('activity'=>'Product-Edit','details'=>$this->input->post('pro_name'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);

  if($upStatus):

          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/product_view');
}


 function user_manual(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'Admin Manual';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );



    $this->load->view('admin/user_manual',$data);
  }


 function user_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'User';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get('admin')->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_view',$data);
  }

    function user_edit(){

   $prod_id = $_POST["employee_id"];


    $data['menu'] = 'User';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get_where('admin', array('id'=>$prod_id))->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_edit',$data);
  }



function user_save(){


    $saveCert = array(
      'name'  => $this->input->post('name'),
      'usrname'  => $this->input->post('usrname'),
      'usrpassword'    => md5($this->input->post('usrpassword')),
      'email'    => $this->input->post('email'),
      'desig_id'    => $this->input->post('desig_id'),
      'district_id'    => $this->input->post('district_id'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );



$upStatus = $this->db->insert('admin',$saveCert);

$insert_id = $this->db->insert_id();

 $logDet = array('activity'=>'User-Add','details'=>$this->input->post('usrname'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);


  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_view');
}


function user_update(){


     $saveCert = array(
      'name'  => $this->input->post('name'),
      'usrname'  => $this->input->post('usrname'),
      'email'    => $this->input->post('email'),
      'desig_id'    => $this->input->post('desig_id'),
      'district_id'    => $this->input->post('district_id'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );

$insert_id = $this->input->post('user_id');

$this->db->where('id',$insert_id);
$upStatus = $this->db->update('admin',$saveCert);


 $logDet = array('activity'=>'User-Add','details'=>$this->input->post('usrname'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);

  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_view');
}

  function logs(){
    $this->menu = 'Logs';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appLogURL'] = 'admin/ajax/user_logs';
    $this->load->view('admin/logs',$data);
  }


function report()
{
  $data['arr_css'] = array(
                             'admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/datepicker.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );
  $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js',
                             'admin/js/DataTables/dataTables.buttons.js',
                             'admin/js/jquery-ui.js'
                            );

    $data['appReportURL'] = 'admin/ajax/application_report';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/report',$data);
}

function districtwise_report()
{
  $data['arr_css'] = array(
                             'admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/datepicker.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );
  $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js',
                             'admin/js/DataTables/dataTables.buttons.js',
                             'admin/js/jquery-ui.js'
                            );

    $data['appReportCount'] = 'admin/ajax/application_district_report';
    $data['appViewURL1']    = 'admin/application/view/';
    $this->load->view('admin/districtwise_report',$data);
}
//START TIMELINE


 function user_timeline_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'Timeline';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get('approval_timeline')->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_timeline_view',$data);
  }

    function user_timeline_edit(){

   $prod_id = $_POST["employee_id"];


    $data['menu'] = 'Timeline';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get_where('approval_timeline', array('id'=>$prod_id))->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_timeline_edit',$data);
  }



function user_timeline_save(){


    $saveCert = array(
      'desig_id'    => $this->input->post('desig_id'),
      'app_status_id'    => $this->input->post('app_status_id'),
      'timeline'  => $this->input->post('timeline'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );



$upStatus = $this->db->insert('approval_timeline',$saveCert);

$insert_id = $this->db->insert_id();

 $logDet = array('activity'=>'Approval-Timeline-Add','details'=>'Timeline Created','crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);


  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_timeline_view');
}


function user_timeline_update(){


     $saveCert = array(
      'timeline'    => $this->input->post('timeline'),
      'desig_id'    => $this->input->post('desig_id'),
      'app_status_id'    => $this->input->post('app_status_id'),
      'isactive'  => $this->input->post('status'),
      'mdfdate'    => date('Y-m-d H:i:s'),
      'mdfby'     => $this->admID
    );
//print_r($saveCert);
//die;
$insert_id = $this->input->post('user_id');

$this->db->where('id',$insert_id);
$upStatus = $this->db->update('approval_timeline',$saveCert);


 $logDet = array('activity'=>'Approval-Timeline-Update','details'=>'Timeline Updated','crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);

  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_timeline_view');
}



//START MAKE PAYMENT DYNAMIC


 function user_regfee_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'Registration Fee';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get('m_reg_fee')->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_regfee_view',$data);
  }

    function user_regfee_edit(){

   $prod_id = $_POST["employee_ida"];

//echo $prod_id;

    $data['menu'] = 'Registration Fee';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get_where('m_reg_fee', array('id'=>$prod_id))->result();
    $data['pro_det'] = $productt;
//print_r($data['pro_det']);
    $this->load->view('admin/user_regfee_edit',$data);
  }



function user_regfee_save(){

//echo $this->input->post('prod_id');
//die;
    $saveCert = array(
      'prod_id'    => $this->input->post('prod_id'),
      'org_loc_district_id'    => $this->input->post('org_loc_district_id'),
      'org_loc_taluk_id'  => $this->input->post('org_loc_taluk_id'),
      'amount'  => $this->input->post('timeline'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );



$upStatus = $this->db->insert('m_reg_fee',$saveCert);

$insert_id = $this->db->insert_id();

 $logDet = array('activity'=>'User-Registration-Fee-Added','details'=>'TUser-Registration-Fee-Created','crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);


  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_regfee_view');
}


function user_regfee_update(){


     $saveCert = array(
    'prod_id'    => $this->input->post('prod_id'),
      'org_loc_district_id'    => $this->input->post('org_loc_district_id'),
      'org_loc_taluk_id'  => $this->input->post('org_loc_taluk_id'),
      'amount'  => $this->input->post('timeline'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );
//print_r($saveCert);
//die;
$insert_id = $this->input->post('user_id');

$this->db->where('id',$insert_id);
$upStatus = $this->db->update('m_reg_fee',$saveCert);


 $logDet = array('activity'=>'User-Registration-Fee-Update','details'=>'User-Registration-Fee Updated','crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);

  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_regfee_view');
}


  function get_talukloc()
    {

$districtid=$_POST["districtid"];

$query = $this->db->query("SELECT * FROM m_taluk WHERE district_id ='$districtid'");
//$query = $this->db->get_where('m_states', array('country_id' => $countryid));    
    //Count total number of rows
 echo '<option value="">Select Taluk</option>';
    foreach ($query->result() as $row) {
  
    if($row->id > 0){
 echo '<option value="'.$row->id.'">'.$row->name.'</option>';      
    }else{
 echo '<option value="">No Taluk Available</option>';
    }
}
 
}

//END  MAKE PAYMENT DYNAMIC



//END TIMELINE


}
