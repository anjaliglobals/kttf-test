<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	function __construct(){
		parent::__construct();

	    if($this->session->userdata('admlogged_in') !== TRUE)
		//redirect('admin/login');
	    redirect('Login');

	    $this->admID       = $this->session->userdata('admID');
	    $this->admName     = $this->session->userdata('admName');
	    $this->admDesig    = $this->session->userdata('admDesig');
	    $this->admDistrict = $this->session->userdata('admDistrict');


 	    $this->load->model('M_application','_application');
 	    $this->load->model('M_masters','_masters');
	}

	function application_pending()
	{	
		$data['dist_id']=$this->input->post('distId');
		$data['prod_id']=$this->input->post('prodid');
		$appDetails = $this->_application->getPendingApplication($data);
		echo json_encode($appDetails);
	}

	function application_summary()
	{
		$data['dist_id']=$this->input->post('distId');
		$data['prod_id']=$this->input->post('prodid');
		$appDetails = $this->_application->getSummaryApplication($data);

		echo json_encode($appDetails);
	}

	function application_closed(){
		$data['dist_id']=$this->input->post('distId');
		$data['prod_id']=$this->input->post('prodid');
		$appDetails = $this->_application->getClosedApplication($data);
		echo json_encode($appDetails);
	}

	function application_rejected(){
		$data['dist_id']=$this->input->post('distId');
		$data['prod_id']=$this->input->post('prodid');
		$appDetails = $this->_application->getRejectedApplication($data);
		echo json_encode($appDetails);
	}


	function user_logs(){
		$logDetails = $this->_masters->getUserLogs();
		echo json_encode($logDetails);
	}
	function application_report()
	{
		$data['dist_id']=$this->input->post('distId');
		$data['prod_id']=$this->input->post('prodid');
		$data['fdate']=$this->input->post('fromdate');
		$data['tdate']=$this->input->post('todate');
		$data['status_id']=$this->input->post('status_id');
		$appDetails = $this->_application->getreportData($data);
		echo json_encode($appDetails);
	}
	function exportreport()
	{	
		$params = $_REQUEST;
		$data['dist_id']=$params['districtId'];
		$data['prod_id']=$params['prod_id'];
		$data['fdate']=$params['fdate'];
		$data['tdate']=$params['tdate'];
		$data['status_id']=$params['staus'];
		$appDetails = $this->_application->getExportData($data);
		echo json_encode($appDetails);
	}
	function vehicledata()
  	{
  		 $id=$this->input->post('appId');
	     $appvehicledata=$this->_application->vehicleInfo($id);
	     echo json_encode($appvehicledata);
  	}
}
