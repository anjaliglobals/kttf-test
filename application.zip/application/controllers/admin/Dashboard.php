<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller{
  function __construct(){
    parent::__construct();
    if($this->session->userdata('admlogged_in') !== TRUE){
      redirect('admin/login');
    }


    $this->admID       = $this->session->userdata('admID');
    $this->admName     = $this->session->userdata('admName');
    $this->admDesig    = $this->session->userdata('admDesig');
    $this->admDistrict = $this->session->userdata('admDistrict');

    $this->load->model('M_application','_application');

    $this->menu = 'Dashboard';
  }

  function index(){

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                              'admin/css/style.css'
                            );

    $data['arr_js']  = array();

    $data['dashboardInfo'] = $this->_application->adminDashboardInfo();

    $this->load->view('admin/dashboard',$data);
  }

}
