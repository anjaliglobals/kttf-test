<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Application extends CI_Controller{
  function __construct(){
    parent::__construct();

    if($this->session->userdata('admlogged_in') !== TRUE)
	   redirect('admin/login');

    $this->admID       = $this->session->userdata('admID');
    $this->admName     = $this->session->userdata('admName');
    $this->admDesig    = $this->session->userdata('admDesig');
    $this->admDistrict = $this->session->userdata('admDistrict');

    

    $this->load->model('M_application','_application');
    $this->load->model('M_organization','_organization');
    $this->load->model('M_location','_location');
    $this->load->model('M_stage','_stage');

    $this->menu = 'Application';
  }

  function index(){
    $this->menu = 'Application';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appPendingURL'] = 'admin/ajax/application_pending';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_pending',$data);
  }

  function application_summary(){
    $this->menu = 'Summary';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appSummaryURL'] = 'admin/ajax/application_summary';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_summary',$data);
  }

  function application_closed(){
    $this->menu = 'Closed';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appClosedURL'] = 'admin/ajax/application_closed';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_closed',$data);
  }

  function admin_notification(){    
  
	//echo $this->admID;

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );
		$this->db->query("SET sql_mode=(SELECT REPLACE(@@sql_mode, 'ONLY_FULL_GROUP_BY', ''));");
		$this->db->group_by('application_id');
		$this->db->order_by('id','desc');
		$notifi_det = $this->db->get_where('adm_notification', array('adm_id'=>$this->admID))->result();
		 //print_r($notifi_det);
		$data['note_det'] = $notifi_det;
		$this->load->view('admin/notification',$data);
  }

  function application_rejected(){
    $this->menu = 'Rejected';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appRejectedURL'] = 'admin/ajax/application_rejected';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_rejected',$data);
  }

  function view(){

    $id = $this->uri->segment(4);

    $this->menu = 'Application';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js'
                           );

    $data['appRejectLink']  = 'admin/application/rejectApplication';
    $data['appApproveLink'] = 'admin/application/approveApplication';

    $data['access'] = $this->_stage->accessPrivilege($id);


    $appDettails = $this->_application->getAppInfo($id);

    $data['application'] = array_shift($appDettails);

    $data['organization'] = $this->_organization->getListOrgType();

    $data['country']  = $this->_location->getListLocation('m_countries');
    $data['state']    = $this->_location->getListLocation('m_states');
    $data['city']     = $this->_location->getListLocation('m_cities');
    $data['district'] = $this->_location->getListLocation('m_district');

    $data['comments']  = $this->_application->getAppComments($id,$data['application']->licence_renewal_count);
    $data['docverify'] = $this->_application->getAppDocVerify($id,$data['application']->licence_renewal_count);

    $this->load->view('admin/application',$data);
  }
  
    function application_notification_view(){
		$id = $this->uri->segment(4);	
        $appdet = $this->db->get_where('application' , array('id'=>$id))->result();
        //print_r($appdet);
		$notiInfo = array(
          'status'    => '1',
          'statusviewed_date'    => date('Y-m-d H:i:s')
		);
		$this->db->where('application_id',$id);
		$upstatusa = $this->db->update('adm_notification',$notiInfo);
		$appnot_det = $this->db->get_where('adm_notification' , array('application_id'=>$id))->result();
		//print_r($appnot_det);
		$data['appnot_det']   = $appnot_det;		
		$data['appdetails']   = $appdet;
		$this->menu = 'Application';
		$data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );
	    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js'
                           );
	   $data['organization'] = $this->_organization->getListOrgType();
	   $data['appRejectLink']  = 'admin/application/rejectApplication';
	   $data['appApproveLink'] = 'admin/application/approveApplication';
	   $data['access'] = $this->_stage->accessPrivilege($id);
	   $appDettails = $this->_application->getAppInfo($id);
	   $data['application'] = array_shift($appDettails);
	   $this->load->view('admin/application',$data);
  }


  function certificate(){

    $id = $this->uri->segment(4);

//echo $id;
    $this->menu = 'Application';
    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );
    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js'
                           );
    $data['appRejectLink']  = 'admin/application/rejectApplication';
    $data['appApproveLink'] = 'admin/application/approveApplication';
    $data['access'] = $this->_stage->accessPrivilege($id);
    $accessPrivilege = $data['access'];

    $appDettails=$this->_application->getAppInfo($id);

//print_r($appDettails);
// $data['appDettails'] = $appDettails;
    $data['application'] = array_shift($appDettails);
    // print_r($data['application']);
    $data['organization'] = $this->_organization->getListOrgType();
    $data['country']  = $this->_location->getListLocation('m_countries');
    $data['state']    = $this->_location->getListLocation('m_states');
    $data['city']     = $this->_location->getListLocation('m_cities');
    $data['district'] = $this->_location->getListLocation('m_district');

    $data['comments']  = $this->_application->getAppComments($id,$data['application']->licence_renewal_count);
    $data['docverify'] = $this->_application->getAppDocVerify($id,$data['application']->licence_renewal_count);

    $this->load->view('admin/certificate',$data);
  }



  function application_update()
  {

    $appID = $this->input->post('application_id');
    $appDetails = $this->db->get_where('application',array('id' => $appID), true)->result_array();
    $appDettails = array_shift($appDetails);
    $upload_check = $this->input->post('upload_check');
	  $desc_id=$this->input->post('desc_id');


//--------Doc verification-----------
  $document_verification = $this->input->post('document_verification');
  if(isset($document_verification)):
    $reg_certificate         = $this->input->post('img_registration_certificate');
    $reg_certificate_details = $this->input->post('img_registration_certificate_details');
    $bank_reference          = $this->input->post('img_bank_reference');
    $bank_reference_details  = $this->input->post('img_bank_reference_details');
    $ca_certificate          = $this->input->post('img_ca_certificate');

    $ca_certificate_details  = $this->input->post('img_ca_certificate_details');
    $audited_balance         = $this->input->post('img_audited_balance_sheet');
    $audited_balance_details = $this->input->post('img_audited_balance_sheet_details');
    $patners_list            = $this->input->post('img_list_patners');
    $patners_list_details    = $this->input->post('img_list_patners_details');

    $brochures               = $this->input->post('img_brochures');
    $brochures_details       = $this->input->post('img_brochures_details');
    $off_premises            = $this->input->post('img_off_premises');
    $off_premises_details    = $this->input->post('img_off_premises_details');
    $labour_dep              = $this->input->post('img_labour_department');
    $labour_dep_details      = $this->input->post('img_labour_department_details');

    $md_photo                = $this->input->post('img_md_photo_attested');
    $md_photo_details        = $this->input->post('img_md_photo_attested_details');
    $off_exterior            = $this->input->post('img_off_buil_exterior');
    $off_exterior_details    = $this->input->post('img_off_buil_exterior_details');
    $off_interior            = $this->input->post('img_off_buil_interior');

    $off_interior_details    = $this->input->post('img_off_buil_interior_details');
    $off_staff_cv            = $this->input->post('img_off_staff_member');
    $off_staff_cv_details    = $this->input->post('img_off_staff_member_details');


//NEWW


    $img_gst_regis            = $this->input->post('img_gst_regis');
    $img_gst_regis_details    = $this->input->post('img_gst_regis_details');

    $img_tourist_arrival_details            = $this->input->post('img_tourist_arrival_details');
    $img_tourist_arrival_details_details    = $this->input->post('img_tourist_arrival_details_details');

    $img_pledge_commitment            = $this->input->post('img_pledge_commitment');
    $img_pledge_commitment_details    = $this->input->post('img_pledge_commitment_details');

    $img_pan_copy            = $this->input->post('img_pan_copy');
    $img_pan_copy_details    = $this->input->post('img_pan_copy_details');

    $img_power_of_attorney            = $this->input->post('img_power_of_attorney');
    $img_power_of_attorney_details    = $this->input->post('img_power_of_attorney_details');


    $insArrDocsComment = array('reg_certificate'        =>  $reg_certificate,
                              'reg_certificate_details' =>  $reg_certificate_details,
                              'bank_reference'          =>  $bank_reference,
                              'bank_reference_details'  =>  $bank_reference_details,
                              'ca_certificate'          =>  $ca_certificate,
                              'ca_certificate_details'  =>  $ca_certificate_details,
                              'audited_balance'         =>  $audited_balance,
                              'audited_balance_details' =>  $audited_balance_details,
                              'patners_list'            =>  $patners_list,
                              'patners_list_details'    =>  $patners_list_details ,
                              'brochures'               =>  $brochures,
                              'brochures_details'       =>  $brochures_details,
                              'off_premises'            =>  $off_premises,
                              'off_premises_details'    =>  $off_premises_details,
                              'labour_dep'              =>  $labour_dep,
                              'labour_dep_details'      =>  $labour_dep_details,
                              'md_photo'                =>  $md_photo,
                              'md_photo_details'        =>  $md_photo_details,
                              'off_exterior'            =>  $off_exterior,
                              'off_exterior_details'    =>  $off_exterior_details,
                              'off_interior'            =>  $off_interior,
                              'off_interior_details'    =>  $off_interior_details,
                              'off_staff_cv'            =>  $off_staff_cv,
                              'off_staff_cv_details'    =>  $off_staff_cv_details,

                              'img_gst_regis'    =>  $img_gst_regis,
                              'img_gst_regis_details'    =>  $img_gst_regis_details,
                              'img_tourist_arrival_details'    =>  $img_tourist_arrival_details,
                              'img_tourist_arrival_details_details'    =>  $img_tourist_arrival_details_details,
                              'img_pledge_commitment'    =>  $img_pledge_commitment,
                              'img_pledge_commitment_details'    =>  $img_pledge_commitment_details,
                              'img_pan_copy'    =>  $img_pan_copy,
                              'img_pan_copy_details'    =>  $img_pan_copy_details,
                              'img_power_of_attorney'    =>  $img_power_of_attorney,
                              'img_power_of_attorney_details'    =>  $img_power_of_attorney_details,
                              'crtdate'                 =>  date('Y-m-d H:i:s'),
                              'crtby'                   =>  $this->admID,
                              'application_id'          =>  $appDettails['id'],
                              'licence_renewal_no'      =>  $appDettails['licence_renewal_count'],
                              'app_stage_id'            =>  $appDettails['stage_id']
                            );
  endif;


//----Action performed
    $applicationType = $this->input->post('btnAction');
    $message = '';
    // echo $applicationType;
    switch ($applicationType) 
    {
          case 'btnReject':
    	          $subject = 'Application Rejected';
                $updApp = array('status_code' => 1,
                               'status_code_date' => date('Y-m-d H:i:s')
                              );
                // Start Alert & Notification Code
                // Mail For Alert
                $appdet_id = $appDettails['id'];
                $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;

                $externalCom = $this->input->post('external_comment');

                $messagen = "Your application number is ".$appDettails['application_id']." is rejected. Kindly login KTTF portal for more information";

                $mail_config = $this->config->item('mail_conf');
                $user = $mail_config['username'];
                $pass = $mail_config['password'];
                $url  = $mail_config['url'];
                $fromname  = $mail_config['from'];
                $fromid  = $mail_config['admin_mail'];
            
                $body = "<h3>Dear ".$applicant_name.",</h3><p><br> ".$messagen."</p><p><h4>
                  <br>
                  Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                  </h4>
                  </p>";
                $subject = "Application Rejected";
                $fromname = "support@kstdc.co";
                $params = array(
                      'api_user'  => $user,
                      'api_key'   => $pass,
                      'to'        => $official_email,
                      'subject'   => $subject,
                      'html'      => $body,
                      'text'      => '',
                      'from'      => $fromname
                  ); 

                  $request =  $url.'api/mail.send.json';
                  $session = curl_init($request);
                  curl_setopt ($session, CURLOPT_POST, true);
                  curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                  curl_setopt($session, CURLOPT_HEADER, false);
                  curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                  // obtain response
                  $response = curl_exec($session); 
                  curl_close($session);
                  $respMsg =  json_decode($response);
                  $response = $respMsg->message;
  
 
                  //-----insert into email status
                    $notimsg = " Your application number is ".$appDettails['application_id']." is rejected. ".$externalCom;
                    $emailInfo = array(
                      'register_id'    => $register_id,
                      'application_id'    => $appdet_id,
                      'subject'    => $subject,
                      'message'    => $notimsg,
                      'app_stage'    => $appDettails['stage_id'],
                      'status'    => '0',
                      'mail_status'    => ($response=='success') ? '0' : '1',
                      'crtdate'    => date('Y-m-d H:i:s'),
                      'crtby'     => $this->admID,
                      'crtname'     => $this->admName
                      );
                    $upStatusnoti = $this->db->insert('application_notification',$emailInfo);					
					
					//-----Admin Notification
					$org_loc_district_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->org_loc_district_id;
					$adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;			

						$adm_noti = "You Rejected ".$appDettails['application_id']." this application ".$externalCom;
						$new_appli = array(
							'register_id'    => $register_id,
							'application_id'    => $appdet_id,
							'district_id'     => $org_loc_district_id,
							'adm_id'     => $adm_id,
							'subject'    => $subject,
							'message'    => $adm_noti,
							'app_stage'    => $appDettails['stage_id'],
							'status'    => '0',
							'mail_status'    => ($response=='success') ? '0' : '1',
							'crtdate'    => date('Y-m-d H:i:s'),
							'crtby'     => $this->admID,
							'crtname'     => $this->admName
						  );
						
					$upStatusnoti = $this->db->insert('adm_notification',$new_appli);


                    // End Alert & Notification Code
	                  $message = "Dear KTTF Customer, Your application number is ".$appDettails['application_id']." is rejected. Kindly login KTTF portal for more information";

                    break;

                    /**************Return for clarification***********/
                    case 'btnresend':
                        $appstatus=($desc_id==3 ? "5" : "2");
                        $iteration=($desc_id==3 ? $appDettails['iteration'] : (($appDettails['iteration']!=null?($appDettails['iteration']+1):1)));
              	        $subject = 'Application Resent for Clarification';                                                  
                        $updApp = array('status_code' => 0,
                               'status_code_date' => date('Y-m-d H:i:s'),
                               'app_status'=>$appstatus,
                               'iteration'=>$iteration
                              );
                          // Start Alert & Notification Code
                          // Mail For Alert
                          $appdet_id = $appDettails['id'];
                          $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                          $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                          $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;

                          $externalCom = $this->input->post('external_comment');
                          // Start Alert & Notification Code
                          // Mail For Alert
                          $appdet_id = $appDettails['id'];
                          $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                          $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                          $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;
                          $messagen = "Your application number is ".$appDettails['application_id']." has been resented for clarification. Kindly login to your KTTF account to check the status.";
                          $mail_config = $this->config->item('mail_conf');
                          $user = $mail_config['username'];
                          $pass = $mail_config['password'];
                          $url  = $mail_config['url'];
                          $fromname  = $mail_config['from'];
                          $fromid  = $mail_config['admin_mail'];
                                
                          $body = "<h3>Dear ".$applicant_name.",</h3><p><br> ".$messagen."</p><p><h4>
                           
                          <br>
                          Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                          </h4>
                          </p>";                          
                          $subjecta = "Application resented for clarification";
                          $fromname = "support@kstdc.co";
                          $params = array(
                                'api_user'  => $user,
                                'api_key'   => $pass,
                                'to'        => $official_email,
                                'subject'   => $subjecta,
                                'html'      => $body,
                                'text'      => '',
                                'from'      => $fromname
                          ); 

                          $request =  $url.'api/mail.send.json';
                          $session = curl_init($request);
                          curl_setopt ($session, CURLOPT_POST, true);
                          curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                          curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                          curl_setopt($session, CURLOPT_HEADER, false);
                          curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                          curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                          // obtain response
                          $response = curl_exec($session); 
                          curl_close($session);
                          $respMsg =  json_decode($response);
                          $response = $respMsg->message;
                          
                          //-----insert into email status
                          $notimsg = " Your application number is ".$appDettails['application_id']." has been resented for clarification. Kindly login to your KTTF account to check the status ";
                          $emailInfo = array(
                               'register_id'    => $register_id,
                               'application_id'    => $appdet_id,
                               'subject'    => $subjecta,
                               'message'    => $notimsg,
                               'app_stage'    => $stage_id,
                               'status'    => '0',
                               'mail_status'    => ($response=='success') ? '0' : '1',
                               'crtdate'    => date('Y-m-d H:i:s'),
                               'crtby'     => $this->admID,
                               'crtname'     => $this->admName
                                );

                          $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
						  
						  $org_loc_district_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->org_loc_district_id;
						  $adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;			

							$adm_noti = "You resented ".$appDettails['application_id']." Application";
							$new_appli = array(
								'register_id'    => $register_id,
								'application_id'    => $appdet_id,
								'district_id'     => $org_loc_district_id,
								'adm_id'     => $adm_id,
								'subject'    => $subjecta,
								'message'    => $adm_noti,
								'app_stage'    => $appDettails['stage_id'],
								'status'    => '0',
								'mail_status'    => ($response=='success') ? '0' : '1',
								'crtdate'    => date('Y-m-d H:i:s'),
								'crtby'     => $this->admID,
								'crtname'     => $this->admName
							  );
							
						$upStatusnoti = $this->db->insert('adm_notification',$new_appli);

                          //print_r($this->db->last_query());
                            // End Alert & Notification Code
                        	$message = "Dear KTTF Customer, Your application number is ".$appDettails['application_id']." has been resented for clarification. Kindly login to your KTTF account to check the status.";

                    break;
                    /**************End for return of clarification***********/                    

                    case 'btnApprovePayment':   
                          $subject = 'Application Approved To Next Stage';
                          $stage_id = ++$appDettails['stage_id'];
                          $updApp = array('is_payment_approved'  => 1,
                            'approve_payment_date' => date('Y-m-d H:i:s'),
                            'stage_id' => $stage_id
                          );
                          // Start Alert & Notification Code
                          // Mail For Alert
                          $appdet_id = $appDettails['id'];
                          $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                          $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                          $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;
                          $messagen = "Your application number is ".$appDettails['application_id']." has been approved for payment. Kindly login to your KTTF account to make payment.";
                          $mail_config = $this->config->item('mail_conf');
                          $user = $mail_config['username'];
                          $pass = $mail_config['password'];
                          $url  = $mail_config['url'];
                          $fromname  = $mail_config['from'];
                          $fromid  = $mail_config['admin_mail'];
                        
                          $body = "<h3>Dear ".$applicant_name.",</h3><p><br> ".$messagen."</p><p><h4>
                           
                          <br>
                          Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                          </h4>
                          </p>";
                          $subjecta = "Application Approved for Payment";
                          $fromname = "support@kstdc.co";
                             $params = array(
                                'api_user'  => $user,
                                'api_key'   => $pass,
                                'to'        => $official_email,
                                'subject'   => $subjecta,
                                'html'      => $body,
                                'text'      => '',
                                'from'      => $fromname
                            ); 

                            $request =  $url.'api/mail.send.json';
                            $session = curl_init($request);
                            curl_setopt ($session, CURLOPT_POST, true);
                            curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                            curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                            curl_setopt($session, CURLOPT_HEADER, false);
                            curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                            curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                            // obtain response
                            $response = curl_exec($session); 
                            curl_close($session);
                            $respMsg =  json_decode($response);
                            $response = $respMsg->message;
                            //-----insert into email status
                            $notimsg = " Your application number is ".$appDettails['application_id']." has been approved for payment. Kindly check the payment Section. ";
                            $emailInfo = array(
                             'register_id'    => $register_id,
                             'application_id'    => $appdet_id,
                             'subject'    => $subjecta,
                             'message'    => $notimsg,
                             'app_stage'    => 3,
                             'status'    => '0',
                             'mail_status'    => ($response=='success') ? '0' : '1',
                             'crtdate'    => date('Y-m-d H:i:s'),
                             'crtby'     => $this->admID,
                             'crtname'     => $this->admName
                              );

                            $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
							
							// Admin Notification
							$org_loc_district_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->org_loc_district_id;
							$adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;			

							$adm_noti = "You approved for payment for this Application ".$appDettails['application_id']." ";
							$new_appli = array(
								'register_id'    => $register_id,
								'application_id'    => $appdet_id,
								'district_id'     => $org_loc_district_id,
								'adm_id'     => $adm_id,
								'subject'    => $subjecta,
								'message'    => $adm_noti,
								'app_stage'    => $stage_id,
								'status'    => '0',
								'mail_status'    => ($response=='success') ? '0' : '1',
								'crtdate'    => date('Y-m-d H:i:s'),
								'crtby'     => $this->admID,
								'crtname'     => $this->admName
							  );
							
						$upStatusnoti = $this->db->insert('adm_notification',$new_appli);
							
                          // End Alert & Notification Code
                            $message = "Dear KTTF Customer, Your application number is ".$appDettails['application_id']." has been approved for payment. Kindly login to your KTTF account to make payment.";
                    break;
                   

                    case 'btnApproveNxtStage':   
                	    $subject = 'Application Approved To Next Stage';
                      $stage_id = ++$appDettails['stage_id'];
                      //print_r($stage_id);
                      $updApp = array('stage_id' => $stage_id);
                      // Start Alert & Notification Code
                      // Mail For Alert
                      $appdet_id = $appDettails['id'];
                      $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                      $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                      $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;
                      // echo $this->db->last_query(); 

                      $messagen = "Your application number is ".$appDettails['application_id']." has been Moved To Next Stage. Kindly login to your KTTF account and check the status.";
                      $mail_config = $this->config->item('mail_conf');
                      $user = $mail_config['username'];
                      $pass = $mail_config['password'];
                      $url  = $mail_config['url'];
                      $fromname  = $mail_config['from'];
                      $fromid  = $mail_config['admin_mail'];
                         
                      $body = "<h3>Dear ".$applicant_name.",</h3><p><br> ".$messagen."</p><p><h4>
                      <br>
                       Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                        </h4>
                        </p>";
                      $subjecta = "Application Approved To Next Stage";
                      $fromname = "support@kstdc.co";
                      $params = array(
                            'api_user'  => $user,
                            'api_key'   => $pass,
                            'to'        => $official_email,
                            'subject'   => $subjecta,
                            'html'      => $body,
                            'text'      => '',
                            'from'      => $fromname
                        ); 

                        $request =  $url.'api/mail.send.json';
                        $session = curl_init($request);
                        curl_setopt ($session, CURLOPT_POST, true);
                        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                        curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                        curl_setopt($session, CURLOPT_HEADER, false);
                        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                      // obtain response
                      $response = curl_exec($session); 
                      curl_close($session);
                      $respMsg =  json_decode($response);
                      $response = $respMsg->message;                
                      //-----insert into email status
                      $notimsg = " Your application number is ".$appDettails['application_id']." has been Moved to Next Stage.";
                      $emailInfo = array(
                       'register_id'    => $register_id,
                       'application_id'    => $appdet_id,
                       'subject'    => $subjecta,
                       'message'    => $notimsg,
                       'app_stage'    => $stage_id,
                       'status'    => '0',
                       'mail_status'    => ($response=='success') ? '0' : '1',
                       'crtdate'    => date('Y-m-d H:i:s'),
                       'crtby'     => $this->admID,
                       'crtname'     => $this->admName
                        );
                      //print_r($this->db->last_query()); 
                      $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
				  
						// Admin Notification
						$org_loc_district_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->org_loc_district_id;
						$adm_id = $this->db->get_where('admin', array('district_id' => $org_loc_district_id))->row()->id;			

						$adm_noti = "You Moved Application ".$appDettails['application_id']. " to [JD] Next Stage.";
						$new_appli = array(
							'register_id'    => $register_id,
							'application_id'    => $appdet_id,
							'district_id'     => $org_loc_district_id,
							'adm_id'     => $adm_id,
							'subject'    => $subjecta,
							'message'    => $adm_noti,
							'app_stage'    => $stage_id,
							'status'    => '0',
							'mail_status'    => ($response=='success') ? '0' : '1',
							'crtdate'    => date('Y-m-d H:i:s'),
							'crtby'     => $this->admID,
							'crtname'     => $this->admName
						  );
						
					$upStatusnoti = $this->db->insert('adm_notification',$new_appli);
				  // End Alert & Notification Code
                	    //-------resubmit from send back
                	    if($appDettails['stg_send_back_date'] != '' && $appDettails['stg_send_back_submit_date'] == ''):
                            	$updApp['stg_send_back_submit_date'] = date('Y-m-d H:i:s');
                	    endif;

                      break;
                      case 'btnApproveLicenseStage':   
                    	    $subject = 'Application Approved For License';
                          $stage_id = ++$appDettails['stage_id'];
                          $licence_no = rand(5, 15);
                          $licence_issued_date = date('Y-m-d H:i:s');
                          $updApp = array('stage_id' => $stage_id,'status_code' => '2','licence_no' => $licence_no,'licence_issued_date' => $licence_issued_date);
                          // Start Alert & Notification Code
                          // Mail For Alert
                          $appdet_id = $appDettails['id'];
                          $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                          $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                          $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;
                          $messagen = "Your application number is ".$appDettails->application_id." has been Approved For License. Kindly login to your KTTF account and check the status.";
                          $mail_config = $this->config->item('mail_conf');
                          $user = $mail_config['username'];
                          $pass = $mail_config['password'];
                          $url  = $mail_config['url'];
                          $fromname  = $mail_config['from'];
                          $fromid  = $mail_config['admin_mail'];                        
                          $body = "<h3>Dear ".$applicant_name.",</h3><p><br> ".$messagen."</p><p><h4>                  
                          
                          <br>
                          Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                          </h4>
                          </p>";
                          $subjecta = "Application Approved For License";
                          $fromname = "support@kstdc.co";
                          $params = array(
                          'api_user'  => $user,
                          'api_key'   => $pass,
                          'to'        => $official_email,
                          'subject'   => $subjecta,
                          'html'      => $body,
                          'text'      => '',
                          'from'      => $fromname
                          ); 

                          $request =  $url.'api/mail.send.json';
                          $session = curl_init($request);
                          curl_setopt ($session, CURLOPT_POST, true);
                                curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                          curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                          curl_setopt($session, CURLOPT_HEADER, false);
                                curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                          curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                          // obtain response
                          $response = curl_exec($session); 
                          curl_close($session);
                          $respMsg =  json_decode($response);
                          $response = $respMsg->message;
                          //-----insert into email status
                          $notimsg = " Your application number is ".$appDettails['application_id']." has been Approved For License.";
                          $emailInfo = array(
                          'register_id'    => $register_id,
                          'application_id'    => $appdet_id,
                          'subject'    => $subjecta,
                          'message'    => $notimsg,
                          'app_stage'    => $stage_id,
                          'status'    => '0',
                          'mail_status'    => ($response=='success') ? '0' : '1',
                          'crtdate'    => date('Y-m-d H:i:s'),
                          'crtby'     => $this->admID,
                          'crtname'     => $this->admName
                          );

                        $upStatusnoti = $this->db->insert('application_notification',$emailInfo);

                    // End Alert & Notification Code
                    break;
                    case 'btnSendBack':   
                	    $subject  = 'Application Sent Back To Previous Stage';
                      $stage_id = --$appDettails['stage_id'];
                      $updApp   = array('stage_id' => $stage_id,'stg_send_back_date' => date('Y-m-d H:i:s'));
                      // Start Alert & Notification Code
                     // Mail For Alert
                    $appdet_id = $appDettails['id'];
                    $applicant_name = $this->db->get_where('application', array('id' => $appdet_id))->row()->applicant_name;
                    $official_email = $this->db->get_where('application', array('id' => $appdet_id))->row()->official_email;
                    $register_id = $this->db->get_where('application', array('id' => $appdet_id))->row()->register_id;
                    $externalCom = $this->input->post('external_comment');
                    $messagen = "Your application number is ".$appDettails['application_id']." has been Sent Back To Previous Stage. Kindly login to your KTTF account and check the status. ".$externalCom;
                    $mail_config = $this->config->item('mail_conf');
                    $user = $mail_config['username'];
                    $pass = $mail_config['password'];
                    $url  = $mail_config['url'];
                    $fromname  = $mail_config['from'];
                    $fromid  = $mail_config['admin_mail'];
                    $body = "<h3>Dear ".$applicant_name.",</h3><p><br> ".$messagen."</p><p><h4>                   
                    <br>
                      Regards,<br> Karnataka Tourism Trade Facilitation.<br>
                    </h4>
                    </p>";
                    $subjecta = "Application Sent Back To Previous Stage";
                    $fromname = "support@kstdc.co";
                       $params = array(
                          'api_user'  => $user,
                          'api_key'   => $pass,
                          'to'        => $official_email,
                          'subject'   => $subjecta,
                          'html'      => $body,
                          'text'      => '',
                          'from'      => $fromname
                      ); 
                  $request =  $url.'api/mail.send.json';
                  $session = curl_init($request);
                  curl_setopt ($session, CURLOPT_POST, true);
                  curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
                  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
                  curl_setopt($session, CURLOPT_HEADER, false);
                  curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
                  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

                  // obtain response
                  $response = curl_exec($session); 
                  curl_close($session);
                  $respMsg =  json_decode($response);
                  $response = $respMsg->message;
                  

                  //-----insert into email status
                    $notimsg = " Your application number is ".$appDettails['application_id']." has been Sent Back To Previous Stage.".$externalCom;
                    $emailInfo = array(
                      'register_id'    => $register_id,
                      'application_id'    => $appdet_id,
                      'subject'    => $subjecta,
                      'message'    => $notimsg,
                      'app_stage'    => $stage_id,
                      'status'    => '0',
                      'mail_status'    => ($response=='success') ? '0' : '1',
                      'crtdate'    => date('Y-m-d H:i:s'),
                      'crtby'     => $this->admID,
                      'crtname'     => $this->admName
                      );

                    $upStatusnoti = $this->db->insert('application_notification',$emailInfo);
                    // End Alert & Notification Code
                    break;
                    }

                //--------comment----------
                    $internalCom = $this->input->post('internal_comment');
                    $externalCom = $this->input->post('external_comment');
                //echo $internalCom;
                //echo $externalCom;
                //die;
                      $insArrGeneralComment = array('application_id' => $appDettails['id'],
                                                    'subject'        => $subject,
                                                    'inter_comm'     => $internalCom,
                                                    'cons_comm'      => $externalCom,
                                                    'app_stage'      => $appDettails['stage_id'],
                                                    'licence_renewal_no' => $appDettails['licence_renewal_count'],
                                                    'crtdate'        => date('Y-m-d H:i:s'),
                                                    'crtby'          => $this->admID,
                                                    'crtname'        => $this->admName,
                                                  );
                //AD stg file upload
                    if($upload_check == 'Yes'):

                  	    $prevFile = ($appDettails['adm_upload'])? explode(',',$appDettails['adm_upload']) : array();
                  	    $prevFilCom = ($appDettails['adm_upload_details'])? explode(',',$appDettails['adm_upload_details']) : array();

                  	    $admimg = $this->img_upload('admin','adm_upload');			

                	     if($admimg !=''):
                    		$prevFile[]   = $admimg;
                    		$prevFilCom[] = $this->input->post('adm_upload_details');

                    		$admUplod = implode(',',$prevFile);
                    		$admUpDet = implode(',',$prevFilCom);

                    	  $updApp['adm_upload_details'] = $admUpDet;
                    		$updApp['adm_upload'] 	      = $admUplod;
                	     endif;
                    endif;


                    $this->db->trans_start(); # Starting Transaction
                    if(isset($document_verification))
                      	$insDocStatus = $this->db->insert('application_doc_verification',$insArrDocsComment);
                        $insComStatus = $this->db->insert('application_comment',$insArrGeneralComment);
                                        $this->db->where('id',$appDettails['id']);
                        $upAppstatus  = $this->db->update('application',$updApp);
                        $this->db->trans_complete(); # Completing transaction
                      if ($this->db->trans_status() === FALSE) {
                          $this->db->trans_rollback();
                          $this->session->set_flashdata('msg-error','Record not saved successfully. Please, try again.');
                          redirect('admin/application');
                      } 
                      else {
                          $this->db->trans_commit();
                        	if($message):
                        		$sendsms = $this->sendSMS($appDettails->org_loc_mobile, $message);
                        	endif;
                                $this->session->set_flashdata('msg','Record saved successfully.');
                                redirect('admin/application');
                      }
  }

  function reports()
  {

    $id = $this->uri->segment(4);

    $this->menu = 'Reports';

    $data['arr_css'] = array('admin/css/bootstrap.min.css');


    $appDettails = $this->_application->getAppInfo($id);

    $appDettails = array_shift($appDettails);

    $data['application'] = $appDettails;
    // print_r($data['application']);


    $payDet = $this->db->get_where('payment',array('id' => $appDettails->payment_id), true)->result_array();

    $payDet = array_shift($payDet);

    $data['payment'] = $payDet;
	    
    $this->load->view('admin/reports',$data);
  }

  function sendSMS($mobilenum, $message)
  {

	  $url  =   'http://smspush.openhouseplatform.com/smsmessaging/1/outbound/tel%3A%2BGKSTDC/requests';
	  $mobilefiotp3 = $mobilenum;
		$random_id_length = 4; 
		$rnd_id = rand(1000,9999);
		//End Random Code

		$messagee = $message;

		$bookingObj = array();
		$bookingObj['outboundSMSMessageRequest']['address'] = ["tel:$mobilefiotp3"];
		$bookingObj['outboundSMSMessageRequest']['senderAddress'] = "tel:GKSTDC"; 
		$bookingObj['outboundSMSMessageRequest']['outboundSMSTextMessage']['message']  = "$messagee";
		$bookingObj['outboundSMSMessageRequest']['clientCorrelator'] = "";
		$bookingObj['outboundSMSMessageRequest']['messageType'] = "";
		$bookingObj['outboundSMSMessageRequest']['category'] = "GKSTDC";
		$bookingObj['outboundSMSMessageRequest']['receiptRequest']['notifyURL'] = "";
		$bookingObj['outboundSMSMessageRequest']['receiptRequest']['callbackData'] = "$(callbackData)";
		$bookingObj['outboundSMSMessageRequest']['senderName'] = "GKSTDC";
		$data_string = json_encode($bookingObj);
		//print_r($data_string);
		//print_r($datastring);
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json', 'key: 6d2a1102-7c24-486d-ad7e-784c5bda6d66'));

		$output = curl_exec($ch);
		return true;
	} 


//************Upload*******
  function img_upload($folderName,$fName)
  {
        $config['upload_path'] = './upload/'.$folderName.'/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        $config['max_size'] = 2000;
        $config['max_width'] = 1500;
        $config['max_height'] = 1500;

      	$ext = pathinfo($_FILES[$fName]['name'], PATHINFO_EXTENSION);
      	$filename = rand(10000, 990000) . '_' . time() . '.' . $ext;
      	$config['file_name'] = $filename;

        $this->load->library('upload', $config);
  	    $this->upload->initialize($config);

	      $response = '';
        if (!$this->upload->do_upload($fName)) 
        {
            $error = array('error' => $this->upload->display_errors());
        	  // print_r($error);
        	   $response = NULL;
        } 
        else 
        {
            $data = array('image_metadata' => $this->upload->data());
      	    //print_r($data);
      	   $response = $filename;
        }      
	   return $response;
  }
  
}
