<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	function __construct(){
		parent::__construct();

	    if($this->session->userdata('admlogged_in') !== TRUE)
		redirect('admin/login');

	    $this->admID       = $this->session->userdata('admID');
	    $this->admName     = $this->session->userdata('admName');
	    $this->admDesig    = $this->session->userdata('admDesig');
	    $this->admDistrict = $this->session->userdata('admDistrict');


 	    $this->load->model('M_application','_application');
 	    $this->load->model('M_masters','_masters');
	}

	function application_pending(){
		$appDetails = $this->_application->getPendingApplication();

		echo json_encode($appDetails);
	}

	function application_summary(){
		$appDetails = $this->_application->getSummaryApplication();

		echo json_encode($appDetails);
	}

	function application_closed(){
		$appDetails = $this->_application->getClosedApplication();
		echo json_encode($appDetails);
	}


	function application_rejected(){
		$appDetails = $this->_application->getRejectedApplication();
		echo json_encode($appDetails);
	}


	function user_logs(){
		$logDetails = $this->_masters->getUserLogs();
		echo json_encode($logDetails);
	}
}
