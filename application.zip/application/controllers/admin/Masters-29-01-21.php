<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Masters extends CI_Controller{
  function __construct(){
    parent::__construct();

    if($this->session->userdata('admlogged_in') !== TRUE)
	redirect('admin/login');

    $this->admID       = $this->session->userdata('admID');
    $this->admName     = $this->session->userdata('admName');
    $this->admDesig    = $this->session->userdata('admDesig');
    $this->admDistrict = $this->session->userdata('admDistrict');

    

    $this->load->model('M_application','_application');
    $this->load->model('M_organization','_organization');
    $this->load->model('M_location','_location');
    $this->load->model('M_stage','_stage');
     $this->load->model('M_masters','_master');

    $this->menu = 'Product';
  }

  function index(){
    

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appPendingURL'] = 'admin/ajax/application_pending';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/products_view',$data);
  }

  function product_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'Product';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get('m_product')->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/products_view',$data);
  }

    function product_edit(){

   $prod_id = $_POST["employee_id"];


    $data['menu'] = 'Product';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get_where('m_product', array('id'=>$prod_id))->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/products_edit',$data);
  }


function save(){


    $saveCert = array(
      'name'  => $this->input->post('pro_name'),
      'short_description'  => $this->input->post('pro_desc'),
      'terms_conditions'    => $this->input->post('pro_general'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );



$upStatus = $this->db->insert('m_product',$saveCert);

$insert_id = $this->db->insert_id();


 $logDet = array('activity'=>'Product-Add','details'=>$this->input->post('pro_name'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);


  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/product_view');
}




function update(){


    $upAppData = array(
      'name'  => $this->input->post('pro_name'),
      'short_description'  => $this->input->post('pro_desc'),
      'terms_conditions'    => $this->input->post('pro_general'),
      'isactive'  => $this->input->post('status'),
      'mdfdate'    => date('Y-m-d H:i:s'),
      'mdfby'     => $this->admID
    );

$insert_id = $this->input->post('pro_id');

$this->db->where('id',$insert_id);
$upStatus = $this->db->update('m_product',$upAppData);

 $logDet = array('activity'=>'Product-Edit','details'=>$this->input->post('pro_name'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);

  if($upStatus):

          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/product_view');
}

 function user_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'User';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js',
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get('admin')->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_view',$data);
  }

    function user_edit(){

   $prod_id = $_POST["employee_id"];


    $data['menu'] = 'User';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             
                             'admin/js/jquery-3.3.1.min.js',
                             'admin/js/dataTables.min.js'
                            
                             
                           );

 $productt = $this->db->get_where('admin', array('id'=>$prod_id))->result();
    $data['pro_det'] = $productt;

    $this->load->view('admin/user_edit',$data);
  }



function user_save(){


    $saveCert = array(
      'name'  => $this->input->post('name'),
      'usrname'  => $this->input->post('usrname'),
      'usrpassword'    => md5($this->input->post('usrpassword')),
      'email'    => $this->input->post('email'),
      'desig_id'    => $this->input->post('desig_id'),
      'district_id'    => $this->input->post('district_id'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );



$upStatus = $this->db->insert('admin',$saveCert);

$insert_id = $this->db->insert_id();

 $logDet = array('activity'=>'User-Add','details'=>$this->input->post('usrname'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);


  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_view');
}


function user_update(){


     $saveCert = array(
      'name'  => $this->input->post('name'),
      'usrname'  => $this->input->post('usrname'),
      'email'    => $this->input->post('email'),
      'desig_id'    => $this->input->post('desig_id'),
      'district_id'    => $this->input->post('district_id'),
      'isactive'  => $this->input->post('status'),
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => $this->admID
    );

$insert_id = $this->input->post('user_id');

$this->db->where('id',$insert_id);
$upStatus = $this->db->update('admin',$saveCert);


 $logDet = array('activity'=>'User-Add','details'=>$this->input->post('usrname'),'crtby'=>$this->admID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
 $insLog = $this->db->insert('log',$logDet);

  if($upStatus):
          $this->session->set_flashdata('msg','Record updated successfully.');  
  else:
          $this->session->set_flashdata('msg','Record Not updated.'); 
  endif;

  redirect('admin/masters/user_view');
}

  function logs(){
    $this->menu = 'Logs';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appLogURL'] = 'admin/ajax/user_logs';
    $this->load->view('admin/logs',$data);
  }


}
