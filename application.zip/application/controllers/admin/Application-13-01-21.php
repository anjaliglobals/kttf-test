<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Application extends CI_Controller{
  function __construct(){
    parent::__construct();

    if($this->session->userdata('admlogged_in') !== TRUE)
	redirect('admin/login');

    $this->admID       = $this->session->userdata('admID');
    $this->admName     = $this->session->userdata('admName');
    $this->admDesig    = $this->session->userdata('admDesig');
    $this->admDistrict = $this->session->userdata('admDistrict');

    

    $this->load->model('M_application','_application');
    $this->load->model('M_organization','_organization');
    $this->load->model('M_location','_location');
    $this->load->model('M_stage','_stage');

    $this->menu = 'Application';
  }

  function index(){
    $this->menu = 'Application';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appPendingURL'] = 'admin/ajax/application_pending';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_pending',$data);
  }

  function application_summary(){
    $this->menu = 'Summary';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appSummaryURL'] = 'admin/ajax/application_summary';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_summary',$data);
  }

  function application_closed(){
    $this->menu = 'Closed';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appClosedURL'] = 'admin/ajax/application_closed';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_closed',$data);
  }

  function application_rejected(){
    $this->menu = 'Rejected';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appRejectedURL'] = 'admin/ajax/application_rejected';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/application_rejected',$data);
  }

  function view(){

    $id = $this->uri->segment(4);
    $this->menu = 'Application';
    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );
    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js'
                           );
    $data['appRejectLink']  = 'admin/application/rejectApplication';
    $data['appApproveLink'] = 'admin/application/approveApplication';
    $data['access'] = $this->_stage->accessPrivilege($id);
    $appDettails = $this->_application->getAppInfo($id);
    $data['application'] = array_shift($appDettails);
    $data['organization'] = $this->_organization->getListOrgType();
    $data['country']  = $this->_location->getListLocation('m_countries');
    $data['state']    = $this->_location->getListLocation('m_states');
    $data['city']     = $this->_location->getListLocation('m_cities');
    $data['district'] = $this->_location->getListLocation('m_district');
    $data['comments']  = $this->_application->getAppComments($id,$data['application']->licence_renewal_count);
    $data['docverify'] = $this->_application->getAppDocVerify($id,$data['application']->licence_renewal_count);

    $this->load->view('admin/application',$data);
  }

  function certificate(){

    $id = $this->uri->segment(4);

//echo $id;
    $this->menu = 'Application';
    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );
    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js'
                           );
    $data['appRejectLink']  = 'admin/application/rejectApplication';
    $data['appApproveLink'] = 'admin/application/approveApplication';
    $data['access'] = $this->_stage->accessPrivilege($id);
    $appDettails=$this->_application->getAppInfo($id);
//print_r($appDettails);
// $data['appDettails'] = $appDettails;
    $data['application'] = array_shift($appDettails);
    $data['organization'] = $this->_organization->getListOrgType();
    $data['country']  = $this->_location->getListLocation('m_countries');
    $data['state']    = $this->_location->getListLocation('m_states');
    $data['city']     = $this->_location->getListLocation('m_cities');
    $data['district'] = $this->_location->getListLocation('m_district');

    $data['comments']  = $this->_application->getAppComments($id,$data['application']->licence_renewal_count);
    $data['docverify'] = $this->_application->getAppDocVerify($id,$data['application']->licence_renewal_count);

    $this->load->view('admin/certificate',$data);
  }

  function application_update(){

    $appID = $this->input->post('application_id');

    $appDetails = $this->db->get_where('application',array('id' => $appID), true)->result_array();

    $appDettails = array_shift($appDetails);

    $upload_check = $this->input->post('upload_check');
	

//--------Doc verification-----------
  $document_verification = $this->input->post('document_verification');
  if(isset($document_verification)):
    $reg_certificate         = $this->input->post('img_registration_certificate');
    $reg_certificate_details = $this->input->post('img_registration_certificate_details');
    $bank_reference          = $this->input->post('img_bank_reference');
    $bank_reference_details  = $this->input->post('img_bank_reference_details');
    $ca_certificate          = $this->input->post('img_ca_certificate');

    $ca_certificate_details  = $this->input->post('img_ca_certificate_details');
    $audited_balance         = $this->input->post('img_audited_balance_sheet');
    $audited_balance_details = $this->input->post('img_audited_balance_sheet_details');
    $patners_list            = $this->input->post('img_list_patners');
    $patners_list_details    = $this->input->post('img_list_patners_details');

    $brochures               = $this->input->post('img_brochures');
    $brochures_details       = $this->input->post('img_brochures_details');
    $off_premises            = $this->input->post('img_off_premises');
    $off_premises_details    = $this->input->post('img_off_premises_details');
    $labour_dep              = $this->input->post('img_labour_department');
    $labour_dep_details      = $this->input->post('img_labour_department_details');

    $md_photo                = $this->input->post('img_md_photo_attested');
    $md_photo_details        = $this->input->post('img_md_photo_attested_details');
    $off_exterior            = $this->input->post('img_off_buil_exterior');
    $off_exterior_details    = $this->input->post('img_off_buil_exterior_details');
    $off_interior            = $this->input->post('img_off_buil_interior');

    $off_interior_details    = $this->input->post('img_off_buil_interior_details');
    $off_staff_cv            = $this->input->post('img_off_staff_member');
    $off_staff_cv_details    = $this->input->post('img_off_staff_member_details');

    $insArrDocsComment = array('reg_certificate'        =>  $reg_certificate,
                              'reg_certificate_details' =>  $reg_certificate_details,
                              'bank_reference'          =>  $bank_reference,
                              'bank_reference_details'  =>  $bank_reference_details,
                              'ca_certificate'          =>  $ca_certificate,
                              'ca_certificate_details'  =>  $ca_certificate_details,
                              'audited_balance'         =>  $audited_balance,
                              'audited_balance_details' =>  $audited_balance_details,
                              'patners_list'            =>  $patners_list,
                              'patners_list_details'    =>  $patners_list_details ,
                              'brochures'               =>  $brochures,
                              'brochures_details'       =>  $brochures_details,
                              'off_premises'            =>  $off_premises,
                              'off_premises_details'    =>  $off_premises_details,
                              'labour_dep'              =>  $labour_dep,
                              'labour_dep_details'      =>  $labour_dep_details,
                              'md_photo'                =>  $md_photo,
                              'md_photo_details'        =>  $md_photo_details,
                              'off_exterior'            =>  $off_exterior,
                              'off_exterior_details'    =>  $off_exterior_details,
                              'off_interior'            =>  $off_interior,
                              'off_interior_details'    =>  $off_interior_details,
                              'off_staff_cv'            =>  $off_staff_cv,
                              'off_staff_cv_details'    =>  $off_staff_cv_details,
                              'crtdate'                 =>  date('Y-m-d H:i:s'),
                              'crtby'                   =>  $this->admID,
                              'application_id'          =>  $appDettails['id'],
                              'licence_renewal_no'      =>  $appDettails['licence_renewal_count'],
                              'app_stage_id'            =>  $appDettails['stage_id']
                            );
  endif;


//----Action performed
    $applicationType = $this->input->post('btnAction');
    $message = '';
    switch ($applicationType) {
      case 'btnReject':            
	
	    $subject = 'Application Rejected';

            $updApp = array('status_code' => 1,
                           'status_code_date' => date('Y-m-d H:i:s')
                          );
	    $message = "Dear KTTF Customer, Your application number is ".$appDettails->application_id." is rejected. Kindly login KTTF portal for more information";

      break;
      case 'btnApprovePayment':   
	    $subject = 'Application Approved To Next Stage';

            $stage_id = ++$appDettails['stage_id'];
            $updApp = array('is_payment_approved'  => 1,
			    'approve_payment_date' => date('Y-m-d H:i:s'),
                            'stage_id' => $stage_id
                          );

	    $message = "Dear KTTF Customer, Your application number is ".$appDettails->application_id." has been approved for payment. Kindly login to your KTTF account to make payment.";

      break;
      case 'btnApproveNxtStage':   
	    $subject = 'Application Approved To Next Stage';

            $stage_id = ++$appDettails['stage_id'];
            $updApp = array('stage_id' => $stage_id);

	    //-------resubmit from send back
	    if($appDettails['stg_send_back_date'] != '' && $appDettails['stg_send_back_submit_date'] == ''):
            	$updApp['stg_send_back_submit_date'] = date('Y-m-d H:i:s');
	    endif;

      break;
      case 'btnApproveLicenseStage':   
	    $subject = 'Application Approved For License';
            $stage_id = ++$appDettails['stage_id'];
 $licence_no = rand(5, 15);
 $licence_issued_date = date('Y-m-d H:i:s');
            $updApp = array('stage_id' => $stage_id,'licence_no' => $licence_no,'licence_issued_date' => $licence_issued_date);
      break;
      case 'btnSendBack':   
	    $subject  = 'Application Sent Back To Previous Stage';
            $stage_id = --$appDettails['stage_id'];
            $updApp   = array('stage_id' => $stage_id,'stg_send_back_date' => date('Y-m-d H:i:s'));
      break;
      
    }

//--------comment----------
    $internalCom = $this->input->post('internal_comment');
    $externalCom = $this->input->post('external_comment');

      $insArrGeneralComment = array('application_id' => $appDettails['id'],
                                    'subject'        => $subject,
                                    'inter_comm'     => $internalCom,
                                    'cons_comm'      => $externalCom,
                                    'app_stage'      => $appDettails['stage_id'],
                                    'licence_renewal_no' => $appDettails['licence_renewal_count'],
                                    'crtdate'        => date('Y-m-d H:i:s'),
                                    'crtby'          => $this->admID,
                                    'crtname'        => $this->admName,
                                  );



//AD stg file upload
     if($upload_check == 'Yes'):

	    $prevFile = ($appDettails['adm_upload'])? explode(',',$appDettails['adm_upload']) : array();
	    $prevFilCom = ($appDettails['adm_upload_details'])? explode(',',$appDettails['adm_upload_details']) : array();

	    $admimg = $this->img_upload('admin','adm_upload');			

	    if($admimg !=''):
		$prevFile[]   = $admimg;
		$prevFilCom[] = $this->input->post('adm_upload_details');

		$admUplod = implode(',',$prevFile);
		$admUpDet = implode(',',$prevFilCom);

	    	$updApp['adm_upload_details'] = $admUpDet;
		$updApp['adm_upload'] 	      = $admUplod;
	    endif;
     endif;


    $this->db->trans_start(); # Starting Transaction

      if(isset($document_verification))
      	 $insDocStatus = $this->db->insert('application_doc_verification',$insArrDocsComment);

      $insComStatus = $this->db->insert('application_comment',$insArrGeneralComment);

                      $this->db->where('id',$appDettails['id']);
      $upAppstatus  = $this->db->update('application',$updApp);

    $this->db->trans_complete(); # Completing transaction



    if ($this->db->trans_status() === FALSE) {
        $this->db->trans_rollback();
        $this->session->set_flashdata('msg-error','Record not saved successfully. Please, try again.');
        redirect('admin/application');
    } 
    else {
        $this->db->trans_commit();
	if($message):
		$sendsms = $this->sendSMS($appDettails->org_loc_mobile, $message);
	endif;
        $this->session->set_flashdata('msg','Record saved successfully.');
        redirect('admin/application');
    }
  }

  function reports(){

    $id = $this->uri->segment(4);

    $this->menu = 'Reports';

    $data['arr_css'] = array('admin/css/bootstrap.min.css');


    $appDettails = $this->_application->getAppInfo($id);

    $appDettails = array_shift($appDettails);

    $data['application'] = $appDettails;

    $payDet = $this->db->get_where('payment',array('id' => $appDettails->payment_id), true)->result_array();

    $payDet = array_shift($payDet);

    $data['payment'] = $payDet;
	    
    $this->load->view('admin/reports',$data);
  }

  function sendSMS($mobilenum, $message){

	 $url  =   'http://smspush.openhouseplatform.com/smsmessaging/1/outbound/tel%3A%2BGKSTDC/requests';

	 $mobilefiotp3 = $mobilenum;

	
		$random_id_length = 4; 
		$rnd_id = rand(1000,9999);
		//End Random Code

		$messagee = $message;

		$bookingObj = array();
		$bookingObj['outboundSMSMessageRequest']['address'] = ["tel:$mobilefiotp3"];
		$bookingObj['outboundSMSMessageRequest']['senderAddress'] = "tel:GKSTDC"; 
		$bookingObj['outboundSMSMessageRequest']['outboundSMSTextMessage']['message']  = "$messagee";
		$bookingObj['outboundSMSMessageRequest']['clientCorrelator'] = "";
		$bookingObj['outboundSMSMessageRequest']['messageType'] = "";
		$bookingObj['outboundSMSMessageRequest']['category'] = "GKSTDC";
		$bookingObj['outboundSMSMessageRequest']['receiptRequest']['notifyURL'] = "";
		$bookingObj['outboundSMSMessageRequest']['receiptRequest']['callbackData'] = "$(callbackData)";
		$bookingObj['outboundSMSMessageRequest']['senderName'] = "GKSTDC";
		$data_string = json_encode($bookingObj);
		//print_r($data_string);
		//print_r($datastring);



		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json', 'key: 6d2a1102-7c24-486d-ad7e-784c5bda6d66'));

			$output = curl_exec($ch);
		return true;


	} 


//************Upload*******
  function img_upload($folderName,$fName){
        $config['upload_path'] = './upload/'.$folderName.'/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        $config['max_size'] = 2000;
        $config['max_width'] = 1500;
        $config['max_height'] = 1500;

	$ext = pathinfo($_FILES[$fName]['name'], PATHINFO_EXTENSION);
	$filename = rand(10000, 990000) . '_' . time() . '.' . $ext;
	$config['file_name'] = $filename;

        $this->load->library('upload', $config);
	$this->upload->initialize($config);

	$response = '';
        if (!$this->upload->do_upload($fName)) {
            $error = array('error' => $this->upload->display_errors());
	  // print_r($error);
	   $response = NULL;
        } else {
            $data = array('image_metadata' => $this->upload->data());
	    //print_r($data);
	   $response = $filename;

        }      
	 return $response;
  }

}
