<?php
class Login extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('login_model');
  }

  function index(){
    $this->load->view('admin/login');
  }

  function auth(){
    $usrname  = $this->input->post('admin_user_name',TRUE);
    $usrpswd  = md5($this->input->post('admin_user_password',TRUE));
    $validate = $this->login_model->validate($usrname,$usrpswd);
    if($validate->num_rows() > 0){
        $usrdata  = $validate->row_array();
        if($usrdata['isactive'] == 0):
          $this->session->set_flashdata('msg-error','Sorry, your not a valid user.');
          redirect('login');
        endif;
        $usrID       = $usrdata['id'];
        $usrName     = $usrdata['name'];
        $usrEmail    = $usrdata['email'];
        $usrDesig    = $usrdata['desig_id'];
        $usrDistrict = $usrdata['district_id'];

        $sesdata = array(
            'admID'     => $usrID,
            'admName'   => $usrName,
            'admEmail'  => $usrEmail,
            'admDesig'  => $usrDesig,
            'admDistrict' => $usrDistrict,
            'admlogged_in' => TRUE
        );
	
	 $logDet = array('activity'=>'Last loged in','crtby'=>$usrID,'ip_address'=>$_SERVER['REMOTE_ADDR']);
      	 $insLog = $this->db->insert('log',$logDet);
	
        $this->session->set_userdata($sesdata);
        redirect('admin/dashboard');

    }else{
        $this->session->set_flashdata('msg-error','Username or Password is Wrong');
        redirect('admin/login');
    }
  }

  function logout(){
      $this->session->sess_destroy();
      redirect('admin');
  }

}
