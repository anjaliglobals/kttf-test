<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Masters extends CI_Controller{
  function __construct(){
    parent::__construct();

    if($this->session->userdata('admlogged_in') !== TRUE)
	redirect('admin/login');

    $this->admID       = $this->session->userdata('admID');
    $this->admName     = $this->session->userdata('admName');
    $this->admDesig    = $this->session->userdata('admDesig');
    $this->admDistrict = $this->session->userdata('admDistrict');

    

    $this->load->model('M_application','_application');
    $this->load->model('M_organization','_organization');
    $this->load->model('M_location','_location');
    $this->load->model('M_stage','_stage');

    $this->menu = 'Product';
  }

  function index(){
    $data['menu'] = 'Product';

    $data['arr_css'] = array('admin/css/bootstrap.min.css',
                             'admin/css/style.css',
                             'admin/css/DataTables/jquery.dataTables.min.css'
                            );

    $data['arr_js'] = array('admin/js/DataTables/jquery-1.12.4.js',
                             'admin/js/DataTables/jquery.dataTables.min.js'
                            );

    $data['appPendingURL'] = 'admin/ajax/application_pending';
    $data['appViewURL']    = 'admin/application/view/';
    $this->load->view('admin/products_view',$data);
  }

  function product_view(){

    $id = $this->uri->segment(4);

    $data['menu'] = 'Product';

    $data['arr_css'] = array('admin/css/bootstrap.min.css', 
                             'admin/css/style.css',
                             'admin/css/application.css'
                            );

    $data['arr_js']  = array(/*'admin/js/jquery.2.1.3.min.js',
                             'admin/js/jquery.min.map',*/
                             'admin/js/application.js'
                           );

    $data['appRejectLink']  = 'admin/application/rejectApplication';
    $data['appApproveLink'] = 'admin/application/approveApplication';

    $data['access'] = $this->_stage->accessPrivilege($id);


    $appDettails = $this->_application->getAppInfo($id);

    $data['application'] = array_shift($appDettails);

    $data['organization'] = $this->_organization->getListOrgType();

    $data['country']  = $this->_location->getListLocation('m_countries');
    $data['state']    = $this->_location->getListLocation('m_states');
    $data['city']     = $this->_location->getListLocation('m_cities');
    $data['district'] = $this->_location->getListLocation('m_district');

//print_r($data['application']);die;

    $this->load->view('admin/products_view',$data);
  }

  
}
