<?php
class Register extends CI_Controller{
  function __construct(){
    parent::__construct();
    $this->load->model('M_user','_user');

  }

  function index(){
    $this->load->view('user/register');
  }

 

    function save(){
    $name  = $this->input->post('reg_name',TRUE);
    $usremail  = $this->input->post('reg_email',TRUE);
    $usrpassword  = md5($this->input->post('reg_password',TRUE));
    $mobile  = $this->input->post('reg_mob',TRUE);
    $usrpasswordf  = $this->input->post('reg_password',TRUE);
    // printf($name);
    // echo "++++";   

   $saveCert = array(
      'name'  => $name,
      'usremail'  => $usremail,
      'usrpassword'  => $usrpassword,
      'mobile'   => $mobile,
      'crtdate'    => date('Y-m-d H:i:s'),
      'crtby'     => 0,
      'isactive'     => '1'
    );

    $validate = $this->_user->validatereg($usremail);
    if($validate->num_rows() > 0){
       
          $this->session->set_flashdata('msg','User Already Exist.');
          redirect('register');
       
    }else{
        

        $upStatus = $this->db->insert('usr_register',$saveCert);

$insert_id = $this->db->insert_id();



// Mail For Activation Link


          $mail_config = $this->config->item('mail_conf');


  $user = $mail_config['username'];
  $pass = $mail_config['password'];
  $url  = $mail_config['url'];
  $fromname  = $mail_config['from'];
  $fromid  = $mail_config['admin_mail'];
        
$body = "<h3>Dear ".$name.",</h3><p><br> You have Successfully Registered in 'Karnataka Tourism Trade Facilitation'. Please Check the Below Link to Activate your Account.</p><p><br><a href='https://kttf.karnatakatourism.org/login/activate/$insert_id' target='_blank'>Click Here to Activate</a></p><p><br>User Name : ".$usremail."</p><p><br>Password : ".$usrpasswordf."</p><p><h4><br>
 Regards,<br> Karnataka Tourism Trade Facilitation.<br></h4></p>";
$body = str_replace(array("\n", "\r"), '', $body);
$subject = "Account Activation Link";
$fromname = "support@karnatakatourism.org";
   $params = array(
      'api_user'  => $user,
      'api_key'   => $pass,
      'to'        => $usremail,
      'subject'   => $subject,
      'html'      => $body,
      'text'      => '',
      'from'      => $fromname
  ); 
  $toname = "KSTDC";      
  $tonamen=str_replace(' ', '%20', $toname);
  $ton=str_replace(' ', '%20', $params['to']);
  $subjectn=str_replace(' ', '%20', $params['subject']);
  $htmln=str_replace(' ', '%20', $params['html']);
  $fromn=str_replace(' ', '%20', $params['from']);

/*
  $request =  $url.'api/mail.send.json';

  $session = curl_init($request);
  curl_setopt ($session, CURLOPT_POST, true);
        curl_setopt($session, CURLOPT_SAFE_UPLOAD , false);
  curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
  curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_2);
  curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

  // obtain response
  $response = curl_exec($session); 
  curl_close($session);
  $respMsg =  json_decode($response);
  $response = $respMsg->message;
  */


  $curl = curl_init();
  $url_value="https://api.sendgrid.com/api/mail.send.json?to=".$ton."&toname=".$tonamen."&subject=".$subjectn."&html=".$htmln."&from=".$fromn;        
  $headers = array(
            "MIME-Version: 1.0\r\n",
            "Content-type: text/html; application/json;charset=\"utf-8\"",
            "Cache-Control: no-cache",
            "Pragma: no-cache"
        ); 
  curl_setopt_array($curl, array(
  CURLOPT_POST=>1,
  CURLOPT_URL =>$url_value,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HEADER=>false,
  CURLOPT_SSL_VERIFYPEER=> false,
  CURLOPT_SAFE_UPLOAD=>true,
  CURLOPT_HTTPHEADER => array(
    'Authorization: Bearer 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',$headers
  ),
));

  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);
  if ($err) {
    echo "cURL Error #:" . $err;    
  } else {
       $respMsg =  json_decode($response);
       $response = $respMsg->message;    
  }

  //-----insert into email status
    
   $emailInfo = array(
          'response'    => $response,
          'status'    => ($response=='success') ? '0' : '1',
          'mailreceive_date'    => date('Y-m-d H:i:s')

      );

   $this->db->where('id',$insert_id);
$upstatusa = $this->db->update('usr_register',$emailInfo);

  //-----end insert into email status

 // End Mail For Activation Link         

        $this->session->set_flashdata('msg','User Registered Successfully');
        redirect('login');
    }



  }



}
