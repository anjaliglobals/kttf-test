<?php

/**
 * Email credentials
 */
$config['mail_conf'] = array(
			"username" => "KSTDCERP",
			"password" => "p0m0d0r02015",
			"url"      => "https://api.sendgrid.com/",
			"from"	   => "kstdcTourism",
			"key"	   => "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",
			"admin_mail" => "kttf@kstdc.co"
		   );

?>
