<?php include 'include/header.php';?>



		<div class="application">
			<!-- <div class="summary">
				<h3>Summary</h3>
			</div> -->
			<div class="waiting-application">
				<h4>KTTF : Log Details</h4>
			</div>
			<?php if($this->session->flashdata('msg')):?>			
				<div class="alert">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg');?>
				</div>
			<?php endif; ?>
			<?php if($this->session->flashdata('msg-error')):?>			
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-error');?>
				</div>
			<?php endif; ?>
			<div class="appli-table">
				<div style="overflow:auto">
					<table id='application-table'>
					 	<thead>
           					<tr class="app-tn-head">
								<th>SI.No</th>
								<th>Activity</th>
								<th>Activity Details</th>
								<th>IP Address</th>
								<th>Create/Edit By</th>
								<th>Create/Edit Date</th>
							</tr>
						</thead>
						<tbody id='app-details'>        
			            </tbody>
					</table>
				</div>
			</div>
		</div>



<?php include 'include/footer.php';?>

<script>

var appPath = '<?php echo base_url().$appLogURL; ?>';

   var table = $('#application-table').DataTable( {
			        ajax: {
				        url: appPath,
				        dataSrc: ''
				    },
					language : {
				        sLoadingRecords : '<span style="width:100%;"><img src="<?php echo base_url().'theme/admin/images/loader_icon.gif'?>"></span>'
				    },
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'activity' },
				        { data: 'details' },
				        { data: 'ip_address' },
				        { data: 'usrname' },
				        { data: 'crtdate' }
				    ]
    			});
</script>
<script>
$('#sub-menu-btn').prop('checked', true);
</script>

