<?php 
 foreach($pro_det as $prod_det){ 
    ?> 



                            <form action="<?php echo base_url();?>admin/masters/user_timeline_update" method="post">


 <input type="hidden" required name="user_id" value="<?php echo $prod_det->id; ?>">
  <input type="hidden" required name="desig_id" value="<?php echo $prod_det->desig_id; ?>">


    <select name="app_status_id" id="app_status_id"required class="">
                <option value="">Select Application Status</option>
                    <?php                 
                                $this->db->where(array('isactive' => '1'));
                              $clients = $this->db->get('m_application_status')->result_array();
                              foreach ($clients as $row):
                                  ?>
                                  <option value="<?php echo $row['id']; ?>" <?php if($prod_det->app_status_id==$row['id']){echo "selected";}?>>
                                      <?php echo $row['flow_name']; ?></option>
                              <?php endforeach; ?>
              </select>


        <select name="desig_ida" disabled="disabled" style="color:#000;" id="desig_id"required class="">
                  <option value="">Select Designation</option>
                  <?php
                 
                                $this->db->where(array('isactive' => '1'));
                              $clients = $this->db->get('m_designation')->result_array();
                              foreach ($clients as $row):
                                  ?>
                                  <option value="<?php echo $row['id']; ?>" <?php if($prod_det->desig_id==$row['id']){echo "selected";}?> >
                                      <?php echo $row['designation_name']; ?></option>
                              <?php endforeach; ?>
              </select>

<input type="text" required name="timeline" value="<?php echo $prod_det->timeline; ?>" onkeypress="return isNumbera(event)" placeholder="Enter the Approval Timeline (Days)">


                 <select name="status" id="status"required>
 <option value="">Select Status</option>
 <option value="1" <?php if($prod_det->isactive==1){echo "selected";}?>>Active</option>
 <option value="0" <?php if($prod_det->isactive==0){echo "selected";}?>>In Active</option>
                 
                  
              </select>
                <input type="submit" value="Update">
              </form>



                            <?php
                        }
                        ?>