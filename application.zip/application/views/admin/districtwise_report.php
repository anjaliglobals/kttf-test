<?php include 'include/header.php';?>
<div class="application">
			<!-- <div class="summary">
				<h3>Summary</h3>
			</div> -->
			<div class="waiting-application">
				<h4>Report</h4>
			</div>
			<?php if($this->session->flashdata('msg')):?>			
				<div class="alert">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg');?>
				</div>
			<?php endif; ?>
			<?php if($this->session->flashdata('msg-error')):?>			
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-error');?>
				</div>
			<?php endif; ?>
			<div class=clearfix>&nbsp;&nbsp;</div>
			
			<div class="row">				
				<div class="col-xs-2 col-sm-2 col-md-6 col-lg-12">
					&nbsp;&nbsp;
					<!-- <div class='container'></div> -->
						<label>From Date <span style="color:tomato;">*</span> : </label>
						<input type="text" id="datepicker1" autocomplete="off" name="" class="selection_box"/>
						<label>To Date <span style="color:tomato;">*</span> : </label>
						<input type="text" id="datepicker2" autocomplete="off" name="" class="selection_box "/>
 						<label>Product :</label>		
						<select name="product_id[]" id="product_id" class="selection_box">
							<option value="">Select Product</option>
							<?php
								$query=$this->db->query("select id, name from m_product where isactive like 1");
								$clients = $query->result_array();
								foreach ($clients as $row):
							?>
							<option value="<?php echo $row['id']; ?>">
							<?php echo $row['name']; ?></option>
							<?php endforeach; ?>
						</select>&nbsp;	
					   <button class="btn-success" onclick="loadreport_data()"> Submit</button> 
					    <button class="btn-primary" onclick="exportdata1()"> Export Excel</button>
				</div>
			</div>
			
			<div class=clearfix>&nbsp;&nbsp;</div>
			<div>
				<div style="width: 50%">
					<table id='application-table' class="table table-striped">
					 	<thead>
           					<tr class="app-tn-head">
								<th>Sl.No</th>
								<th>District</th>
								<th>Count</th> 
							</tr>
						</thead>
						<tbody id='app-details'>        
			            </tbody>
					</table>
				</div>
			</div>
		</div>

<?php include 'include/footer.php';?>
<script>
$(document).ready(function()
{
	loadreport_data();	
});
function loadreport_data()
{
	// alert("load data");
	// console.log(window.location.origin);
	var applink = '<?php echo base_url().$appViewURL1; ?>';
	var appPath = '<?php echo base_url().$appReportCount; ?>';
	//var districtId=$("#district_id :selected").val();
	var prod_id=$("#product_id :selected").val();
	//var status=$("#status_id :selected").val();
	var date1=$("#datepicker1").val();
	var date2=$("#datepicker2").val();	
	$("#application-table").dataTable().fnDestroy();
	var table = $('#application-table').DataTable({	   
			 // dom: 'Bfrtip',
			 // buttons: ['csv'],       	
			 ajax: {
			 			type: 'POST',
				        url: appPath,
				        dataSrc: '',
				        data:{
				            // distId:districtId,
				             prodid:prod_id,
				             fromdate:date1,
				             todate:date2
				             //status_id:status
				        } 
				    },
				        language : {
				        	sLoadingRecords : '<span style="width:100%;"><img src="<?php echo base_url().'theme/admin/images/loader_icon.gif'?>"></span>'
				    	},
				    	// "bAutoWidth": false,
				    	// "width":"100%",
					    columns: [ 
					     	{ data: 'slno' },  
					     	{ data: 'districtname' },  
					     	{ data: 'app_count' },
					        ]

					       
    			});

}
$('#sub-menu-btn1').prop('checked', true);

	$("#datepicker1").datepicker({
            dateFormat: "dd-mm-yy",
            onSelect: function (date) {
                var date2 = $('#datepicker1').datepicker('getDate');
                //date2.setDate(date2.getDate() + 1);
                //$('#datepicker2').datepicker('setDate', date2);
                //sets minDate to dt1 date + 1
                $('#datepicker2').datepicker('option', 'minDate', date2);
            }
        });

    $('#datepicker2').datepicker({
            dateFormat: "dd-mm-yy",
            onClose: function () {
                var dt1 = $('#datepicker1').datepicker('getDate');
                var dt2 = $('#datepicker2').datepicker('getDate');
                if (dt2 <= dt1) {
                    var minDate = $('#datepicker2').datepicker('option', 'minDate');
                    $('#datepicker2').datepicker('setDate', minDate);
                }
            }
    });
    $("#datepicker1,#datepicker2").datepicker().datepicker("setDate", new Date());
    function exportdata1()
    {   

		//http://localhost/kttf/admin/ajax/application_report
		//var districtId=$("#district_id :selected").val();
		var prod_id=$("#product_id :selected").val();
		//var status=$("#status_id :selected").val();
		var date1=$("#datepicker1").val();
		var date2=$("#datepicker2").val();	
      	var basePath=window.location.origin; 
      	var href=(basePath+'/'+'admin/ajax/exportcountreport?fdate='+date1+'&tdate='+date2+'&prod_id='+prod_id);    
      	// var href=(basePath+'/'+'admin/ajax/exportreport?fdate='+date1+'&tdate='+date2+'&staus='+status+'&prod_id='+prod_id+'&districtId='+districtId);
      	 $('<a href="'+href+'" target="blank"></a>')[0].click();
      	 // alert("hi"+href);
    }
</script>
<style type="text/css">
	.label_css
	{
		margin-bottom: 20px;width: 165px;height: 26px;line-height: 30px;
	}
	.selection_box
	{
		height: 35px;width: 10%;border: 1px solid #E4E4E4;cursor: pointer;
	}
	#ui-datepicker-div{
		left: 339.266px !important ;
	}
</style> 