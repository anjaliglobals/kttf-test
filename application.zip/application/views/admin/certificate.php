<?php include 'include/header.php';?>
<?php //  print_r($application); ?>

<?php
$application_approve_date = $application->licence_issued_date;
$application_approve_date = strtotime($application_approve_date);
// echo date('d/m/Y', $application_approve_date);
$expiry_date = strtotime('+ 5 year', $application_approve_date);
// echo date('d/m/Y', $expiry_date);
$current_date = $application->confirmed_date;
$current_date = strtotime($current_date);
//echo date('d/m/Y', $current_date);
?>
	<div class="application">
<div id="print-report" class="certi">
	<table style="max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px 4%;border-collapse: inherit;border-bottom:none;">
		<tbody>			
			<tr>
				<td style="text-align:center;">
					<img style="max-width:100%" src="<?php echo base_url().'theme/user/images/head-logo_cert.png';?>">
				</td>				
			</tr>
			<!--tr>
				<td style="text-align:left;padding-left:03%;width: 100%;">
					<p>Number:<span style="color:#ca0027;"> 2458732/54</p>
				</td>				
			</tr-->
			<!--tr>
				<td style="text-align:center;width: 100%;">
					<p><span style="font-size:40px;font-family: 'Times New Roman';">CERTIFICATE</span> <br>of Registration </p>
				</td>				
			</tr-->
			<!--tr>
				<td style="text-align:center;width: 100%;">
					<hr align="center" style="width:80%;"></hr>
				</td>				
			</tr-->
			<!--tr>
				<td style="text-align:center;width: 100%;">
					<p> to this organization, about issuing an Registration Letter from the Tourism Department</p>
				</td>				
			</tr-->
			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 0px 0 0px;"><span style="font-size:25px;"><b>FORM A1 / ಫಾರ್ಮ್ ಎ 1</b></span></p>
				</td>				
			</tr>

			<tr>
				<td style="text-align:center;">
					<p style="margin: 25px 0 0px;"><span style="font-size:25px;font-weight: 600;text-transform: uppercase;">ಕರ್ನಾಟಕ ಸರ್ಕಾರ / GOVERNMENT OF KARNATAKA</span></p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:center;">
					<p style="margin: 0px 0 10px;"><span style="font-size:25px;font-weight: 600;text-transform: uppercase;"> ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆ / DEPARTMENT OF TOURISM</span></p>
				</td>								
			</tr>
			<tr>
				<td style="margin: 30px 0 10px;text-align:left;float:left;">
					<p><b>ನೋಂದಣಿ ಸಂ: ಪ್ರ ಇ  / Registration No:DT</b> <span style="color:#000;">  &nbsp;&nbsp;<?php echo $application->rc_number;?></p>
				</td>
				<td style="margin: 30px 0 10px;text-align:left;width: 265px;float:right;">
					<p><b>ದಿನಾಂಕ / Date : </b><?php echo date('d-m-Y', $application_approve_date) ?>  </p>
				</td>				
			</tr>			

<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 0px 0 0px;"><span style="font-size:25px;"><b>
ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ</b></span></p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 0px 0 10px;font-size:16px;">ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ ( ಸೌಲಭ್ಯ ಮತ್ತು ನಿಯಂತ್ರಣ ) ಅಧಿನಿಯಮ, 2015 ರಡಿ</p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 0px 0 0px;"><span style="font-size:25px;"><b>Registration Certificate </b></span></p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 0px 0 10px;font-size:16px;">Under Karnataka Tourism Trade (Facilitation & Regulation) Act,2015</p>
				</td>				
			</tr><br>
			<!-- <tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;"></p>
				</td>								
			</tr> -->
			<tr>
				<td style="text-align:left;">
					<!-- <p style="margin:25px 0 10px;text-transform: capitalize;"> M/<span style='text-transform: lowercase;'>s</span>  <?php if($application->certificate_name==1){echo $application->legal_name;}else{echo $application->applicant_name;} ?>  <b>ವಿಳಾಸ / Address :</b> <?php echo $application->org_loc_add1;?>, <?php echo $application->org_loc_city;?>, <?php echo $this->db->get_where('m_district', array('id' => $application->org_loc_district_id))->row()->name; ?>, <?php echo $application->org_loc_pincode_id;?>.
						<br><b>ಘಟಕದ ಹೆಸರು / Entity Name :</b> <?php echo  $application->entity_name;?>
					 </p> -->
					<p style="margin:25px 0 10px;text-transform: capitalize;"> M/<span style='text-transform: lowercase;'>s</span>  <?php if($application->certificate_name==1){echo $application->legal_name;}else{echo $application->applicant_name;} ?>  <b>ವಿಳಾಸ / Address :</b> <?php echo $application->org_loc_add1;?>, <?php echo $application->org_loc_city;?>, <?php echo $this->db->get_where('m_district', array('id' => $application->org_loc_district_id))->row()->name; ?>, <?php echo $application->org_loc_pincode_id;?>. </p>
				</td>								
			</tr>
			<!--tr>
				<td style="text-align:left;">
					<p style="margin: 10px 0;">Number:<b> <?php echo $appdet->rc_number;?></b>, Date: <b><?php echo date('d-m-Y', $current_date);?></b> </p>
				</td>								
			</tr-->

				<td style="text-align:left;">
					<p style="margin: 10px 0 10px;line-height: 2em;">ರವರನ್ನು ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ ( ಸೌಲಭ್ಯ ಮತ್ತು ನಿಯಂತ್ರಣ ) ಅಧಿನಿಯಮ, 2015ರ ಕಲಂ 8ರಡಿ <b><?php echo $this->db->get_where('m_product', array('id' => $application->product_id))->row()->name; ?></b>  ವರ್ಗದಲ್ಲಿ   ನೋಂದಾಯಿಸಲಾಗಿದೆ.</p>


					<p style="margin: 25px 0 10px;line-height: 2em;">Has been registered under Section 8, Karnataka Tourism Trade (Facilitation & Regulation) Act,2015 as <b>' <?php echo $this->db->get_where('m_product', array('id' => $application->product_id))->row()->name; ?> '</b>. </p>

					
				</td>								
			</tr>
			<tr>
				<td style="margin: 20px 0 10px;text-align:left;float:left;">
					<p><b>Date of Issue / ವಿತರಣಾ ದಿನಾಂಕ :</b> <span style="color:#000;">  &nbsp;&nbsp;<?php echo date('d-m-Y', $application_approve_date) ?></p>
				</td>
				<td style="margin: 20px 0 10px;text-align:left;width: 420px;float:right;">
					<p><b>Date of Expiry / ಮುಕ್ತಾಯ ದಿನಾಂಕ : </b><?php echo date('d-m-Y', $expiry_date); ?>  </p>
				</td>				
			</tr>
			
		</tbody>
	</table>
	<table style="max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 30px 20px 20px 20px;border-collapse: inherit;border-top:none;">
		<tbody>
		<tr>
				<td style="text-align:right;margin: 0px 0 60px;">
					<p style="margin: 0px 0 60px;"><b>ನಿಯೋಜಿತ ಅಧಿಕಾರಿಯ ಸಹಿ /<br>
Signature of Designated Officer</b></p>

					
				</td>								
			</tr>

			<tr>
				<td style="text-align:right;">
					<p><b>ಜಂಟಿ ನಿರ್ದೇಶಕರು ( ಪ್ರಚಾರ ಮತ್ತು ಉತ್ತೇಜನ )<br>
/ Joint Director (Publicity & Promotion)</b></p>
					<p><b> ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆ  / DEPARTMENT OF TOURISM</b></p>
					
				</td>								
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<!-- <p style="margin: 20px 0 10px;"><span style="font-size:20px;line-height:2em;">"Note: This Certificate is issued based on the information and documents provided by the applicant. If found to be false, it will be cancelled automatically. This Certificate shall not absolve the grantee from any obligations cast on him under any other law and hence is liable for suspension, revocation or cancellation at any point of time.". <br>"ಸೂಚನೆ: ಅರ್ಜಿದಾರರು ನೀಡಿದ ಮಾಹಿತಿ ಮತ್ತು ದಾಖಲೆಗಳನ್ನು ಆಧರಿಸಿ ಈ ಪ್ರಮಾಣಪತ್ರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ. ಸುಳ್ಳು ಎಂದು ಕಂಡುಬಂದಲ್ಲಿ, ಅದನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ರದ್ದುಗೊಳಿಸಲಾಗುತ್ತದೆ. ಈ ಪ್ರಮಾಣಪತ್ರವು ಯಾವುದೇ ಇತರ ಕಾನೂನಿನ ಅಡಿಯಲ್ಲಿ ನೀಡಲಾದ ಯಾವುದೇ ಬಾಧ್ಯತೆಗಳಿಂದ ಅನುದಾನಿತರನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಆದ್ದರಿಂದ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಅಮಾನತು, ರದ್ದು ಅಥವಾ ರದ್ದತಿಗೆ ಹೊಣೆಗಾರನಾಗಿರುತ್ತಾನೆ."</span></p> -->
					<p style="margin: 20px 0 10px;"><span style="font-size:14px;font-weight : 600; line-height:2em;"><strong>"Note:</strong> This Certificate is issued based on the information and documents provided by the applicant. If found to be false, it will be cancelled automatically. This Certificate shall not absolve the grantee from any obligations cast on him under any other law and hence is liable for suspension, revocation or cancellation at any point of time." <br><strong>"ಸೂಚನೆ:</strong> ಅರ್ಜಿದಾರರು ನೀಡಿದ ಮಾಹಿತಿ ಮತ್ತು ದಾಖಲೆಗಳನ್ನು ಆಧರಿಸಿ ಈ ಪ್ರಮಾಣಪತ್ರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ. ಸುಳ್ಳು ಎಂದು ಕಂಡುಬಂದಲ್ಲಿ, ಅದನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ರದ್ದುಗೊಳಿಸಲಾಗುತ್ತದೆ. ಈ ಪ್ರಮಾಣಪತ್ರವು ಯಾವುದೇ ಇತರ ಕಾನೂನಿನ ಅಡಿಯಲ್ಲಿ ನೀಡಲಾದ ಯಾವುದೇ ಬಾಧ್ಯತೆಗಳಿಂದ ಅನುದಾನಿತರನ್ನು ಮುಕ್ತಗೊಳಿಸುವುದಿಲ್ಲ ಮತ್ತು ಆದ್ದರಿಂದ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಅಮಾನತು, ರದ್ದು ಅಥವಾ ರದ್ದತಿಗೆ ಹೊಣೆಗಾರನಾಗಿರುತ್ತಾನೆ."</span></p>

					<!--p style="margin: 20px 0 10px;"><span style="font-size:20px;line-height:2em;">ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆ, # 49, 2ನೇ ಮಹಡಿ, ಖನಿಜ ಭವನ್, ರೇಸ್ ಕೋರ್ಸ್ ರಸ್ತೆ, ಬೆಂಗಳೂರು - 560001. <br>Department of Tourism, #49, 2nd Floor, Khanija Bhavan, Race Course Road, Bengaluru - 560001.</span></p-->
				</td>								
			</tr>
		</tbody>		
	</table>

</div>
<div class="certi">
				<button type="button" onclick="printDiv('print-report')">Print</button>
			</div>
</div>
<script>
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}


	</script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Times%20New%20Roman" rel="stylesheet"> 
	<style>	
.certi {float: left;position: relative;width: 100%;margin: 10px 0;text-align: center;}	
@media screen, print {
         table{max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;}
		img{max-width:100%;}

      }
		
	</style>
<style  media="print">	
         table{max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;}
		img{max-width:100%;}
.certi {float: left;position: relative;width: 100%;margin: 10px 0;}
b{color:#ca0027;}
	</style>

<?php include 'include/footer.php';?>
