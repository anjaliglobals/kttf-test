

<?php include 'include/header.php';?>

	          <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

          
	<script>
$(document).ready(function() {
    $('#datatable').dataTable();
    
     $("[data-toggle=tooltip]").tooltip();
    
} );
</script> 


			

	<div class="admin-dashboard">
		<div class="manage-pro">

<?php if($this->session->flashdata('msg')):?>
				<div class="alert">
			  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
			</div>

			<?php endif; ?>

			<div class="add-new-pro">
				<h3 class="head-pro">Manage Product</h3>
				<a id="myBtn">+ Add</a>
				<div id="myModal" class="modal">
					<div class="modal-content">
						<span class="close">&times;</span>
						<h4>Add Users</h4>
						<div class="pro-add">							
							<form action="<?php echo base_url();?>admin/masters/user_save" method="post">
								<input type="text" required name="name" onkeypress="return isNumbera(event)" placeholder="Enter the Name">
								<input type="text" required name="usrname" placeholder="Enter the Login User Name">
								<div class="user-pas">
								    <input type="password" id="usrpassword" name="usrpassword" placeholder="Enter the Password">
									<i class="fa fa-eye-slash" onclick="show('usrpassword')"></i>
								</div>
								<input type="email" required name="email" placeholder="Enter the Email">
								<select name="desig_id" id="desig_id"required class="">
								<option value="">Select Designation</option>
								    <?php                 
                                $this->db->where(array('isactive' => '1'));
                              $clients = $this->db->get('m_designation')->result_array();
                              foreach ($clients as $row):
                                  ?>
                                  <option value="<?php echo $row['id']; ?>">
                                      <?php echo $row['designation_name']; ?></option>
                              <?php endforeach; ?>
              </select>

    <select name="district_id" id="district_id"required class="">
                  <option value="">Select District</option>
                  <?php
                 
                                $this->db->where(array('isactive' => '1'));
                              $clientsa = $this->db->get('m_district')->result_array();
                              foreach ($clientsa as $rowa):
                                  ?>
                                  <option value="<?php echo $rowa['id']; ?>">
                                      <?php echo $rowa['name']; ?></option>
                              <?php endforeach; ?>
              </select>

								 <select name="status" id="status"required>
 <option value="">Select Status</option>
 <option value="1">Active</option>
 <option value="0">In Active</option>
                 
                  
              </select>
								<input type="submit" value="Add">
							</form>
						</div>
					</div>
				</div>
			</div>


						<div class="add-new-pro">
				
				<div id="myModala" class="modal" style="display:none;">
					<div class="modal-content">
						<span class="closea">&times;</span>
						<h4>Update User Details</h4>
						<div class="pro-add">							
							 <div  id="employee_detail">  
                </div>
						</div>
					</div>
				</div>
			</div>


			<div class="product-header">
			
<?php //print_r($pro_det); ?>

        <div class="container-fluid" style="overflow-x:auto;overflow-y:hidden;" >

        <table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">

 <thead >
<tr class="success" style="background-color:#086788;color:#fff">
<th>Sl_No</th> 

<th>Name</th>
<th>User Name</th>
<th>Email</th>
<th>Designation</th>
<th>District</th>
<th>Status</th>
<th>Actions</th>
</tr> 
</thead>
    <?php 
 $counter = 1;
    foreach($pro_det as $prod_det){ ?>      
<tr>
<td><?php echo $counter++;?></td>  
<td style="text-align:justify;"><?php echo $prod_det->name; ?></td>
<td style="text-align:justify;"><?php echo $prod_det->usrname; ?></td> 
<td style="text-align:justify;"><?php echo $prod_det->email; ?></td> 
<td style="text-align:justify;">
<?php echo $this->db->get_where('m_designation', array('id' => $prod_det->desig_id))->row()->designation_name; ?>
   </td> 
<td style="text-align:justify;">
    <?php echo $this->db->get_where('m_district', array('id' => $prod_det->district_id))->row()->name; ?></td> 
<td><?php if($prod_det->isactive==1){echo "Active";}else{echo "In Active";} ?></td> 
<td class="pro-action"><span id="<?php echo $prod_det->id ?>" class="view_data"><i class="fa fa-pencil-square-o"></i></span>	</td>
</tr>

<?php 
}
?>
</table>
</div>

			</div>
		</div>
	</div>
	<script>		
		var modal = document.getElementById("myModal");
		var btn = document.getElementById("myBtn");
		var span = document.getElementsByClassName("close")[0];
		btn.onclick = function() {modal.style.display = "block";}
		span.onclick = function() {modal.style.display = "none";}
		window.onclick = function(event) {if (event.target == modal) {modal.style.display = "none";}} 
	</script>
<script>
    $(document).ready(function () {

        "use strict"; // Start of use strict

        $("#dataTableExample26").DataTable({
            dom: "<'row'<'col-md-6'l><'col-md-6'f>>tp",
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            buttons: [
               
                
            ]
            
        });

    });
</script> 



 <script>
        function show(id) {
            
          var a = document.getElementById(id);
          if (a.type == "password") {
            a.type = "text";

          } else {
            a.type = "password";
          }
        }
    </script>

  <script>  
 $(document).ready(function(){  
      $('.view_data').click(function(){  
           var employee_id = $(this).attr("id");
//alert(employee_id);	
  
   var BASE_URL = "<?php echo base_url();?>";
    var path    = BASE_URL+'admin/masters/user_edit';

 $.ajax({  
                url:"<?php echo base_url()?>admin/masters/user_edit",  
                method:"post",  
                data:{employee_id:employee_id},  
                success:function(data){  
                     $('#employee_detail').html(data); 
                    var modal = document.getElementById("myModala");
					modal.style.display = "block";
					var span = document.getElementsByClassName("closea")[0];
					span.onclick = function() {modal.style.display = "none";}
                      
                }  
           });

      });  
 });  
 </script>

<style>
.manage-pro .add-new-pro .modal-content {margin: 10% auto;}
.manage-pro .add-new-pro .pro-add textarea {float: left;width: 100%;margin: 5px;padding: 10px;border: 2px solid #d8d8d8;border-radius: 5px;}
.manage-pro .add-new-pro .pro-add select {float: left;width: 100%;margin: 5px;padding: 10px;border: 2px solid #d8d8d8;border-radius: 5px;}
.alert {padding: 10px;background-color: #d6efd7;color: #000;float: left;position: relative;width: 100%;}
.alert .closebtn {margin-left: 15px;color: #888;font-weight: bold;float: right;font-size: 22px;line-height: 20px;cursor: pointer;transition: 0.3s;}
#dataTableExample26_wrapper .row{display:contents!important;}
#dataTableExample26_wrapper .row .col-md-6{	margin-bottom:10px!important;}
.table>tbody>tr.success>td, .table>tbody>tr.success>th, .table>tbody>tr>td.success, .table>tbody>tr>th.success, .table>tfoot>tr.success>td, .table>tfoot>tr.success>th, .table>tfoot>tr>td.success, .table>tfoot>tr>th.success, .table>thead>tr.success>td, .table>thead>tr.success>th, .table>thead>tr>td.success, .table>thead>tr>th.success { background-color: #0a6788;color: #fff;font-size: 15px;font-weight: 500;box-shadow: 0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(255, 152, 0, 0.4);}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {  font-size: 15px;}
label{font-size: 14px;} 
#dataTableExample26_wrapper{padding: 0px 30px 0px 0px;}
.pagination>.disabled>a, .pagination>.disabled>a:focus, .pagination>.disabled>a:hover, .pagination>.disabled>span, .pagination>.disabled>span:focus, .pagination>.disabled>span:hover {   color: #777;cursor: not-allowed;background-color: #fff;border-color: #ddd;}
.pagination>li:first-child>a, .pagination>li:first-child>span {margin-left: 0;border-top-left-radius: 4px;border-bottom-left-radius: 4px;}
.pagination>li>a, .pagination>li>span {position: relative;float: left;padding: 6px 12px;margin-left: -1px;line-height: 1.42857143;color: #337ab7;text-decoration: none;background-color: #fff;border: 1px solid #ddd;}
.pagination {display: inline-block;padding-left: 0;margin: 20px 0;border-radius: 4px;}
.pagination>li {display: inline;}
.manage-pro .add-new-pro .closea {color: #aaa;float: right;font-size: 28px;font-weight: bold;position: absolute;right: 10px;cursor: pointer;}
.product-header table th{width: auto !important;}
.manage-pro {float: left;position: relative;width: 100%;padding: 2%;min-height: 700px;}
.user-pas {float: left;position: relative;width: 100%;}
.user-pas .fa {position: absolute;top: 40%;right: 3%;cursor:pointer;}
.manage-pro .add-new-pro .head-pro {float: left;width: 50%;text-align: left;}
</style>

<script>
function isNumbera(evt) {
   var regex = new RegExp("^[A-Za-z]");
        var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    return true;
}

</script>

  <script>
$('#sub-menu-btn').prop('checked', true);
</script> 
<?php include 'include/footer.php';?>

