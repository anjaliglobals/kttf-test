<html lang="en" class="notranslate" translate="no"> 
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo base_url();?>theme/admin/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>theme/admin/css/style.css">
    <title>KTTF</title>
  </head>
<body style="display: flex; background-color: #ececec">
		<div class="login-page-form">
			<div class="ka-logo">
				<img src="<?php echo base_url();?>theme/admin/images/ka-logo.jpg" style="width:100px;">
			</div>
			<div class="kttf-form">
				<h3>Karnataka Tourism Trade (Facilatation and Regulation) Act 2015 <br>ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ (ಸೌಲಭ್ಯ ಮತ್ತು ನಿಯಂತ್ರಣ) ಕಾಯ್ದೆ 2015</h3><br>
				<h4>Admin Login / ನಿರ್ವಹಣೆ ಲಾಗಿನ್</h4>
				<hr align="center" width="50px">


			<?php if($this->session->flashdata('msg')):?>			
				<div class="alert">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg');?>
				</div>
			<?php endif; ?>
			<?php if($this->session->flashdata('msg-error')):?>			
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-error');?>
				</div>
			<?php endif; ?>
				<form action="<?php echo base_url().'admin/login/auth';?>" method="post">
					<div class="admin-user-name">
						<span class="username">Username / ಬಳಕೆದಾರ ಹೆಸರು</span>
						<span class="username-box">
							<input type="text" placeholder="Username" required name="admin_user_name">
						</span>
					</div>
					<div class="admin-user-pass">
						<span class="username">Password / ಗುಪ್ತಪದ</span>
						<span class="username-box">							
							<input type="password" id="admin_user_password" name="admin_user_password" placeholder="Password">
							<i class="fa fa-eye-slash" onclick="show('admin_user_password')" id="amin-pass"></i>
						</span>
					</div>
					<div class="admin-submit">
						<input type="submit" value="Login" class="admin-login-submit"><br>
						<!--a href="#">Forgot Password</a-->
					</div>
				</form>
			</div>

      <div class="copyright-agent"><p style="font-style: italic;">© 2021 Deportment of Tourism, Karnataka All Rights Reserved.</p></div>
		</div>
	</div>
	<script>
		function show(id) {
		  var a = document.getElementById(id);
		  if (a.type == "password") {
			a.type = "text";

		  } else {
			a.type = "password";

		  }
		}
	</script>
	<style>
	.kttf-form h3 {
    font-size: 20px;
}
.kttf-form h4 {
    font-size: 20px;
}
.kttf-form form .admin-user-name {
    font-size: 16px;
}
.kttf-form form .admin-user-pass {
    font-size: 16px;
}
</style>

	<style>
	.login-page-form {
    float: left;
    position: sticky;
    width: 60%;
    padding: 2% 5%;
    text-align: center;
    margin: auto;
    border: 0px solid;
    box-shadow: 0 2px 5px 0 rgb(0 0 0 / 36%), 0 2px 10px 0 rgb(0 0 0 / 32%);
    border-radius: 20px;
    background-color: #ffffff;
}
  .kttf-form .admin-more-info {
    float: left;
    position: relative;
    width: 50%;
    text-align: center;

  }
 .login-page {
    float: left;
    position: relative;
    width: 100%;
    background: #ececec;
    display: flex;
}
.copyright-agent{
	font-size: 10px;
	color: grey;
}
</style>
	
</body>
</html>
