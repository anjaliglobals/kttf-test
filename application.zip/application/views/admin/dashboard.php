<?php include 'include/header.php';?>

		<div class="admin-report-options">
			<div class="admin-total-app">
				<div class="total-app-image" style="height: 150px;">
					<i class="fa fa-download" style="font-size:90px;"></i>
				</div>
				<div class="total-app-text">
					<span class="issued">Total Application Received</span><span class="issued-count"><?php echo $dashboardInfo['appTotal'];?></span>
				</div>
				<!--div class="total-app-more">
					<h6>More Info</h6>
				</div-->				
			</div>
			<div class="admin-field-verify">
				<div class="field-verify-image" style="height: 150px;">
					<i class="fa fa-bell" style="font-size:90px;"></i>
				</div>
				<div class="field-verify-text">
					<span class="issued">Applications Pending</span><span class="issued-count"><?php echo $dashboardInfo['appPending'];?></span>
				</div>
				<!--div class="field-verify-more">
					<h6>More Info</h6>
				</div-->				
			</div>
			<div class="admin-renew-pending">
				<div class="renew-pending-image" style="height: 150px;">
					<i class="fa fa-window-close" style="font-size:90px;"></i>
				</div>
				<div class="renew-pending-text">
					<span class="issued">Total Application Closed</span><span class="issued-count"><?php echo $dashboardInfo['appClosed'];?></span>
				</div>
				<!--div class="renew-pending-more">
					<h6>More Info</h6>
				</div-->				
			</div>
			<div class="admin-total-app-rej">
				<div class="total-app-rej-image" style="height: 150px;">
					<i class="fa fa-file-excel-o" style="font-size:90px;"></i>
				</div>
				<div class="total-app-rej-text">
					<span class="issued">Total Application Rejected</span><span class="issued-count"><?php echo $dashboardInfo['appRejected'];?></span>
				</div>
				<!--div class="total-app-rej-more">
					<h6>More Info</h6>
				</div-->				
			</div>

			<div class="admin-payment">
				<div class="payment-image" style="height: 150px;">
					<i class="fa fa-inr" style="font-size:90px;"></i>
				</div>
				<div class="payment-text">
					<span class="issued">Payment Received</span><span class="issued-count"><?php echo $dashboardInfo['appPayed'];?></span>
				</div>
				<!--div class="payment-more">
					<h6>More Info</h6>
				</div-->				
			</div>
		</div>
		
<?php include 'include/footer.php';?>
