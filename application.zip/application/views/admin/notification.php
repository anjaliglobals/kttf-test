

<?php include 'include/header.php';?>

	          <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

          
	<script>
$(document).ready(function() {
    $('#datatable').dataTable();
    
     $("[data-toggle=tooltip]").tooltip();
    
} );
</script> 


			

	<div class="admin-dashboard">
		<div class="manage-pro">

<?php if($this->session->flashdata('msg')):?>
				<div class="alert">
			  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
			</div>

			<?php endif; ?>

			<div class="add-new-pro">
				<h3 class="head-pro">View Notifications</h3>
			<?php 
 //print_r($note_det);
      ?>
				
			</div>


				

			<div class="product-header">
			
<?php //print_r($pro_det); ?>

        <div class="container-fluid" style="overflow-x:auto;overflow-y:hidden;" >

        <table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">

 <thead >
<tr class="success" style="background-color:#086788;color:#fff">
<th>Sl_No</th> 
<th>Application ID (Notification Count)</th>
<th>Entity Name</th>
<th>Recent Messages</th>
<th>Date</th>
<th>Status</th>
<th>Actions</th>
</tr> 
</thead>
    <?php 
 $counter = 1;
    foreach($note_det as $noti_det){ 


$pendWhere['note.application_id'] = $noti_det->application_id;
      $pendWhere['note.status'] = '0';

    $this->db->select('count(note.id) total');
    $this->db->from('adm_notification note');
    
    if($pendWhere)
      $this->db->where($pendWhere);

    $penResult = $this->db->get()->result();
    $appn_count = $penResult[0]->total;


      ?>      
<tr>
<td><?php echo $counter++;?></td>  
<td style="text-align:justify;"><?php echo $this->db->get_where('application', array('id' => $noti_det->application_id))->row()->application_id; ?> &nbsp; (<?php echo $appn_count; ?>)</td>
<td style="text-align:justify;"><?php echo $this->db->get_where('application', array('id' => $noti_det->application_id))->row()->applicant_name; ?></td> 
<td style="text-align:justify;"><?php 
    
    
$this->db->order_by('id', 'desc');
$this->db->limit(1);
$sub = $this->db->get_where('adm_notification', array('application_id' => $noti_det->application_id))->row()->subject; 
 echo $sub;
?>
<td style="text-align:justify;"><?php 
    
    
$this->db->order_by('id', 'desc');
$this->db->limit(1);
$crt_date = $this->db->get_where('adm_notification', array('application_id' => $noti_det->application_id))->row()->crtdate;
echo date("d/m/Y",strtotime($crt_date)); 
?>
</td> 
<td><?php if($noti_det->status==1){echo "Viewed";}else{echo "Pending";} ?></td> 
<td class="pro-action"><!--span id="<?php echo $noti_det->id ?>" class="view_data"><i class="fa fa-pencil-square-o"></i></span-->
<a class='btn btn-info btn-sm' href="<?php echo base_url();?>admin/application/application_notification_view/<?php echo $noti_det->application_id;?>" target="_blank">VIEW</a>
	</td>
</tr>

<?php 
}
?>
</table>
</div>

			</div>
		</div>
	</div>

<style>
.manage-pro .add-new-pro .modal-content {margin: 10% auto;}
.manage-pro .add-new-pro .pro-add textarea {float: left;width: 100%;margin: 5px;padding: 10px;border: 2px solid #d8d8d8;border-radius: 5px;}
.manage-pro .add-new-pro .pro-add select {float: left;width: 100%;margin: 5px;padding: 10px;border: 2px solid #d8d8d8;border-radius: 5px;}
.alert {padding: 10px;background-color: #d6efd7;color: #000;float: left;position: relative;width: 100%;}
.alert .closebtn {margin-left: 15px;color: #888;font-weight: bold;float: right;font-size: 22px;line-height: 20px;cursor: pointer;transition: 0.3s;}
#dataTableExample26_wrapper .row{display:contents!important;}
#dataTableExample26_wrapper .row .col-md-6{	margin-bottom:10px!important;}
.table>tbody>tr.success>td, .table>tbody>tr.success>th, .table>tbody>tr>td.success, .table>tbody>tr>th.success, .table>tfoot>tr.success>td, .table>tfoot>tr.success>th, .table>tfoot>tr>td.success, .table>tfoot>tr>th.success, .table>thead>tr.success>td, .table>thead>tr.success>th, .table>thead>tr>td.success, .table>thead>tr>th.success { background-color: #0a6788;color: #fff;font-size: 15px;font-weight: 500;box-shadow: 0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(255, 152, 0, 0.4);}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {  font-size: 15px;}
label{font-size: 16px;} 
#dataTableExample26_wrapper{padding: 0px 30px 0px 0px;}
.pagination>.disabled>a, .pagination>.disabled>a:focus, .pagination>.disabled>a:hover, .pagination>.disabled>span, .pagination>.disabled>span:focus, .pagination>.disabled>span:hover {   color: #777;cursor: not-allowed;background-color: #fff;border-color: #ddd;}
.pagination>li:first-child>a, .pagination>li:first-child>span {margin-left: 0;border-top-left-radius: 4px;border-bottom-left-radius: 4px;}
.pagination>li>a, .pagination>li>span {position: relative;float: left;padding: 6px 12px;margin-left: -1px;line-height: 1.42857143;color: #337ab7;text-decoration: none;background-color: #fff;border: 1px solid #ddd;}
.pagination {display: inline-block;padding-left: 0;margin: 20px 0;border-radius: 4px;}
.pagination>li {display: inline;}
.manage-pro .add-new-pro .closea {color: #aaa;float: right;font-size: 28px;font-weight: bold;position: absolute;right: 10px;cursor: pointer;}
.product-header table th{width: auto !important;}
.manage-pro {float: left;position: relative;width: 100%;padding: 2%;min-height: 700px;}
.user-pas {float: left;position: relative;width: 100%;}
.user-pas .fa {position: absolute;top: 40%;right: 3%;cursor:pointer;}
.manage-pro .add-new-pro .head-pro {float: left;width: 50%;text-align: left;}
</style>

  <script>
$('#sub-menu-btn').prop('checked', true);
</script> 
<?php include 'include/footer.php';?>

