<?php 
 foreach($pro_det as $prod_det){ 
    ?> 



                            <form action="<?php echo base_url();?>admin/masters/user_update" method="post">

<input type="text" required name="name" value="<?php echo $prod_det->name; ?>" onkeypress="return isNumbera(event)" placeholder="Enter the Name">
<input type="text" required name="usrname" value="<?php echo $prod_det->usrname; ?>" placeholder="Enter the Login User Name">

 <input type="hidden" required name="user_id" value="<?php echo $prod_det->id; ?>">

                         
                            <!--input type="text" value="<?php echo md5($prod_det->usrpassword); ?>" id="usrpassword" name="usrpassword" placeholder="Enter the Password"-->
                            <!--i class="fa fa-eye-slash" onclick="show('usrpassword')"></i-->
                        
<input type="email" required name="email" value="<?php echo $prod_det->email; ?>" placeholder="Enter the Email">
    
        <select name="desig_id" id="desig_id"required class="">
                  <option value="">Select Designation</option>
                  <?php
                 
                                $this->db->where(array('isactive' => '1'));
                              $clients = $this->db->get('m_designation')->result_array();
                              foreach ($clients as $row):
                                  ?>
                                  <option value="<?php echo $row['id']; ?>" <?php if($prod_det->desig_id==$row['id']){echo "selected";}?> >
                                      <?php echo $row['designation_name']; ?></option>
                              <?php endforeach; ?>
              </select>

    <select name="district_id" id="district_id"required class="">
                  <option value="">Select District</option>
                  <?php
                 
                                $this->db->where(array('isactive' => '1'));
                              $clientsa = $this->db->get('m_district')->result_array();
                              foreach ($clientsa as $rowa):
                                  ?>
                                  <option value="<?php echo $rowa['id']; ?>" <?php if($prod_det->district_id==$rowa['id']){echo "selected";}?> >
                                      <?php echo $rowa['name']; ?></option>
                              <?php endforeach; ?>
              </select>

                 <select name="status" id="status"required>
 <option value="">Select Status</option>
 <option value="1" <?php if($prod_det->isactive==1){echo "selected";}?>>Active</option>
 <option value="0" <?php if($prod_det->isactive==0){echo "selected";}?>>In Active</option>
                 
                  
              </select>
                <input type="submit" value="Update">
              </form>



                            <?php
                        }
                        ?>