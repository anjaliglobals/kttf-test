

<?php include 'include/header.php';?>

	          <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>

          
	<script>
$(document).ready(function() {
    $('#datatable').dataTable();
    
     $("[data-toggle=tooltip]").tooltip();
    
} );
</script> 


			

	<div class="admin-dashboard">
		<div class="manage-pro">

<?php if($this->session->flashdata('msg')):?>
				<div class="alert">
			  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
			</div>

			<?php endif; ?>

		
				<h3 class="head-pro" style="text-align:center;">Admin User Manual</h3>
				<br><br><br>

                    <div class="app-form-field">
                      <div class="form-text">
                         <a href="<?php echo base_url().'theme/admin/images/KTTF_admin_manual_kannada.pdf';?>" target="_blank"><p class="man2" style="text-align:center;"><img src="<?php echo base_url().'theme/user/images/pdf_dn.jpg';?>" style="width: 100px;height: auto;"><b class="man1">ಬಳಕೆದನರರ ಕೆೈಪಿಡ</b> </p></a>
                      </div>
                      <div class="form-input">
                          <a href="<?php echo base_url().'theme/admin/images/KTTF_admin_manual.pdf';?>"target="_blank"><p class="man2" style="text-align:center;"><img src="<?php echo base_url().'theme/user/images/pdf_dn.jpg';?>" style="width: 100px;height: auto;"><b class="man1">User Manual</b> </p></a>        
                      </div>                  
                    </div>
	
			


		</div>
	</div>

 

<style>
.manage-pro .add-new-pro .modal-content {margin: 10% auto;}
.manage-pro .add-new-pro .pro-add textarea {float: left;width: 100%;margin: 5px;padding: 10px;border: 2px solid #d8d8d8;border-radius: 5px;}
.manage-pro .add-new-pro .pro-add select {float: left;width: 100%;margin: 5px;padding: 10px;border: 2px solid #d8d8d8;border-radius: 5px;}
.alert {padding: 10px;background-color: #d6efd7;color: #000;float: left;position: relative;width: 100%;}
.alert .closebtn {margin-left: 15px;color: #888;font-weight: bold;float: right;font-size: 22px;line-height: 20px;cursor: pointer;transition: 0.3s;}
#dataTableExample26_wrapper .row{display:contents!important;}
#dataTableExample26_wrapper .row .col-md-6{	margin-bottom:10px!important;}
.table>tbody>tr.success>td, .table>tbody>tr.success>th, .table>tbody>tr>td.success, .table>tbody>tr>th.success, .table>tfoot>tr.success>td, .table>tfoot>tr.success>th, .table>tfoot>tr>td.success, .table>tfoot>tr>th.success, .table>thead>tr.success>td, .table>thead>tr.success>th, .table>thead>tr>td.success, .table>thead>tr>th.success { background-color: #0a6788;color: #fff;font-size: 15px;font-weight: 500;box-shadow: 0 4px 20px 0px rgba(0, 0, 0, 0.14), 0 7px 10px -5px rgba(255, 152, 0, 0.4);}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {  font-size: 15px;}
label{font-size: 14px;} 
#dataTableExample26_wrapper{padding: 0px 30px 0px 0px;}
.pagination>.disabled>a, .pagination>.disabled>a:focus, .pagination>.disabled>a:hover, .pagination>.disabled>span, .pagination>.disabled>span:focus, .pagination>.disabled>span:hover {   color: #777;cursor: not-allowed;background-color: #fff;border-color: #ddd;}
.pagination>li:first-child>a, .pagination>li:first-child>span {margin-left: 0;border-top-left-radius: 4px;border-bottom-left-radius: 4px;}
.pagination>li>a, .pagination>li>span {position: relative;float: left;padding: 6px 12px;margin-left: -1px;line-height: 1.42857143;color: #337ab7;text-decoration: none;background-color: #fff;border: 1px solid #ddd;}
.pagination {display: inline-block;padding-left: 0;margin: 20px 0;border-radius: 4px;}
.pagination>li {display: inline;}
.manage-pro .add-new-pro .closea {color: #aaa;float: right;font-size: 28px;font-weight: bold;position: absolute;right: 10px;cursor: pointer;}
.product-header table th{width: auto !important;}
.manage-pro {float: left;position: relative;width: 100%;padding: 2%;min-height: 700px;}
.user-pas {float: left;position: relative;width: 100%;}
.user-pas .fa {position: absolute;top: 40%;right: 3%;cursor:pointer;}
.manage-pro .add-new-pro .head-pro {float: left;width: 50%;text-align: left;}

.man1{color: #000;padding: 40px;font-size: 20px;}
.man2{border: 2px solid #adb5bd;width: 75%;padding: 10px 1px 5px 5px;border-radius: 5px}
.man3{height:50%;}
.app-form-field {margin-left: 100px;}
@media only screen and (max-width: 768px){
.man1{color: #000;padding: 20px;font-size: 18px;display: inline-block;}
.man2{border: 2px solid #adb5bd;width: 100%;padding: 10px 1px 5px 5px;border-radius: 5px}
.man3{height:100%;}
.app-form-field {margin-left: 0;}

}
p{text-align:center;}
</style>

<script>
function isNumbera(evt) {
   var regex = new RegExp("^[A-Za-z]");
        var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    return true;
}

</script>

  <script>
$('#sub-menu-btn').prop('checked', true);
</script> 
<?php include 'include/footer.php';?>

