<?php 
 foreach($pro_det as $prod_det){ 
    ?> 



                            <form action="<?php echo base_url();?>admin/masters/user_regfee_update" method="post">


 <input type="hidden" required name="user_id" value="<?php echo $prod_det->id; ?>">


 <select name="prod_id" id="app_status_id"required class="">
                <option value="">Select Product</option>
                    <?php                 
                                $this->db->where(array('isactive' => '1'));
                              $clients = $this->db->get('m_product')->result_array();
                              foreach ($clients as $row):
                                  ?>
                                  <option value="<?php echo $row['id']; ?>" <?php if($prod_det->prod_id==$row['id']){echo "selected";}?> >
                                      <?php echo $row['name']; ?></option>
                              <?php endforeach; ?>
              </select>


<select name="org_loc_district_id" id="loc_district" class="">
                            <option value="">Select District</option>
                            <?php
                              $this->db->where(array('state_id' => '17'));
                            $clients = $this->db->get('m_district')->result_array();
                            foreach ($clients as $row): ?>
                            <option value="<?php echo $row['id']; ?>"  <?php if($prod_det->org_loc_district_id==$row['id']){echo "selected";}?> >
                            <?php echo $row['name']; ?></option>
                            <?php endforeach; ?>
                        </select>


<select name="org_loc_taluk_id" class="" id="loc_taluk">
                          <option value="">Select Taluk</option>
                           <?php
                            $this->db->where(array('district_id' => $prod_det->org_loc_district_id)) ;
                            $clients = $this->db->get('m_taluk')->result_array();
                            foreach ($clients as $row): ?>
                            <option value="<?php echo $row['id']; ?>"  <?php if($prod_det->org_loc_taluk_id==$row['id']){echo "selected";}?> >
                            <?php echo $row['name']; ?></option>
                            <?php endforeach; ?>
                        </select>

<input type="text" required name="timeline" value="<?php echo $prod_det->amount; ?>" onkeypress="return isNumbera(event)" placeholder="Enter the Registration Fee">
              
 <select name="status" id="status"required>
 <option value="">Select Status</option>
 <option value="1" <?php if($prod_det->isactive==1){echo "selected";}?>>Active</option>
 <option value="0" <?php if($prod_det->isactive==0){echo "selected";}?>>In Active</option>
                 
                  
              </select>



                
                <input type="submit" value="Update">
              </form>



                            <?php
                        }
                        ?>