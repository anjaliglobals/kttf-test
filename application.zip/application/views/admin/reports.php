<html>
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <link rel="stylesheet" href="<?php echo base_url();?>css/bootstrap.min.css"> 
    <!-- <link rel="stylesheet" href="css/style.css"> -->
    <title>KTTF Application Details</title>
  </head>
<body id="print-report">
	<div class="application-logo-header">
		<div class="kttf-logo">
			<img src="<?php echo base_url();?>theme/admin/images/ka-logo.jpg"> Karnataka Tourism Trade Facilitation
		</div>		
	</div>	

<?php
// print_r($payment);
// print_r($application);
?>
	<div class="admin-report">		
		<div class="admin-report-section">	
			<div class="report-details">
				<div class="payment-details">
					<p>Payment Approved Date: <?php echo date("d-m-Y",strtotime($application->approve_payment_date)); ?></p>
					<p>Payable Amount: <?php echo $application->payment_payed_amount; ?></p>
				</div>
				<div class="payment-tab">
					<h3><?php echo $application->applicant_name; ?> - Payment Details</h3>
					<div class="payment-report-tab">
						<div style="overflow-x:auto;">
							<table class="pay-table">
								<tr>
									<th>Product Name</th>
									<td>Tour Operators</td>
								</tr>
								<tr>
									<th>Transaction Status</th>
									<td>Success</td>
								</tr>
								<tr>
									<th>Transaction Date</th>
									<td><?php echo  date("d-m-Y",strtotime($application->payment_payed_date)); ?></td>
								</tr>
								<tr>
									<th>Transaction Amount</th>
									<td><?php echo $application->payment_payed_amount; ?></td>
								</tr>
								<tr>
									<th>Total Amount</th>
									<td><?php echo $application->payment_payed_amount; ?></td>
								</tr>
							</table>
						</div>
					</div>
				</div>
					
			</div>
			<div class="report-print">
				<button type="button" onclick="printDiv('print-report')">Print</button>
			</div>
		</div>
	</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	
	<style>			
		.application-logo-header {float: left;position: relative;width: 100%;box-shadow: 0 0 5px 0 #333;}
		.application-logo-header .kttf-logo {float: left;position: relative;width: 100%;font-size: 30px;font-weight: 600;padding: 1% 3%;text-align:center;}
		.application-logo-header .kttf-logo img {width: 80px;margin-right: 20px;}
		.admin-report {float: left;position: relative;width: 100%;margin-top: 10px;}
		.admin-report .admin-report-section {margin: auto;width: 70%;}
		.admin-report .admin-report-section .report-details {float: left;position: relative;width: 100%;box-shadow: 0 0 3px 0 #333;padding: 3%;}
		.admin-report .admin-report-section .report-details .payment-details {float: left;position: relative;width: 100%;text-align: right;}
		.admin-report .admin-report-section .report-details .payment-details p {margin: 5px 0;}
		.admin-report .admin-report-section .report-details .payment-tab {text-align: center;float: left;position: relative;width: 100%;}
		.admin-report .admin-report-section .report-details .payment-tab .payment-report-tab {margin: auto;width: 50%;}
		.admin-report .admin-report-section .report-details .payment-tab .payment-report-tab .pay-table {width: 100%;}
		.admin-report .admin-report-section .report-details .payment-tab .payment-report-tab .pay-table tr {border: 1px solid #aaa;}
		.admin-report .admin-report-section .report-details .payment-tab .payment-report-tab .pay-table th {padding: 10px;}
		.admin-report .admin-report-section .report-details .payment-tab .payment-report-tab .pay-table td {padding: 10px;}
		.report-print {float: left;position: relative;width: 100%;text-align: center;margin: 10px 0;}
		.report-print button {background: #2093d1;color: #fff;border: none;padding: 10px 20px;border-radius: 5px;}
		@media only screen and (max-width:1024px){
		.application-logo-header .kttf-logo {width: 100%;}
		.application-logo-header .kttf-logo img {width: 80px;margin-right: 20px;display: block;margin: auto;}
		}
		@media only print{.report-print{display: none;}}
	</style>
	<script>
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}
	</script>
</body>
</html>
