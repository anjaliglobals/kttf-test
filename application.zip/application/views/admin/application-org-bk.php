<?php include 'include/header.php';?>

<div class="application">	
			<div class="alli-dashboard">		
				<section class="wizard-section">
					<div class="no-gutters">			
						<div class="col-lg-12 col-md-12">
							<div class="form-wizard">
								<h3>KTTF Application for Travel Agents</h3>
								<form action="" method="post" role="form" name="application_form">
									<input type="hidden" name="application_id" value="$application->id">
									<div class="form-wizard-header">								
										<ul class="list-unstyled form-wizard-steps clearfix">
											<li class="active"><span>1</span><span class="verify">General Verification</span></li>
											<li><span>2</span><span class="verify">Field Verification</span></li>											
											<li><span>3</span><span class="verify">Next Level</span></li>
											<li><span>4</span><span class="verify">Payment Verification</span></li>
										</ul>
									</div>
									<fieldset class="wizard-fieldset general-verify show">
										<div class="app-form-field">
											<div class="form-text app-image">
												<p>Applicant Name<sup>*</sup></p>
											</div>
											<div class="form-input app-image">
												<input type="text" name="applicant_name" readonly value="<?php echo $application->applicant_name ;?>" style="text-align:center;">
											</div>
											<div class="app-image-user">
												<!-- <img src="images/user.png"> -->
											</div>
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Approved By Govt of India<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="central_gov_approved" value="<?php echo $application->applicant_name ;?>">
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Name of Organization<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_name" value="<?php echo $application->org_name ;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Year of registration / commencement of business<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_commencement_date" value="<?php echo $application->org_commencement_date ;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Organization Type<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_type_id" value="<?php echo $organization[$application->org_type_id] ;?>" readonly>							
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Name of proprietor / Directors / Partners<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="proprietor_name" value="<?php echo $application->proprietor_name ;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Whether associate with any firm<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="associate_firm" value="<?php echo $application->associate_firm ;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Whether a member of any recognised trade body?<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="member_recognised_trade" value="<?php echo $application->member_recognised_trade ;?>" readonly >
											</div>									
										</div>
										<?php if($application->member_recognised_trade == 'Yes'):?>
										<div class="app-form-field">
											<div class="form-text">
												<p>Trade body details</p>
											</div>
											<div class="form-input">
												<!-- <input type="text" name="member_recognised_trade_details" value="<?php echo $application->member_recognised_trade_details ;?>" readonly> -->
												<input type="text" name="member_recognised_trade_details" value="<?php echo $application->member_recognised_trade_details ;?>" readonly>
											</div>									
										</div>
										<?php endif; ?>
										<div class="form-heading">
											<h4>Organization Address</h4>
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 1</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_add1" value="<?php echo $application->org_add1 ;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 2</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_add2" value="<?php echo $application->org_add2;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Country</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_country" value="<?php echo $country[$application->org_country];?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>State</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_state" value="<?php echo $state[$application->org_state];?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>City</p>
											</div>
											<div class="form-input">
												<!-- <input type="text" name="org_city" value="<?php echo $city[$application->org_city];?>" readonly /> -->
												<input type="text" name="org_city" value="test-static" readonly />
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Pincode</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_pincode_id" value="<?php echo $application->org_pincode_id;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Mobile Number</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_mobile" value="<?php echo $application->org_mobile;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Telephone Number</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_telephone" value="<?php echo $application->org_telephone;?>" readonly>
											</div>									
										</div>
										


										<div class="form-heading">
											<h4>Organization Location Address</h4>
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 1</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add1" value="<?php echo $application->org_loc_add1 ;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 2</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add2" value="<?php echo $application->org_loc_add2;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>State</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_state" value="<?php echo $state[$application->org_loc_state];?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>District</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_district_id" value="<?php echo $district[$application->org_loc_district_id];?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Pincode</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_pincode_id" value="<?php echo $application->org_loc_pincode_id;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Mobile Number</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_mobile" value="<?php echo $application->org_loc_mobile;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Telephone Number</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_telephone" value="<?php echo $application->org_loc_telephone;?>" readonly>
											</div>									
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-nopadd">
												<p>Details of activity undertaken by the firm besides acting as a Travel Agent</p>
											</div>									
											<div class="field-comment-nopadd">
												<p class="non-edit-fields"><?php echo $application->off_activity;?></p>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-nopadd">
												<p>Memberships of International tour associations, if any </p>
											</div>									
											<div class="field-comment-nopadd">
												<p class="non-edit-fields"><?php echo $application->off_international_membership;?></p>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-nopadd">
												<p>Steps taken to promote domastic tourists activity</p>
											</div>									
											<div class="field-comment-nopadd">
												<p class="non-edit-fields"><?php echo $application->off_promote_domestic_activity;?></p>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-nopadd">
												<p>Special Programmes arranged for Foreign Tourists, if any</p>
											</div>									
											<div class="field-comment-nopadd">
												<p class="non-edit-fields"><?php echo $application->off_prog_arranged_foreign_tourist;?></p>
											</div>
										</div> 
										
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
										</div>
									</fieldset>	
									<fieldset class="wizard-fieldset comment-section" id="comment-sec">
										<!-- <div class="form-required">
											<div class="form-required-area">
												<h4 style="visibility: hidden;">Required Documents</h4>
												<h5 style="visibility: hidden;">Allowed Document Type .JPG, .PNG, .PDF(less than 2MB)</h5>
											</div>
											<div class="form-comment">
												<br>
												<p>Comments</p>
											</div>
										</div> -->

										<!-- 2nd screen start user fields  -->

										

										<!-- 2nd screen end user fields  -->

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>1. Registration certificates from government</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_registration_certificate/$application->img_registration_certificate'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='reg-gov' class="reg_govrn" name='img_registration_certificate' type='radio' value="Yes" checked />  Yes
												
												<input id='reg-gov1' name='img_registration_certificate' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_registration_certificate_details"style="display: none;" ></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>2. Reference letter from bank</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_bank_reference/$application->img_bank_reference'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='ref-let' class="ref_let" name='img_bank_reference' type='radio' checked value="Yes" />  Yes
												
												<input id='ref-let1' name='img_bank_reference' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_bank_reference_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>3. Certificate of statutory chartered</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_ca_certificate/$application->img_ca_certificate'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='certify' class="cert" name='img_ca_certificate' type='radio' checked value="Yes" />  Yes
												
												<input id='certify1' name='img_ca_certificate' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_ca_certificate_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>4. Audited balance sheet</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_audited_balance_sheet/$application->img_audited_balance_sheet'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='audited' class="cert" name='img_audited_balance_sheet' type='radio' checked value="Yes" />  Yes
												
												<input id='audited1' name='img_audited_balance_sheet' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_audited_balance_sheet_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>5. List of Directors/Partners</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_list_patners/$application->img_list_patners'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='list-direct' class="cert" name='img_list_patners' type='radio' checked value="Yes" />  Yes
												
												<input id='list-direct1' name='img_list_patners' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="limg_list_patners_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>6. Brochures or leaflets<sup>*</sup></p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_brochures/$application->img_brochures'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='brochure' class="cert" name='img_brochures' type='radio' checked value="Yes" />  Yes
												
												<input id='brochure1' name='img_brochures' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_brochures_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd-upload">
												<p>7. Details of office premises<sup>*</sup></p>										
											</div>
											<div class="field-download-padd-upload">
												<a href="<?php base_url().'upload/img_off_premises/$application->img_off_premises'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_off_premises' class="cert" name='img_off_premises' type='radio' checked value="Yes" />  Yes
												
												<input id='img_off_premises1' name='img_off_premises' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_off_premises_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>8. Labour department letter</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_labour_department/$application->img_labour_department'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='labour' class="cert" name='img_labour_department' type='radio' checked value="Yes" />  Yes
												
												<input id='labour1' name='img_labour_department' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_labour_department_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form">
												<p>Attached photograph of managing Director/Cheif Executive</p>
											</div>
											<div class="field-download">
												<a href="<?php base_url().'upload/img_md_photo_attested/$application->img_md_photo_attested'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='photo-director' class="cert" name='img_md_photo_attested' type='radio' checked value="Yes" />  Yes
												
												<input id='photo-director1' name='img_md_photo_attested' type='radio'value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_md_photo_attested_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-upload">
												<p>Photograph of the office building exterior</p>
											</div>
											<div class="field-download-upload">
												<a href="<?php base_url().'upload/img_off_buil_exterior/$application->img_off_buil_exterior'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='photo-build' class="cert" name='img_off_buil_exterior' type='radio' checked value="Yes" />  Yes
												
												<input id='photo-build1' name='img_off_buil_exterior' type='radio'value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_off_buil_exterior_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-upload">
												<p>Photograph of the office building interior</p>
											</div>
											<div class="field-download-upload">
												<a href="<?php base_url().'upload/img_off_buil_interior/$application->img_off_buil_interior'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='photo-interior' class="cert" name='img_off_buil_interior' type='radio' checked value="Yes" />  Yes
												
												<input id='photo-interior1' name='img_off_buil_interior' type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_off_buil_interior_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form">
												<p>CV of Staff Member</p>
											</div>
											<div class="field-download-upload">
												<a href="<?php base_url().'upload/img_off_staff_member/$application->img_off_staff_member'?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='cv-staff' class="cert" name='img_off_staff_member' type='radio' checked value="Yes" />  Yes
												
												<input id='cv-staff1' name='img_off_staff_member' type='radio' value="No" />  No
											</div>
											<div id="staff" class="field-comment-sec">
												<textarea class="condition-comment wizard-required-reject" name="img_off_staff_member_details" style="display: none;"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>

										<div id="reject" class="reject-option">
											<div class="field-appli-form-nopadd">
												<p>Reason for Rejecting</p>
											</div>									
											<div class="field-comment-nopadd">
												<textarea name="reject-admin" class="wizard-required-reject"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div id="reject-user" class="reject-option">
											<div class="field-appli-form-nopadd">
												<p>Message to User</p>
											</div>									
											<div class="field-comment-nopadd">
												<textarea name="reject-user" class="wizard-required-reject"></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
											<a href="javascript:;" id="hide_next" class="form-wizard-next-btn second-next float-right">Next</a>
											<a href="javascript:;" id="sub" class="form-wizard-submit-reject float-right" style="display:none;">Reject The Application</a>
											<a href="javascript:;" id="chck-sub" class="form-wizard-check-submit float-right" style="display:none;">Next</a>
										</div>
									</fieldset>										
									<fieldset class="wizard-fieldset nodal-officer">
										<div class="nodal-office-comment">
											<h3>Comments for Internal</h3>
											<textarea name="nodal-officer-comment" class="wizard-required"></textarea>
											<div class="wizard-form-error"></div>
											<div class="nodal-approve">
												<!-- <a href="#">REJECT</a>
												<a href="#">Approve to next step</a> -->										
											</div>
										</div>
										<div class="nodal-comment-applicant">
											<h3>Comments to Applicant</h3>
											<textarea name="nodal-comment-applicant" class="wizard-required"></textarea>
											<div class="wizard-form-error"></div>
											<!-- <div class="nodal-applicant">
												<a href="#">Send</a>										
											</div> -->
										</div>
										<div class="applicant-process-stage1">
											<div class="appli-stage1">
												<h2>Application Process Stages</h2>
												<h3>Stage GENERAL VERIFICATION By: AD <span>Approved to next Stage</span>
											</div>
											<div class="appli-comment">
												<h3>Commented by: AD</h3>
												<textarea name="application-ad-comment">All document are verified</textarea>
											</div>
										</div>

										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
											<a href="javascript:;" class="form-wizard-next-btn float-right">Approve for Payment</a>
											
										</div>
									</fieldset>
									<fieldset class="wizard-fieldset payment-history">
										<h3>Payment History</h3>
										<div class="pay-history-table">
											<div style="overflow:auto">
												<table class="pay-tab">
													<tbody>
														<tr class="pay-his-head">
															<th>Payment For</th>
															<th>Amount</th>
															<th>Date</th>
															<th>TNX Id</th>
															<th>Status</th>
															<th>Receipt</th>													
														</tr>
														<tr>
															<td colspan="6"></td>
														</tr>
														
													</tbody>
												</table>
											</div>									
										</div> 
										
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
											<a href="javascript:;" class="form-wizard-submit float-right">Approve </a>
										</div>
									</fieldset>
								</form>
							</div>
						</div>
					</div>
				</section>		
			</div>
		</div>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php include 'include/footer.php';?>
