<?php include 'include/header.php';?>
<div class="application">
			<!-- <div class="summary">
				<h3>Summary</h3>
			</div> -->
			<div class="waiting-application">
				<h4>Application: Waiting For my Approval</h4>
			</div>
			<?php if($this->session->flashdata('msg')):?>			
				<div class="alert">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg');?>
				</div>
			<?php endif; ?>
			<?php if($this->session->flashdata('msg-error')):?>			
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-error');?>
				</div>
			<?php endif; ?>
			<?php if($this->admDesig != 1):  ?>
			<div class=clearfix>&nbsp;&nbsp;</div>

			<div class="cls-filter">
				<!-- &nbsp;
				<label>From Date :</label>		
				<input type="text" name="" class="datepick">
				&nbsp;
				<label>To Date :</label>		
				<input type="text" id="datetimepicker" name="" class="datepick"> -->
				&nbsp;
				<label class="label_css">
				District :</label>
				<select class="selection_box"  name="district_id[]" id="district_id" onchange="loadpending_data()">
				<option value="">Select District</option>
				<?php
					$clients = $this->db->get('m_district')->result_array();
					foreach ($clients as $row):
				?>
				<option value="<?php echo $row['id']; ?>">
					<?php echo $row['name']; ?></option>
					<?php endforeach; ?>
				</select>
				&nbsp;&nbsp;&nbsp;
				<label>Product :</label>		
				<select class="selection_box" name="product_id[]" id="product_id" onchange="loadpending_data()">
				<option value="">Select Product</option>
				<?php
					$query=$this->db->query("select id, name from m_product where isactive like 1");
					$clients = $query->result_array();
					foreach ($clients as $row):
				?>
				<option value="<?php echo $row['id']; ?>">
					<?php echo $row['name']; ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<?php endif; ?>
			<div class="appli-table">
				<div style="overflow:auto">
					<table id='application-table'>
					 	<thead>
           					<tr class="app-tn-head">
								<th>SI.No</th>
								<th>Application Id</th>
								<th>Application Name</th>
								<th>District Id</th>
								<th>Stage</th>
								<th>Status</th>
								<th>Timeline</th>
								<th>Submited on</th>
								<th>Options</th>
							</tr>
						</thead>
						<tbody id='app-details'>        
			            </tbody>
					</table>
				</div>
			</div>
		</div>

<?php include 'include/footer.php';?>
<script>
$(document).ready(function()
{  
	loadpending_data();	
});
function loadpending_data()
{
	var applink = '<?php echo base_url().$appViewURL; ?>';
	console.log(applink);
	var appPath = '<?php echo base_url().$appPendingURL; ?>';
	var districtId=$("#district_id :selected").val();
	var prod_id=$("#product_id :selected").val();
	$("#application-table").dataTable().fnDestroy();
	var table = $('#application-table').DataTable({
			 ajax: {
			 			type: 'POST',
				        url: appPath,
				        dataSrc: '',
				        data:{
				             distId:districtId,
				             prodid:prod_id
				        }
				    },
					language : {
				        sLoadingRecords : '<span style="width:100%;"><img src="<?php echo base_url().'theme/admin/images/loader_icon.gif'?>"></span>'
				    },
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'appNumber' },
				        { data: 'appName' },
				        { data: 'appDisName' },
				        { data: 'appDesgName' },
				        { data: 'appStgDesc' }, 
				        { data: 'status'	,
					        render : function(data,sData, oData, iRow, iCol) 
					        {
					        	var dif=0;
					        	if(oData.originalTimeline!=null)
					        	{
					        		dif=Math.abs(parseInt(oData.originalTimeline)-parseInt(oData.Timeline));	
					        	}

					        	if(data=='N')
					        	{
					        		return '<span style="color:red">'+dif+'</span>' ;
					        	}
					        	else
					        	{
					        		if(oData.Timeline==0)
					        		{
					        			return '<span>'+oData.originalTimeline+'</span>';
					        		}
					        		else
					        		{
					        			return '<span>'+dif+'</span>' ;	
					        		}
					        	}
					        }
				    	},
				        { data: 'appConfDate' },
				        { data: 'appID' ,
				        "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
				            $(nTd).html("<a class='btn btn-info btn-sm' href='"+applink+oData.appID+"'>"+"view"+"</a>");
				        	},
				        }
				    ]
				    //parseInt(oData.originalTimeline)-parseInt(diff)
    			});
}
$('#sub-menu-btn1').prop('checked', true);

</script> 
<style type="text/css">
	.label_css
	{
		margin-bottom: 20px;padding-left: 100px;width: 165px;height: 26px;line-height: 30px;
	}
	.selection_box
	{
		height: 35px;width: 15%;border: 1px solid #E4E4E4;cursor: pointer;
	}
</style>
<!--<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
