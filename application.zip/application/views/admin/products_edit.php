<?php 
 foreach($pro_det as $prod_det){ 
    ?> 



<form action="<?php echo base_url();?>admin/masters/update" method="post">
                                <input type="text" required name="pro_name" value="<?php echo $prod_det->name; ?>" placeholder="Enter Product Name">

                                  <input type="hidden" required name="pro_id" value="<?php echo $prod_det->id; ?>">

                                <textarea  required name="pro_desc" style="height: 144px;" placeholder="Enter Product Description"><?php echo $prod_det->short_description; ?></textarea>
                                <textarea required name="pro_general"  style="height: 144px;" placeholder="Enter General Criteria"><?php echo $prod_det->terms_conditions; ?></textarea>
                                 <select name="status" id="status"required>
 <option value="">Select Status</option>
 <option value="1" <?php if($prod_det->isactive==1){echo "selected";}?> >Active</option>
 <option value="0" <?php if($prod_det->isactive==0){echo "selected";}?> >In Active</option>
                 
                  
              </select>
                                <input type="submit" value="Update">
                            </form>

                            <?php
                        }
                        ?>