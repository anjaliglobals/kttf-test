<?php include 'include/header.php';?>

		<div class="admin-report-options">
			<div class="admin-certificate">
				<div class="certificate-image" style="height: 150px;">
					<i class="fa fa-id-card-o" style="font-size:90px;"></i>
				</div>
				<div class="certificate-text">
					<span class="issued">Certificate Issued</span><span class="issued-count">30</span>
				</div>
				<div class="certificate-more">
					<h6>More Info</h6>
				</div>				
			</div>
			<div class="admin-payment">
				<div class="payment-image" style="height: 150px;">
					<i class="fa fa-money" style="font-size:90px;"></i>
				</div>
				<div class="payment-text">
					<span class="issued">Payment Received</span><span class="issued-count">20</span>
				</div>
				<div class="payment-more">
					<h6>More Info</h6>
				</div>				
			</div>
			<div class="admin-renew-pending">
				<div class="renew-pending-image" style="height: 150px;">
					<i class="fa fa-building-o" style="font-size:90px;"></i>
				</div>
				<div class="renew-pending-text">
					<span class="issued">Renewal Pending</span><span class="issued-count">10</span>
				</div>
				<div class="renew-pending-more">
					<h6>More Info</h6>
				</div>				
			</div>
			<div class="admin-field-verify">
				<div class="field-verify-image" style="height: 150px;">
					<i class="fa fa-building-o" style="font-size:90px;"></i>
				</div>
				<div class="field-verify-text">
					<span class="issued">Field Verification In Progress</span><span class="issued-count">12</span>
				</div>
				<div class="field-verify-more">
					<h6>More Info</h6>
				</div>				
			</div>
			<div class="admin-renewal">
				<div class="renewal-image" style="height: 150px;">
					<i class="fa fa-refresh" style="font-size:90px;"></i>
				</div>
				<div class="renewal-text">
					<span class="issued">Renewal</span><span class="issued-count">30</span>
				</div>
				<div class="renewal-more">
					<h6>More Info</h6>
				</div>				
			</div>
			<div class="admin-total-app">
				<div class="total-app-image" style="height: 150px;">
					<i class="fa fa-download" style="font-size:90px;"></i>
				</div>
				<div class="total-app-text">
					<span class="issued">Total Application Received</span><span class="issued-count">05</span>
				</div>
				<div class="total-app-more">
					<h6>More Info</h6>
				</div>				
			</div>
			<div class="admin-total-app-rej">
				<div class="total-app-rej-image" style="height: 150px;">
					<i class="fa fa-file-excel-o" style="font-size:90px;"></i>
				</div>
				<div class="total-app-rej-text">
					<span class="issued">Total Application Rejected</span><span class="issued-count">01</span>
				</div>
				<div class="total-app-rej-more">
					<h6>More Info</h6>
				</div>				
			</div>
		</div>
		
<?php include 'include/footer.php';?>