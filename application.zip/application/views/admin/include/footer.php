
	</div>

<?php foreach ($arr_js as $js): ?>
		<script type="text/javascript" src="<?php echo base_url().'theme/'.$js;?>"></script>	
<?php endforeach;?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />	
</body>
</html>
