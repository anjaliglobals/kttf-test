<html>
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- <link rel="stylesheet" href="<?php echo base_url();?>theme/admin/css/style.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>theme/admin/css/DataTables/jquery.dataTables.min.css"> -->


    <?php 
    	foreach ($arr_css as $css): ?>
    		<link rel="stylesheet" href="<?php echo base_url().'theme/'.$css;?>">
    <?php
    	endforeach;
    ?>


    <title>KTTF</title>
  </head>
<body>
	<div class="application-logo-header">
		<div class="kttf-logo">
			<img src="<?php echo base_url();?>theme/admin/images/ka-logo.jpg"> Karnataka Tourism Trade Facilitation
		</div>
<!-- 		<div class="notification-area">
			<i class="fa fa-bell" aria-hidden="true"><span class="notification-alert">2</span></i>
		</div> -->
 		<div class="login-area">
			<span><?php echo $this->admName;?></span>
		</div> 
	</div>
	<div class="admin-dashboard">
		<div class="admin-menu">			
			<header class="header">
			  <a class="user-profile">Profile</a>
			  <input class="menu-btn" type="checkbox" id="menu-btn" />
			  <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
			  <ul class="menu">
				<li><a href="<?php echo base_url().'admin/dashboard';?>"<?php echo ($this->menu == 'Dashboard') ? ' class="active"': ''; ?>>Dashboard</a></li>				
				<li class="has-child">
							<input class="sub-menu-btn1" type="checkbox" id="sub-menu-btn1">	  
							<label class="sub-menu-icon1" for="sub-menu-btn1">Applications</label>
								<ul class="sub-menu">
									<li><a href="<?php echo base_url().'admin/application';?>"<?php echo ($this->menu == 'Application') ? ' class="active"': ''; ?>>1. Pending</a></li>
									<li><a href="<?php echo base_url().'admin/application/application_summary';?>"<?php echo ($this->menu == 'Summary') ? ' class="active"': ''; ?>>2. Summary</a></li>
									<li><a href="<?php echo base_url().'admin/application/application_closed';?>"<?php echo ($this->menu == 'Closed') ? ' class="active"': ''; ?>>3. Closed</a></li>
									<li><a href="<?php echo base_url().'admin/application/application_rejected';?>"<?php echo ($this->menu == 'Rejected') ? ' class="active"': ''; ?>>4. Rejected</a></li>
									
								</ul>
						</li>	
				<!--li><a href="#">Reports</a></li-->	
				<!--<li><a href="#">Send Email / SMS</a></li>-->
			<?php if($this->admDesig == 3):  ?>
				<li class="has-child">
					<input class="sub-menu-btn" type="checkbox" id="sub-menu-btn" />	  
					<label class="sub-menu-icon" for="sub-menu-btn">Master</label>
					<ul class="sub-menu">
						<li><a href="<?php echo base_url().'admin/masters/product_view';?>"<?php echo ($this->menu == 'Product') ? ' class="active"': ''; ?>">Manage Products</a></li>
						<li><a href="<?php echo base_url().'admin/masters/user_view';?>"<?php echo ($this->menu == 'User') ? ' class="active"': ''; ?>">User Management</a></li>	
						<li><a href="<?php echo base_url().'admin/masters/logs';?>"<?php echo ($this->menu == 'Logs') ? ' class="active"': ''; ?>">Logs</a></li>	
					</ul>
				</li>
			<?php endif; ?>
				<li><a href="<?php echo base_url().'admin/login/logout';?>">Logout</a></li>				
			  </ul>
			</header>
		</div>
