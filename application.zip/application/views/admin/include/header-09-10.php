<html>
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!-- <link rel="stylesheet" href="<?php echo base_url();?>theme/admin/css/style.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>theme/admin/css/DataTables/jquery.dataTables.min.css"> -->


    <?php 
    	foreach ($arr_css as $css): ?>
    		<link rel="stylesheet" href="<?php echo base_url().'theme/'.$css;?>">
    <?php
    	endforeach;
    ?>


    <title>KTTF</title>
  </head>
<body>
	<div class="application-logo-header">
		<div class="kttf-logo">
			<img src="<?php echo base_url();?>theme/admin/images/ka-logo.jpg"> Karnataka Tourism Trade Facilitation
		</div>
<!-- 		<div class="notification-area">
			<i class="fa fa-bell" aria-hidden="true"><span class="notification-alert">2</span></i>
		</div> -->
	</div>
	<div class="admin-dashboard">
		<div class="admin-menu">
			<!-- <a href="#" class="active">Dashboard</a>
			<a href="#">Manage Products</a>
			<a href="#">Applications</a>
			<a href="#">Reports</a>
			<a href="#">Send Email / SMS</a>
			<a href="#">Logout</a> -->
			<header class="header">
			  <a class="user-profile">Profile</a>
			  <input class="menu-btn" type="checkbox" id="menu-btn" />
			  <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
			  <ul class="menu">
				<li><a href="<?php echo base_url().'admin/dashboard';?>"<?php echo ($this->menu == 'Dashboard') ? ' class="active"': ''; ?>>Dashboard</a></li>	
				<li><a href="<?php echo base_url().'admin/masters/product_view';?>"<?php echo ($this->menu == 'Product') ? ' class="active"': ''; ?>">Manage Products</a></li>	
				<li><a href="<?php echo base_url().'admin/application';?>"<?php echo ($this->menu == 'Application') ? ' class="active"': ''; ?>>Application</a></li>	
				<li><a href="#">Reports</a></li>	
				<li><a href="#">Send Email / SMS</a></li>	
				<li><a href="#">Logout</a></li>				
			  </ul>
			</header>
		</div>
