<?php include 'include/header.php';?>
<div class="application">
			<div class="alli-dashboard">		
				<section class="wizard-section">
					<div class="no-gutters">			
						<div class="col-lg-12 col-md-12">
							<div class="form-wizard">
				<!-- 		 <?php 
						 // print_r($application);
						 ?>  -->
							<?php if($application->product_id==7){?>
								<h3>KTTF Application for Guest House</h3>
							<?php }?>
							
									<div class="form-wizard-header">
										<ul class="list-unstyled form-wizard-steps clearfix">
											<li class="active"><span>1</span><span class="verify">General Verification</span></li>
											<li><span>2</span><span class="verify">Field/Document Verification</span></li>
											<li><span>3</span><span class="verify">Approve To Next Stage</span></li>
										</ul>
									</div>									 
									<div class="agent-form-file-view1">
										<?php if($application->licence_issued_date != NULL)
										{ ?>
											<a href="<?php echo base_url();?>admin/application/certificate/<?php echo $application->application_id;?>" target="_blank">View Certificate</a>
										<?php } ?>
									</div>
									<div class="agent-form-file-view1">
										<?php if($application->is_confirmed == 1)
										{ ?>
											<a href="<?php echo base_url();?>admin/application/pay_det/<?php echo $application->id;?>" target="_blank">Payment Details</a>
										<?php } ?>
									</div>
									<fieldset class="wizard-fieldset general-verify show">

<?php if($access['workflow'] == 1){
if($jdcomm[0]->subject=='Application Resent for Clarification' and $jdcomm[0]->crtname=='JD'){

	?>
										<div class="payment-level">
											<div style="overflow-x:auto">
												<table class="payment-details">
													<tbody>	
														<tr><th colspan="5">Comments</th></tr>
														<tr class="table-head">
															<th>Subject</th>
															<th>Comments</th>
															<th>Comments by</th>
															<th>Date</th>
															
														</tr>
															
														<tr>
										<td><?php echo $jdcomm[0]->subject; ?></td>
										<td><?php echo $jdcomm[0]->inter_comm; ?></td>
										<td><?php echo $jdcomm[0]->crtname; ?></td>
										<td><?php echo $jdcomm[0]->crtdate; ?></td>
														</tr>
														
												
													<tbody>	
												</table>
											</div>
										</div>
<?php
}
}
?>
                                    <!-- 
										<div class="app-form-field">
											<div class="form-text">
												<p>Category Type / ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆಮಾಡಿ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="applicant_name" readonly value="<?php echo $application->category_type ;?>" style="text-align:;">						
											</div>									
										</div> -->



											<div class="app-form-field">
											<div class="form-text">
												<p>Trade Name / ವ್ಯಾಪಾರ ಹೆಸರು<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="applicant_name" readonly value="<?php echo $application->applicant_name ;?>" style="text-align:;">						
											</div>									
										</div>
											<div class="app-form-field">
											<div class="form-text">
												<p>Entity Name  /  ಘಟಕದ ಹೆಸರು<sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="applicant_name" readonly value="<?php echo $application->entity_name ;?>" style="text-align:;">						
											</div>									
										</div>

<div class="app-form-field">
											<div class="form-text">
												<p>In which name you need certificate to be printed / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ನಿಮಗೆ ಮುದ್ರಿಸಲು ಪ್ರಮಾಣಪತ್ರ ಬೇಕು <sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="applicant_name" readonly value="<?php if($application->certificate_name==1){echo "Entity Name";}else if ($application->certificate_name==2){echo "Trade Name";}else{echo ""; }?>" style="text-align:;">						
											</div>									
										</div>

										<div class="app-form-field">
											<div class="form-text">
												<p>Entity Type/ಸಂಸ್ಥೆಯ ಪ್ರಕಾರ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_type_id" value="<?php echo $organization[$application->org_type_id] ;?>" readonly>							
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Date of Registration/Incorporation of the Entity<br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Shops and Establishment Act)/ಸಂಸ್ಥೆಯ ನೋಂದಣಿ / ಸಂಯೋಜನೆಯ ದಿನಾಂಕ (ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956 /2013 ಅಥವಾ ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ 
ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ ಪ್ರಕಾರ) <sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_commencement_date" value="<?php if(!empty($application->org_commencement_date)){echo date('d-m-Y',strtotime($application->org_commencement_date));}else{} ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Date of issue of Certificate/License from Municipality/Corporation/Panchayat <sup>*</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_license_date " value="<?php if(!empty($application->org_license_date )){echo date('d-m-Y',strtotime($application->org_license_date));}else{} ?>" readonly >
											</div>									
										</div>


										
										<div class="app-form-field">
											<div class="form-text">
												<p>Date of issue of Trade License/ ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನೀಡಿದ ದಿನಾಂಕ <sup> * </sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="trade_date" value="<?php if(!empty($application->trade_lic_date)){echo date('d-m-Y',strtotime($application->trade_lic_date));}else{} ?>" readonly >
											</div>									
										</div>
										
										
										<div class="app-form-field">
											<div class="form-text">
												<p>Name of Proprietor / Directors / Partners/ಮಾಲೀಕರು / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಹೆಸರು  <sup> * </sup></p>
												<!-- Name of Proprietor / Directors / Partners/ಮಾಲೀಕರ / ನಿರ್ದೇಶಕರ / ಪಾಲುದಾರರ ಹೆಸರು  -->
												
											</div>
											<div class="form-input">
												<input type="text" name="proprietor_name" value="<?php echo $application->proprietor_name ;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>GST Identification Number / ಜಿ ಎಸ್ ಟಿ ಗುರುತಿನ ಸಂಖ್ಯೆ <sup> * </sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_name" value="<?php echo $application->gst_number ;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>PAN Number / ಪ್ಯಾನ್ ಸಂಖ್ಯೆ <sup>*</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="org_name" value="<?php echo $application->pan_number ;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು URL</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_name" value="<?php echo $application->website_name ;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Official email id of the Entity / ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ</p>
												<!-- <sup>*</sup> -->
											</div>
											<div class="form-input">
												<input type="text" name="org_name" value="<?php echo $application->official_email ;?>" readonly>
											</div>									
										</div>

										<div class="app-form-field">
											<div class="form-text">
												<p>Whether the member of Karnataka Tourism Society (KTS)? / ಯಾವುದೇ ಮಾನ್ಯತೆ ಪಡೆದ ಹೋಟೆಲ್ ಮತ್ತು ರೆಸ್ಟೋರೆಂಟ್ ಅಸೋಸಿಯೇಶನ್‌ನ ಸದಸ್ಯರಾಗಿದ್ದೀರಾ?<sup> * </sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="central_gov_approved" value="<?php echo $application->member_kts ;?>">
										<?php
										if($application->member_kts=="yes"){
										?>
											<div class="field-download">
												<a href="<?php echo base_url().'upload/img_member_kts/'.$application->img_member_kts;?>" target="_blank"><i class="fa fa-download"></i></a>
											</div>								
											<?php
											}
											?>										
											</div>

<!-- 
										<div class="app-form-field">
											<div class="form-text">
												<p>Whether a Member of any recognized Guest House Association? / ಯಾವುದೇ ಮಾನ್ಯತೆ ಪಡೆದ ಹೋಟೆಲ್ ಮತ್ತು ರೆಸ್ಟೋರೆಂಟ್ ಅಸೋಸಿಯೇಶನ್‌ನ ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="member_recognised_trade" value="<?php echo $application->member_recognised_trade ; if($application->member_recognised_trade=="Others"){ echo ' - '.$application->member_recognised_trade_other ; } ?>" readonly >
											</div>									
										</div> -->
										
									
										

										<div class="form-heading">
											<h4>Registered Office Address / ನೋಂದಾಯಿತ ಕಚೇರಿ ವಿಳಾಸ </h4>

											<p>[Applicant to mention only the details of office address in Karnataka for which registration under Department of Tourism is required] / [ ಅರ್ಜಿದಾರರು  ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿಗೆ ಅಗತ್ಯವಿರುವ ಕರ್ನಾಟಕದಲ್ಲಿನ ಕಚೇರಿ ವಿಳಾಸದ ವಿವರಗಳನ್ನು ಮಾತ್ರ ನಮೂದಿಸಬೇಕು] </p>
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>State / ಜ್ಯ  <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_district_id" value="<?php echo $this->db->get_where('m_states', array('id' => $application->org_state))->row()->name; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 1 / ವಿಳಾಸ ಸಾಲು 1 <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add1" value="<?php echo $application->org_loc_add1 ;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 2 / ವಿಳಾಸ ಸಾಲು 2  </p>
												<!-- <sup> *</sup> -->
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add2" value="<?php echo $application->org_loc_add2;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>District / ಜಿಲ್ಲೆ  <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_district_id" value="<?php echo $this->db->get_where('m_district', array('id' => $application->org_loc_district_id))->row()->name; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Taluk / ತಾಲೂಕು  <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_state" value="<?php echo $this->db->get_where('m_taluk', array('id' => $application->org_loc_taluk_id))->row()->name; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>City / Town / Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_country" value="<?php echo $application->org_loc_city;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್   <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_country" value="<?php echo $application->org_loc_landmark;?>" readonly >
											</div>									
										</div>
										
										<div class="app-form-field">
											<div class="form-text">
												<p>Pincode /ಪಿನ್‌ಕೋಡ್ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_pincode_id" value="<?php echo $application->org_loc_pincode_id;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_mobile" value="<?php echo $application->org_loc_mobile;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Telephone Number / ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_telephone" value="<?php echo $application->org_loc_telephone;?>" readonly>
											</div>									
										</div>
<!-- 										<div class="app-form-field">
											<div class="form-text">
												<p>Total Built Area ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ)   <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_total_build_sqft" value="<?php echo $application->org_total_build_sqft;?>" readonly>
			
											</div>										
										</div> -->

													<div class="form-heading">
											<h4>Guest House Unit Details</h4>
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Name of Guest House / ಅತಿಥಿ ಗೃಹದ ಹೆಸರು <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="guest_name" value="<?php echo $application->guest_name ;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Is the Guest House star classified under Ministry of Tourism, Government of India /  ಭಾರತ ಸರ್ಕಾರ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಅತಿಥಿ ಗೃಹದ ಸ್ಟಾರ್ ವರ್ಗೀಕರಿಸಲಾಗಿದೆಯೇ </p>
												 <sup> *</sup>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add2" value="<?php echo $application->central_gov_approved;?>" readonly >
												<?php
										if($application->central_gov_approved=="Yes"){
										?>
										
											<div class="field-download">
												<a href="<?php echo base_url().'upload/img_MoT/'.$application->img_MoT;?>" target="_blank"><i class="fa fa-download"></i></a>
											</div>								
											<?php
											}
											?>

											</div>									
										</div>


										<?php
										if($application->central_gov_approved=="Yes"){
										?>	
										<!-- <div class="app-form-field">
											<div class="form-text">
												<p>Category of the Guest House (only applicable, if the Guest House is classified under Ministry of Tourism, Government of India) /  "ಅತಿಥಿ ಗೃಹದ ವರ್ಗ
(ಅತಿಥಿ ಗೃಹದ ಅನ್ನು ಭಾರತ ಸರ್ಕಾರ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ವರ್ಗೀಕರಿಸಲ್ಪಟ್ಟಿದ್ದರೇ ಮಾತ್ರ ಅನ್ವಯವಾಗುತ್ತದೆ) <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="cat_restaurant" value="<?php echo $application->cat_restaurant;?> Star" readonly >
											</div>									
										</div> -->

										<?php
											}
											?>

										<div class="app-form-field">
											<div class="form-text">
												<p>Total No. of Rooms in the Guest House / ಹೋಟೆಲ್/ರಸಾರ್ಟ್ ಒಟ್ಟು  ಕೋಣೆಗಳ ಸಂಖ್ಯೆ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="no_rooms" value="<?php echo $application->no_rooms;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Total No. of Beds in the Guest House /  ಹೋಟೆಲ್/ರಸಾರ್ಟ್ ಒಟ್ಟು  ಬೆಡ್ ಗಳ ಸಂಖ್ಯೆ<sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="no_beds" value="<?php echo $application->no_bed;?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p style="height:100px;">Type of Accommodation Provided /ಒದಗಿಸಲಾಗುವ ವಸತಿ ಪ್ರಕಾರ <sup> *</sup></p>
											</div>
											<div class="field-comment-nopadd">
												<p class="non-edit-fields"><?php $acc = $this->db->get_where('hotel_accommodation', array('app_id'=>$application->id))->result();
												$cou = count($acc);

														for($i=0;$i<$cou;$i++){
														if($acc[$i]->accommodation_type=='other')
															{
$accpo[] = $acc[$i]->accommodation_type.' - '.$acc[$i]->other_facility;
															}
															else{
	 														$accp[] = $acc[$i]->accommodation_type;
															}
															
															}
															if(empty($accpo)){
													$accpa = $accp;
															}
															else{
														$accpa = array_merge($accp,$accpo);
															}
															
															echo implode(', ',$accpa);

												?></p>
											</div>									
										</div>
										
										<div class="app-form-field">
											<div class="form-text">
												<p style="height:100px;">Facilities Available in the Guest House /  ಹೋಟೆಲ್ ಮತ್ತು ರೆಸಾರ್ಟ್ ನಲ್ಲಿ ಲಭ್ಯವಿರುವ ಸೌಲಭ್ಯಗಳು <sup> *</sup></p>
											</div>
											<div class="field-comment-nopadd">
												

												<p class="non-edit-fields"><?php $acc = $this->db->get_where('hotel_facility', array('app_id'=>$application->id))->result();
												$cou = count($acc);


															for($i=0;$i<$cou;$i++){
														if($acc[$i]->facility_type=='other')
															{
$accpof[] = $acc[$i]->facility_type.' - '.$acc[$i]->other_facility;
															}
															else{
	 														$accpf[] = $acc[$i]->facility_type;
															}
															
															}
															if(empty($accpof)){
													$accpaf = $accpf;
															}
															else{
												$accpaf = array_merge($accpf,$accpof);
															}
															
															echo implode(', ',$accpaf);
													

												?></p>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Name of the Owner/ Manager of the Guest House / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ಮಾಲೀಕರ/ ಮ್ಯಾನೇಜರ್ ಹೆಸರು <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="owner_name" value="<?php echo $application->owner_name;?>" readonly>
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ್ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="owner_mobile" value="<?php echo $application->owner_mobile;?>" readonly>
											</div>									
										</div>
										
										<div class="app-form-field">
											<div class="form-text">
												<p>Email Id of the Owner/Manager of the Guest House / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ಮಾಲೀಕರು/ ಮ್ಯಾನೇಜರ್ ಇಮೇಲ್ ಐಡಿ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="owner_email" value="<?php echo $application->owner_email;?>" readonly>
			
											</div>										
										</div>

<div class="app-form-field">
											<div class="form-text">
												<p>Number of Permanent Employees /  ಖಾಯಂ ನೌಕರರ ಸಂಖ್ಯೆ<sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="no_beds" value="<?php echo $application->permanent_emp_male;?> <?php if(!empty($application->permanent_emp_male)){echo 'Male';} ?>     <?php echo $application->permanent_emp_female;?> <?php if(!empty($application->permanent_emp_female)){echo 'Female';} ?> " readonly > 
											</div>									
										</div>

										<div class="app-form-field">
											<div class="form-text">
												<p>Number of Outsourced Employees /  ಹೊರಗುತ್ತಿಗೆ ನೌಕರರ ಸಂಖ್ಯೆ<sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="no_beds" value="<?php echo $application->outsourced_emp_male;?> <?php if(!empty($application->outsourced_emp_male)){echo 'Male';} ?>     <?php echo $application->outsourced_emp_female;?> <?php if(!empty($application->outsourced_emp_female)){echo 'Female';} ?>" readonly > 
											</div>									
										</div>

								
										<div class="form-heading">
											<h4>Guest House Address / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ವಿಳಾಸ  </h4>
											<p>[Applicant to mention only the details of Guest House address in Karnataka for which registration under Department of Tourism is required] / [ಅರ್ಜಿದಾರರು ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಅಗತ್ಯವಿರುವ ಕರ್ನಾಟಕದಲ್ಲಿನ  ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ವಿಳಾಸದ ವಿವರಗಳನ್ನು ಮಾತ್ರ ನಮೂದಿಸಬೇಕು]</p>
										</div>
										
                         <?php 
							// print_r($addressdet);
						 	$counter = 1;
						    foreach($addressdet as $address_det){ 
						?>   
					<div class="app-form-field">
											<div class="form-text">
												<p>Address 1 / ವಿಳಾಸ ಸಾಲು 1 <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add1" value="<?php echo $address_det->other_off_addr1; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Address 2 / ವಿಳಾಸ ಸಾಲು 2  </p>
												<!-- <sup> *</sup> -->
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_add2" value="<?php echo $address_det->other_off_addr2; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>District / ಜಿಲ್ಲೆ  <sup> *</sup> </p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_district_id" value="<?php echo $this->db->get_where('m_district', array('id' => $address_det->other_off_district_id))->row()->name; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Taluk / ತಾಲೂಕು <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_state" value="<?php echo $this->db->get_where('m_taluk', array('id' => $address_det->other_off_taluk))->row()->name; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>City / Town / Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_country" value="<?php echo $address_det->other_off_city; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್  <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_country" value="<?php echo $address_det->org_landmark; ?>" readonly >
											</div>									
										</div>
										
										<div class="app-form-field">
											<div class="form-text">
												<p>Pincode /ಪಿನ್‌ಕೋಡ್ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_loc_pincode_id" value="<?php echo $address_det->other_off_pincode_id; ?>" readonly >
											</div>									
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ್ <sup> *</sup></p>
											</div>
<div class="form-input">
												<input type="text" name="org_loc_mobile" value="<?php echo $address_det->other_off_contact; ?>" readonly>
											</div>									
										</div>

<div class="app-form-field">
											<div class="form-text">
												<p>Telephone number / ದೂರವಾಣಿ ಸಂಖ್ಯೆ <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="guest_mbl_no" value="<?php echo $application->org_loc_telephone;?>" readonly>
			
											</div>										
										</div>
										<div class="app-form-field">
											<div class="form-text">
												<p>Official Email Id of the Guest House / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ * <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="email_id_guest" value="<?php echo $address_det->other_email; ?>" readonly>
			
											</div>										
										</div>

										<?php 
						}
						?>


										<div class="app-form-field">
											<div class="form-text">
												<p>Total Built up Area of the Guest House (in Sq. Ft) / ಅತಿಥಿ ಗೃಹದ‌ ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ) <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="total_guest_build_area" value="<?php echo $application->total_guest_build_area;?>" readonly>
			
											</div>										
										</div>
										<!-- <div class="app-form-field">
											<div class="form-text">
												<p>Total Built Area ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ)   <sup> *</sup></p>
											</div>
											<div class="form-input">
												<input type="text" name="org_total_build_sqft" value="<?php echo $application->org_total_build_sqft;?>" readonly>
			
											</div>										
										</div> -->


										
									
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-next-btn float-right">Next/ಮುಂದೆ</a>
										</div>
									</fieldset>

									
									<!-- --------WF 1 Payment Approval---------------- -->
									<?php if($access['workflow'] == 1 && $access['admPrivilege']):?>
									<?php
									//print_r($save_draft);
									?>									
									<fieldset class="wizard-fieldset comment-section" id="comment-sec">
										<form method="POST" action="<?php echo base_url().'admin/application/application_update';?>" id="formSavedraft" enctype="multipart/form-data">

										<input type="hidden" id="application_id" name="application_id" value="<?php echo $application->id;?>">
										<input type="hidden" name="document_verification" value="true">
										<p style='color:Red'>Check the Documents & provide the feedback./ದಾಖಲೆಗಳನ್ನು ಪರಿಶೀಲಿಸಿ ಮತ್ತು ಪ್ರತಿಕ್ರಿಯೆಯನ್ನು ಒದಗಿಸಿ </p>
										<!-- prabha -->
										

										<input type="text" style="display:none;" name="save_draft_id" value="<?php if($save_draft->isdraft==1){echo $save_draft->id;}else{} ?>">
										<input type="text" style="display:none;" name="isactivenot" value="<?php echo $save_draft->isactive;?>">
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>1. Registration/Incorporation Certificate of the Entity / ಸಂಸ್ಥೆಯ ನೋಂದಣಿ/ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup><p style="font-size:12px;">Documentary proof to be uploaded in compliance with the any one of the below act/ ಕೆಳಗಿನ ಯಾವುದೇ ಕಾಯಿದೆಯ ಅನುಸಾರವಾಗಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ದಾಖಲಾತಿ ಪುರಾವೆ:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or / ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು
ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ 
ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ

								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / -ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ 
ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ.</p></p>
											</div>
											<div class="field-download">
												<a href="<?php echo base_url().'upload/img_registration_certificate/'.$application->img_registration_certificate;?>" target="_blank"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='reg-gov' class="reg_govrn" name='img_registration_certificate' type='radio' <?php if($save_draft->reg_certificate=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='reg-gov1' name='img_registration_certificate' type='radio' <?php if($save_draft->reg_certificate=="No"){echo "checked";}?> value="No" />  No
											</div>
											<div class="field-comment-sec" <?php if($save_draft->reg_certificate=="No"){echo 'style="display:block;"';}?> > 
												<textarea class="condition-comment" name="img_registration_certificate_details"<?php if($save_draft->reg_certificate=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?> ><?php if($save_draft->reg_certificate=="No"){echo $save_draft->reg_certificate_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>





									<!-- 	<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>2. Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ವಾಣಿಜ್ಯ ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ, 1961 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ (ಹೋಟೆಲ್/ರೆಸಾರ್ಟಗಳಿಗಾಗಿ)<sup>*</sup></p>
											</div>
											<div class="field-download">
												<a href="<?php echo base_url().'upload/img_certificate_shops/'.$application->img_certificate_shops;?>" target="_blank"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='reg-gov-shops' class="reg_govrn_shops" name='img_certificate_shops' type='radio' <?php if($save_draft->img_certificate_shops=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='reg-gov1-shops' name='img_certificate_shops' type='radio' <?php if($save_draft->img_certificate_shops=="No"){echo "checked";}?> value="No" />  No
											</div>
											<div class="field-comment-sec" <?php if($save_draft->img_certificate_shops=="No"){echo 'style="display:block;"';}?> > 
												<textarea class="condition-comment" name="img_certificate_shops_details"<?php if($save_draft->img_certificate_shops=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?> ><?php if($save_draft->img_certificate_shops=="No"){echo $save_draft->img_certificate_shops_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div> -->



										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>2. Address Proof of the Guest House / "ಹೋಟೆಲ್ ಮತ್ತು ರೆಸಾರ್ಟ್ ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></p><p style="font-size:12px;">Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt. / ಇತ್ತೀಚಿನ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಅನಿಲ/ನೀರಿನ ಬಿಲ್ ಸೇರಿದಂತೆ ಆಸ್ತಿ ಅಥವಾ ಪುರಸಭೆಯ ತೆರಿಗೆ ರಶೀದಿ. ಈ ಬಿಲ್ ಮತ್ತು ರಶೀದಿಗಳು ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_bank_reference/'.$application->img_bank_reference;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='ref-let' class="ref_let" name='img_bank_reference' type='radio'  <?php if($save_draft->bank_reference=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='ref-let1' name='img_bank_reference'  <?php if($save_draft->bank_reference=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->bank_reference=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_bank_reference_details" <?php if($save_draft->bank_reference=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->bank_reference=="No"){echo $save_draft->bank_reference_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>



										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>3. Details of Guest House Premises / ಅತಿಥಿ ಗೃಹದ ಸ್ಥಳದ ವಿವರಗಳು<sup>*</sup></p>
												<p style="font-size:12px;">Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / (ಸ್ಥಳವನ್ನು ಬಾಡಿಗೆ ಪಡೆದ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ ಪತ್ರ. 
ಸ್ಥಳವು ಸ್ವಂತದ್ದಾಗಿದ್ದರೇ, ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ ಪತ್ರ ಲಗತ್ತಿಸಬೇಕು)</p>
											</div>
											<div class="field-download-padd-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_off_premises/'.$application->img_off_premises;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_off_premises' class="cert"  <?php if($save_draft->off_premises=="Yes"){echo "checked";}?> name='img_off_premises' type='radio' value="Yes" />  Yes
												
												<input id='img_off_premises1' name='img_off_premises'  <?php if($save_draft->off_premises=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->off_premises=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_off_premises_details" <?php if($save_draft->off_premises=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->off_premises=="No"){echo $save_draft->off_premises_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>4. Photograph of Guest House Interior/"ಅತಿಥಿ ಗೃಹದ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
												<p style="font-size:12px;">(All the mandatory features to be captured including the name of the Guest House) / (ಅತಿಥಿ ಗೃಹದ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು) </p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_off_buil_interior/'.$application->img_off_buil_interior;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='photo-interior' class="cert" name='img_off_buil_interior' type='radio'  <?php if($save_draft->off_interior=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='photo-interior1' name='img_off_buil_interior'  <?php if($save_draft->off_interior=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->off_interior=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_off_buil_interior_details" <?php if($save_draft->off_interior=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->off_interior=="No"){echo $save_draft->off_interior_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	


										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>5. Photograph of Guest House Exterior/ "ಅತಿಥಿ ಗೃಹದ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
												<p style="font-size:12px;">(All the mandatory features to be captured including the name of the Guest House) / (ಅತಿಥಿ ಗೃಹದ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_off_buil_exterior/'.$application->img_off_buil_exterior;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='photo-build' class="cert" name='img_off_buil_exterior' type='radio'  <?php if($save_draft->off_exterior=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='photo-build1' name='img_off_buil_exterior'  <?php if($save_draft->off_exterior=="No"){echo "checked";}?> type='radio'value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->off_exterior=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_off_buil_exterior_details" <?php if($save_draft->off_exterior=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->off_exterior=="No"){echo $save_draft->off_exterior_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>


											<!--div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>9. Copy of Trade License / ವ್ಟ್ರೇಡ್ ಪರವಾನಗಿ ಪ್ರತಿ  <sup>*</sup></p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_trade_lic/'.$application->img_trade_lic;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_trade_lich' class="cert" name='img_trade_lic' type='radio'  <?php if($save_draft->img_trade_lic=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='img_trade_lic1h' name='img_trade_lic'  <?php if($save_draft->img_trade_lic=="No"){echo "checked";}?> type='radio'value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_trade_lic=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_trade_lic_details" <?php if($save_draft->img_trade_lic=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_trade_lic=="No"){echo $save_draft->img_trade_lic_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div-->

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>6. Sanctioned Building Plans/Occupancy Certificate / ಮಂಜೂರಾದ ಕಟ್ಟಡ ಯೋಜನೆಗಳು/ಸ್ವಾಧೀನ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_occupancy_certificate/'.$application->img_occupancy_certificate;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_occupancy_certificateh' class="cert"  <?php if($save_draft->img_occupancy_certificate=="Yes"){echo "checked";}?> name='img_occupancy_certificate' type='radio' value="Yes" />  Yes
												
												<input id='img_occupancy_certificate1h' name='img_occupancy_certificate'  <?php if($save_draft->img_occupancy_certificate=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_occupancy_certificate=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_occupancy_certificate_details" <?php if($save_draft->img_occupancy_certificate=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_occupancy_certificate=="No"){echo $save_draft->img_occupancy_certificate_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>7. Copy of GST Registration Certificate/GST ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_gst_regis/'.$application->img_gst_regis;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='gst' class="cert" name='img_gst_regis'  <?php if($save_draft->img_gst_regis=="Yes"){echo "checked";}?> type='radio' value="Yes" />  Yes
												
												<input id='gst1' name='img_gst_regis'  <?php if($save_draft->img_gst_regis=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div id="staff" class="field-comment-sec"  <?php if($save_draft->img_gst_regis=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_gst_regis_details" <?php if($save_draft->img_gst_regis=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_gst_regis=="No"){echo $save_draft->img_gst_regis_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<!-- <div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>9. Copy of PAN/ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ<sup>*</sup></p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_pan_copy/'.$application->img_pan_copy;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='copy_pan' class="cert" name='img_pan_copy'  <?php if($save_draft->img_pan_copy=="Yes"){echo "checked";}?> type='radio' value="Yes" />  Yes
												
												<input id='copy_pan1' name='img_pan_copy'  <?php if($save_draft->img_pan_copy=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div id="staff" class="field-comment-sec"  <?php if($save_draft->img_pan_copy=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_pan_copy_details" <?php if($save_draft->img_pan_copy=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_pan_copy=="No"){echo $save_draft->img_pan_copy_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div> -->
									
																				
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>8. Certificate from FSSAI / FSSAI ನಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_fssai_certificate/'.$application->img_fssai_certificate;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_fssai_certificateh' class="cert"  <?php if($save_draft->img_fssai_certificate=="Yes"){echo "checked";}?> name='img_fssai_certificate' type='radio' value="Yes" />  Yes
												
												<input id='img_fssai_certificate1h' name='img_fssai_certificate'  <?php if($save_draft->img_fssai_certificate=="No"){echo "checked";}?> type='radio'value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_fssai_certificate=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_fssai_certificate_details" <?php if($save_draft->img_fssai_certificate=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_fssai_certificate=="No"){echo $save_draft->img_fssai_certificate_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>9. No-Objection Certificate from Fire department / ಅಗ್ನಿಶಾಮಕ ಇಲಾಖೆಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ </p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_noobj_certificate/'.$application->img_noobj_certificate;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_noobj_certificateh' class="cert"  <?php if($save_draft->img_noobj_certificate=="Yes"){echo "checked";}?> name='img_noobj_certificate' type='radio' value="Yes" />  Yes
												
												<input id='img_noobj_certificate1h' name='img_noobj_certificate'  <?php if($save_draft->img_noobj_certificate=="No"){echo "checked";}?> type='radio'value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_noobj_certificate=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_noobj_certificate_details" <?php if($save_draft->img_noobj_certificate=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_noobj_certificate=="No"){echo $save_draft->img_noobj_certificate_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>10. Certificate/License from Municipality/corporation/ Panchayat to show that your establishment is registered as a Guest House (Trade License) / ನಿಮ್ಮ ಸಂಸ್ಥೆಯನ್ನು ಅತಿಥಿ ಗೃಹದ ಎಂದು ನೋಂದಾಯಿಸಲಾಗಿದೆ ಎಂದು ತೋರಿಸುವ ಪುರಸಭೆ / ನಿಗಮ / 
ಪಂಚಾಯಿತಿಯ ಪ್ರಮಾಣಪತ್ರ / ಪರವಾನಗಿ ಪ್ರತಿ*
<sup>*</sup></p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_license/'.$application->img_license;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_licenseh' class="cert"  <?php if($save_draft->img_license=="Yes"){echo "checked";}?> name='img_license' type='radio' value="Yes" />  Yes
												
												<input id='img_license1h' name='img_license'  <?php if($save_draft->img_license=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_license=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_license_details" <?php if($save_draft->img_license=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_license=="No"){echo $save_draft->img_license_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>


										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>11. NOC from Pollution Control Board / ಮಾಲಿನ್ಯ ನಿಯಂತ್ರಣ ಮಂಡಳಿಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_pollution_noc/'.$application->img_pollution_noc;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_pollution_noch' class="cert"  <?php if($save_draft->img_pollution_noc=="Yes"){echo "checked";}?> name='img_pollution_noc' type='radio' value="Yes" />  Yes
												
												<input id='img_pollution_noc1h' name='img_pollution_noc'  <?php if($save_draft->img_pollution_noc=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_pollution_noc=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_pollution_noc_details" <?php if($save_draft->img_pollution_noc=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_pollution_noc=="No"){echo $save_draft->img_pollution_noc_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	

										

										<!-- <div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>14. NOC from Police Department / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್‌ಒಸಿ </p>
											</div>
											<div class="field-download">
												<a href="<?php echo base_url().'upload/img_commercial_certificate/'.$application->img_commercial_certificate;?>" target="_blank"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_commercial_certificateh' class="reg_govrn_shops" name='img_commercial_certificate' type='radio' <?php if($save_draft->img_commercial_certificate=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='img_commercial_certificate1h' name='img_commercial_certificate' type='radio' <?php if($save_draft->img_commercial_certificate=="No"){echo "checked";}?> value="No" />  No
											</div>
											<div class="field-comment-sec" <?php if($save_draft->img_commercial_certificate=="No"){echo 'style="display:block;"';}?> > 
												<textarea class="condition-comment" name="img_commercial_certificate_details"<?php if($save_draft->img_commercial_certificate=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?> ><?php if($save_draft->img_commercial_certificate=="No"){echo $save_draft->img_commercial_certificate_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div> -->

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>12. Trade Licence / ವ್ಯಾಪಾರ ಪರವಾನಗಿ (ಅನ್ವಯಿಸುವುದಾದರೇ)</p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_trade_licence/'.$application->img_trade_licence;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_trade_licenceh' class="cert"  <?php if($save_draft->img_trade_licence=="Yes"){echo "checked";}?> name='img_trade_licence' type='radio' value="Yes" />  Yes
												
												<input id='img_trade_licence1h' name='img_trade_licence'  <?php if($save_draft->img_trade_licence=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_trade_licence=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_trade_licence_details" <?php if($save_draft->img_trade_licence=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_trade_licence=="No"){echo $save_draft->img_trade_licence_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>13. Bar Licence / ಬಾರ್ ಪರ್ಮಿಟ್ (ಅನ್ವಯಿಸುವುದಾದರೇ)</p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_bar_permit/'.$application->img_bar_permit;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_bar_permith' class="cert"  <?php if($save_draft->img_bar_permit=="Yes"){echo "checked";}?> name='img_bar_permit' type='radio' value="Yes" />  Yes
												
												<input id='img_bar_permit1h' name='img_bar_permit'  <?php if($save_draft->img_bar_permit=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_bar_permit=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_bar_permit_details" <?php if($save_draft->img_bar_permit=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_bar_permit=="No"){echo $save_draft->img_bar_permit_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	
	

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>14. Declaration stating that the Guest House operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details (Foreign& Domestic) on the Karnataka Tourism Website / “ ಅತಿಥಿ ಗೃಹದ ಆಪರೇಟರ್ ಕಡ್ಡಾಯವಾಗಿ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರತಿ ತಿಂಗಳು ಪ್ರವಾಸಿಗರ 
ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆ.
<sup>*</sup></p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_tourist_arrival_details/'.$application->img_tourist_arrival_details;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='dec_tourist' class="cert" name='img_tourist_arrival_details' type='radio'  <?php if($save_draft->img_tourist_arrival_details=="Yes"){echo "checked";}?> value="Yes" />  Yes
												
												<input id='dec_tourist1' name='img_tourist_arrival_details'  <?php if($save_draft->img_tourist_arrival_details=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div id="staff" class="field-comment-sec"  <?php if($save_draft->img_tourist_arrival_details=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_tourist_arrival_details_details" <?php if($save_draft->img_tourist_arrival_details=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_tourist_arrival_details=="No"){echo $save_draft->img_tourist_arrival_details_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	

										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>15. Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
											</div>
											<div class="field-download-upload">
												<a target="_blank" href="<?php echo base_url().'upload/img_board_entity/'.$application->img_board_entity;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='photo_tourexterior' class="cert"  <?php if($save_draft->img_board_entity=="Yes"){echo "checked";}?> name='img_board_entity' type='radio' value="Yes" />  Yes
												
												<input id='photo_tourexterior1' name='img_board_entity'  <?php if($save_draft->img_board_entity=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_board_entity=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_board_entity_details" <?php if($save_draft->img_board_entity=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_board_entity=="No"){echo $save_draft->img_board_entity_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	


										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>16. A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ "ಸುರಕ್ಷಿತ ಮತ್ತು ಗೌರವಾನಿತ್ವ ಪ್ರವಾಸೋದ್ಯಮ” ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞಾ ಪತ್ರಕ್ಕೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ<sup>*</sup></p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_pledge_commitment/'.$application->img_pledge_commitment;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='signed_copy_pledge' class="cert" name='img_pledge_commitment'  <?php if($save_draft->img_pledge_commitment=="Yes"){echo "checked";}?> type='radio' value="Yes" />  Yes
												
												<input id='signed_copy_pledge1' name='img_pledge_commitment' type='radio'  <?php if($save_draft->img_pledge_commitment=="No"){echo "checked";}?> value="No" />  No
											</div>
											<div id="staff" class="field-comment-sec"  <?php if($save_draft->img_pledge_commitment=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_pledge_commitment_details" <?php if($save_draft->img_pledge_commitment=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_pledge_commitment=="No"){echo $save_draft->img_pledge_commitment_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>	
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>17. NOC from Ministry of Environment & Forests (wherever applicable) / "ಪರಿಸರ ಮತ್ತು ಅರಣ್ಯ ಸಚಿವಾಲಯದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ
(ಅನ್ವಯವಾಗುವಲ್ಲೆಲ್ಲಾ) "
</p>
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_noc_environment/'.$application->img_noc_environment;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_noc_environmenth' class="cert" name='img_noc_environment'  <?php if($save_draft->img_noc_environment=="Yes"){echo "checked";}?> type='radio' value="Yes" />  Yes
												
												<input id='img_noc_environment1h' name='img_noc_environment'  <?php if($save_draft->img_noc_environment=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_noc_environment=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_noc_environment_details" <?php if($save_draft->img_noc_environment=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_noc_environment=="No"){echo $save_draft->img_noc_environment_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>18. NOC from Airport Authority of India for Guest House located near the Airport (wherever applicable) / ಅತಿಥಿ ಗೃಹದ ಏರಪೋರ್ಟ್ ಹತ್ತಿರದಲ್ಲಿದ್ದರೇ, ಭಾರತದ ವಿಮಾನ ನಿಲ್ದಾಣ ಪ್ರಾಧಿಕಾರದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</p>
												
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_noc_airport/'.$application->img_noc_airport;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_noc_airporth' class="cert" name='img_noc_airport'  <?php if($save_draft->img_noc_airport=="Yes"){echo "checked";}?> type='radio' value="Yes" />  Yes
												
												<input id='img_noc_airport1h' name='img_noc_airport'  <?php if($save_draft->img_noc_airport=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_noc_airport=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_noc_airport_details" <?php if($save_draft->img_noc_airport=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_noc_airport=="No"){echo $save_draft->img_noc_airport_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="field-app-form">
											<div class="field-appli-form-padd">
												<p>19. CRZ clearance (wherever applicable) / CRZ ಕ್ಲಿಯರೆನ್ಸ್ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</p>
												
											</div>
											<div class="field-download">
												<a target="_blank" href="<?php echo base_url().'upload/img_crz_clearance/'.$application->img_crz_clearance;?>"><i class="fa fa-download"></i></a>
											</div>
											<div class="form-condition">
												<input id='img_crz_clearanceh' class="cert" name='img_crz_clearance'  <?php if($save_draft->img_crz_clearance=="Yes"){echo "checked";}?> type='radio' value="Yes" />  Yes
												
												<input id='img_crz_clearance1h' name='img_crz_clearance'  <?php if($save_draft->img_crz_clearance=="No"){echo "checked";}?> type='radio' value="No" />  No
											</div>
											<div class="field-comment-sec"  <?php if($save_draft->img_crz_clearance=="No"){echo 'style="display:block;"';}?>>
												<textarea class="condition-comment" name="img_crz_clearance_details" <?php if($save_draft->img_crz_clearance=="No"){echo 'style="display: inline-block;"';}else{echo 'style="display: none;"';}?>><?php if($save_draft->img_crz_clearance=="No"){echo $save_draft->img_crz_clearance_details;} ?></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>							
										
										
										
										<div id="reject" class="reject-option">
											<div class="field-appli-form-nopadd">
												<p>Comments for Department Purpose/ಇಲಾಖೆಯ ಇಲಾಖೆಯ ಉದ್ದೇಶಕ್ಕಾಗಿ ಪ್ರತಿಕ್ರಿಯೆಗಳು</p>
											</div>									
											<div class="field-comment-nopadd">
												<textarea id="rej-text" name="internal_comment" class=""></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div id="reject-user" class="reject-option">
											<div class="field-appli-form-nopadd">
												<p>Comments for Applicant/ಅರ್ಜಿದಾರರಿಗಾಗಿ  ಪ್ರತಿಕ್ರಿಯೆಗಳು</p>
											</div>									
											<div class="field-comment-nopadd">
												<textarea id="rej-text1" name="external_comment" class=""></textarea>
												<div class="wizard-form-error"></div>
											</div>
										</div>
										<div class="extra-doc">
											<input type="checkbox" value="Yes" name="upload_check" id="file-reupload"  /> Upload Field Verification Report/ಕ್ಷೇತ್ರ ಪರಿಶೀಲನೆ ವರದಿಯನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ

											<div id="autoUpdate" class="autoUpdate" style="display:none">
												<div class="msg">
													<textarea name="adm_upload_details" id="textar"></textarea>
													<div class="wizard-form-error"></div>
												</div>
												
											<div class="field-comment-sec upload">
												<div class="file-upload-wrapper" data-text="Select your file!">
													<input id="doc_up" type="file" name="adm_upload" class="file-upload-field" accept="image/jpeg,image/gif,image/png,application/pdf"/>	
													<div class="wizard-form-error"></div>
												</div>
											</div>
											</div>
										</div>										
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>

											

											<a href="javascript:;"  class="form-wizard-save-btn" id="admin_draftdata">Save as draft</a>


											<a href="javascript:;" id="hide_next" class="form-wizard-next-btn second-next float-right">Next</a>
											<!-- <a href="javascript:;" id="sub" class="form-wizard-submit-reject float-right" style="display:none;">Reject The Application</a> -->

											
											<!----------------- Enabling return clarification button --------------------------------->
											
											<?php if($application->iteration<=4){?>
												<button name="btnAction" value="btnresend" id="sub" class="form-wizard-submit-resend resendbtn" style="display:none;">Return for Clarification</button> 
											<?php }?>
											<?php if($application->iteration>2){?>
											<!----------------- Rejection button  --------------------------------->
												<button name="btnAction" value="btnReject" id="sub" class="form-wizard-submit-reject float-right" style="display:none;">Reject The Application</button>
											<?php }?>
											<a href="javascript:;" id="chck-sub" class="form-wizard-check-submit float-right" style="display:none;">Next</a>
										</div>
								    </fieldset>										
								    <fieldset class="wizard-fieldset nodal-officer">
										<div class="nodal-office-comment">
											<h3>Comments for Department Purpose/ಇಲಾಖೆಯ ಇಲಾಖೆಯ ಉದ್ದೇಶಕ್ಕಾಗಿ ಪ್ರತಿಕ್ರಿಯೆಗಳು</h3>
											<textarea name="internal_comment" class="wizard-required"></textarea>
											<div class="wizard-form-error"></div>
											<div class="nodal-approve">
												<!-- <a href="#">REJECT</a>
												<a href="#">Approve to next step</a> -->										
											</div>
										</div>
										<div class="nodal-comment-applicant">
											<h3>Comments for Applicant/ಅರ್ಜಿದಾರರಿಗಾಗಿ  ಪ್ರತಿಕ್ರಿಯೆಗಳು</h3>
											<textarea name="external_comment" class="wizard-required"></textarea>
											<div class="wizard-form-error"></div>
										</div>											
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
											<!--button id="newsub" name="btnAction" value="btnApprovePayment" class="form-wizard-submit float-right">Approve for Payment</button-->
											<button name="btnAction" value="btnApproveNxtStage" class="form-wizard-submit float-right" style="background: #128439;margin-left: 10px;">Approve To Next Stage</button>
											<button name="btnAction" value="btnresend" id="sub" class="form-wizard-submit-resend resendbtn" >Return for Clarification</button>
										</div>
									
								</form>
								
								<!-- --------WF 1 Payment Approval---------------- -->
								
								<!-- --------WF 2 Verify Payment---------------- -->
								<?php elseif(($access['workflow'] == 2 || $access['workflow'] == 3 || $access['workflow'] == 4) && $access['admPrivilege']):?>
									<!-- <?php print_r($application->product_id)?> -->
									<fieldset class="wizard-fieldset comment-section" id="comment-sec1">
										<!--div class="payment-level">
											<div style="overflow-x:auto">
												<table class="payment-details">
													<tbody>	
														<tr><th colspan="5">Payment Details</th></tr>
														<tr class="table-head">
															<th>Payment Approved Date</th>
															<th>Payment Status</th>
															<th>Payment Transaction Date</th>
															<th>Total Amount</th>
															<th>Action</th>
														</tr>
															<?php if(empty($application->product_id)):?>							
														</tr>
															<td colspan='5'>Payment Not Found.<td>
														</tr>
														<?php else:?>
														<tr>
															<td><?php echo $application->approve_payment_date;?></td>
															<td><?php echo ($application->payment_id != '' ? 'Transaction Successfull' : 'Payment Not Made');  ?></td>
															<td><?php echo $application->payment_payed_date;?></td>
															<td><?php echo $application->payment_payed_amount;?></td>
															<td><?php if(empty($application->payment_id)): echo ''; else: ?><a href="<?php echo base_url().'admin/application/reports/'.$application->id ?>" target="_blank" >View</a> <?php endif;?></td>
														</tr>
														<?php endif; ?>		
													<tbody>	
												</table>
											</div>
										</div-->

										
										<div class="next-level">
											<div style="overflow-x:auto">
												<table class="next-level-details">
													<tbody>	
														<tr class="table-head">
															<th>Fields</th>
															<th>Documents</th>
															<th>AD Approved<br>Yes(or) No</th>
															<th>Comments</th>
														</tr>
														<tr>
															<th><p>1. Registration/Incorporation Certificate of the Entity / ಸಂಸ್ಥೆಯ ನೋಂದಣಿ/ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup><p style="font-size:12px;">Documentary proof to be uploaded in compliance with the any one of the below act/ ಕೆಳಗಿನ ಯಾವುದೇ ಕಾಯಿದೆಯ ಅನುಸಾರವಾಗಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ದಾಖಲಾತಿ ಪುರಾವೆ:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or / ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು
ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ 
ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ

								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / -ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ 
ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ.</p></p></th>
															<td><a href="<?php echo base_url().'upload/img_registration_certificate/'.$application->img_registration_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->reg_certificate;?></td>									
															<td><?php if($docverify->reg_certificate=="Yes"){echo "Approved";}else{echo $docverify->reg_certificate_details;} ?></td>									
														</tr>




														<!-- <tr>
															<th>2. Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ವಾಣಿಜ್ಯ ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ, 1961 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ (ಹೋಟೆಲ್/ರೆಸಾರ್ಟಗಳಿಗಾಗಿ)<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_registration_certificate/'.$application->img_certificate_shops;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_certificate_shops;?></td>									
															<td><?php if($docverify->img_certificate_shops=="Yes"){echo "Approved";}else{echo $docverify->img_certificate_shops_details;} ?></td>									
														</tr> -->


														<tr>
															<th><p>2. Address Proof of the Guest House / "ಹೋಟೆಲ್ ಮತ್ತು ರೆಸಾರ್ಟ್ ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></p><p style="font-size:12px;">Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt. / ಇತ್ತೀಚಿನ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಅನಿಲ/ನೀರಿನ ಬಿಲ್ ಸೇರಿದಂತೆ ಆಸ್ತಿ ಅಥವಾ ಪುರಸಭೆಯ ತೆರಿಗೆ ರಶೀದಿ. ಈ ಬಿಲ್ ಮತ್ತು ರಶೀದಿಗಳು ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p></th>
															<td><a href="<?php echo base_url().'upload/img_bank_reference/'.$application->img_bank_reference;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->bank_reference;?></td>									
															<td><?php if($docverify->bank_reference=="Yes"){echo "Approved";}else{echo $docverify->bank_reference_details;} ?></td>									
														</tr>
													
														
													<tr>
															<th><p>3. Details of Guest House Premises / ಅತಿಥಿ ಗೃಹದ ಸ್ಥಳದ ವಿವರಗಳು<sup>*</sup></p>
												<p style="font-size:12px;">Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / (ಸ್ಥಳವನ್ನು ಬಾಡಿಗೆ ಪಡೆದ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ ಪತ್ರ. 
ಸ್ಥಳವು ಸ್ವಂತದ್ದಾಗಿದ್ದರೇ, ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ ಪತ್ರ ಲಗತ್ತಿಸಬೇಕು)</p>
</th>
															
															<td><a href="<?php echo base_url().'upload/img_off_premises/'.$application->img_off_premises;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->off_premises;?></td>									
															<td><?php if($docverify->off_premises=="Yes"){echo "Approved";}else{echo $docverify->off_premises_details;} ?></td>	
														</tr>
														<tr>
															<th><p>4. Photograph of Guest House Interior/"ಅತಿಥಿ ಗೃಹದ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
												<p style="font-size:12px;">(All the mandatory features to be captured including the name of the Guest House) / (ಅತಿಥಿ ಗೃಹದ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು) </p></th>
															<td><a href="<?php echo base_url().'upload/img_off_buil_interior/'.$application->img_off_buil_interior;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->off_interior;?></td>									
															<td><?php if($docverify->off_interior=="Yes"){echo "Approved";}else{echo $docverify->off_interior_details;} ?></td>			
														</tr>
	<tr>
															<th>	<p>5. Photograph of Guest House Exterior/ "ಅತಿಥಿ ಗೃಹದ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
												<p style="font-size:12px;">(All the mandatory features to be captured including the name of the Guest House) / (ಅತಿಥಿ ಗೃಹದ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p></th>
															<td><a href="<?php echo base_url().'upload/img_off_buil_exterior/'.$application->img_off_buil_exterior;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->off_exterior;?></td>									
															<td><?php if($docverify->off_exterior=="Yes"){echo "Approved";}else{echo $docverify->off_exterior_details;} ?></td>									
														</tr>
														
														<!--tr>
															<th>9. Copy of Trade License / ವ್ಟ್ರೇಡ್ ಪರವಾನಗಿ ಪ್ರತಿ  <sup>*</sup>

</th>
															<td><a href="<?php echo base_url().'upload/img_trade_lic/'.$application->img_trade_lic;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_trade_lic;?></td>									
															<td><?php if($docverify->img_trade_lic=="Yes"){echo "Approved";}else{echo $docverify->img_trade_lic_details;} ?></td>									
														</tr-->
														<tr>
															<th>6. Sanctioned Building Plans/Occupancy Certificate / ಮಂಜೂರಾದ ಕಟ್ಟಡ ಯೋಜನೆಗಳು/ಸ್ವಾಧೀನ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup>

</th>
															<td><a href="<?php echo base_url().'upload/img_occupancy_certificate/'.$application->img_occupancy_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_occupancy_certificate;?></td>									
															<td><?php if($docverify->img_occupancy_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_occupancy_certificate_details;} ?></td>									
														</tr>

														<tr>
															<th>7. Copy of GST Registration Certificate/GST ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_gst_regis/'.$application->img_gst_regis;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_gst_regis;?></td>									
															<td><?php if($docverify->img_gst_regis=="Yes"){echo "Approved";}else{echo $docverify->img_gst_regis_details;} ?></td>	
														</tr>

														<!-- <tr>
															<th>9. Copy of PAN/ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_pan_copy/'.$application->img_pan_copy;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_pan_copy;?></td>									
															<td><?php if($docverify->img_pan_copy=="Yes"){echo "Approved";}else{echo $docverify->img_pan_copy_details;} ?></td>		
														</tr> -->
														
														<tr>
															<th>8. Certificate from FSSAI / FSSAI ನಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_fssai_certificate/'.$application->img_fssai_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_fssai_certificate;?></td>									
															<td><?php if($docverify->img_fssai_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_fssai_certificate_details;} ?></td>									
														</tr>
														<tr>
															<th>9. No-Objection Certificate from Fire department / ಅಗ್ನಿಶಾಮಕ ಇಲಾಖೆಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_noobj_certificate/'.$application->img_noobj_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_noobj_certificate;?></td>									
															<td><?php if($docverify->img_noobj_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_noobj_certificate_details;} ?></td>									
														</tr>
													

														<tr>
															<th>10. Certificate/License from Municipality/corporation/ Panchayat to show that your establishment is registered as a Guest House (Trade License) / ನಿಮ್ಮ ಸಂಸ್ಥೆಯನ್ನು ಅತಿಥಿ ಗೃಹದ ಎಂದು ನೋಂದಾಯಿಸಲಾಗಿದೆ ಎಂದು ತೋರಿಸುವ ಪುರಸಭೆ / ನಿಗಮ / 
ಪಂಚಾಯಿತಿಯ ಪ್ರಮಾಣಪತ್ರ / ಪರವಾನಗಿ ಪ್ರತಿ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_license/'.$application->img_license;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->img_license;?></td>									
															<td><?php if($docverify->img_license=="Yes"){echo "Approved";}else{echo $docverify->img_license_details;} ?></td>									
														</tr>
													<tr>
															<th>11. NOC from Pollution Control Board / ಮಾಲಿನ್ಯ ನಿಯಂತ್ರಣ ಮಂಡಳಿಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_pollution_noc/'.$application->img_pollution_noc;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_pollution_noc;?></td>									
															<td><?php if($docverify->img_pollution_noc=="Yes"){echo "Approved";}else{echo $docverify->img_pollution_noc_details;} ?></td>									
														</tr>
														<<!-- tr>
															<th><p>14. NOC from Police Department / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್‌ಒಸಿ  </p></th>
															<td><a href="<?php echo base_url().'upload/img_commercial_certificate/'.$application->img_commercial_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_commercial_certificate;?></td>									
															<td><?php if($docverify->img_commercial_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_commercial_certificate_details;} ?></td>									
														</tr> -->
														<tr>
															<th><p>12.Trade licence / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್‌ಒಸಿ  </p></th>
															<td><a href="<?php echo base_url().'upload/img_trade_licence/'.$application->img_trade_licence;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_trade_licence;?></td>									
															<td><?php if($docverify->img_trade_licence=="Yes"){echo "Approved";}else{echo $docverify->img_trade_licence_details;} ?></td>									
														</tr>
														<tr>
															<th>13. Bar Licence / ಬಾರ್ ಪರ್ಮಿಟ್ (ಅನ್ವಯಿಸುವುದಾದರೇ)<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_bar_permit/'.$application->img_bar_permit;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_bar_permit;?></td>									
															<td><?php if($docverify->img_bar_permit=="Yes"){echo "Approved";}else{echo $docverify->img_bar_permit_details;} ?></td>									
														</tr>



														

														
														<tr>
															<th>14. Declaration stating that the Guest House operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details (Foreign& Domestic) on the Karnataka Tourism Website / “ ಅತಿಥಿ ಗೃಹದ ಆಪರೇಟರ್ ಕಡ್ಡಾಯವಾಗಿ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರತಿ ತಿಂಗಳು ಪ್ರವಾಸಿಗರ 
ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆ.<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_tourist_arrival_details/'.$application->img_tourist_arrival_details;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_tourist_arrival_details;?></td>									
															<td><?php if($docverify->img_tourist_arrival_details=="Yes"){echo "Approved";}else{echo $docverify->img_tourist_arrival_details_details;} ?></td>	
														</tr>

														<tr>
															<th>15. Photograph of building with Board name stating name of the entity/ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_board_entity/'.$application->img_board_entity;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->img_board_entity;?></td>									
															<td><?php if($docverify->img_board_entity=="Yes"){echo "Approved";}else{echo $docverify->img_board_entity_details;} ?></td>									
														</tr>

														<tr>
															<th>16. A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ "ಸುರಕ್ಷಿತ ಮತ್ತು ಗೌರವಾನಿತ್ವ ಪ್ರವಾಸೋದ್ಯಮ” ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞಾ ಪತ್ರಕ್ಕೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_pledge_commitment/'.$application->img_pledge_commitment;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_pledge_commitment;?></td>									
															<td><?php if($docverify->img_pledge_commitment=="Yes"){echo "Approved";}else{echo $docverify->img_pledge_commitment_details;} ?></td>		
														</tr>
														<tr>
															<th>17. NOC from Ministry of Environment & Forests (wherever applicable) / "ಪರಿಸರ ಮತ್ತು ಅರಣ್ಯ ಸಚಿವಾಲಯದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ
(ಅನ್ವಯವಾಗುವಲ್ಲೆಲ್ಲಾ) "</th>
															<td><a href="<?php echo base_url().'upload/img_noc_environment/'.$application->img_noc_environment;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_noc_environment;?></td>									
															<td><?php if($docverify->img_noc_environment=="Yes"){echo "Approved";}else{echo $docverify->img_noc_environment_details;} ?></td>									
														</tr>
	<tr>
															<th>18. NOC from Airport Authority of India for Guest House located near the Airport (wherever applicable) / ಅತಿಥಿ ಗೃಹದ ಏರಪೋರ್ಟ್ ಹತ್ತಿರದಲ್ಲಿದ್ದರೇ, ಭಾರತದ ವಿಮಾನ ನಿಲ್ದಾಣ ಪ್ರಾಧಿಕಾರದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</th>
															<td><a href="<?php echo base_url().'upload/img_noc_airport/'.$application->img_noc_airport;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_noc_airport;?></td>									
															<td><?php if($docverify->img_noc_airport=="Yes"){echo "Approved";}else{echo $docverify->img_noc_airport_details;} ?></td>									
														</tr>

														<tr>
															<th>19. CRZ clearance (wherever applicable) / CRZ ಕ್ಲಿಯರೆನ್ಸ್ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</th>
															<td><a href="<?php echo base_url().'upload/img_crz_clearance/'.$application->img_crz_clearance;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_crz_clearance;?></td>									
															<td><?php if($docverify->img_crz_clearance=="Yes"){echo "Approved";}else{echo $docverify->img_crz_clearance_details;} ?></td>									
														</tr>


														<?php $admUpload =  explode(',',$application->adm_upload); $admUploadDet =  explode(',',$application->adm_upload_details); 
														foreach($admUpload as $key=>$val):?>
														<tr>
															<th>AD/DD Officer Attachment</th>
															<td><a href="<?php echo base_url().'upload/admin/'.$val;?>" target="_blank"><i class="fa fa-download"></i></a></td>				
															<td><?php echo ($val ? 'Available': 'Not Available');?></td>									
															<td><?php if($val){echo $admUploadDet[$key];} ?></td>									
														</tr>
														<?php endforeach; ?>
													</tbody>
											</table>
											</div>
										</div>
										
										
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
											<a href="javascript:;" id="hide_next" class="form-wizard-next-btn second-next float-right">Next</a>
										</div>
									</fieldset>
									<fieldset class="wizard-fieldset nodal-officer">
									<form method="POST" action="<?php echo base_url().'admin/application/application_update';?>" enctype="multipart/form-data">
										<input type="hidden" name="application_id" value="<?php echo $application->id;?>">
										<?php 	 if($application->stg_send_back_date != '' && $application->stg_send_back_submit_date == ''):?>
										<div class="extra-doc">
											<input type="checkbox" value="Yes" name="upload_check" id="file-reupload"  /> Do you have any Document to Upload
											<div id="autoUpdate" class="autoUpdate" style="display:none">
												<div class="msg">
													<textarea name="adm_upload_details" id="textar"></textarea>	
													<div class="wizard-form-error"></div>
												</div>
											<div class="field-comment-sec upload">
												<div class="file-upload-wrapper" data-text="Select your file!">
													<input type="file" name="adm_upload" class="file-upload-field" accept="image/jpeg,image/gif,image/png,application/pdf"/>	
													<div class="wizard-form-error"></div>
												</div>
											</div>
											</div>
										</div>
										<?php endif; ?>
										<div class="nodal-office-comment">
											<h3>Comments for Department Purpose/ಇಲಾಖೆಯ ಇಲಾಖೆಯ ಉದ್ದೇಶಕ್ಕಾಗಿ ಪ್ರತಿಕ್ರಿಯೆಗಳು</h3>
											<textarea name="external_comment" class="wizard-required"></textarea>
											<div class="wizard-form-error"></div>
											<div class="nodal-approve">
												
											</div>
										</div>
										<div class="nodal-comment-applicant">
											<h3>Comments for Applicant/ಅರ್ಜಿದಾರರಿಗಾಗಿ  ಪ್ರತಿಕ್ರಿಯೆಗಳು</h3>
											<textarea name="internal_comment" class="wizard-required"></textarea>
											<div class="wizard-form-error"></div>
										</div>
										
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left aprov-left">Previous</a>
											<!-- Submit method-->
											<!-- MD-->
											<?php if($access['workflow'] == 4): ?>
												<button name="btnAction" value="btnApproveLicenseStage" class="form-wizard-submit float-right">Approve Certificate</button>
											<!-- JD-->	
											<?php elseif($access['workflow'] == 3): ?>
											<!--button name="btnAction" value="btnApproveNxtStage" class="form-wizard-submit float-right aprov">Approve To Next Stage</button-->

<button name="btnAction" value="btnApproveLicenseStage" class="form-wizard-submit float-right">Approve Certificate</button>


											<!-- <button name="btnAction" value="btnReject" id="reject" class="form-wizard-submit float-right rejec">Reject The Application</button> -->
											<button name="btnAction" value="btnresend" id="sub" class="form-wizard-submit-resend resendbtn">Return for Clarification</button> 
											<input type="text" value="<?php echo $access['workflow']?>" name="desc_id" style="display: none;">
											<?php if($application->stg_send_back_date == NULL):?>
												<!--button name="btnAction" value="btnSendBack" class="form-wizard-submit float-right sendback">Send Back To Previous Stage</button-->
											<?php endif;?>
											<!-- AD/DD-->	
											<?php elseif($access['workflow'] == 2): ?>
											<button name="btnAction" value="btnApproveNxtStage" class="form-wizard-submit float-right" style="background: #128439;margin-left: 10px;">Approve To Next Stage</button>
											<?php if($application->stg_send_back_date == NULL):?>
												<button name="btnAction" value="btnReject" id="reject" class="form-wizard-submit float-right" style="background-color: #d65470;color: #fff;min-width: 120px;padding: 10px;border: none;">Reject The Application</button>
												<?php endif;?>
											<?php endif; ?>
										</div>
								    </form>	
								    
								<!-- --------WF 2 Verify Payment---------------- -->
								<!-- --------Stage Default---------------- -->
								<?php else: ?>	
									<fieldset class="wizard-fieldset comment-section" id="comment-sec1">
										<!-- <div class="payment-level">
											<div style="overflow-x:auto">
												<table class="payment-details">
													<tbody>	
														<tr><th colspan="5">Payment Details</th></tr>
														<tr class="table-head">
															<th>Payment Approved Date</th>
															<th>Payment Status</th>
															<th>Payment Transaction Date</th>
															<th>Total Amount</th>
															<th>Action</th>
														</tr>
														<?php if(empty($application->product_id)):?>							
														</tr>
															<td colspan='5'>Payment Not Found.<td>
														</tr>
														<?php else:?>
														<tr>
															<td><?php echo $application->approve_payment_date;?></td>
															<td><?php echo ($application->product_id != '' ? 'Transaction Successfull' : 'Payment Not Made');  ?></td>
															<td><?php echo $application->payment_payed_date;?></td>
															<td><?php echo $application->payment_payed_amount;?></td>
															<td><?php if(empty($application->product_id)): echo ''; else: ?><a href="<?php echo base_url().'admin/application/reports/'.$application->id ?>" target="_blank">View</a> <?php endif;?></td>
														</tr>
														<?php endif; ?>	
													<tbody>	
												</table>
											</div>
										</div> -->
										
										<div class="next-level">
											<div style="overflow-x:auto">
												<table class="next-level-details">
													<tbody>	
														<tr class="table-head">
															<th>Fields</th>
															<th>Documents</th>
															<th>AD Approved<br>Yes(or) No</th>
															<th>Comments</th>				
														</tr>
														

														<tr>
															<th><p>1. Registration/Incorporation Certificate of the Entity / ಸಂಸ್ಥೆಯ ನೋಂದಣಿ/ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup><p style="font-size:12px;">Documentary proof to be uploaded in compliance with the any one of the below act/ ಕೆಳಗಿನ ಯಾವುದೇ ಕಾಯಿದೆಯ ಅನುಸಾರವಾಗಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ದಾಖಲಾತಿ ಪುರಾವೆ:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or / ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು
ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ 
ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ

								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / -ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ 
ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ.</p></p></th>
															<td><a href="<?php echo base_url().'upload/img_registration_certificate/'.$application->img_registration_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->reg_certificate;?></td>									
															<td><?php if($docverify->reg_certificate=="Yes"){echo "Approved";}else{echo $docverify->reg_certificate_details;} ?></td>									
														</tr>




													<!-- 	<tr>
															<th>2. Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ವಾಣಿಜ್ಯ ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ, 1961 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ (ಹೋಟೆಲ್/ರೆಸಾರ್ಟಗಳಿಗಾಗಿ)<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_registration_certificate/'.$application->img_certificate_shops;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_certificate_shops;?></td>									
															<td><?php if($docverify->img_certificate_shops=="Yes"){echo "Approved";}else{echo $docverify->img_certificate_shops_details;} ?></td>									
														</tr> -->


														<tr>
															<th><p>2. Address Proof of the Guest House / "ಹೋಟೆಲ್ ಮತ್ತು ರೆಸಾರ್ಟ್ ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></p><p style="font-size:12px;">Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt. / ಇತ್ತೀಚಿನ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಅನಿಲ/ನೀರಿನ ಬಿಲ್ ಸೇರಿದಂತೆ ಆಸ್ತಿ ಅಥವಾ ಪುರಸಭೆಯ ತೆರಿಗೆ ರಶೀದಿ. ಈ ಬಿಲ್ ಮತ್ತು ರಶೀದಿಗಳು ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p></th>
															<td><a href="<?php echo base_url().'upload/img_bank_reference/'.$application->img_bank_reference;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->bank_reference;?></td>									
															<td><?php if($docverify->bank_reference=="Yes"){echo "Approved";}else{echo $docverify->bank_reference_details;} ?></td>									
														</tr>
													
														
													<tr>
															<th><p>3. Details of Guest House Premises / ಅತಿಥಿ ಗೃಹದ ಸ್ಥಳದ ವಿವರಗಳು<sup>*</sup></p>
												<p style="font-size:12px;">Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / (ಸ್ಥಳವನ್ನು ಬಾಡಿಗೆ ಪಡೆದ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ ಪತ್ರ. 
ಸ್ಥಳವು ಸ್ವಂತದ್ದಾಗಿದ್ದರೇ, ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ ಪತ್ರ ಲಗತ್ತಿಸಬೇಕು)</p>
</th>
															
															<td><a href="<?php echo base_url().'upload/img_off_premises/'.$application->img_off_premises;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->off_premises;?></td>									
															<td><?php if($docverify->off_premises=="Yes"){echo "Approved";}else{echo $docverify->off_premises_details;} ?></td>	
														</tr>
														<tr>
															<th><p>4. Photograph of Guest House Interior/"ಅತಿಥಿ ಗೃಹದ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
												<p style="font-size:12px;">(All the mandatory features to be captured including the name of the Guest House) / (ಅತಿಥಿ ಗೃಹದ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು) </p></th>
															<td><a href="<?php echo base_url().'upload/img_off_buil_interior/'.$application->img_off_buil_interior;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->off_interior;?></td>									
															<td><?php if($docverify->off_interior=="Yes"){echo "Approved";}else{echo $docverify->off_interior_details;} ?></td>			
														</tr>
	<tr>
															<th>	<p>5. Photograph of Guest House Exterior/ "ಅತಿಥಿ ಗೃಹದ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></p>
												<p style="font-size:12px;">(All the mandatory features to be captured including the name of the Guest House) / (ಅತಿಥಿ ಗೃಹದ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p></th>
															<td><a href="<?php echo base_url().'upload/img_off_buil_exterior/'.$application->img_off_buil_exterior;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->off_exterior;?></td>									
															<td><?php if($docverify->off_exterior=="Yes"){echo "Approved";}else{echo $docverify->off_exterior_details;} ?></td>									
														</tr>
														
														<!--tr>
															<th>9. Copy of Trade License / ವ್ಟ್ರೇಡ್ ಪರವಾನಗಿ ಪ್ರತಿ  <sup>*</sup>

</th>
															<td><a href="<?php echo base_url().'upload/img_trade_lic/'.$application->img_trade_lic;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_trade_lic;?></td>									
															<td><?php if($docverify->img_trade_lic=="Yes"){echo "Approved";}else{echo $docverify->img_trade_lic_details;} ?></td>									
														</tr-->
														<tr>
															<th>6. Sanctioned Building Plans/Occupancy Certificate / ಮಂಜೂರಾದ ಕಟ್ಟಡ ಯೋಜನೆಗಳು/ಸ್ವಾಧೀನ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup>

</th>
															<td><a href="<?php echo base_url().'upload/img_occupancy_certificate/'.$application->img_occupancy_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_occupancy_certificate;?></td>									
															<td><?php if($docverify->img_occupancy_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_occupancy_certificate_details;} ?></td>									
														</tr>

														<tr>
															<th>7. Copy of GST Registration Certificate/GST ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_gst_regis/'.$application->img_gst_regis;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_gst_regis;?></td>									
															<td><?php if($docverify->img_gst_regis=="Yes"){echo "Approved";}else{echo $docverify->img_gst_regis_details;} ?></td>	
														</tr>

														<!-- <tr>
															<th>9. Copy of PAN/ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_pan_copy/'.$application->img_pan_copy;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_pan_copy;?></td>									
															<td><?php if($docverify->img_pan_copy=="Yes"){echo "Approved";}else{echo $docverify->img_pan_copy_details;} ?></td>		
														</tr> -->
														
														<tr>
															<th>8. Certificate from FSSAI / FSSAI ನಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_fssai_certificate/'.$application->img_fssai_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_fssai_certificate;?></td>									
															<td><?php if($docverify->img_fssai_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_fssai_certificate_details;} ?></td>									
														</tr>
														<tr>
															<th>9. No-Objection Certificate from Fire department / ಅಗ್ನಿಶಾಮಕ ಇಲಾಖೆಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_noobj_certificate/'.$application->img_noobj_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_noobj_certificate;?></td>									
															<td><?php if($docverify->img_noobj_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_noobj_certificate_details;} ?></td>									
														</tr>
													

														<tr>
															<th>10. Certificate/License from Municipality/corporation/ Panchayat to show that your establishment is registered as a Guest House (Trade License) / ನಿಮ್ಮ ಸಂಸ್ಥೆಯನ್ನು ಅತಿಥಿ ಗೃಹದ ಎಂದು ನೋಂದಾಯಿಸಲಾಗಿದೆ ಎಂದು ತೋರಿಸುವ ಪುರಸಭೆ / ನಿಗಮ / 
ಪಂಚಾಯಿತಿಯ ಪ್ರಮಾಣಪತ್ರ / ಪರವಾನಗಿ ಪ್ರತಿ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_license/'.$application->img_license;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->img_license;?></td>									
															<td><?php if($docverify->img_license=="Yes"){echo "Approved";}else{echo $docverify->img_license_details;} ?></td>									
														</tr>
													<tr>
															<th>11. NOC from Pollution Control Board / ಮಾಲಿನ್ಯ ನಿಯಂತ್ರಣ ಮಂಡಳಿಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_pollution_noc/'.$application->img_pollution_noc;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_pollution_noc;?></td>									
															<td><?php if($docverify->img_pollution_noc=="Yes"){echo "Approved";}else{echo $docverify->img_pollution_noc_details;} ?></td>									
														<!-- </tr>
														<tr>
															<th><p>14. NOC from Police Department / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್‌ಒಸಿ  </p></th>
															<td><a href="<?php echo base_url().'upload/img_commercial_certificate/'.$application->img_commercial_certificate;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_commercial_certificate;?></td>									
															<td><?php if($docverify->img_commercial_certificate=="Yes"){echo "Approved";}else{echo $docverify->img_commercial_certificate_details;} ?></td>									
														</tr> -->
														<tr>
															<th><p>12. Trade Licence/ ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್‌ಒಸಿ  </p></th>
															<td><a href="<?php echo base_url().'upload/img_trade_licence/'.$application->img_trade_licence;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_trade_licence;?></td>									
															<td><?php if($docverify->img_trade_licence=="Yes"){echo "Approved";}else{echo $docverify->img_trade_licence_details;} ?></td>									
														</tr>
														<tr>
															<th>13. Bar Licence / ಬಾರ್ ಪರ್ಮಿಟ್ (ಅನ್ವಯಿಸುವುದಾದರೇ)<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_bar_permit/'.$application->img_bar_permit;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_bar_permit;?></td>									
															<td><?php if($docverify->img_bar_permit=="Yes"){echo "Approved";}else{echo $docverify->img_bar_permit_details;} ?></td>									
														</tr>
														


														

														
														<tr>
															<th>14. Declaration stating that the Guest House operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details (Foreign& Domestic) on the Karnataka Tourism Website / “ ಅತಿಥಿ ಗೃಹದ ಆಪರೇಟರ್ ಕಡ್ಡಾಯವಾಗಿ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರತಿ ತಿಂಗಳು ಪ್ರವಾಸಿಗರ 
ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆ.<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_tourist_arrival_details/'.$application->img_tourist_arrival_details;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_tourist_arrival_details;?></td>									
															<td><?php if($docverify->img_tourist_arrival_details=="Yes"){echo "Approved";}else{echo $docverify->img_tourist_arrival_details_details;} ?></td>	
														</tr>

														<tr>
															<th>15. Photograph of building with Board name stating name of the entity/ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_board_entity/'.$application->img_board_entity;?>" target="_blank"><i class="fa fa-download"></i></a></td>
															<td><?php echo $docverify->img_board_entity;?></td>									
															<td><?php if($docverify->img_board_entity=="Yes"){echo "Approved";}else{echo $docverify->img_board_entity_details;} ?></td>									
														</tr>


														<tr>
															<th>16. A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ "ಸುರಕ್ಷಿತ ಮತ್ತು ಗೌರವಾನಿತ್ವ ಪ್ರವಾಸೋದ್ಯಮ” ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞಾ ಪತ್ರಕ್ಕೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ<sup>*</sup></th>
															<td><a href="<?php echo base_url().'upload/img_pledge_commitment/'.$application->img_pledge_commitment;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_pledge_commitment;?></td>									
															<td><?php if($docverify->img_pledge_commitment=="Yes"){echo "Approved";}else{echo $docverify->img_pledge_commitment_details;} ?></td>		
														</tr>
														<tr>
															<th>17. NOC from Ministry of Environment & Forests (wherever applicable) / "ಪರಿಸರ ಮತ್ತು ಅರಣ್ಯ ಸಚಿವಾಲಯದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ
(ಅನ್ವಯವಾಗುವಲ್ಲೆಲ್ಲಾ) "</th>
															<td><a href="<?php echo base_url().'upload/img_noc_environment/'.$application->img_noc_environment;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_noc_environment;?></td>									
															<td><?php if($docverify->img_noc_environment=="Yes"){echo "Approved";}else{echo $docverify->img_noc_environment_details;} ?></td>									
														</tr>
	<tr>
															<th>20. NOC from Airport Authority of India for Guest House located near the Airport (wherever applicable) / ಅತಿಥಿ ಗೃಹದ ಏರಪೋರ್ಟ್ ಹತ್ತಿರದಲ್ಲಿದ್ದರೇ, ಭಾರತದ ವಿಮಾನ ನಿಲ್ದಾಣ ಪ್ರಾಧಿಕಾರದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</th>
															<td><a href="<?php echo base_url().'upload/img_noc_airport/'.$application->img_noc_airport;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_noc_airport;?></td>									
															<td><?php if($docverify->img_noc_airport=="Yes"){echo "Approved";}else{echo $docverify->img_noc_airport_details;} ?></td>									
														</tr>

														<tr>
															<th>21. CRZ clearance (wherever applicable) / CRZ ಕ್ಲಿಯರೆನ್ಸ್ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</th>
															<td><a href="<?php echo base_url().'upload/img_crz_clearance/'.$application->img_crz_clearance;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo $docverify->img_crz_clearance;?></td>									
															<td><?php if($docverify->img_crz_clearance=="Yes"){echo "Approved";}else{echo $docverify->img_crz_clearance_details;} ?></td>									
														</tr>

														<?php $admUpload =  explode(',',$application->adm_upload); $admUploadDet =  explode(',',$application->adm_upload_details); 
														foreach($admUpload as $key=>$val):?>
														<tr>
															<th>AD/DD Officer Attachment</th>
															<td><a href="<?php echo base_url().'upload/admin/'.$val;?>" target="_blank"><i class="fa fa-download"></i></a></td>									
															<td><?php echo ($val ? 'Available': 'Not Available');?></td>									
															<td><?php if($val){echo $admUploadDet[$key];} ?></td>									
														</tr>
														<?php endforeach; ?>
													</tbody>
											</table>
											</div>
										</div>
										

										
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
										<a href="javascript:;" id="hide_next" class="form-wizard-next-btn second-next float-right">Next</a>
										</div>
									</fieldset>
									<fieldset class="wizard-fieldset nodal-officer">
										<?php if(!empty($comments)):?>
											<p class="commentsad">Comments By Admin Users</p>
										<?php else:?>
											<p class="commentsad">No Previous Comments By Admin Users</p>
										<?php endif;?>
										<div class="form-group clearfix">
											<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
										</div>
										<?php endif; ?>
			<!-- --------Stage Default End---------------- -->

									<?php foreach($comments as $comm):?>
										<div class="applicant-process-stage1">
											<div class="appli-stage1">
												<h4>Stage <?php echo $comm->subject;?></h4>
												
											</div>
											<div class="appli-comment">
												<h5>Commented by: <b><?php echo $comm->crtname;?></b> ON <?php echo $comm->crtdate;?></h5>
												<p><b>Consumer</b><br><?php echo $comm->cons_comm;?></p>
												<p><b>Internal</b><br><?php echo $comm->inter_comm;?></p>
											</div>
										</div>
									<?php endforeach;?>
									</fieldset>
							</div>
						</div>
					</div>
				</section>		
			</div>
		</div>
<style>
.next-level {float: left;position: relative;width: 100%;}
.next-level-details {float: left;position: relative;width: 100%;margin: 0;}
.next-level-details tr{background: #fff;border-bottom: 1px solid #eee;}
.next-level-details tr:nth-child(even) {background: #f9f9f9;border-bottom: 1px solid #eee;}
.next-level-details th {width: 40%;font-weight: 600;font-size: 18px;padding: 15px 10px;}
.next-level-details th:nth-child(2) {width: 10%;}
.next-level-details th:nth-child(3) {width: 20%;}
.next-level-details .table-head {background: #fff;color: #086788;text-align:center;}
.next-level-details td {text-align: center;font-size:18px;padding:5px;}
.next-level-details td a{font-size:22px;color: #333;}
.next-level-details td:last-child{width:40%;}
.next-level-details td:nth-child(1){width:15%;}
.next-level-details td:first-child{width:10%;}

.payment-level {margin: 10px auto 50px;width: 70%;}
.payment-details {float: left;position: relative;width: 100%;border: 1px solid #fff;}
.payment-details tr {text-align: center;padding: 10px;background: #167368;border: 1px solid #fff;color: #ffff;}
.payment-details th {padding: 10px;border: 1px solid #dfdfdf; font-size:15px;}
.payment-details td {border: 1px solid #fff;padding: 10px; font-size:14px;}
.payment-details td a {background: #fffc29;color: #000;padding: 5px;border-radius: 5px;}
.commentsad{font-weight: 700;font-size: 18px;}
.extra-doc {float: left;position: relative;width: 100%;}
.extra-doc #autoUpdate {float: left;position: relative;width: 100%;margin: 20px 0px;}
.extra-doc #autoUpdate .msg {float: left;position: relative;width: 40%;padding: 0;}
.extra-doc #autoUpdate .msg textarea {width: 100%;padding: 10px;border: none;box-shadow: 0 0 5px 0 #aaa;border-radius: 5px;height:150px;}
.extra-doc #autoUpdate .msg-file {float: left;position: relative;width: 58%;margin-left: 2%;}
@media only screen and (max-width:1360px){
.payment-level {width: 80%;}
}
@media only screen and (max-width:1024px){
.payment-level {width: 90%;}
}
@media only screen and (max-width:768px){
.payment-level {width: 100%;}
}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> 
<script>
$('#sub-menu-btn1').prop('checked', true);
$('#file-reupload').change(function(){
  if (this.checked) {
  	//alert("show");
    $('#autoUpdate').show();
    $('#textar').addClass('wizard-required wizard-required-reject');
    $('#doc_up').addClass('wizard-required wizard-required-reject');
	$("#autoUpdate .upload__input").attr("id","file_up");
  } else {
  	//alert("hide");
    $('#autoUpdate').hide();
    $('#textar').val("");
    $('#autoUpdate .file-upload-field').val("");
	 $('#textar').removeClass('wizard-required wizard-required-reject');
	 $('#doc_up').removeClass('wizard-required wizard-required-reject');
	$("#autoUpdate .upload__input").removeAttr('id');
  }                   
});

$(function() {
  $(document).ready( function() 
  {
		window.images = [];
		$('body').on('change', '.upload__input', function(event) {	
			let messages = $(this).closest('.upload').find('.count_img, .size_img, .file_types');
			$(messages).hide();
			let files = event.target.files;
			let filename = $(this).attr('name').slice(0, -2);

			let names2 = window.images[filename];
			let names = [];
			if(names2)
			{
				names = names2;
			}

			let max_count = $(this).data('maxCount');
			for (var i = 0; i < files.length; i++) {
				let file = files[i];			
				names.push(file.size);
				if (names.length == max_count) {
					$(this).closest('.upload').find('.count_img').show();
					$(this).closest('.upload').find('.count_img_var').html(max_count);
					$(this).closest('.upload').find('.upload__btn').hide();
				}
				if (names.length > max_count) {
					names.pop();
					return false;
				}
				window.images[filename] = names;
				var fileType = file.type;
				if (fileType == 'image/png' || fileType == 'image/jpeg' || fileType == 'application/pdf'){
				}
				else{
					$(this).closest('.upload').find('.file_types').show();
					return false;
				}
				if (fileType == 'application/pdf'){
					var max_size = 3;
				}
				else{
					var max_size = 3;
				}
				var totalBytes = file.size;		
				var max_bites = max_size * 1024 * 1024;
				if(totalBytes > max_bites){
					$(this).closest('.upload').find('.size_img').show();
					$(this).closest('.upload').find('.size_img_var').html(max_size + 'MB');
					return false;
				}
				var picBtn = $(this).closest('.upload').find('.upload__btn');		
				var picReader = new FileReader();
				picReader.addEventListener("load", function(event) {
					var picFile = event.target;
					var picSize = event.total;
					var picCreate = $("<div class='upload__item'><img src='" + picFile.result + "'" + " class='upload__img'/><a data-id='" + picSize + "' class='upload__del'></a></div>");
					$(picCreate).insertBefore(picBtn);
				});			
				picReader.readAsDataURL(file);
			}
		});		
		$('body').on('click', '.upload__del', function() {
			$(this).closest('.upload').find('.upload__btn').show();
			let filename = $(this).closest('.upload').find('.upload__input').attr('name').slice(0, -2);
			let names = window.images[filename];
			let messages = $(this).closest('.upload').find('.count_img, .size_img, .file_types');
			$(messages).hide();
			$(this).closest('.upload__item').remove();
			var removeItem = $(this).attr('data-id');
			var yet = names.indexOf(removeItem);
			names.splice(yet, 1);
		});
		loadvehicledata();
			
  });

	$(".field-comment-sec").on("change", ".file-upload-field", function(){ 
	    $(this).parent(".file-upload-wrapper").attr("data-text",$(this).val().replace(/.*(\/|\\)/, '') );
	});
	function loadvehicledata()
	{		
		console.log("loadvehicle data");
		var application_id=<?php echo($application->id)?>;
		var BASE_URL = "<?php echo base_url();?>";
		var path 		= BASE_URL+'admin/ajax/vehicledata';		
		var table = $('#dataTableExample26').DataTable({
			ajax: {
			 			type: 'POST',
				        url: path,
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },	
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'vehicle_type' },
				        { data: 'permit_type' },
				        { data: 'regitration_name' },
				        { data: 'registeration_no' },
				        { data: 'tourist_permit' },
				        { data: 'permitdate' }, 
				        { data: 'enddate' }
				    ]
    			});
	}
});
</script>


<!--Start NEWW--->
<script>
$("#admin_draftdata").on('click',function()
{

		var application_id=<?php echo($application->id)?>;
	//alert(application_id);
var BASE_URL = "<?php echo base_url();?>";
	var path 		= BASE_URL+'admin/application/application_update_draft';
	//alert(path);
	//alert('testt');
		var appName = application_id;
		var form = $('#formSavedraft')[0];
	    var formData = new FormData(form); 
   
	    	//alert("else");
		    $.ajax({
					    type: 'POST',
					   	url: path,
					    //data: form.serialize(),
						processData: false,
			            contentType: false,
			            data: formData,
					    success: function(data) 
					    {
							if(data=="Record not saved successfully.Please try again" || data=="Record Not Updated. Please Enter Any one Fields")
							{
								alert(data);
							}
							else
							{

								var BASE_URL = "<?php echo base_url();?>";
	
								//alert(data);
							     /*var dataval=data.split("/");
					     		 sucval= dataval[0]; 
					      		 insid= dataval[1];
					       		 document.getElementById("insid_draft").value = insid;*/
								 var replaceUrl=BASE_URL+'admin/application';
								 window.location.replace(replaceUrl);
							}
						}
				});
		    

});

</script>

<!--End NEWW---->



<style>
	.wrap {width: 100%;position: relative;border-radius: 4px;background-color: #fff;box-shadow: 0 1px 2px 0 #c9ced1;padding: 5px;float: left;}
	.upload__wrap {padding-bottom: 0.9375rem;margin-bottom: 0.9375rem;border-bottom: 1px dotted #edeff0;}
	.upload__mess {border-left: solid 3px #ffb74d;padding-left: 0.5rem;color: #b5bac1;}
	.upload p {line-height: 2;}
	.upload p strong {color: #2f3640;padding-left: 0.3125rem;}
	.upload__item {position: relative;display: inline-block;vertical-align: top;margin-right: 10px;margin-bottom: 10px;}
	.upload__del {display: block;position: absolute;right: -8px;top: -8px;width: 21px;height: 22px;background: url("http://timra.ru/portfolio/8_auto.uz/img/icons/delete-icon-copy.svg") 0 0 no-repeat;cursor: pointer;opacity: 0.8;}
	.upload__del:hover {opacity: 1;}
	.upload__img {width: 100px;height: 100px;-o-object-fit: contain;object-fit: contain;}
	.upload__btn {position: relative;display: inline-block;vertical-align: top;width: 5.6875rem;height: 5.6875rem;line-height: 5.6875rem;border-radius: 2px;border: solid 0.5px #dee1e6;text-align: center;cursor: pointer;opacity: 0.6;overflow: hidden;}
	.upload__btn:after {content: "+";color: #dee1e6;font-size: 2.5rem;line-height: 5rem;cursor: pointer;}
	.upload__btn:hover {opacity: 0.99;}
	.upload__btn:active {box-shadow: inset 10px 10px 90px -30px rgba(0, 0, 0, 0.1);}
	.upload__input {opacity: 0;position: absolute;top: 0;bottom: 0;left: 0;right: 0;cursor: pointer;z-index: 100;}
	.hidden_ms {display: none;}
	.field-comment-sec.upload {float: left;position: relative;width: 50%;margin-top: 50px;padding: 0 20px;}
	.file-upload-wrapper {position: relative;width: 100%;height: 60px;}
	.file-upload-wrapper:before {content: 'Browse';position: absolute;top: 0;right: 0;display: inline-block;height: 40px;background: #ca0027;color: #fff;z-index: 25;line-height: 40px;padding: 0 50px;text-transform: uppercase;pointer-events: none;border-radius: 5px;}
	.file-upload-wrapper input {opacity: 0;position: absolute;top: 0;right: 0;bottom: 0;left: 0;z-index: 99;height: 40px;margin: 0;padding: 0;display: block;cursor: pointer;width: 100%;}
	.file-upload-wrapper:after {content: attr(data-text);font-size: 18px;position: absolute;top: 0;left: 0;padding: 10px 15px;display: block;width: calc(100% - 40px);pointer-events: none;z-index: 20;height: 40px;line-height: 20px;color: #999;border-radius: 5px;border: 1px solid;white-space: nowrap;overflow: hidden;}
	.form-wizard .aprov-left{float: left  !important;}
	.form-wizard .aprov{background: #128439;margin-left: 10px;}
	.form-wizard .rejec{background-color: #d65470;color: #fff;min-width: 120px;padding: 10px;border: none;margin-left: 10px;}
	.form-wizard .sendback{background: #f79f42;}
	.float-left {float: left  !important;}
	.float-right {float: right  !important;}
	.resendbtn {float: right;padding: 10px;background-color: #f50136;color: #fff;min-width: 100px;min-width: 120px;padding: 10px;text-align: center;border: none;margin: 1px 12px 12px 10px;}
	@media only screen and (max-width:1300px){
	.form-wizard .aprov {width: 50%;}
	.form-wizard .rejec {width: 50%;margin-top: 10px;}
	.form-wizard .sendback {background: #f79f42;float: left !important;margin-top: 10px;}
	}
	@media only screen and (max-width:768px){
	.form-wizard .aprov-left {float: none !important;margin: 10px auto;display: block;width: max-content;}
	.form-wizard .aprov {float: none !important;margin: 10px auto;display: block;}
	.form-wizard .rejec {margin: 10px auto;float: none !important;display: block;}
	.form-wizard .sendback{margin: 10px auto;float: none !important;display: block;}
	.extra-doc #autoUpdate .msg {width: 100%;}
	.field-comment-sec.upload {width: 100%;}
	.applicant-process-stage1 .appli-stage1 h4 {width: 100%;}
	}
	.agent-form-file-view1 {float: left;position: relative;width: 100%;padding: 30px 4%;text-align: right;}
	.agent-form-file-view1 a {background: #178597;color: #fff;padding: 10px 20px;border-radius: 3px;}



	.form-wizard-save-btn{background-color: #feca05;color: #000;padding: 10px;left: 35%;text-align: center;border:none;position: absolute;}
	.form-wizard-save-btn:hover{background-color: green;color: #fff;padding: 10px;left: 35%;text-align: center;border:none;position: absolute;}


</style>

<style>
fieldset.wizard-fieldset.comment-section {
    width: 95%;
}
@media only screen and (max-width: 1376px){
fieldset {
    width: 92%;
}
}
.field-appli-form-padd p {
	text-align: justify!important;
}
.field-app-form .field-appli-form-padd {

    width: 60%;
    font-size: 16px;

}
.field-app-form .field-comment-sec textarea {

    min-height: 100px;
    margin-top: 25px;
}
.app-form-field .form-input input[type="text"] {
    font-size: 16px;
}
p{
	font-size: 16px;
}
.h3, h3 {
    font-size: 20px;
}

.next-level-details th {
    width: 60%;

    font-size: 16px;

    text-align: justify;
}
.agent-form-file-view1 a {
    padding: 10px 20px;

}
.agent-form-file-view1 {

    padding: 9px 4%;

}
.app-form-field {

    font-weight: 500;

}
.field-app-form .field-appli-form-padd {
    font-weight: 500;

}
.app-form-field .form-input input[type="text"] {

    font-weight: 500;
 
}

th{
    font-weight: 500!important;
    }
</style>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
<?php include 'include/footer.php';?>
