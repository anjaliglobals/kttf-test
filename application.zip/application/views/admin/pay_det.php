<?php include 'include/header.php';?>
<?php //print_r($application); ?>

<?php
$application_approve_date = $appDettails->licence_issued_date;
$application_approve_date = strtotime($application_approve_date);
// echo date('d/m/Y', $application_approve_date);
$expiry_date = strtotime('+ 5 year', $application_approve_date);
// echo date('d/m/Y', $expiry_date);
$current_date = $appDettails->confirmed_date;
$current_date = strtotime($current_date);
//echo date('d/m/Y', $current_date);

$category_name = $this->db->get_where('m_product', array('id' => $appDettails->product_id))->row()->category_name;
$category_code = $this->db->get_where('m_district', array('id' => $appDettails->district_id))->row()->code;
$regg_id = $appDettails->acg_id;
$acg_format = "DOT".$category_code."/".$category_name."/00000".$regg_id;
?>
	<div class="application">
<div id="print-report" class="certi">
	<table style="max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px 4%;border-collapse: inherit;border-bottom:none;">
<?php
//print_r($appDettails);
?>				
			<tr>
				<td style="text-align:center;">
					<img style="max-width:100%" src="<?php echo base_url().'theme/user/images/head-logo.jpg';?>">
				</td>				
			</tr>
			<!--tr>
				<td style="text-align:left;padding-left:03%;width: 100%;">
					<p>Number:<span style="color:#ca0027;"> 2458732/54</p>
				</td>				
			</tr-->
			<!--tr>
				<td style="text-align:center;width: 100%;">
					<p><span style="font-size:40px;font-family: 'Times New Roman';">CERTIFICATE</span> <br>of Registration </p>
				</td>				
			</tr-->
			<!--tr>
				<td style="text-align:center;width: 100%;">
					<hr align="center" style="width:80%;"></hr>
				</td>				
			</tr-->
			<!--tr>
				<td style="text-align:center;width: 100%;">
					<p> to this organization, about issuing an Registration Letter from the Tourism Department</p>
				</td>				
			</tr-->
			<tr>
				<td style="margin: 30px 0 10px;text-align:left;float:left;">
					<p>No:<span style="color:#000;"> <b> <?php echo $acg_format;?></b></p>
				</td>
				<td style="margin: 30px 0 10px;text-align:left;width: 200px;float:right;">
					<p>Date:<b> <?php echo date('d-m-Y', $current_date) ?> </b> </p>
				</td>				
			</tr>			
			
			<tr>
				<td style="text-align:center;">
					<p style="margin: 25px 0 10px;"><span style="font-size:20px;font-weight: 600;text-transform: uppercase;"><?php echo $appDettails->applicant_name;?>  - Payment Details </span></p>
				</td>								
			</tr>

<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 12px 0 15px;"><span style="font-size:21px;line-height: 2em;">This is to acknowledge that you have applied for Registration with Department of Tourism under <b><?php echo $this->db->get_where('m_product', array('id' => $appDettails->product_id))->row()->name; ?></b>.</span></p>
				</td>				
			</tr>
			

<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 12px 0 15px;"><span style="font-size:21px;line-height: 2em;"> ನೀವು <b><?php echo $this->db->get_where('m_product', array('id' => $appDettails->product_id))->row()->name; ?></b> ಅಡಿಯಲ್ಲಿ ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯೊಂದಿಗೆ ನೋಂದಣಿಗಾಗಿ ಅರ್ಜಿಯನ್ನು ಸಲ್ಲಿಸಿದ್ದೀರಿ ಎಂದು ಅಂಗೀಕರಿಸಲಾಗಿದೆ</span></p>
				</td>				
			</tr>



			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left:15%;"><span style="font-size:20px;"> <b>Product Name :</b>&nbsp;&nbsp;&nbsp; <?php echo $this->db->get_where('m_product', array('id' => $appDettails->product_id))->row()->name; ?></p>
				</td>				
			</tr>
			
			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Transaction Date :</b>&nbsp;&nbsp;&nbsp; <?php echo date('d-m-Y', strtotime($appdet_pay[0]->crtdate)) ?></p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Transaction Amount :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->txnamount; ?></p>
				</td>				
			</tr>

			<?php
if($appdet_pay[0]->paystatus=="TXN_SUCCESS"){
			?>
	<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Order ID :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->order_id; ?></p>
				</td>				
			</tr>

				<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>MID :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->mid; ?></p>
				</td>				
			</tr>

			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Payment Mode :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->paymentmode; ?></p>
				</td>				
			</tr>

			<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Transaction ID :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->txnid; ?></p>
				</td>				
			</tr>

				<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Status :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->paystatus; ?></p>
				</td>				
			</tr>

				<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Response Message :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->respmsg; ?></p>
				</td>				
			</tr>

				<?php if(!empty($appdet_pay[0]->bankname)){ ?>
				<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Bank Name :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->bankname; ?></p>
				</td>				
			</tr>
			<?php
		}
			?>
			<?php
}
else{
			?>


				

				<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Status :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->paystatus; ?></p>
				</td>				
			</tr>

				<tr>
				<td style="text-align:center;width: 100%;">
					<p style="margin: 25px 0 10px;text-align: left;padding-left: 15%;"><span style="font-size:20px;"> <b>Response Message :</b> &nbsp;&nbsp;&nbsp;<?php echo $appdet_pay[0]->respmsg; ?></p>
				</td>				
			</tr>

				
			<?php
}

			?>
			
		</tbody>
	</table>
	<table style="max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 100px 20px 20px 20px;border-collapse: inherit;border-top:none;">
		<tbody>
		
			
		</tbody>		
	</table>

</div>
<div class="certi">
				<button type="button" onclick="printDiv('print-report')">Print</button>
			</div>
</div>
<script>
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}


	</script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Times%20New%20Roman" rel="stylesheet"> 
	<style>	
.certi {float: left;position: relative;width: 100%;margin: 10px 0;text-align: center;}	
@media screen, print {
         table{max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;}
		img{max-width:100%;}

      }
		
	</style>
<style  media="print">	
         table{max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;}
		img{max-width:100%;}
.certi {float: left;position: relative;width: 100%;margin: 10px 0;}
b{color:#ca0027;}
	</style>

<?php include 'include/footer.php';?>
