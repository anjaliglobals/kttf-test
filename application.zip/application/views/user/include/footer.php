
	</div>

<?php foreach ($arr_js as $js): ?>
		<script type="text/javascript" src="<?php echo base_url().'theme/'.$js;?>"></script>	
<?php endforeach;?>
	
</body>
</html>