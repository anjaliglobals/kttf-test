<html lang="en" class="notranslate" translate="no"> 
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <?php 
    	foreach ($arr_css as $css): ?>
    		<link rel="stylesheet" href="<?php echo base_url().'theme/'.$css;?>">
    <?php
    	endforeach;
    ?>

    <title>KTTF User</title>
  </head>
<body>
	<div class="application-logo-header">
		<div class="kttf-logo">
			<img src="<?php echo base_url().'theme/user/images/ka-logo1.jpg';?>"> 
		</div>
		<!-- <div class="notification-area">
			<i class="fa fa-bell" aria-hidden="true"><span class="notification-alert">2</span></i>
		</div> -->
	</div>
	
	<div class="admin-dashboard">
		<div class="admin-menu">			
			<header class="header">
			  <a class="user-profile">Profile</a>
			  <input class="menu-btn" type="checkbox" id="menu-btn" />
			  <label class="menu-icon" for="menu-btn"><span class="navicon"></span></label>
			  <ul class="menu">
			  	<?php if($menu == 'Dashboard'):?>
					<li><a href="#" class="active"><i class="fa fa-home" aria-hidden="true"></i> &nbsp;</a></li>	
			  	<?php elseif($menu == 'Application_agreement'): $this->session->unset_userdata('app_id');?>
					<li><a href="#" class="active"><i class="fa fa-home" aria-hidden="true"></i> &nbsp;</a></li>	
			  	<?php else:?>
			  	   <?php if($this->session->userdata('app_id')):?>			  		
						<li><a href="<?php echo base_url().'applications/application_view/'.$this->session->userdata('app_id');?>" class="<?php if($menu == 'Application'): echo 'active'; endif;?>"><i class="fa fa-home" aria-hidden="true"></i> &nbsp;</a></li>	
						<li><a href="<?php echo base_url().'dashboard';?>">View Status </a></li>	
						<li><a href="<?php echo base_url().'applications/application_msg/'.$this->session->userdata('app_id'); ?>">Messages</a></li>	
						<!--li><a href="<?php echo base_url().'applications/application_payments/'.$this->session->userdata('app_id'); ?>">Payments</a></li-->
				  	<?php else: ?>	
						<li><a href="#" class="<?php if($menu == 'Application'): echo 'active'; endif;?>"><i class="fa fa-home" aria-hidden="true"></i> &nbsp;</a></li>					
				  	<?php endif; ?>					
			  	<?php endif; ?>					

			  </ul>
			</header>
			<div class="agent-logout">
				
				<input class="menu-bttn" type="checkbox" id="menu-bttn" />
				<label class="menu-icon" for="menu-bttn"><i class="fa fa-user"></i>  Logged In<span class="navicon"></span></label>
				<ul class="menu">
					<li><a href="<?php echo base_url().'dashboard';?>"><i class="fa fa-tachometer"></i>  Dashboard</a></li>
<li><a href="<?php echo base_url().'applications/about';?>"><i class="fa fa-podcast"></i>  About KTTF</a></li>
					<!--li><a href="#"><i class="fa fa-user-circle-o"></i>  Profile</a></li-->
<li><a href="<?php echo base_url().'applications/editprofile';?>"><i class="fa fa-edit"></i></i> Edit Profile</a></li>
<!--li><a href="https://kttf.karnatakatourism.org/theme/user/images/KTTF_user_manual.pdf" target="_blank"><i class="fa fa-address-card"></i></i> User Manual</a></li-->
	<li><a href="<?php echo base_url().'applications/manual';?>"><i class="fa fa-address-card"></i>  User Manual</a></li>
					<li><a href="<?php echo base_url().'applications/logout';?>"><i class="fa fa-power-off"></i> Logout</a></li>
				</ul>
			</div>
		</div>	


<style>
.kttf-logo img {
    width: 100%!important;
}
</style>	
