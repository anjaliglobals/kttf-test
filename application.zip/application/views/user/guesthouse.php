<form  method="post" role="form" enctype="multipart/form-data"  id="formSave123">
								<fieldset id="general-verify" class="wizard-fieldset general-verify show">
									<?php if($prod_id!=7){  ?>
										<input hidden type="text" id="proId" value="<?php echo $prod_id ?>">
									<?php }?>
									<?php if($new_pid!=7){  ?>
										<input hidden type="text" id="proId" value="<?php echo $new_pid ?>">
									<?php }?>	


									<input style="display:none" type="text" name="pg_orderid" id="pg_orderid" value="<?php echo $result['orderId']; ?>">

									

									<div class="agent-form">
										<div class="form_label">
											<!-- <p>Full Name of the Entity / ಘಟಕದ ಪೂರ್ಣ ಹೆಸರು<br>(Firm/Company/Limited Liabilities Partnership/Proprietorship) / <br>(ಸಂಸ್ಥೆ / ಕಂಪನಿ / ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳು ಸಹಭಾಗಿತ್ವ / ಮಾಲೀಕತ್ವ) <sup> * </sup></p> -->
											<p>Trade Name / ವ್ಯಾಪಾರ ಹೆಸರು <sup> * </sup></p>
										</div>
										<div class="form_input">
											
											<input hidden type="text" id="eproduct_id" name="product_id" >
											
											<input type="text" onkeypress="return isNumbera(event,'albhabet')"  name="applicant_name" id="eapplication_name" value="" class="">
											<input style="display:none;" type="text" class="" name="insid_draft"  id="insid_draft" >
										</div>										
									</div>
									
									<div class="agent-form">
										<div class="form_label">
											<p>Entity Name / ಘಟಕದ ಹೆಸರು <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" onkeypress="return isNumbera(event,'albhabet')" name="entity_name" id="entity_name" value="" class="">
										</div>	
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>In which name you need a certificate to be printed ? / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ನಿಮಗೆ ಮುದ್ರಿಸಲು ಪ್ರಮಾಣಪತ್ರ ಬೇಕು <sup> * </sup></p>
										</div>
										<div class="form_input">
										<select name="certificate_name" id="ecertificate_name"class="form-control wizard-required">
											<option value="">Select Type</option>
											<option value="1">Trade name</option>
											<option value="2">Entity Name</option>
										</select>
										<div class="wizard-form-error"></div>
										</div>									
									</div>

									<div class="agent-form">
										<div class="form_label">
											<p>Entity Type / ಘಟಕದ  ಪ್ರಕಾರ <sup> * </sup></p>
										</div>
										<div class="form_input">
										<select name="org_type_id" id="eorg_type_id" class="form-control wizard-required">
											<option value="">Select Entity Type</option>
											<?php
											$this->db->where('isactive', '1');
											$clients = $this->db->get('m_organization_nature')->result_array();
											foreach ($clients as $row):
											?>
											<option value="<?php echo $row['id']; ?>">
											<?php echo $row['name']; ?></option>
											<?php endforeach; ?>
										</select>
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Date of Registration/Incorporation of the Entity / "ಸಂಸ್ಥೆಯ ನೋಂದಣಿ / ಸಂಯೋಜನೆಯ ದಿನಾಂಕ<sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="date" name="org_commencement_date" id="eorg_commencement_date" style="text-transform:lowercase;border-radius: 5px;" class="wizard-required">											
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="form_label.new" style= "text-align: justify;">
										<p>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Karnataka Shops and Establishment Act) / 
											"ಘಟಕದ ನೋಂದಣಿ/ಸಂಯೋಜನೆಯ ದಿನಾಂಕ(ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956 /2013 ಅಥವಾ ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ) " </p>
										<div class="agent-form">
											<div class="form_label">
												<p>Date of issue of Certificate/License from Municipality/Corporation/Panchayat / ಪುರಸಭೆ/ನಿಗಮ/ಪಂಚಾಯತ್ ನಿಂದ ಪ್ರಮಾಣಪತ್ರ/ಪರವಾನಗಿ ನೀಡುವ ದಿನಾಂಕ<sup> * </sup></p>
											</div>
											<div class="form_input">
												<input type="date" name="org_license_date" id="eorg_license_date" style="text-transform:lowercase;border-radius: 5px;" class="wizard-required">					<div class="wizard-form-error"></div>
											</div>									
										</div>	
									<!-- <div class="agent-form">
										<div class="form_label">
											<p>Date of registration of entity as per Karnataka shops and establishment act / ಕರ್ನಾಟಕ ಅಂಗಡಿಗಳು ಮತ್ತು ಸ್ಥಾಪನಾ ಕಾಯ್ದೆಯ ಪ್ರಕಾರ ಘಟಕದ ನೋಂದಣಿ ದಿನಾಂಕ<sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="date" name="org_shop_date" id="org_shop_date" class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>-->
									<div class="agent-form">
										<div class="form_label">
											<p>Date of issue of Trade License/ ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನೀಡಲಾದ ದಿನಾಂಕ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="date" name="trade_lic_date"  class="wizard-required" id="etrade_lic_date"style="text-transform:lowercase;border-radius: 5px;">
											<div class="wizard-form-error"></div>
										</div>									
									</div> 
									
									<div class="agent-form">
										<div class="form_label">
											<p>Name of Proprietor / Directors / Partners/ಮಾಲೀಕರು / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಹೆಸರು <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" onkeypress="return isNumbera(event,'albhabet')" id="eproperitor_name" name="proprietor_name" class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>GST Identification Number / ಜಿ ಎಸ್ ಟಿ ಗುರುತಿನ ಸಂಖ್ಯೆ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" maxlength="15" name="gst_number" id="egst_number" value=""class="wizard-required" >
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>PAN Number / ಪ್ಯಾನ್ ಸಂಖ್ಯೆ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" maxlength="10" id="epan_number" name="pan_number" value=""class="wizard-required">

											<div class="wizard-form-error"></div>

										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು URL</p>
										</div>
										<div class="form_input">
											<input type="text" name="website_name" id="ewebsite_name" value="">
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Official email id of the Entity / ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ </p>
											<!-- <sup> * </sup> -->
										</div>
										<div class="form_input">
											<input type="email" id="eofficial_email" name="official_email" class="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="">
											<div id="valid"></div>
											<!-- wizard-required<div class="wizard-form-error"></div> -->
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">			
											<p>Whether the member of Karnataka Tourism Society (KTS)? / ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ಸೊಸೈಟಿಯ (KTS) ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup>*</sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck_kts" onclick="javascript:yesnoCheck_d1('yesCheck_kts','ifYes','div_reg_upload');" name="member_kts" value="yes">										
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck_kts" onclick="javascript:yesnoCheck_d1('noCheck_kts','ifYes','div_reg_upload');" name="member_kts" value="no">
											<label for="no">No</label>	
											<input hidden type="text" name="member_recognised_trade_new" id="emember_recognised_trade_new" >
										</div>									
									</div>
									<div class="agent-form" style="display:none;" id="ifYes">
										<div class="form_label">
											<p>Upload Registration Document / ನೋಂದಣಿ ಡಾಕ್ಯುಮೆಂಟ್ ಅನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ<sup>*</sup></p>
										</div>
										<div class="form_input_file">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_member_kts_upload">
												<input id="img_member_kts" name="img_member_kts" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_member_kts" style="display: none">
												<a id="a_member_kts" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="reg_document" name="member_kts" Sdivname="div_member_kts_upload" hdivname="div_member_kts">Remove</button>
											</div>
										</div>
									</div>
									<div  class="agent-form" style="display:none;" id="nodiv">
										<span><a style="color: red;" href="https://www.karnatakatourismsociety.org/" target="_blank">Note: Register in KTS <span style='color:blue'>https://www.karnatakatourismsociety.org</span> to avail Benefits from Government</a></span>
									</div>
									<!--div class="agent-form">
										<div class="form_label">
												<p>Whether a Member of any recognized Hotel & Restaurant Association? / ಯಾವುದೇ ಮಾನ್ಯತೆ ಪಡೆದ ಹೋಟೆಲ್ ಮತ್ತು ರೆಸ್ಟೋರೆಂಟ್ ಅಸೋಸಿಯೇಶನ್‌ನ ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup> * </sup></p>
										</div>
										<div class="form_input">
											<select name="member_recognised_trade" id="emember_recognised_trade" class="form-control wizard-required dropdownchange"style="display:none;border-radius: 5px;">
												<option showvalue="emember_recognised_trade_other" value="">Member of any recognized Hotel & Restaurant Association</option>
												<option showvalue="emember_recognised_trade_other" value="Karnataka State Hotels and Resorts Association">Karnataka State Hotels and Resorts Association</option>
												<option showvalue="emember_recognised_trade_other" value="Bruhat Bangalore Hotels Association (Regd.)">Bruhat Bangalore Hotels Association (Regd.)</option>
												<option showvalue="emember_recognised_trade_other" value="National Restaurant Association of India">National Restaurant Association of India</option>
												<option showvalue="emember_recognised_trade_other" value="Federation Of Hotel & Restaurant Association Of India">Federation Of Hotel & Restaurant Association Of India</option>
												<option showvalue="emember_recognised_trade_other" value="Hotel Association of India">Hotel Association of India</option>
												<option showvalue="emember_recognised_trade_other" value="South India Hotels and Restaurants Association(SIHRA)">South India Hotels and Restaurants Association(SIHRA)</option>
												<!- <option value="International Hotel & Restaurant Associations">International Hotel & Restaurant Associations</option> ->
												<option value="Others" showvalue="emember_recognised_trade_other">Others</option>
											</select>											
											<div class="wizard-form-error"></div>
											<br> &nbsp;
											<input style="display: none;" id="emember_recognised_trade_other" type="text" name="member_recognised_trade_other">
										</div>
									</div-->										
									<div class="form-heading-location">
											<h4>Registered Office Address / ನೋಂದಾಯಿತ ಕಚೇರಿ ವಿಳಾಸ</h4>
											<span>[Applicant to mention only the details of office address for which registration under Department of Tourism is required] / (ಅರ್ಜಿದಾರರು  ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿಗೆ ಅಗತ್ಯವಿರುವ ಕರ್ನಾಟಕದಲ್ಲಿನ ಕಚೇರಿ ವಿಳಾಸದ ವಿವರಗಳನ್ನು ಮಾತ್ರ ನಮೂದಿಸಬೇಕು)
											</span>
									</div>
									<div class="agent-loc-off-address">
										<div class="agent-form-field">
												<div class="agent-form-text">
													<p>State / ರಾಜ್ಯ  <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select name="org_state" id="eorg_state" class="form-control wizard-required" onchange="showdropdown(this)">
														  <option value="">Select State</option>
														  <?php
														  	// $this->db->where(array('state_id' => '17'));
															$clients = $this->db->get('m_states')->result_array();
															foreach ($clients as $row):	?>
															<option value="<?php echo $row['id']; ?>">
															<?php echo $row['name']; ?></option>
														  <?php endforeach; ?>
													</select>
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1 <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_add1" id="eloc_addr1" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2 </p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_add2" id="eloc_addr2" class="">
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>District / ಜಿಲ್ಲೆ  <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select style="display: none;"  name="org_loc_district_id" id="eloc_district" onchange="showtaluk(0,'eloc_taluk_office','eloc_district')"class="form-control ">
														  <option value="">Select District</option>
														  <?php
														  	$this->db->where(array('state_id' => '17'));
															$clients = $this->db->get('m_district')->result_array();
															foreach ($clients as $row):	?>
															<option value="<?php echo $row['id']; ?>">
															<?php echo $row['name']; ?></option>
														  <?php endforeach; ?>
													</select>
													<input type="text" name="new_district" id="eloc_districtnew" class="form-control">
													<div class="wizard-form-error"></div>
												</div>									
											</div>										
											
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Taluk / ತಾಲೂಕು <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select style="display: none;" name="org_loc_taluk_id" class="form-control" id="eloc_taluk_office">
														<option value="">Select Taluk</option>
													</select>
													<input type="text" name="new_taluk" id="eloc_taluk_office_new" class="form-control">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>City / Town / Village <br> ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text"  id="eorg_loc_city" name="org_loc_city" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text"  id="eorg_loc_landmark" name="org_loc_landmark" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" maxlength="6" onkeypress="return isNumber(event)" name="org_loc_pincode_id" id="eorg_loc_pincode_id" class="wizard-required"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" maxlength="10" name="org_loc_mobile" onkeypress="return isNumber(event)" class="wizard-required" id="eloc_mob"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Telephone number / ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_telephone"  maxlength="10" onkeypress="return isNumber(event)"  id="eloc_tele"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<!-- <div class="agent-form-field">
												<div class="agent-form-text">
													<p>Total Built Area(Sq.ft) / ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ) <sup> * </sup> </p>
												</div>
												<div class="agent-form-input">
													<input type="text" id="etotalbuildfuna" onkeypress="return isNumbera(event,'number')"  name="org_total_build_sqft" class="wizard-required" onpaste="return false" onkeyup="totalbuildfun('totalbuildfuna')">
													<div class="wizard-form-error"></div>
												</div>									
											</div> -->
									</div>
									<div class="form-heading">
										<h4>Guest House Details</h4>
									</div>
									<div class="agent-loc-off-address">
										<div id="other_address_div">		
										<div class="other-off-addre">
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Name of Guest House  / ಅತಿಥಿ ಗೃಹದ ಹೆಸರು <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="guest_name" id="eguest_name" class="new_required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Is the Guest House recognized under Ministry of Tourism, Government of India /  ಭಾರತ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಅತಿಥಿ ಗೃಹವನ್ನು ಗುರುತಿಸಲಾಗಿದೆಯೇ<sup> * </sup></p>	
													
												</div>
												<div class="form_input">
														<input type="radio" id="yesCheck_dmot" onclick="javascript:yesnoCheck_d1('yesCheck_dmot','ifYesmot','div_reg_upload');" name="central_gov_approved" value="yes">										
														<label for="yes">Yes</label>
														<input type="radio" id="noCheck_dmot" onclick="javascript:yesnoCheck_d1('noCheck_dmot','ifYesmot','div_mot_upload');" name="central_gov_approved" value="no">
														<label for="no">No</label>	
													</div>						
											</div>	
											<div class="agent-form-text.new" style="text-align: justify;">
												<p>(If yes, the applicants must upload the valid MoT star classification certificate/ ಹೌದು ಎಂದಾದಲ್ಲಿ ಅರ್ಜಿದಾರರು ಮಾನ್ಯವಾದ MoT ಸ್ಟಾರ್ ವರ್ಗೀಕರಣ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಅಪಲೋಡ್ ಮಾಡಬೇಕು</p>
											</div>
											<div id="ifYesmot" style="display:none;">
												<div class="agent-form" >
													<div class="form_label">
														<p>Upload MOT star classification / MOT ಸ್ಟಾರ್ ವರ್ಗೀಕರಣವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ <sup>*</sup></p>
													</div>
													<div class="form_input_file">
														<div class="file-upload-wrapper" data-text="Select your file!" id="div_mot_upload">
															<input id="img_MoT" name="img_MoT" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
															<div class="wizard-form-error"></div>
														</div>
														<div class="agent-form-file-view1" id="div_mot_firm" style="display: none">
															<a id="a_mot" href="" target="_blank">View</a>
															<button class="btn btn-danger removebtn" value="mot_document" name="mot_document" Sdivname="div_mot_upload" hdivname="div_mot_firm">Remove</button>
														</div>
													</div>	
												</div>

											
											<!--div class="agent-form-field" >
												<div class="agent-form-text">
													<label>Category of the Hotel/Resort / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ವರ್ಗ</label>
													<sup> * </sup>
													<p>(only applicable, if the hotel/resort is classified under Ministry of Tourism, Government of India)/ (ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಅನ್ನು ಕೇಂದ್ರ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ವರ್ಗೀಕರಿಸಿದರೆ ಮಾತ್ರ ಅನ್ವಯವಾಗುತ್ತದೆ.) ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ವರ್ಗ</p>
												</div>
												<div class="agent-form-input">
													<select name="cat_restaurant"  id="cat_restaurant" class="form-control">
														<option value="">Select Category</option>
														<option value="1-Star">1-Star</option>
														<option value="2-Star">2-Star</option>
														<option value="3-Star">3-Star</option>
														<option value="4-Star">4-Star</option>
														<option value="5-Star">5-Star</option>
														<option value="5-Star Deluxe">5-Star Deluxe</option>
													</select>
												</div>
											</div-->
										</div>


											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Total No. of Rooms in the Guest House  / ಅತಿಥಿಗೃಹದಲ್ಲಿನ ಒಟ್ಟು ಕೊಠಡಿಗಳ ಸಂಖ್ಯೆ  <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" onkeypress="return isNumbera(event,'number')" onkeyup="totalroomval('noofroom')"  name="no_rooms" class="new_required wizard-required" id="eno_rooms">
												</div>
												<div class="wizard-form-error"></div>
											</div>	
													<div class="alert-error" id="totalroom" style="display:none;margin-top: 26px;text-align: center;">
												<!--span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span--> 
												<?php echo "Since the Total Rooms are less than 10, the applications will not be moved further.";?>
											</div>
																				
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Total No. of Beds in the Guest House / ಅತಿಥಿಗೃಹದಲ್ಲಿರುವ ಹಾಸಿಗೆಗಳ ಒಟ್ಟು ಸಂಖ್ಯೆ  <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" id="eno_beds" name="no_beds" class="new_required" >
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Type of Accommodation Provided/ ಒದಗಿಸಲಾಗುವ ವಸತಿ ಪ್ರಕಾರ <sup> * </sup></p>
													</div>
													<div class="agent-form-input" id="accom_checkbox">
														<input type="checkbox" name="accommodation_type[]"  class="new_required wizard-required newcheckbox" id="eaccommodation_type" value="Suite Room"> &nbsp;<span>Suite Room / ಸೂಟ್ ರೂಮ್</span>
														<br>
														<input type="checkbox" name="accommodation_type[]"  class="newcheckbox new_required wizard-required" id="eaccommodation_type" value="Executive Room"> &nbsp;<span>Executive Room / ಕಾರ್ಯನಿರ್ವಾಹಕ ಕೊಠಡಿ</span>
														<br>
														<input type="checkbox" name="accommodation_type[]"  class="newcheckbox new_required wizard-required" id="eaccommodation_type" value="Deluxe Room"> &nbsp;<span>Deluxe Room / ಐಷಾರಾಮಿ ಕೊಠಡಿ</span>
														<br>
														<input type="checkbox" name="accommodation_type[]"  class="newcheckbox new_required wizard-required" id="eaccommodation_type" value="Dormitory"> &nbsp;<span>Dormitory / ವಸತಿ ನಿಲಯ</span>
														<br>
														 <input type="checkbox" name="accommodation_type[]"  class="newcheckbox new_required wizard-required" id="eaccommodation_type" value="Super Deluxe Room"> &nbsp;<span>Super Deluxe Room / ಸೂಪರ್ ಡಿಲಕ್ಸ್ ರೂಮ್</span>
														<br> 
														<input type="checkbox" name="accommodation_type[]"  class="newcheckbox new_required wizard-required" id="eaccommodation_type" value="Standard Room (Without AC)"> &nbsp;<span>Standard Room (Without AC) / ಸ್ಟ್ಯಾಂಡರ್ಡ್ ರೂಮ್ (ಎಸಿ ಇಲ್ಲದೆ)</span>
														<br>
														<input type="checkbox" name="accommodation_type[]"  class="newcheckbox new_required wizard-required" id="eaccommodation_type" value="Standard Room (With AC)"> &nbsp;<span>Standard Room (With AC)/ಸ್ಟ್ಯಾಂಡರ್ಡ್ ರೂಮ್ (ಎಸಿಯೊಂದಿಗೆ)</span>
														<br>
														<input type="checkbox"  class="new_required wizard-required newcheckbox" id="eaccommodation_type"  name="accommodation_type[]" value="other" onclick="specifyother(this,'othervalueadd')"> &nbsp;<span>Others (Please specify) / ಇತರರು (ದಯವಿಟ್ಟು ಸೂಚಿಸಿ)</span><br>
														<input style="display: none;" id="othervalueadd" type="text" name="accommodation_othertype[]">
														<!-- <div class="wizard-form-error"></div> -->
													</div>									
												</div><br>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Facilities Available in the Guest House /  ಅತಿಥಿ ಗೃಹದಲ್ಲಿ ಲಭ್ಯವಿರುವ ಸೌಲಭ್ಯಗಳು  <sup> * </sup></p>
													</div>
													<div class="agent-form-input" id="facility_checkbox">
														<input type="checkbox" name="facility_available[]" class="new_required wizard-required" 
														id="efacility_available" value="Car Parking"> &nbsp;<span>Car Parking /ವಾಹನ ನಿಲ್ದಾಣ </span>
														<br>
														<input type="checkbox" name="facility_available[]"  class="new_required wizard-required" id="efacility_available" value="Restaurant"> &nbsp;<span>Restaurant /ರೆಸ್ಟೋರೆಂಟ್ </span>
														<br>
														<input type="checkbox" name="facility_available[]"  class="new_required wizard-required" id="efacility_available" value="Bar"> &nbsp;<span>Bar / ಬಾರ್  </span>
														<!-- <br>
														<input type="checkbox" name="facility_available[]"  class="new_required wizard-required" id="efacility_available" value="Super Deluxe Room"> &nbsp;
														<span>Super Deluxe Room 
														</span> -->
														<br>
														<input type="checkbox" name="facility_available[]"  class="new_required wizard-required" id="efacility_available" value="Swimming Pool"> &nbsp;<span>Swimming Pool / ಈಜು ಕೊಳ</span>
														<br>
														<input type="checkbox" name="facility_available[]"  class="new_required wizard-required" id="efacility_available" value="Conference Hall"> &nbsp;<span>Conference Hall /ಸಮ್ಮೇಳನ ಸಭಾಂಗಣ</span>
														<br>
														<input type="checkbox" name="facility_available[]"  class="new_required wizard-required" id="efacility_available" value="CCTV"> &nbsp;<span>CCTV/ CCTV</span>
														<br>
														<input type="checkbox" class="" id="efacility_available" name="facility_available[]" value="other" onclick="specifyother(this,'othervaluefacility')">&nbsp;<span>Other Facilities (Please specify)/ಇತರೆ ಸೌಲಭ್ಯಗಳು (ದಯವಿಟ್ಟು ನಿರ್ದಿಷ್ಟಪಡಿಸಿ)</span><br>
														<input style="display: none;" id="othervaluefacility" type="text" name="otherfacility_available[]" >
														<!-- <div class="wizard-form-error"></div> -->
													</div>									
												</div>												
										</div>
										</div>
										<!-- <a class="add_button disable-click">Add / ಸೇರಿಸಿ</a> -->
										<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Name of the Owner/ Manager of the Guest House/ ಅತಿಥಿ ಗೃಹ ಮಾಲೀಕರ/ ಮ್ಯಾನೇಜರ್ ಹೆಸರು <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" id="eownername" class="new_required" name="ownername" onkeypress="return isNumbera(event,'albhabet')">
													<div class="wizard-form-error"></div>		
												</div>									
									</div>
									<div class="agent-form-field">
										<div class="agent-form-text">
											<p>Mobile Number/ ಮೊಬೈಲ್ ನಂಬರ್ <sup> * </sup></p>
										</div>
										<div class="agent-form-input">
											<input type="text" maxlength=10 onkeypress="return isNumber(event)" id="emobileNo" name="mobileNo" class="new_required" >
											<div class="wizard-form-error"></div>		
										</div>									
									</div>

									<div class="agent-form-field">
										<div class="agent-form-text">
											<p>Email Id of the Owner/Manager of the Guest House / ಅತಿಥಿ ಗೃಹದ ಮಾಲೀಕರ/ ವ್ಯವಸ್ಥಾಪಕರ ಇಮೇಲ್ ಐಡಿ</p>
										</div>
										<div class="agent-form-input">
											<input type="text" id="eowner_email" name="owner_email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$">
										</div>									
									</div>
									<div class="agent-form-field">
										<div class="agent-form-text">
											<p>Number of Permanent Employees / ಖಾಯಂ ನೌಕರರ ಸಂಖ್ಯೆ <sup> * </sup></p>
										</div>
										<div class="agent-form-input" style="    width: 25%;">
											<input type="text" maxlength=10 onkeypress="return isNumber(event)" placeholder="Male" name="permanent_emp_male" id="epermanent_emp_male" class="new_required" >
											<div class="wizard-form-error"></div>
										</div>
										&nbsp;&nbsp;
										<div class="agent-form-input" style="    width: 25%;margin-top: -43px;margin-left: 30%;">
											<input type="text" maxlength=10 onkeypress="return isNumber(event)"  placeholder="Female" name="permanent_emp_female"id="epermanent_emp_female" class="new_required" >
											<div class="wizard-form-error"></div>
										</div>							
									</div>

									<div class="agent-form-field">
										<div class="agent-form-text">
											<p>Number of Outsourced Employees / ಹೊರಗುತ್ತಿಗೆ ನೌಕರರ ಸಂಖ್ಯೆ <sup> * </sup></p>
										</div>
										<div class="agent-form-input" style="    width: 25%;">
											<input type="text" maxlength=10 onkeypress="return isNumber(event)"placeholder="Male" name="outsourced_emp_male" id="eoutsourced_emp_male" class="new_required" >
											<div class="wizard-form-error"></div>
										</div>
										&nbsp;&nbsp;
										<div class="agent-form-input" style="    width: 25%;margin-top: -43px;margin-left: 30%;">
											<input type="text" maxlength=10 onkeypress="return isNumber(event)"  placeholder="Female" name="outsourced_emp_female" id="eoutsourced_emp_female" class="new_required" >
											<div class="wizard-form-error"></div>
										</div>							
									</div>
										
									
									<div class="form-heading-location">
											<h4>Registered Guest House Address</h4>
											ಅತಿಥಿ ಗೃಹ ವಿಳಾಸ 
											<span>[Applicant to mention only the details of Guest House address in Karnataka for which registration under Department of Tourism is required]/(ಅರ್ಜಿದಾರರು ಕರ್ನಾಟಕದಲ್ಲಿ ಅತಿಥಿ ಗೃಹ ವಿಳಾಸದ ವಿವರಗಳನ್ನು ನಮೂದಿಸಲು ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಅಗತ್ಯವಿದೆ)
											</span>
									</div>
									<div id="other_address_div" >
										<!-- <div class="other-off-head other-off-no">
											<h4 id="address_1">Address /ವಿಳಾಸದ </h4>
										</div> -->
										<div class="other-off-addre">
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1<sup>*</sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_add1[]" id="eorg_addr1" class="">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2</p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_add2[]" id="eorg_addr2" class="">
												</div>									
											</div>										
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>District / ಜಿಲ್ಲೆ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select name="org_district_id[]" id="eorg_district" class="form-control org_city" onchange="showtaluk(0,'eorg_taluk','eorg_district')">
														<option value="">Select District</option>
														<?php
														$this->db->where(array('state_id' => '17'));
														$clients = $this->db->get('m_district')->result_array();
														foreach ($clients as $row):
														?>
														<option value="<?php echo $row['id']; ?>">
														<?php echo $row['name']; ?></option>
														<?php endforeach; ?>
													</select>
												</div>
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Taluk / ತಾಲೂಕು<sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select name="org_taluk[]"  class="org_taluk" id="eorg_taluk">
													<option value="">Select Taluk</option>	
													</select>				
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>City/Town/Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_city[]" class="" id="eorg_town">
												</div>
											</div>	
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text"  id="eorg_landmark" name="org_landmark[]" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>									
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
								
													<input type="text" maxlength="6" name="org_pincode_id[]" onkeypress="return isNumber(event)" id="eorg_pincode"  class="" onpaste="return false">
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ್ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" maxlength="10" name="org_mobile[]" onkeypress="return isNumber(event)" class="wizard-required" id="eorg_loc_mobile"   onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Telephone number / ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_telephone"  maxlength="10" onkeypress="return isNumber(event)"  id="eorg_loc_telephone"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Official Email Id of the Guest House  / ಅತಿಥಿ ಗೃಹದ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ  <sup> * </sup> </p>
												</div>
												<div class="agent-form-input">
													<input type="text" id="eguestemail" name="emailhotel[]" class="wizard-required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Total Built up Area of the Guest House (in Sq. Ft) /ಅತಿಥಿ ಗೃಹದ ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ) <sup> * </sup> </p>
												</div>
												<div class="agent-form-input">
													<input type="text" id="etotal_guest_build_area" onkeypress="return isNumbera(event,'number')"  name="total_guest_build_area" class="wizard-required" onpaste="return false" onkeyup="totalbuildfun('totalbuildfuna')">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											</div>												
												<input type="hidden" name="remove_ids" id="remove_ids">
										</div>
									</div>
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">	
										<p>"Data saving please wait"</p>
									</div>
									<div class="form-group clearfix" id="totalbuildnext">
										<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a>
									</div>
								</fieldset>							
								<fieldset class="wizard-fieldset comment-section">
									<div class="form-required">
										<div class="form-required-area">
											<h4>Required Documents / ಅಗತ್ಯವಿರುವ ದಾಖಲೆಗಳು</h4>
											<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB)</h5>
										</div>										
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration/Incorporation Certificate / ಸಂಸ್ಥೆಯ ನೋಂದಣಿ/ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
											
										</div>									
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_registration_upload">
														<input name="img_registration_certificate"  id="eimg_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_registration_certificate" style="display:none">
														<a id="a_registration_certificate" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="registration_certificate" Sdivname="div_registration_upload" hdivname="div_registration_certificate">Remove</button>
													</div>
												</div>
										
									</div>
									<div class="field-appli-form-padd.new" style="text-align: justify;">
										<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or </li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or</li> 
											<li>In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li>
											<br>
											ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
										    <li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ </li>
										    <li>ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ</li></p>
										</div>
									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Commencement Certificate of the Hotel/Resort/ ಹೋಟೆಲ್ / ರೆಸಾರ್ಟ್‌ನ ಪ್ರಾರಂಭ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
										</div>									
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_commercial_upload">
												<input id="eimg_commercial_certificate" name="img_commercial_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_commercial_certificate" style="display:none">
											<a id="a_registration_certificate" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="registration_certificate" Sdivname="div_commercial_upload" hdivname="div_commercial_certificate">Remove</button>
											</div>
										</div>
									</div> -->
									<!--div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ ಕಾಯ್ದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ</h5>
											<sup> *</sup>
											<p>(For Hotel/Resort)</p>
										</div>						
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload">
														<input name="img_certificate_shops" type="file" id="eimg_certificate_shops" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
														<a id="a_certificate_shops" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
													</div>
											</div>
									</div-->
									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate from Chartered Accountant/ ಶಾಸನಬದ್ಧ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ನ ಪ್ರಮಾಣಪತ್ರ  <sup> * </sup></h5>
											
											<p>Documentary proof of turn over in Indian or foreign exchange from Hotel/Resort related activities operations during the previous financial year/ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಆಗಿರುವ ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಸಂಬಂಧಿತ ವಹಿವಾಟಿನ  ( ಭಾರತೀಯ ಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದಲ್ಲಿ ) ದಾಖಲೆಗಳು  “ <br>• Certificate of Chartered Accountant on original letter head /  ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್‌ನ ಮೂಲ ಪ್ರಮಾಣಪತ್ರ<br>• Profit & Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟ ಹೇಳಿಕೆ. </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_img_ca_upload">
												<input name="img_ca_certificate" id="eimg_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_ca_certificate" style="display:none">
												<a id="a_img_ca" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn"name="ca_certificate" Sdivname="div_img_ca_upload" hdivname="div_ca_certificate">Remove</button>
											</div>
										</div>
									</div> -->
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Address Proof of the Guest House / ಅತಿಥಿ ಗೃಹದ ವಿಳಾಸ ಪುರಾವೆ <sup> * </sup> </h5>
											<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt / ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಅನಿಲ/ನೀರಿನ ಬಿಲ್ ಸೇರಿದಂತೆ ಆಸ್ತಿ ಅಥವಾ ಪುರಸಭೆಯ ತೆರಿಗೆ ರಶೀದಿ. ಈ ಬಿಲ್ ಮತ್ತು ರಶೀದಿಗಳು ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು. </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_bank_upload">
												<input name="img_bank_reference" id="eimg_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_bank_referencee" style="display:none" >
												<a id="a_bank_referencee" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="bank_referencee" name="bank_referencee" Sdivname="div_bank_upload" hdivname="div_bank_referencee">Remove</button>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5> Details of Guest House /  ಅತಿಥಿ ಗೃಹ ಸ್ಥಳದ ವಿವರಗಳು <sup> *</sup></h5>
											<p>Rent agreement/LeaseAgreement in case of rented property. Sale Deed & Property Tax in the case of owned property / (ಸ್ಥಳವನ್ನು ಬಾಡಿಗೆ ಪಡೆದ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ ಪತ್ರ. ಸ್ಥಳವು ಸ್ವಂತದ್ದಾಗಿದ್ದರೇ, ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ ಪತ್ರ ಲಗತ್ತಿಸಬೇಕು)</p>			
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_premises_upload">
														<input name="img_off_premises" id="eimg_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_premises" style="display:none">
														<a id="a_premises" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="off_premises" Sdivname="div_premises_upload" hdivname="div_off_premises">Remove</button>
													</div> 
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Guest House Interior / ಅತಿಥಿ ಗೃಹ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the Guest House / (ಅತಿಥಿ ಗೃಹ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
														<input name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
														<a id="a_buildInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
													</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Guest House Exterior /ಅತಿಥಿ ಗೃಹ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the Guest House / (ಅತಿಥಿ ಗೃಹ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
														<input name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
														<a id="a_builexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
													</div> 
										</div>
									</div>
									<!--div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h6>Copy of Trade License / ವ್ಯಾಪಾರ ಪರವಾನಗಿಯ ಪ್ರತಿ <sup> * </sup></h6>
										</div>
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_tradelic_upload">
												<input id="trade_lic" name="img_trade_lic" id="eimg_trade_lic" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_lic_firm" style="display: none;">
												<a id="a_trade_lic" href="" target="_blank">View</a>
													<button class="btn btn-danger removebtn" value="trade_lic" name="trade_lic" Sdivname="div_tradelic_upload" hdivname="div_lic_firm">Remove</button>
											</div>
										</div>
									</div-->
									
									<div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h6>Sanctioned Building Plans / Occupancy Certificate / Building Stability Certificate from a Chartered Engineer*/ ಮಂಜೂರಾದ ಕಟ್ಟಡ ಯೋಜನೆಗಳು/ಸ್ವಾಧೀನ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h6>
										</div>
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_occupancy_upload">
												<input id="eimg_occupancy_certificate" name="img_occupancy_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_occupancy_certificate" style="display:none">
												<a id="a_occupancy" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="buil_exterior" Sdivname="div_occupancy_upload" hdivname="div_occupancy_certificate">Remove</button>
											</div> 
										</div>										
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of GST registration/GST Identification number ಗುರುತಿನ ಸಂಖ್ಯೆ  <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_gstregis_upload">
														<input name="img_gst_regis" id="eimg_gst_regis" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_gst_regis" style="display:none">
														<a id="a_gstregis" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="gstregis" Sdivname="div_gstregis_upload" hdivname="div_gst_regis">Remove</button>
													</div>
										</div>
									</div>
									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pan_upload">
												<input name="img_pan_copy" id="eimg_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pan_copy" style="display:none">
												<a id="a_pancopy" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pan" Sdivname="div_pan_upload" hdivname="div_pan_copy">Remove</button>
											</div> 
										</div>
									</div> -->
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Certificate from FSSAI/ FSSAI ನಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_fssai_upload">
												<input name="img_fssai_certificate" id="eimg_fssai_certificate" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_fssai_certificate" style="display:none">
												<a id="a_fssai" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pan" Sdivname="div_fssai_upload" hdivname="div_fssai_certificate">Remove</button>
											</div>
										</div>
									</div>
									
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>No-Objection Certificate from Fire department / ಅಗ್ನಿಶಾಮಕ ಇಲಾಖೆಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ </h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_noobj_upload">
												<input name="img_noobj_certificate"id="eimg_noobj_certificate" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_noobj_certificate" style="display: none;">
												<a id="a_noobj_certificate" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="trade_lic" name="noobj_certificate" Sdivname="div_noobj_upload" hdivname="div_noobj_certificate">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate/License from Municipality/corporation/ Panchayat to show that your establishment is registered as a Guest House (Trade License) / "ನಿಮ್ಮ ಸಂಸ್ಥೆಯನ್ನು ಅತಿಥಿ ಗೃಹ ಎಂದು ನೋಂದಾಯಿಸಲಾಗಿದೆ ಎಂದು ತೋರಿಸುವ ಪುರಸಭೆ / ನಿಗಮ / ಪಂಚಾಯಿತಿಯ ಪ್ರಮಾಣಪತ್ರ / ಪರವಾನಗಿ ಪ್ರತಿ" <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_license_upload">
												<input name="img_license" id="eimg_license" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_license" style="display: none;">
												<a id="a_license" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="trade_lic" name="noobj_certificate" Sdivname="div_license_upload" hdivname="div_license">Remove</button>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>NOC from Pollution Control Board / ಮಾಲಿನ್ಯ ನಿಯಂತ್ರಣ ಮಂಡಳಿಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pollutionnoc_upload">
												<input name="img_pollution_noc" id="eimg_pollution_noc" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pollution_noc" style="display: none;">
												<a id="a_pollution_noc" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="trade_lic" name="noobj_certificate" Sdivname="div_pollutionnoc_upload" hdivname="div_pollution_noc">Remove</button>
											</div>
										</div>
									</div>
									
									<!--div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>NOC from Police Department / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್ಒಸಿ<sup> * </sup></h5>
										</div>									
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_commercial_upload">
												<input id="eimg_commercial_certificate" name="img_commercial_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_commercial_certificate" style="display:none">
											<a id="a_registration_certificate" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="registration_certificate" Sdivname="div_commercial_upload" hdivname="div_commercial_certificate">Remove</button>
											</div>
										</div>
									</div-->
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Copy of Trade Licence (ವ್ಯಾಪಾರ ಪರವಾನಗಿ)</h5>
											<p>If applicable</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_trade_licence_upload">
												<input name="img_trade_licence" id="eimg_trade_licence" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_trade_licence" style="display: none;">
												<a id="a_trade_licence" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="trade_licence" name="trade_licence" Sdivname="div_trade_licence_upload" hdivname="div_trade_licence">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Bar permit (ಅನ್ವಯಿಸಿದರೆ)</h5>
											<p>If applicable</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_bar_permit_upload">
												<input name="img_bar_permit" id="eimg_bar_permit" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_bar_permit" style="display: none;">
												<a id="a_bar_permit" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="bar_permit" name="bar_permit" Sdivname="div_bar_permit_upload" hdivname="div_bar_permit">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Declaration stating that the Guest House operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details (Foreign& Domestic) on the Karnataka Tourism Website / "“ ಅತಿಥಿ ಗೃಹ ಆಪರೇಟರ್ ಕಡ್ಡಾಯವಾಗಿ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರತಿ ತಿಂಗಳು ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆ." <sup> * </sup><br><a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>"style="color:red" download><u>Click here to download</u></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><i class="" aria-hidden="true"></i></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_arrivaldetail_upload">
												<input name="img_tourist_arrival_details" id="eimg_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_tourist_arrival_details" style="display:none">
														<a id="a_arrivaldetail" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="arrival_details" Sdivname="div_arrivaldetail_upload" hdivname="div_tourist_arrival_details">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_board_entity" style="display:none">
												<a id="a_boardentityr" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="board_entity" Sdivname="div_boardentity_upload" hdivname="div_board_entity">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism / "ಸುರಕ್ಷಿತ ಮತ್ತು ಗೌರವಾನಿತ್ವ ಪ್ರವಾಸೋದ್ಯಮ” ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞಾ ಪತ್ರಕ್ಕೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ <sup> * </sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>"style="color:red" download><u>Click here to download</u></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><i class="" aria-hidden="true"></i></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pledge_upload">
												<input name="img_pledge_commitment" id="eimg_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pledge_commitment" style="display:none">
												<a id="a_pledge" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pledge" Sdivname="div_pledge_upload" hdivname="div_pledge_commitment">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>NOC from Ministry of Environment & Forests (wherever applicable)/ "ಪರಿಸರ ಮತ್ತು ಅರಣ್ಯ ಸಚಿವಾಲಯದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ(ಅನ್ವಯವಾಗುವಲ್ಲೆಲ್ಲಾ)"</h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_noc_environment_upload">
												<input name="img_noc_environment" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_noc_environment" style="display:none">
												<a id="a_noc_environment" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pledge" Sdivname="div_noc_environment_upload" hdivname="div_noc_environment">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>NOC from Airport Authority of India for Guest house located near the Airport (wherever applicable) /ಅತಿಥಿ ಗೃಹ ಏರಪೋರ್ಟ್ ಹತ್ತಿರದಲ್ಲಿದ್ದರೇ, ಭಾರತದ ವಿಮಾನ ನಿಲ್ದಾಣ ಪ್ರಾಧಿಕಾರದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_noc_airport_upload">
												<input name="img_noc_airport" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_noc_airport" style="display:none">
												<a id="a_noc_airport" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pledge" Sdivname="div_noc_airport_upload" hdivname="div_noc_airport">Remove</button>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>CRZ clearance (wherever applicable)/ CRZ ಕ್ಲಿಯರೆನ್ಸ್ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ) </h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_crz_clearance_upload">
												<input name="img_crz_clearance" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_crz_clearance" style="display:none">
												<a id="a_crz_clearance" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pledge" Sdivname="div_crz_clearance_upload" hdivname="div_crz_clearance">Remove</button>
											</div>
										</div>
									</div>
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">	
										<p>"Data saving please wait"</p>
									</div>									
									<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous / ಹಿಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ </a>
										<a href="javascript:;" id="ajaxformsubmit" class="form-wizard-next-btn float-right">Application Fee / ಅರ್ಜಿಯ ಶುಲ್ಕ</a>
										<!-- <a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a> -->
									</div>
								</fieldset>							
									
								
								<fieldset id="payment-det" class="wizard-fieldset payment-det">		
							</form>	
									<div class="other-detail-option">
										<div class="agent-application">				
											<div class="user-payment-details">
												<div class="user-payment">
													<div class="payment-title">
														<h3>Payment</h3>
													</div>
													<div class="payment-details">
														<div class="payment-amount">
															<p>Payable Amount</p>
															<p>Pament Method</p>
														</div>
														<div class="payment-value">
															<p>Rs. 500.00</p>
															<p>Online payment</p>
														</div>
													</div>
													<input type="text" name="insertidd" style="display:none;"  id="insertidd">
													<div class="payment-options">
														

													<input type="text" style="display:none;" id="applmob" value=""/>
													<input type="text" style="display:none;" id="applemail" value=""/>
													<input type="text" style="display:none;" id="card_holder_name_ida" value=""/>
													<!--form name="razorpay-form" id="razorpay-form" action="<?php echo $callback_url; ?>" method="POST">
													<input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id" />
													<input type="hidden" name="merchant_order_id" id="merchant_order_id" value="<?php echo $merchant_order_id; ?>"/>
													<input type="hidden" name="merchant_trans_id" id="merchant_trans_id" value="<?php echo $txnid; ?>"/>
													<input type="hidden" name="merchant_product_info_id" id="merchant_product_info_id" value="<?php echo $description; ?>"/>
													<input type="hidden" name="merchant_surl_id" id="merchant_surl_id" value="<?php echo $surl; ?>"/>
													<input type="hidden" name="merchant_furl_id" id="merchant_furl_id" value="<?php echo $furl; ?>"/>
													<input type="hidden" name="card_holder_name_id" id="card_holder_name_id" value=""/>
													<input type="hidden" name="merchant_total" id="merchant_total" value="<?php echo $total; ?>"/>
													<input type="hidden" name="merchant_amount" id="merchant_amount" value="<?php echo $amount; ?>"/>
													</form>
													<input  id="pay-btn" style="float:right;"  onclick="razorpaySubmit(this);" value="Pay Now" class="btn btn-primary" /-->

	<button type="button" style="float:right;" id="JsCheckoutPayment" name="submit" class="btn btn-primary">Pay Now</button>

														<!-- razoor pay ends -->
													</div>
												</div>
											</div>
										</div>
									</div>
							
									<div class="form-group clearfix">
										<!--a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a-->
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center">Save as draft</a> -->
										<!--input type="submit" name="app_submit" value="Submit" class="form-wizard-submit float-right"--> 										
									</div>
								</fieldset>	

<style>
	.admin-dashboard .agent-application .form-wizard .agent-loc-off-address .agent-form-field .agent-form-input {
    float: left;
    position: relative;
    width: 55%;
}
	.admin-dashboard .agent-application .form-wizard .agent-loc-off-address .agent-form-field .agent-form-text {
    float: left;
    position: relative;
    width: 40%;
    margin-right: 30px;
}
	.form-wizard .form-wizard-steps li {
    width: 33%;
    float: left;
    position: relative;
}
.body{
	margin: revert!important;
}

.admin-dashboard .agent-application .form-wizard .agent-form .form_input_file {
    float: right;
    position: relative;
    width: 45%;
}


.admin-dashboard .agent-application .form-wizard .agent-form .form_input {
    float: right;
    position: relative;
    width: 45%;
}
</style>


<script type="text/javascript">
	function specifyother(d,id)
	{		
		if ($(d).is(':checked')) 
		{
			// alert("all is well");
			// console.log(d.value);
			$('#'+id).show();
		}
		else
		{
			$('#'+id).hide();
		}
	}
	function society_enable(id)
	{
		console.log(id);
		var val=$('input[id="'+id+'"]:checked').val();
		
			if(val=='yes')
			{
				// $("#"+value).removeClass("disable-click");
				$("#"+id).prop('checked', false);
			}
			else
			{
				// $("#"+value).addClass("disable-click");
				$("#"+id).prop('checked', false);
			}
	}
	$(function(){
		// alert("test123");
    var dtToday = new Date();
    // alert(dtToday);
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

   	// alert($('#org_commencement_date').val());
    $('#eorg_commencement_date').attr('max', maxDate);
    $('#etrade_lic_date').attr('max', maxDate);
    $('#eorg_registration_date').attr('max', maxDate);
      
});
</script>	
<script>	
function totalroomval(id) 
{
  var x = document.getElementById(id).value;
  //console.log(x);
  if(x < 10){
  	$('#totalbuildnext').hide();
  	$('#totalroom').show();
  }
  else{
  	$('#totalbuildnext').show();
  	$('#totalroom').hide();
  }
}	
function showdropdown(e)
{
	if(e.value=='17')
	{
		$("#eloc_district").show();
		$("#eloc_districtnew").hide();
		$("#eloc_taluk_office").show();
		$("#eloc_taluk_office_new").hide();
		$("#eloc_districtnew").removeClass("wizard-required");
		$("#eloc_taluk_office_new").removeClass("wizard-required");
	}
	else
	{
		$("#eloc_district").hide();
		$("#eloc_districtnew").show();
		$("#eloc_taluk_office").hide();
		$("#eloc_taluk_office_new").show();
		$("#eloc_districtnew").addClass("wizard-required");
		$("#eloc_taluk_office_new").addClass("wizard-required");
	}
}
</script>	
						