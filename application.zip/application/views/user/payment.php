<?php include 'include/header.php';?>
<?php if($this->session->flashdata('msg')):?>
				<div class="alert">
			  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
			</div>

			<?php endif; ?>


			<?php
//echo $reg_amt;
			?>
		<div class="agent-application">				
			<div class="user-payment-details">
				<div class="user-payment">
					<div class="payment-title">
						<h3>Payment</h3>
					</div>
					<div class="payment-details">
						<div class="payment-amount">
							<p>Payable Amount</p>
							<p>Pament Method</p>
						</div>
						<div class="payment-value">
							<p>Rs. 4000.00</p>
							<p>Online payment</p>
						</div>
					</div>
					<?php if($approvalForPayment > 0){ ?>
					<div class="payment-options">
						<!--p>RazorPay  <?php echo CI_VERSION; ?></p-->
						<?php
						//$currency_code = "INR";
						//$callback_url ="";
						//$surl="";
						//$furl="";
						$pay_amount = $reg_amt;
						$description        = $appId;
						$txnid              = date("YmdHis");     
						$key_id             = "rzp_test_8ITHhhrlaWgT4p";
						$currency_code      = $currency_code;            
						$total              = (100* 4000); // 100 = 1 indian rupees
						$amount             = '4000';
						$merchant_order_id  = "KTTF-".date("YmdHis");
						$card_holder_name   = $applicant_name;
						$email              = $official_email;
						$phone              = '9000000001';
						$name               = "RazorPay ";
						?>

    <form name="razorpay-form" id="razorpay-form" action="<?php echo $callback_url; ?>" method="POST">
        <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id" />
        <input type="hidden" name="merchant_order_id" id="merchant_order_id" value="<?php echo $merchant_order_id; ?>"/>
        <input type="hidden" name="merchant_trans_id" id="merchant_trans_id" value="<?php echo $txnid; ?>"/>
        <input type="hidden" name="merchant_product_info_id" id="merchant_product_info_id" value="<?php echo $description; ?>"/>
        <input type="hidden" name="merchant_surl_id" id="merchant_surl_id" value="<?php echo $surl; ?>"/>
        <input type="hidden" name="merchant_furl_id" id="merchant_furl_id" value="<?php echo $furl; ?>"/>
        <input type="hidden" name="card_holder_name_id" id="card_holder_name_id" value="<?php echo $card_holder_name; ?>"/>
        <input type="hidden" name="merchant_total" id="merchant_total" value="<?php echo $total; ?>"/>
        <input type="hidden" name="merchant_amount" id="merchant_amount" value="<?php echo "4000"; ?>"/>
    </form>

    <!--table>
        <tr>
            <th>No.</th>
            <th>Product Name</th>
            <th>Cost</th>
        </tr>
        <tr>
            <td>1</td>
            <td>HeadPhones</td>
            <td>1 Rs</td>
        </tr>
    </table-->
    
    <input  id="pay-btn" type="submit" onclick="razorpaySubmit(this);" value="Pay Now" class="btn btn-primary" />

					<!-- razoor pay ends -->
					</div>
					<?php } ?>


<?php if($appdetails[0]->payment_id): ?>
	<a class="btn btn-primary"  href="<?php echo base_url().'applications/reports/'.$appdetails[0]->id ?>" target="_blank" >View Pyment Details</a> 
<?php endif;?>

					<div class="payment-dashboard">
						<a href="<?php echo base_url().'dashboard';?>">Back to Dashboard</a>
					</div>
					<!--div class="payment-history">
						<h3>Payment History</h3>
						<div class="page-content">	
							<div class="tabbed">
								<input type="radio" id="tab1" name="css-tabs" checked>
								<input type="radio" id="tab2" name="css-tabs">							
								
								<ul class="tabs">
									<li class="tab"><label for="tab1">Successful</label></li>
									<li class="tab"><label for="tab2">Failed</label></li>								
								</ul>								
								<div class="tab-content">
									<div class="payment-table">
										<div style="overflow:auto">
											<table>
												<tbody>
													<tr class="app-tn-head">
														<th>SI.No</th>
														<th>Description</th>
														<th>Status</th>
														<th>Payment Channel</th>
														<th>Date</th>
														<th>Amount</th>
														<th>Receipt</th>													
													</tr>
													<tr>
														<td>1</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>01-MD</td>													
														<td><a href="#">View</a></td>
													</tr>
													<tr>
														<td>2</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>Municipality</td>
														<td><a href="#">View</a></td>
													</tr>
												</tbody>
											</table>
										</div>										
									</div>
								</div>								
								<div class="tab-content">
									<div class="payment-table">
										<div style="overflow:auto">
											<table>
												<tbody>
													<tr class="app-tn-head">
														<th>SI.No</th>
														<th>Description</th>
														<th>Status</th>
														<th>Payment Channel</th>
														<th>Date</th>
														<th>Amount</th>
														<th>Receipt</th>													
													</tr>
													<tr>
														<td>1</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>01-MD</td>													
														<td><a href="#">View</a></td>
													</tr>
													<tr>
														<td>2</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>Municipality</td>
														<td><a href="#">View</a></td>
													</tr>
												</tbody>
											</table>
										</div>										
									</div>
								</div>							
							</div>							
						</div>
					</div-->
				</div>
			</div>
		</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        var options = {
            key:            "<?php echo $key_id; ?>",
            amount:         "<?php echo $total; ?>",
            name:           "<?php echo $name; ?>",
            description:    "Order # <?php echo $merchant_order_id; ?>",
            netbanking:     true,
            currency:       "<?php echo $currency_code; ?>", // INR
            prefill: {
                name:       "<?php echo $card_holder_name; ?>",
                email:      "<?php echo $email; ?>",
                contact:    "<?php echo $phone; ?>"
            },
            notes: {
                soolegal_order_id: "<?php echo $merchant_order_id; ?>",
            },
            handler: function (transaction) {
                document.getElementById('razorpay_payment_id').value = transaction.razorpay_payment_id;
                document.getElementById('razorpay-form').submit();
            },
            "modal": {
                "ondismiss": function(){
                    location.reload()
                }
            }
        };

        var razorpay_pay_btn, instance;
        function razorpaySubmit(el) {
            if(typeof Razorpay == 'undefined') {
                setTimeout(razorpaySubmit, 200);
                if(!razorpay_pay_btn && el) {
                    razorpay_pay_btn    = el;
                    el.disabled         = true;
                    el.value            = 'Please wait...';  
                }
            } else {
                if(!instance) {
                    instance = new Razorpay(options);
                    if(razorpay_pay_btn) {
                    razorpay_pay_btn.disabled   = false;
                    razorpay_pay_btn.value      = "Pay Now";
                    }
                }
                instance.open();
            }
        }  
    </script>
<?php include 'include/footer.php';?>
