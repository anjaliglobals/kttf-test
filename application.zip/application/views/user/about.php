<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<div class="agent-application">				
			<section class="wizard-section">
				<div class="no-gutters">			
					<div class="col-lg-12 col-md-12">
						<div class="form-wizard">
							<h3>About Karnataka Tourism Trade (Facilitation and Regulation) Act 2015 &nbsp; &nbsp;  &nbsp;  &nbsp;   <a class="btn btn-danger" href="<?php echo base_url().'dashboard';?>">Back</a></h3>
								 <?php
									$this->db->where('id', $_SESSION['usrID']);
									$userdata = $this->db->get('usr_register')->row();
								?>
								<br><br>

							<div class="container">

<div class="row">
	
<div class="col-md-12">
	
<p style="text-align:justify;">Department of Tourism (DoT), set up in 1974, focuses on implementing Tourism Projects and undertaking Overseas / Domestic promotion and publicity. It has 30 district offices. It aggressively promotes the state, and its sustained marketing promotions and campaigns have finally made the world sit up and take notice of the 'Many Worlds' that make up this vibrant state.</p>

<p style="text-align:justify;">There are 4 government undertakings functioning under the DoT, namely Karnataka State Tourism Development Corporation (KSTDC), Jungle Lodges and Resorts (JLR), Karnataka Tourism Infrastructure Limited (KTIL) and Karnataka Exhibition Authority (KEA), Mysore.</p>
</br>
<h4>Contact Us</h4>
</br>

<p style="text-align:justify;">
<span style="font-size:16px;font-weight:700;">Department of Tourism, Government of Karnataka</span><br>
49, 2nd Floor,Khanija Bhavan, Race Course Road,<br>
Bengaluru, Karnataka 560001.<br>
080-2235 2424, info@karnatakatourism.org.
</p>

</br>
<h4>Terms & Conditions</h4>
</br>

<p style="text-align:justify;">
Any Registered Agent across India, Must have a Valid GST Number.<br>
Rs.500 for one time registration.
</br></br>

 <span style="font-size:16px;font-weight:700;">No Refund or Cancellation</span>
</p>
</div>

</div>




							</div>
						</div>
					</div>
				</div>
			</section>
		</div>


<style>
a.add_button {background: #0e984c;color: #fff;padding: 10px 20px;border-radius:3px;cursor:pointer;}
.other-off-head h4, .other-off-no label{color: #ca0027;font-size: 25px;}
a.remove_button {float: right;margin: 15px 0 0;background: #ca0027;color: #fff;padding: 10px;border-radius: 3px;cursor:pointer;}
.other-off-addre {float: left;position: relative;width: 100%;margin-bottom: 20px;}
</style>
<?php include 'include/footer.php';?>
