<?php include 'include/header.php';?>
<?php
require_once("./lib/check/config.php");
?>
<script type="application/javascript" crossorigin="anonymous" src="<?php echo PAYTM_ENVIRONMENT; ?>/merchantpgpui/checkoutjs/merchants/<?php echo PAYTM_MID; ?>.js">
</script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<?php
$prod_id = $_GET['apid'];
$pid = $_GET['id'];
$new_pid = $_GET['new_id'];

?>
<!----Start NEWW------>
<?php if(!empty($pid)){
	//echo $pid;
 $comm_date = $this->db->get_where('application', array('id' => $pid))->row()->org_commencement_date;

 //echo $commsplit[1];
 ?>
<script>
$(function()
{
var comm_d = <?php echo "'".$comm_date."'" ?>;
var maxDate = comm_d;

//alert(maxDate);
    
    $('#eorg_commencement_date').attr('min', maxDate);
});
</script>
<?php
}
?>

<style>
@media (min-width: 768px){}
#paytm-checkoutjs.ptm-own-element .offer-desktop-view, #paytm-checkoutjs.ptm-own-element .paytm-wrapper {
    height: 90%;
    max-width: 500px;
    top: 5%;
}
}
</style>
<!----End NEWW------>

<style type="text/css">
	.agent-form-file-view1 {position: relative;width: 100%;padding: 6px 4%;text-align: center;}
	.agent-form-file-view1 a {background: #178597;color: #fff;padding: 10px 20px;border-radius: 3px;}
</style>
<div class="agent-application">				
			<section class="wizard-section">
				<div class="no-gutters">			
					<div class="col-lg-12 col-md-12">
						<div class="form-wizard">
							<?php if($prod_id == 1){?>
								<h3>KTTF Application for Travel Agents / Tour Operator</h3>
							<?php }?>
							<?php if($prod_id == 2){?>
								<h3>KTTF Application for Tourist Transport Operator</h3>
							<?php }?>
							<?php if($prod_id == 3){?>
								<h3>KTTF Application for Caravan Tourism</h3>
							<?php }?>
							<?php if($prod_id == 4){?>
								<h3>KTTF Application for Hotel / Resort</h3>
							<?php }?>
							<?php if($prod_id == 5){?>
								<h3>KTTF Application for Restaurants</h3>
							<?php }?>
							<?php if($prod_id == 6){?>
								<h3>KTTF Application for Amusement Park</h3>
							<?php }?>
							<?php if($prod_id == 7){?>
								<h3>KTTF Application for Guest House</h3>
							<?php }?>

							<?php
      
      $result['orderId'] = $result['orderId'];
    //echo $result['orderId']
      ?>

								<div class="form-wizard-header">								
									<ul class="list-unstyled form-wizard-steps clearfix">
										<li class="active"><span>1</span><span class="verify">General Info</span></li>
										<li><span>2</span><span class="verify">Documents</span></li>
										<?php if($prod_id <= 3 && $new_pid <= 3) 
										{?>
										<li><span>3</span><span class="verify">Other Details</span></li>
										<li><span>4</span><span class="verify">Payment</span></li>
										<?php }?>
										<?php if($prod_id > 3 || $new_pid>3){?>
											<li><span>3</span><span class="verify">Payment</span></li>
										<?php }?>

									</ul>
								</div>	
							<?php
								if($pid==0 && $prod_id <=3)
							{?>
							<form  method="post" role="form" enctype="multipart/form-data"  id="formSave123">
								<fieldset id="general-verify" class="wizard-fieldset general-verify show">
									<input hidden type="text" id="proId" value="<?php echo $prod_id ?>">
									<input style="display:none;" type="text" name="pg_orderid" id="pg_orderid" value="<?php echo $result['orderId']; ?>">
									<div class="agent-form">
										<div class="form_label">
											<!-- <p>Full Name of the Entity / ಸಂಸ್ಥೆಯ ಪೂರ್ಣ ಹೆಸರು<br>(Firm/Company/Limited Liabilities Partnership/Proprietorship) / <br>(ಸಂಸ್ಥೆ/ಕಂಪನಿ/ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ/ಮಾಲೀಕತ್ವ) <sup> * </sup></p> -->
											<p>Trade Name/ ವ್ಯಾಪಾರ ಹೆಸರು <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="hidden" name="product_id" value="<?php echo $prod_id; ?>">
											<input type="text" onkeypress="return isNumbera(event,'albhabet')" style="text-transform:capitalize;" name="applicant_name" value="" class="">
											<!-- wizard-required <div class="wizard-form-error"></div> -->
											<input type="hidden" class="" name="insid_draft" style="display:block;"  id="insid_draft">
											<!-- wizard-required -->
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Legal Name / ಕಾನೂನು ಹೆಸರು <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" onkeypress="return isNumbera(event,'albhabet')" style="text-transform:capitalize;" name="legal_name" id="elegal_name" value="" class="">
										</div>
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>In which name you need a certificate to be printed ? / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ನಿಮಗೆ ಮುದ್ರಿಸಲು ಪ್ರಮಾಣಪತ್ರ ಬೇಕು <sup> * </sup></p>
										</div>
										<div class="form_input">
										<select name="certificate_name" id="certificate_name" class="form-control wizard-required">
											<option value="">Select Type</option>
											<option value="1">Legal name</option>
											<option value="2">Trade Name</option>
										</select>
										<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Entity Type / ಸಂಸ್ಥೆಯ ಪ್ರಕಾರ <sup> * </sup></p>
											<!-- <sup>*</sup> -->
										</div>
										<div class="form_input">
										<select name="org_type_id" id="org_type_id" class="form-control wizard-required">
											<option value="">Select Entity Type</option>
											<?php
											$this->db->where('isactive', '1');
											$clients = $this->db->get('m_organization_nature')->result_array();
											//print_r($this->db->last_query());
											foreach ($clients as $row):
											?>
											<option value="<?php echo $row['id']; ?>">
											<?php echo $row['name']; ?></option>
											<?php endforeach; ?>
										</select>
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Date of Registration/Incorporation of the Entity<br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Karnataka Shops and Establishment Act) / "ನೋಂದಣಿಯ ದಿನಾಂಕ / "ಸಂಸ್ಥೆಯ ನೋಂದಣಿ / ಸಂಯೋಜನೆಯ ದಿನಾಂಕ* (ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956 /2013 ಅಥವಾ ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ ಪ್ರಕಾರ)" <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="date" name="org_commencement_date" id="org_commencement_date" class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Date of registration of entity as per Karnataka shops and establishment act /  ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ಘಟಕ ನೋಂದಣಿಯಾದ ದಿನಾಂಕ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="date" name="org_shop_date" id="org_shop_date" class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<?php if($pid==0 && $prod_id ==3) {?>
									<div class="agent-form">
										<div class="form_label">
											<p>Date of issue of Trade License/ ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನೀಡಲಾದ ದಿನಾಂಕ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="date" name="trade_lic_date"  class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>

									<div class="agent-form" >
										<div class="form_label">
											<p>Copy of Trade License / ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></p>
										</div>
										<div class="form_input_file">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input id="trade_lic" name="img_trade_lic" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
								<?php } ?>

									<div class="agent-form">
										<div class="form_label">
											<p>Recognised Under Ministry Of Tourism, Government of India/ ಭಾರತ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಮಾನ್ಯತೆ ಪಡೆದಿದೆಯೇ? <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck" onclick="javascript:yesnoCheck('yesCheck','ifYes','reg_firm');" name="central_gov_approved" value="Yes">										
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck" onclick="javascript:yesnoCheck('noCheck','ifYes','reg_firm');" name="central_gov_approved" value="no">
											<label for="no">No</label>											
										</div>									
									</div>
									<div class="agent-form" style="display:none;" id="ifYes">
										<div class="form_label">
											<p>Upload Registration Document / ನೋಂದಣಿ ಡಾಕ್ಯುಮೆಂಟ್ ಅನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ <sup> * </sup></p>
										</div>
										<div class="form_input_file">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input id="reg_firm" name="img_central_gov_registration" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>		
									</div>									
									<div class="agent-form">
										<div class="form_label">
											<p>Full Name of the properator / Directors / Partners/ ಮಾಲೀಕರು / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪೂರ್ಣ ಹೆಸರು <sup> * </sup></p>
											<!-- <?php if($prod_id != 2){?><?php }?> -->
												<!-- <p>Applicants Name <br> ಅರ್ಜಿದಾರರ ಹೆಸರು <sup> * </sup></p> -->
											<!-- <p>Name of Proprietor / Directors / Partners  <br> ಮಾಲೀಕರ / ನಿರ್ದೇಶಕರ / ಪಾಲುದಾರರ ಹೆಸರು </p>-->
											<!-- <?php if($prod_id == 2){?>
												<p>Full Name of the properator / Directors / Partners <sup> * </sup></p>
											<?php }?> -->
										</div>
										<div class="form_input">
											<input type="text" onkeypress="return isNumbera(event,'albhabet')" name="proprietor_name" class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>GST Identification Number /ಜಿ ಎಸ್ ಟಿ ಗುರುತಿನ ಸಂಖ್ಯೆ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" maxlength=15 name="gst_number" value=""class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>PAN Number / ಪ್ಯಾನ್ ಸಂಖ್ಯೆ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" maxlength=10  name="pan_number" value="" class="wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು URL</p>
										</div>
										<div class="form_input">
											<input type="text"   name="website_name" value="">
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Official email id of the Entity / ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ </p>
											<!-- <sup> * </sup> -->
										</div>
										<div class="form_input">
											<input type="email" name="official_email" class="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="">
											<!-- wizard-required<div class="wizard-form-error"></div> -->
										</div>
									</div>
									<div class="agent-form">
										<div class="form_label">			
											<p>Whether the member of Karnataka Tourism Society (KTS)? / ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ಸೊಸೈಟಿಯ (KTS) ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup>*</sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck_kts" onclick="javascript:yesnoCheck_d1('yesCheck_kts','ifYes_kts','div_member_kts_upload');" name="member_kts" value="yes">	
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck_kts" onclick="javascript:yesnoCheck_d1('noCheck_kts','ifYes_kts','div_member_kts_upload');" name="member_kts" value="no">
											<label for="no">No</label>	
											<input hidden type="text" name="member_recognised_trade_new" id="emember_recognised_trade_new" >
										</div>
									</div>
									<div class="agent-form" style="display:none;" id="ifYes_kts">
										<div class="form_label">
											<p>Upload Registration Document / ನೋಂದಣಿ ಡಾಕ್ಯುಮೆಂಟ್ ಅನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ<sup>*</sup></p>
										</div>
										<div class="form_input_file">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_member_kts_upload">
												<input id="img_member_kts" name="img_member_kts" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_member_kts" style="display: none">
												<a id="a_member_kts" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="reg_document" name="member_kts" Sdivname="div_member_kts_upload" hdivname="div_member_kts">Remove</button>
											</div>
										</div>
									</div>
									<div  class="agent-form" style="display:none;" id="nodiv">
										<span><a style="color: red;" href="https://www.karnatakatourismsociety.org/" target="_blank">Note: Register in KTS <span style='color:blue'>https://www.karnatakatourismsociety.org</span> to avail Benefits from Government</a></span>
									</div>
									<div class="form-heading-location">
											<h4>Registered Office Address / ನೋಂದಾಯಿತ ಕಚೇರಿ ವಿಳಾಸ </h4>
											<span>[Applicant to mention only the details of office address for which registration under Department of Tourism is required] / (ಅರ್ಜಿದಾರರು  ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿಗೆ ಅಗತ್ಯವಿರುವ ಕರ್ನಾಟಕದಲ್ಲಿನ ಕಚೇರಿ ವಿಳಾಸದ ವಿವರಗಳನ್ನು ಮಾತ್ರ ನಮೂದಿಸಬೇಕು)
											</span>
											<!--span><input type="checkbox" name="sameas" id="sameas"/>Same as above</span-->
									</div>
									<div class="agent-loc-off-address">
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1<sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_add1" id="loc_addr1" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2  </p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_add2" id="loc_addr2" class="">
													<!-- <sup> * </sup><div class="wizard-form-error"></div> -->
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>District / ಜಿಲ್ಲೆ  <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select name="org_loc_district_id" id="loc_district" class="form-control wizard-required">
														  <option value="">Select District</option>
														  <?php
														  	$this->db->where(array('state_id' => '17'));
															$clients = $this->db->get('m_district')->result_array();
															foreach ($clients as $row):	?>
															<option value="<?php echo $row['id']; ?>">
															<?php echo $row['name']; ?></option>
														  <?php endforeach; ?>
													</select>
													<div class="wizard-form-error"></div>
												</div>									
											</div>										
											
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Taluk / ತಾಲೂಕು <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<select name="org_loc_taluk_id" class="form-control wizard-required" id="loc_taluk">
														<option value="">Select Taluk</option>
													</select>
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>City / Town / Village <br> ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text"  id="org_loc_city" name="org_loc_city" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್  <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text"  id="org_loc_landmark" name="org_loc_landmark" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" maxlength="6" onkeypress="return isNumber(event)" name="org_loc_pincode_id" id="org_loc_pincode_id" class="wizard-required"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ <sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" maxlength="10" name="org_loc_mobile" onkeypress="return isNumber(event)" class="wizard-required" id="loc_mob"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Telephone number / ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_loc_telephone"  maxlength="10" onkeypress="return isNumber(event)"  id="loc_tele"  onpaste="return false">
													<div class="wizard-form-error"></div>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Total Build Area(Sq.ft) / ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ)  <sup> * </sup> </p>
												</div>
												<div class="agent-form-input">
													<input type="text" id="totalbuildfuna" onkeypress="return isNumbera(event,'number')"  name="org_total_build_sqft" class="wizard-required" onpaste="return false" onkeyup="totalbuildfun('totalbuildfuna')">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
									</div>
									<div class="form-heading">
										<h4>Other Office Addresses / ಇತರ ಕಚೇರಿ ವಿಳಾಸಗಳು</h4>
									</div>
									
									<div class="agent-off-address">
										<h6 style="color:red;">Note: Please Enter "0" if there is no other offices / ಸೂಚನೆ: ಬೇರೆ ಯಾವುದೇ ಕಚೇರಿಗಳಿಲ್ಲದಿದ್ದರೆ ದಯವಿಟ್ಟು "0" ಅನ್ನು ನಮೂದಿಸಿ</h6>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Number of Offices in Karnataka / ಕರ್ನಾಟಕದಲ್ಲಿರುವ ಕಚೇರಿಗಳ ಸಂಖ್ಯೆ <sup> * </sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="Nuumber_offices" id="no_off" class="wizard-required Nuumber_offices" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" onchange="chkval()" >
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										<div id="other_address_div" style="display: none;">
										<div class="other-off-head other-off-no">
											<h4 id="address_1">Address 1 / ವಿಳಾಸ 1</h4>
										</div>
										<div class="other-off-addre">
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1<sup> * </sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_add1[]" id="org_addr1" class="new_required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2</p>
												</div>
												<!-- <sup><?php if($prod_id == 2 || $prod_id == 3){ ?> * <?php }?></sup> -->
												<div class="agent-form-input">
													<input type="text" name="org_add2[]" id="org_addr2" class="">
													<!-- <?php echo(($prod_id == 2 || $prod_id == 3) ? "wizard-required":"")?> -->
													 <?php if($prod_id == 2 || $prod_id == 3){ ?>
													 	<div class="wizard-form-error"></div>
													 <?php }?>
												</div>									
											</div>										
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>District / ಜಿಲ್ಲೆ <sup><?php if($prod_id == 2 || $prod_id == 3){ ?> * <?php }?></sup></p>
												</div>
												<div class="agent-form-input">
													<select name="org_district_id[]" id="org_city"  class="form-control org_city new_required">
														<!-- <?php echo(($prod_id == 2 || $prod_id == 3) ? "wizard-required":"")?>> -->
														<option value="">Select District</option>
														 <?php
															$this->db->where(array('state_id' => '17'));
															$clients = $this->db->get('m_district')->result_array();
															foreach ($clients as $row):
																?>
																<option talk_attr="org_taluk" value="<?php echo $row['id']; ?>">
																<?php echo $row['name']; ?></option>
															<?php endforeach; ?>
													</select>	
													<?php if($prod_id == 2 || $prod_id == 3){ ?>
													 	<div class="wizard-form-error"></div>
													 <?php }?>											
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Taluk / ತಾಲೂಕು<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> * <?php }?></sup></p>
												</div>
												<div class="agent-form-input">
												<select name="org_taluk" class="org_taluk new_required" id="org_taluk">
												<!-- <?php echo(($prod_id == 2 || $prod_id == 3) ? "wizard-required":"")?>" --> 									
												<option value="">Select Taluk</option>
												</select>
												<?php if($prod_id == 2 || $prod_id == 3){ ?>
													 <div class="wizard-form-error"></div>
												<?php }?>
												</div>									
											</div>
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>City/Town/Village <br> ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_city[]" class="new_required" id="org_town">
													<!-- <?php echo(($prod_id == 2 || $prod_id == 3) ? "wizard-required":"")?> -->
													<?php if($prod_id == 2 || $prod_id == 3){ ?>
													 	<div class="wizard-form-error"></div>
													<?php }?>
												</div>									
											</div>										
											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Pincode / ಪಿನ್‌ಕೋಡ್<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> * <?php }?></sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" maxlength="6" name="org_pincode_id[]" onkeypress="return isNumber(event)" id="org_pincode" class="new_required" onpaste="return false">
													<!-- <?php echo(($prod_id == 2 || $prod_id == 3) ? "wizard-required":"")?> -->
													<?php if($prod_id == 2 || $prod_id == 3){ ?>
													 	<div class="wizard-form-error"></div>
													<?php }?>
												</div>									
											</div>

											<div class="agent-form-field">
												<div class="agent-form-text">
													<p>Contact Number / ಸಂಪರ್ಕ ಸಂಖ್ಯೆ <sup><?php if($prod_id == 2 || $prod_id == 3){ ?> * <?php }?></sup></p>
												</div>
												<div class="agent-form-input">
													<input type="text" name="org_mobile[]" maxlength="10" onkeypress="return isNumber(event)" onpaste="return false" class="new_required" id="org_mob">
													<!-- <?php echo(($prod_id == 2 || $prod_id == 3) ? "wizard-required":"")?> -->
													<?php if($prod_id == 2 || $prod_id == 3){ ?>
													 	<div class="wizard-form-error"></div>
													<?php }?>	
												</div>									
											</div>											
										</div>
										</div>
										<a class="add_button disable-click">Add / ಸೇರಿಸಿ</a>
									</div>

									<?php if ($prod_id == 2 || $prod_id==3){ ?>
									<div class="tour-operator">
											<div class="tour-orepator-vehicle  col-md-12">
												<div class="form-group col-md-6">
												<label><?php echo ($prod_id == 2 ? "Number of Vehicles Viz AC Coaches, Non-AC Coaches, Mini Coaches, Cars and Boats operated as tourist Vehicles/ಎಸಿ ಕೋಚ್‌ಗಳು, ಎಸಿ ರಹಿತ ಕೋಚ್‌ಗಳು, ಮಿನಿ ಕೋಚ್‌ಗಳು, ಕಾರುಗಳು ಮತ್ತು ಬೋಟ್‌ಗಳು ಸೇರಿದಂತೆ ಪ್ರವಾಸಿ ವಾಹನಗಳಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವ ವಾಹನಗಳ ಸಂಖ್ಯೆ":"Number of Caravans/Campervans/ಕಾರವಾನ್/ಕ್ಯಾಂಪರ್‌ವಾನ್‌ಗಳ ಸಂಖ್ಯೆ") ?> <sup> * </sup> </label>
												</div>
												<div class="form-group col-md-6">
													<input type="text" name="veh_count" id="veh_count">
												</div>	
											</div>											
											<div class="vehicle-detail">
												<div class="multi-field-wrapper">
													<div class="multi-field-head">
														<div class="form-group col-md-12">
															<div class="form-group col-md-3">
																<label><?php echo ($prod_id == 2 ? "Vehicle Type/ ವಾಹನದ ಪ್ರಕಾರ *":"Caravan Type/ ಕಾರವಾನ್ ಪ್ರಕಾರ *") ?> <sup> * </sup>
																</label>	
															</div>
															<div class="form-group col-md-3">

															<?php if($prod_id==2){?>
																<select class="vehicle-form wizard-required dropdownchange" name="vehicle_type[]" required="">
																	<option value="" showvalue="othervalue">Vehicle Type</option>
																	<option value="Cars" showvalue="othervalue">Car</option>
																	<option value="Bus" showvalue="othervalue">Bus</option>
																	<option value="AC Coaches" showvalue="othervalue">AC Bus</option>
																	<option value="Non-AC Coaches" showvalue="othervalue">Non-AC Bus</option>
																	<option value="Mini Coaches" showvalue="othervalue">Mini Coaches</option>																					
																	<option value="Boats" showvalue="othervalue">Boats</option>
																	<option value="Others" showvalue="othervalue">Others</option>
																</select>	
																<br> &nbsp;
																	<input style="display: none;" id="othervalueadd" type="text" name="othervalue[]">
															<?php }?>
															<?php if($prod_id==3){?>
																<input type="text" name="vehicle_type[]">
															<?php }?>
																<div class="wizard-form-error">
																</div>
															</div>
															<div class="form-group col-md-3">
																<label>Permit Type / ನೀಡಲಾದ ಅನುಮತಿ ಪ್ರಕಾರ <sup> * </sup>
																</label>	
															</div>
															<div class="form-group col-md-3">
																<select class="vehicle-form wizard-required " name="permit_type[]" required="">
																	<option value="">Permit Type</option>
																	<option value="Karnataka Permit" >Karnataka Permit</option>
																	<option value="All India Permit">All India Permit 
																	</option>
																</select>
																<div class="wizard-form-error">
																</div>
															</div>
														</div>
														<div class="form-group col-md-12">
															<div class="form-group col-md-3">
																<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Permit Number/ ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಿಗೆ ಸಂಖ್ಯೆ:":"Caravan Vehicle Permit Number /ಕಾರವಾನ್ ವಾಹನದ ಪರವಾನಿಗೆ ಸಂಖ್ಯೆ:") ?> <sup> * </sup>
																</label>
															</div>
															<div class="form-group col-md-3">
																<input class="vehicle-form wizard-required" type="text" name="tourist_permit[]">
																<div class="wizard-form-error"></div>
															</div>
															<div class="form-group col-md-3">
																<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Registration Number/ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ:":"Caravan Vehicle Registration Number/ ಕಾರವಾನ್ ವಾಹನದ ನೋಂದಣಿ ಸಂಖ್ಯೆ:") ?> <sup> * </sup></label>	
															</div>
															<div class="form-group col-md-3">
																<input class="vehicle-form wizard-required" type="text" name="registration_no[]">	
																<div class="wizard-form-error"></div>	
															</div>
															
														</div>
														<div class="form-group col-md-12">
															<div class="form-group col-md-3">
																<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Registration in the Name of/  ಈ ಹೆಸರಿನಲ್ಲಿ ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಮಾಡಲಾಗಿದೆ ":"Caravan Registration in the Name / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ಕಾರವಾನ್ ನೋಂದಣಿ ಮಾಡಲಾಗಿದೆ")?> <sup> * </sup></label>
															</div>
															<div class="form-group col-md-3">
																<input class="vehicle-form wizard-required" type="text"  name="registration_name[]" style="text-transform:capitalize;" onkeypress="return isNumbera(event,'albhabet')">
																<div class="wizard-form-error"></div>
															</div>
															<div class="form-group col-md-3">
															<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Permit Start date / ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಿಗೆ ಆರಂಭದ ದಿನಾಂಕ:":"Caravan vehicle permit start date/ ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಿಗೆ ಆರಂಭದ ದಿನಾಂಕ:")?><sup> * </sup></label>
															</div>
															<div class="form-group col-md-3">
															<input type="date" name="tourist_permit_date[]" class="vehicle-form wizard-required datefreeze">
															<div class="wizard-form-error"></div>
															</div>
														</div>
														<div class="form-group col-md-12">
														<div class="form-group col-md-3">
															<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Permit End date/ ಪ್ರವಾಸಿ ವಾಹನ ಅನುಮತಿಯ ಅಂತಿಮ ದಿನಾಂಕ:":"Caravan vehicle permit End date/ ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಿಗೆ ಅಂತಿಮ ದಿನಾಂಕ:")?> <sup> * </sup></label>
															<!-- <label>Vehicle end date:</label> -->
														</div>
														<div class="form-group col-md-3">
															<input type="date" name="tourist_permit_end_date[]"  class="vehicle-form wizard-required">
															<div class="wizard-form-error"></div>
														</div>
														</div>
														
													</div>
												</div>
											</div>
											<div class="form-group col-md-12"><hr class="new4"></div>
											<div class="vehicle-detail_new">
											</div>
											<div class="form-add">	
												<button type="button" class="add-field" onclick="addnewvehicle('add')"> <i class="fa fa-plus"></i>Add</button>
											</div> 
									</div>
									<div id="vehicle_details"></div>
									<?php } ?>
									
									<div class="alert-error" id="totalbuilderr" style="display:none;margin-top: 26px;text-align: center;color:red">
											<!--span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span--> 
											<p>"Since the Total Built Up area is less than 150 sq. ft, the application will not be moved further."</p>
									</div>

									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">										
											<p>"Data saving please wait"</p>
									</div>
											
									<div class="form-group clearfix" id="totalbuildnext">
										<!-- <a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft 1 / ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a>
 -->
										<a href="javascript:;" class="form-wizard-next-btn float-right" id="nextpage"  style="display: none;">Next / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right draftdata" id="draftdata">Next/ ಮುಂದಿನದು</a>

									</div>
								</fieldset>
							<?php if ($prod_id == 1){ ?>
								<fieldset class="wizard-fieldset comment-section">
									<div class="form-required">
										<div class="form-required-area">
											<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
											<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB) / ಅನುಮತಿಸಲಾದ ಡಾಕ್ಯುಮೆಂಟ್ ಪ್ರಕಾರ .JPG, .PNG, .PDF (2MB ಗಿಂತ ಕಡಿಮೆ)</h5>
										</div>										
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration 1/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>
															</div>									
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_registration_upload">
												<input onchange="singleFileUpload('eimg_registration_certificate');" name="img_registration_certificate" id="eimg_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" data-max-size="204" >
												<div class="wizard-form-error"></div>
												 <p id="size"></p>
											</div>
											<div class="agent-form-file-view1" id="div_registration_certificate" style="display:none">
														<a id="a_registration_certificate" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="registration_certificate" Sdivname="div_registration_upload" hdivname="div_registration_certificate">Remove</button>
													</div>
										</div>
									</div>
									<div class="field-appli-form-padd.new">
									<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or</li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or </li>
											<li> In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li><br>
									<br>ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
											<li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ</li>
											<li>"ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</li></p>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ</h5>
											<sup> * </sup>
										</div>						
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload"> 
												<input onchange="singleFileUpload('eimg_certificate_shops');" name="img_certificate_shops" id="eimg_certificate_shops" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
														<a id="a_certificate_shops" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
													</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ <sup> * </sup> </h5>
											<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt / ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು. </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_bank_upload">
												<input onchange="singleFileUpload('eimg_bank_reference');" name="img_bank_reference" id="eimg_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_bank_referencee" style="display:none" >
												<a id="a_bank_referencee" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="bank_referencee" name="bank_referencee" Sdivname="div_bank_upload" hdivname="div_bank_referencee">Remove</button>
											</div>
										</div>
									</div>
									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate from Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ <br><sup> * </sup>												
											</h5>
											<p>Documentary proof of turn over in Indian or foreign exchange from tour related activities operations during the previous financial year which should not beless than Rs. 7.5 Lakh“ / ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಪ್ರವಾಸಿ ಸಾರಿಗೆ ಸಂಬಂಧಿತ ಸಕ್ರಿಯ ಚಟುವಟಿಕೆಗಳಿಂದ ಮಾಡಲಾದ  ಭಾರತೀಯಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದ ಟರ್ನ್ ಓವರ್ ಕುರಿತು ದಸ್ತಾವೇಜಿನ ಪುರಾವೆ. ಟರ್ನ್ ಓವರ್ 7.5 ಲಕ್ಷ ರೂ ಗಳಿಗಿಂತ ಕಡಿಮೆ ಇರಬಾರದು.<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <br>• Profit & Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>	 -->								
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>List of Directors / Partners / Name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup>*</sup></h5>
											<p>List of Directors/Partners or name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು.</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_list_patners_upload">
												<input  onchange="singleFileUpload('eimg_list_patners');" name="img_list_patners" id="eimg_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_list_patners" style="display:none">
														<a id="a_list_partners" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_list_patners" name="list_patners" Sdivname="div_list_patners_upload" hdivname="div_list_patners">Remove</button>
													</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Brochures or Leaflets / ಕರಪತ್ರಗಳು <sup> *</sup></h5>
											<p>Brochures or leaflets brought out by the firms having all information about their activities /"ಸಂಸ್ಥೆಗಳು ಹೊರತಂದಿರುವ ಮತ್ತು ಸಂಸ್ಥೆಗಳ  ಚಟುವಟಿಕೆಗಳ ಕುರಿತು ಎಲ್ಲ ಮಾಹಿತಿಗಳನ್ನು ಹೊಂದಿರುವ ಕರಪತ್ರಗಳು"</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_brochures_upload">
												<input onchange="singleFileUpload('eimg_brochures');" name="img_brochures" id="eimg_brochures" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_img_brochures" style="display:none">
												<a id="a_img_brochers" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_brochures"  name="img_brochures" Sdivname="div_brochures_upload" hdivname="div_img_brochures">Remove</button>
											</div>											
										</div>
									</div>
									
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5> Details of Office Premises / ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು<sup> * </sup></h5>
											<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ </p>			
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_premises_upload">
												<input onchange="singleFileUpload('eimg_off_premises');" name="img_off_premises" id="eimg_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_off_premises" style="display:none">
												<a id="a_premises" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_off_premises" name="off_premises" Sdivname="div_premises_upload" hdivname="div_off_premises">Remove</button>
											</div> 
										</div>
									</div>

									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5> Labour Department Certificate / ಕಾರ್ಮಿಕ ಇಲಾಖೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></h5>	
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_labour_department" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div> -->
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / <br> ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup>*</sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_photoarrested_upload">
												<input onchange="singleFileUpload('eimg_md_photo_attested');" name="img_md_photo_attested" id="eimg_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_md_photo_attested" style="display:none">
												<a id="a_photo_attested" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_md_photo_attested" name="photo_attested" Sdivname="div_photoarrested_upload" hdivname="div_md_photo_attested">Remove</button>
											</div> 
										</div>										
									</div>

							<div class="field-app-form">
								<div class="field-appli-form-padd">
									<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
									<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ) </p>
								</div>										
							<div class="field-comment-sec">
									<div class="file-upload-wrapper" data-text="Select your file!" id="div_powerof_attorney_upload">
										<input onchange="singleFileUpload('eimg_power_of_attorney');" name="img_power_of_attorney" id="eimg_power_of_attorney" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
										<div class="wizard-form-error"></div>
									</div>
									<div class="agent-form-file-view1" id="div_power_of_attorney" style="display:none">
										<a id="a_powerof_attorney" href="" target="_blank">View</a>
										<button class="btn btn-danger removebtn" docname="eimg_power_of_attorney" name="power_of_attorney" Sdivname="div_powerof_attorney_upload" hdivname="div_power_of_attorney">Remove</button>
									</div> 
								</div>										
							</div>
<!-- <div class="field-app-form">
	<div class="field-appli-form-padd">
		<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ<sup>*</sup></h5>
		<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
		<input type="text" hidden="" name="file_type" id="file_type">
	</div>
	<div class="field-comment-sec" >
		<div class="form_input" id="yes_d4">
			<input  type="radio" class="checkupload" id="yesCheck_d4" onclick="javascript:yesnoCheck_doc('yesCheck_d4','div_attorney_upload','yes_d4');"  value="1">	
			<label for="yes">Power Of Attorney / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ</label>
			<input type="radio" class="checkupload" id="noCheck_d4" onclick="javascript:yesnoCheck_doc('noCheck_d4','div_attorney_upload','yes_d4');"  value="2">
			<label for="no">Board Resolution / ಮಂಡಳಿ ನಿರ್ಣಯ </label>
		</div>
		<div class="file-upload-wrapper" style="display: none" data-text="Select your file!" id="div_attorney_upload" id="div_powerof_attorney_upload">
			<input onchange="singleFileUpload('eimg_power_of_attorney');" name="img_power_of_attorney" id="eimg_power_of_attorney" type="file" class="file-upload-field addflag"  value="" accept="image/jpeg,image/gif,image/png,application/pdf">
				  <div class="error_div"></div>  
		</div>
		<div class="agent-form-file-view1" id="div_power_of_attorney" style="display:none">
			<a id="a_powerof_attorney" href="" target="_blank">View</a>
			<button class="btn btn-danger removebtn" docname="eimg_power_of_attorney" name="power_of_attorney" Sdivname="div_powerof_attorney_upload" hdivname="div_power_of_attorney">Remove</button>
		</div> 
	</div>
</div> -->
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup>*</sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
												<input onchange="singleFileUpload('eimg_off_buil_exterior');" name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
											<a id="a_builexterior" href="" target="_blank">View</a>
											<button class="btn btn-danger removebtn" docname="eimg_off_buil_exterior" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
										</div> 
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Interior / ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup>*</sup></h6>											
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
												<input onchange="singleFileUpload('eimg_off_buil_interior');" name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
												<a id="a_buildInterior" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_off_buil_interior" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
											</div>
										</div>
									</div>
									
									<div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರನ್ನು ಹೇಳುವ ಮಂಡಳಿಯ ಹೆಸರಿನೊಂದಿಗೆ ಕಟ್ಟಡದ ಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_boardentity_upload">
												<input onchange="singleFileUpload('eimg_board_entity');" name="img_board_entity" id="eimg_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_board_entity" style="display:none">
											<a id="a_boardentityr" href="" target="_blank">View</a>
											<button class="btn btn-danger removebtn" docname="eimg_board_entity" name="board_entity" Sdivname="div_boardentity_upload" hdivname="div_board_entity">Remove</button>
										</div>
										</div>
										
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of GST Registration Certificate / ಜಿ ಎಸ್ ಟಿ  ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_gstregis_upload">
												<input onchange="singleFileUpload('eimg_gst_regis');" name="img_gst_regis" id="eimg_gst_regis" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_gst_regis" style="display:none">
												<a id="a_gstregis" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_gst_regis" name="gstregis" Sdivname="div_gstregis_upload" hdivname="div_gst_regis">Remove</button>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pan_upload">
												<input onchange="singleFileUpload('eimg_pan_copy');" name="img_pan_copy" id="eimg_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pan_copy" style="display:none">
												<a id="a_pancopy" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_pan_copy" name="pan" Sdivname="div_pan_upload" hdivname="div_pan_copy">Remove</button>
											</div>
										</div>
									</div>
									<!-- <div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input onchange="singleFileUpload('eimg_board_entity');" name="img_board_entity" id="eimg_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div> -->
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Declaration stating that the travel agent on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website./ " ಪ್ರತಿ ತಿಂಗಳು ತಪ್ಪದೇ  ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆಯನ್ನು ಅರ್ಜಿದಾರನು ಕಡ್ಡಾಯವಾಗಿ ಅಪಲೋಡ್ ಮಾಡಬೇಕು."<sup>*</sup><br><a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>"style="color:red;" download><u>Click here to download</u></a></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_arrivaldetail_upload">
												<input onchange="singleFileUpload('eimg_tourist_arrival_details');" name="img_tourist_arrival_details" id="eimg_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_tourist_arrival_details" style="display:none">
														<a id="a_arrivaldetail" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_tourist_arrival_details" name="arrival_details" Sdivname="div_arrivaldetail_upload" hdivname="div_tourist_arrival_details">Remove</button>
													</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”. / "ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ <sup>*</sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" style="color:red;" download=""><u>Click here to download</u></a></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pledge_upload">
												<input onchange="singleFileUpload('eimg_pledge_commitment');" name="img_pledge_commitment" id="eimg_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pledge_commitment" style="display:none">
												<a id="a_pledge" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_pledge_commitment" name="pledge" Sdivname="div_pledge_upload" hdivname="div_pledge_commitment">Remove</button>
											</div>
										</div>
									</div>
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">										
										<p>"Data saving please wait"</p>
									</div>
																			
									<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 7 / ಹಿಂದಿನದು</a>
										<!-- 
										<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a> -->

										<a href="javascript:;" class="form-wizard-next-btn float-right" id="nextpage1"  style="display: none;">Next1 / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right draftdata_stage3" id="draftdata_stage3">Next/ ಮುಂದಿನದು</a>
									</div>
								</fieldset>
							<?php }?>
							<?php if ($prod_id == 2){ ?>
								<fieldset class="wizard-fieldset comment-section">
									<div class="form-required">
										<div class="form-required-area">
											<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು </h4>
											<h5>Allowed Document Type  only .PDF(less than 2MB) / ಅನುಮತಿಸಲಾದ ಡಾಕ್ಯುಮೆಂಟ್ ಪ್ರಕಾರ .PDF (2MB ಗಿಂತ ಕಡಿಮೆ)</h5>
										</div>										
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>
													</div>									
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_registration_upload">
												<input onchange="singleFileUpload('eimg_registration_certificate');" name="img_registration_certificate" id="eimg_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_registration_certificate" style="display:none">
												<a id="a_registration_certificate" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_registration_certificate" name="registration_certificate" Sdivname="div_registration_upload" hdivname="div_registration_certificate">Remove</button>
											</div>
										</div>
									</div>
									<div class="field-appli-form-padd.new">
									<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or</li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or </li>
											<li> In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li><br>
									<br>ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
											<li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ</li>
											<li>"ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</li></p>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ</h5>
											<sup> *</sup>
										</div>						
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload">
												<input onchange="singleFileUpload('eimg_certificate_shops');" name="img_certificate_shops" id="eimg_certificate_shops" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
													<a id="a_certificate_shops" href="" target="_blank">View</a>
													<button class="btn btn-danger removebtn" docname="eimg_certificate_shops" name="certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
												</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ<sup>*</sup> </h5>
											<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt./ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.  </p> <sup> * </sup>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_bank_upload">
												<input onchange="singleFileUpload('eimg_bank_reference');" name="img_bank_reference" id="eimg_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_bank_referencee" style="display:none" >
														<a id="a_bank_referencee" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_bank_reference" value="bank_referencee" name="bank_referencee" Sdivname="div_bank_upload" hdivname="div_bank_referencee">Remove</button>
													</div>
										</div>
									</div>
									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate from Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ <sup> * </sup> <br> 
											</h5>
											<p>Documentary proof of turn over in Indian or foreign exchange from Tourist transport related activated operations during the previous financial year which should not beless than Rs. 7.5 Lakh / ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಪ್ರವಾಸಿ ಸಾರಿಗೆ ಸಂಬಂಧಿತ ಸಕ್ರಿಯ ಚಟುವಟಿಕೆಗಳಿಂದ ಮಾಡಲಾದ  ಭಾರತೀಯಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದ ಟರ್ನ್ ಓವರ್ ಕುರಿತು ದಸ್ತಾವೇಜಿನ ಪುರಾವೆ. ಟರ್ನ್ ಓವರ್ 7.5 ಲಕ್ಷ ರೂ ಗಳಿಗಿಂತ ಕಡಿಮೆ ಇರಬಾರದು. <br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <br>• Profit & Loss statement /ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್.</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div> -->									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>List of Directors / Partners / Name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></h5>
											<p>List of Directors/Partners or name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_list_patners_upload">
												<input onchange="singleFileUpload('eimg_list_patners');" name="img_list_patners" id="eimg_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_list_patners" style="display:none">
												<a id="a_list_partners" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_list_patners" name="list_patners" Sdivname="div_list_patners_upload" hdivname="div_list_patners">Remove</button>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Brochures or Leaflets / ಕರಪತ್ರಗಳು <sup> * </sup></h5>
											<p>Brochures or leaflets brought out by the firms having all information about their activities / "ಸಂಸ್ಥೆಗಳು ಹೊರತಂದಿರುವ ಮತ್ತು ಸಂಸ್ಥೆಗಳ  ಚಟುವಟಿಕೆಗಳ ಕುರಿತು ಎಲ್ಲ ಮಾಹಿತಿಗಳನ್ನು ಹೊಂದಿರುವ ಕರಪತ್ರಗಳು"</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_brochures_upload">
												<input onchange="singleFileUpload('eimg_brochures');" name="img_brochures" id="eimg_brochures" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>	
											<div class="agent-form-file-view1" id="div_img_brochures" style="display:none">
											<a id="a_img_brochers" href="" target="_blank">View</a>
											<button class="btn btn-danger removebtn" docname="eimg_brochures" name="img_brochures" Sdivname="div_brochures_upload" hdivname="div_img_brochures">Remove</button>
										</div>										
										</div> 
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of GST Registration Certificate / ಜಿ ಎಸ್ ಟಿ  ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup> </h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_gstregis_upload">
												<input onchange="singleFileUpload('eimg_gst_regis');" name="img_gst_regis" id="eimg_gst_regis" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
												<div class="wizard-form-error"></div>
											</div>
										<div class="agent-form-file-view1" id="div_gst_regis" style="display:none">
												<a id="a_gstregis" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_gst_regis" name="gstregis" Sdivname="div_gstregis_upload" hdivname="div_gst_regis">Remove</button>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pan_upload">
												<input onchange="singleFileUpload('eimg_pan_copy');" name="img_pan_copy" id="eimg_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pan_copy" style="display:none">
												<a id="a_pancopy" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_pan_copy" name="pan" Sdivname="div_pan_upload" hdivname="div_pan_copy">Remove</button>
											</div> 
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Copies of State Permit valid for Karnataka / All-India Permit tourist permits issued by the concerned Transport Department for Tourist Vehicles/ "ಕರ್ನಾಟಕ ರಾಜ್ಯದಲ್ಲಿ  ಮಾನ್ಯವಾಗುವ ರಾಜ್ಯ ಪರವಾನಗಿಯ ಪ್ರತಿಗಳು / ಪ್ರವಾಸಿ ವಾಹನಗಳಿಗಾಗಿ ಸಂಬಂಧಿತ ಸಾರಿಗೆ ಇಲಾಖೆಯಿಂದ ನೀಡಲಾದ ಪ್ರವಾಸಿ ಪರವಾನಗಿ ಪ್ರತಿಗಳು"  <sup> * </sup></h5>
											<p> For more than 1 vehicle valid permits for all the vehicles must be uploaded in a single pdf /"1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು  ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು."</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_statepermit_upload">
												<input onchange="singleFileUpload('eimg_state_permit');" name="img_state_permit" id="eimg_state_permit" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_state_permit" style="display:none">
											<a id="a_state_permit" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_state_permit" name="permit" Sdivname="div_statepermit_upload" hdivname="div_pan_copy">Remove</button>
											</div> 											
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration Certificate of Tourist Vehicles / ಪ್ರವಾಸಿ ವಾಹನಗಳ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ </h5>
											<!-- <sup> *</sup> -->
											<p>For more than 1 vehicle valid registration certificate for all the vehicles must be uploaded in a single pdf/1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು  ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_tourvehicle_upload">
												<input onchange="singleFileUpload('eimg_tourist_vehicle');" name="img_tourist_vehicle" id="eimg_tourist_vehicle" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_tourist_vehicle" style="display:none">
												<a id="a_tourist_vehicle" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_tourist_vehicle" name="tourist_vehicle" Sdivname="div_tourvehicle_upload" hdivname="div_tourist_vehicle">Remove</button>
											</div> 											
										</div>
									</div>
									
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5> Details of Office Premises / ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು <sup> *</sup></h5>
											<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ</p>			
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_premises_upload">
												<input onchange="singleFileUpload('eimg_off_premises');" name="img_off_premises" id="eimg_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_off_premises" style="display:none">
												<a id="a_premises" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_off_premises" name="off_premises" Sdivname="div_premises_upload" hdivname="div_off_premises">Remove</button>
											</div> 
										</div>
									</div>

									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Labour Department Certificate / ಕಾರ್ಮಿಕ ಇಲಾಖೆ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>		
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_labour_department" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div> -->
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / <br> ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_photoarrested_upload">
												<input onchange="singleFileUpload('eimg_md_photo_attested');" name="img_md_photo_attested" id="eimg_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_md_photo_attested" style="display:none">
												<a id="a_photo_attested" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_md_photo_attested" name="photo_attested" Sdivname="div_photoarrested_upload" hdivname="div_md_photo_attested">Remove</button>
										</div> 
										</div>
										
									</div>
									<!-- <div class="field-app-form">
									<div class="field-appli-form-padd"></div>										
										<div class="field-comment-sec" >											
											<input type="checkbox" class="checkupload" id="auth_rep" onclick="javascript:enable_attoney();" value="1">&nbsp;&nbsp;
											<input type="text" hidden="" id="auth_rep_val" name="auth_rep_val" >
											<label><h5>Authorized Representative of the Entity / ಘಟಕದ ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿ</h5></label>
										</div>
									</div>
									<div class="field-app-form" style="display: none;" id="attorney_boardresolution">
										<div class="field-appli-form-padd">
											<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
											<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
											<input type="text" hidden="" name="file_type" id="file_type">
										</div>
										<div class="field-comment-sec" >
											<div class="form_input" id="yes_d4">
												<input type="radio" class="checkupload" id="yesCheck_d4" onclick="javascript:yesnoCheck_doc('yesCheck_d4','div_attorney_upload','yes_d4');"  value="1">	
												<label for="yes">Power Of Attorney / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ</label>
												<input type="radio" class="checkupload" id="noCheck_d4" onclick="javascript:yesnoCheck_doc('noCheck_d4','div_attorney_upload','yes_d4');"  value="2">
												<label for="no">Board Resolution / ಮಂಡಳಿ ನಿರ್ಣಯ </label>
											</div>
											<div class="file-upload-wrapper" style="display: none" data-text="Select your file!" id="div_attorney_upload">
												<input name="img_power_of_attorney" type="file" class="file-upload-field addflag"  value="" accept="image/jpeg,image/gif,image/png,application/pdf">
													 <div class="error_div"></div>  
											</div>
										</div>
									</div> -->
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
												<input onchange="singleFileUpload('eimg_off_buil_exterior');" name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
												<a id="a_builexterior" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_off_buil_exterior" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
											</div> 
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Interior / ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h6>											
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
												<input onchange="singleFileUpload('eimg_off_buil_interior');" name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
											<a id="a_buildInterior" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_off_buil_interior" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
											</div>
										</div>
									</div>
									
									<div class="field-app-form" hidden>
										<div class="field-appli-form-padd">
											<h5>Photograph of at least 1 Tourist Vehicle Exterior/ಕನಿಷ್ಠ 1 ಪ್ರವಾಸಿ ವಾಹನಗಳ ಫೋಟೋಗ್ರಫಿ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_vehicleexterior_upload">
												<input onchange="singleFileUpload('eimg_vehicle_exterior');" name="img_vehicle_exterior" id="eimg_vehicle_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>	
										<div class="agent-form-file-view1" id="div_vehicle_exterior" style="display:none">
											<a id="a_vehicleexterior" href="" target="_blank">View</a>
											<button class="btn btn-danger removebtn" name="vehicle_exterior" Sdivname="div_vehicleexterior_upload" hdivname="div_vehicle_exterior">Remove</button>
										</div>										
										</div>
									</div>
									 <div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h5>Photograph of the at least 1 Tourist Vehicle Interior/ಕನಿಷ್ಠ 1 ಪ್ರವಾಸಿ ವಾಹನ ಒಳಾಂಗಣದ ಫೋಟೋಗ್ರಫಿ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_vehicleinterior_upload">
												<input onchange="singleFileUpload('eimg_vehicle_interior');" name="img_vehicle_interior" id="eimg_vehicle_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										<div class="agent-form-file-view1" id="div_vehicle_interior" style="display:none">
											<a id="a_vehicleInterior" href="" target="_blank">View</a>
											<button class="btn btn-danger removebtn" name="vehicle_interior" Sdivname="div_vehicleinterior_upload" hdivname="div_vehicle_interior">Remove</button>
										</div>											
										</div>
									</div> 
									<div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_boardentity_upload">
												<input onchange="singleFileUpload('eimg_board_entity');" name="img_board_entity" id="eimg_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_board_entity" style="display:none">
												<a id="a_boardentityr" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_board_entity" name="board_entity" Sdivname="div_boardentity_upload" hdivname="div_board_entity">Remove</button>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Declaration stating that the TTO on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website/"ಟಿಟಿಒಗಳು ಮಾಸಿಕ ಆಧಾರದ ಮೇಲೆ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬುದರ ಕುರಿತು ಘೋಷಣೆ"<sup> * </sup><br><a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>"style="color:red;" download><u>Click here to download</u></a></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_arrivaldetail_upload">
												<input onchange="singleFileUpload('eimg_tourist_arrival_details');" name="img_tourist_arrival_details" id="eimg_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_tourist_arrival_details" style="display:none">
												<a id="a_arrivaldetail" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_tourist_arrival_details"  name="tourist_arrival_details" Sdivname="div_arrivaldetail_upload" hdivname="div_tourist_arrival_details">Remove</button>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”. / "ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ <sup>  *  </sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" style="color:red;" download=""><u>Click here to download</u></a></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_pledge_upload">
												<input onchange="singleFileUpload('eimg_pledge_commitment');" name="img_pledge_commitment" id="eimg_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_pledge_commitment" style="display:none">
												<a id="a_pledge" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_pledge_commitment" name="pledge" Sdivname="div_pledge_upload" hdivname="div_pledge_commitment">Remove</button>
											</div>
										</div>
									</div>
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">											
										<p>"Data saving please wait"</p>
									</div>									
									<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 11/ ಹಿಂದಿನದು</a>
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a> -->

											<a href="javascript:;" class="form-wizard-next-btn float-right" id="nextpage2"  style="display: none;">Next1 / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right draftdata_stage2" id="draftdata_stage2">Next / ಮುಂದಿನದು</a>

									</div>
								</fieldset>
							<?php }?>
							<?php if ($prod_id == 3){ ?>
								<fieldset class="wizard-fieldset comment-section">
									<div class="form-required">
										<div class="form-required-area">
											<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
											<h5>Allowed Document Type  only .PDF(less than 2MB) / ಅನುಮತಿಸಲಾದ ಡಾಕ್ಯುಮೆಂಟ್ ಪ್ರಕಾರ  .PDF (2MB ಗಿಂತ ಕಡಿಮೆ)</h5>
										</div>										
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
																					</div>									
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-appli-form-padd.new">
									<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or</li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or </li>
											<li> In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li><br>
									<br>ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
											<li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ</li>
											<li>"ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</li></p>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ </h5>
											<sup> *</sup>
										</div>						
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_certificate_shops" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ <sup> * </sup> </h5>
											<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt / ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು. </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<!-- <div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate from Chartered Accountant/ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ  <sup> * </sup></h5>											
											<p>Documentary proof of turn over in Indian or foreign exchange from caravan tourism related activities operations during the previous financial year / " ಕಾರವಾನ್ ಪ್ರವಾಸೋದ್ಯಮ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳಿಂದ ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಗಳಿಸಲಾದ ಭಾರತೀಯ ಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯ ಟರ್ನ್ ಒವರ್ ಕುರಿತು ದಸ್ತಾವೇಜು" <br>• Certificate of  Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <br>• Profit & Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್ </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div> -->									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>List of Directors / Partners / Name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></h5>
											<p>List of Directors/Partners or name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು </p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Copies of State Permit valid for Karnataka / All-India Permit for tourism activities or tourism related activities issued by the concerned Transport Department and R.C. of Caravan / ಸಂಬಂಧಿತ ಸಾರಿಗೆ ಇಲಾಖೆಗಳಿಂದ ಮತ್ತು ಕಾರವಾನ್ ನ ಆರ್.ಸಿ. ಯಿಂದ ನೀಡಲಾದ ರಾಜ್ಯ ರಹದಾರಿ/ಅಖಿಲ ಭಾರತ ರಹದಾರಿ (ಪ್ರವಾಸೋದ್ಯಮ ಚಟುವಟಿಕೆಗಳು ಅಥವಾ ಪ್ರವಾಸೋದ್ಯಮ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳಿಗೆ) <sup> * </sup></h5>
											<p>For more than 1 vehicle valid permits for all the vehicles must be uploaded in a single pdf/ "1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು."</p>
										</div>
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_caravan_rc" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5> Details of Office Premises / ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು <sup> *</sup></h5>
											<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties/ ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ </p>			
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / <br> ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>										
									</div>

									<div class="field-app-form">
									<div class="field-appli-form-padd"></div>										
										<div class="field-comment-sec">
											<input type="checkbox" class="checkupload" id="auth_rep" onclick="javascript:enable_attoney();" value="1">&nbsp;&nbsp;
											<input type="text" hidden="" id="auth_rep_val" name="auth_rep_val" >
											<label><h5>Authorized Representative of the Entity / ಘಟಕದ ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿ</h5></label>
										</div>
									</div>
									<div class="field-app-form" style="display: none;" id="attorney_boardresolution">
										<div class="field-appli-form-padd">
											<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
											<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
											<input type="text" hidden="" name="file_type" id="file_type">
										</div>
										<div class="field-comment-sec" >
											<div class="form_input" id="yes_d4">
												<input type="radio" class="checkupload" id="yesCheck_d4" onclick="javascript:yesnoCheck_doc('yesCheck_d4','div_attorney_upload','yes_d4');"  value="1">	
												<label for="yes">Power Of Attorney / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ </label>
												<input type="radio" class="checkupload" id="noCheck_d4" onclick="javascript:yesnoCheck_doc('noCheck_d4','div_attorney_upload','yes_d4');" value="2">
												<label for="no">Board Resolution / ಮಂಡಳಿ ನಿರ್ಣಯ</label>
											</div>
											<div class="file-upload-wrapper" style="display: none" data-text="Select your file!" id="div_attorney_upload">
												<input name="img_power_of_attorney" type="file" class="file-upload-field addflag"  value="" accept="image/jpeg,image/gif,image/png,application/pdf">
													<!-- <div class="error_div"></div> -->
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Interior / ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h6>											
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Photograph of at least 1 Caravan Interior/ ಕಾರವಾನ್ ಒಳಾಂಗಣದ ಕನಿಷ್ಠ 1 ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
											All the mandatory features to be captured/ಎಲ್ಲಾ ಕಡ್ಡಾಯ ಲಕ್ಷಣಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_caravan_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>											
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Photograph of the at least 1 Caravan Exterior / ಕಾರವಾನ್ ಹೊರಾಂಗಣದ ಕನಿಷ್ಠ 1 ಛಾಯಾಚಿತ್ರ <sup> *</sup></h5>
											All the mandatory features to be captured /ಎಲ್ಲಾ ಕಡ್ಡಾಯ ಲಕ್ಷಣಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_caravan_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>											
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of GST Registration Certificate / ಜಿ ಎಸ್ ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_gst_regis" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate for the Caravan(s) to show its compliance to the Automotive Industry Standards (AIS) -124- Procedure for Type Approval / "ಆಟೋಮೋಟಿವ್ ಇಂಡಸ್ಟ್ರಿ ಸ್ಟ್ಯಾಂಡರ್ಡ್ಸ್ (ಎಐಎಸ್) -124- ಟೈಪ್ ಅನುಮೋದನೆಗಾಗಿ ಅದರ ಅನುಸರಣೆಯನ್ನು ತೋರಿಸಲು ಕಾರವಾನ್ (ಗಳಿಗೆ) ಪ್ರಮಾಣಪತ್ರ" <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_caravan_ais_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>											
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Certificate of Motor Caravans for compliance to Central Motor Vehicles Rules, issued by Ministry of Road Transport and Highways/ Karnataka Motor Vehicle Rules (as applicable) / "ರಸ್ತೆ ಸಾರಿಗೆ ಮತ್ತು ಹೆದ್ದಾರಿಗಳ ಸಚಿವಾಲಯ / ಕರ್ನಾಟಕ ಮೋಟಾರು ವಾಹನ ನಿಯಮಗಳು ಅಡಿಯಲ್ಲಿ ನೀಡಲಾದ ಕೇಂದ್ರ ಮೋಟಾರು ವಾಹನ ನಿಯಮಗಳ ಅನುಸರಣೆಗಾಗಿ ಮೋಟಾರ್ ಕಾರವಾನ್ ಗಳ  ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವಂತೆ)" <sup> * </sup></h5>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_caravan_ministry_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>											
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Declaration stating that the Caravan Operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website/ "ಕಾರವಾನ್ ಆಪರೇಟರ್ ಪ್ರತಿ ತಿಂಗಳು ತಪ್ಪದೇ  ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬುದರ ಕುರಿತು ಘೋಷಣೆ." <sup> * </sup><br><a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>"style="color:red;" download><u>Click here to download</u></a></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Approval letter for the Caravan(s) from any of the below-mentioned authorities / ಕೆಳಗಿನ ಯಾವುದೇ ಸಂಸ್ಥೆಗಳಿಂದ ಪಡೆದ ಕಾರವಾನ್ ಗಳ ಅನುಮೋದನೆ ಪತ್ರ <sup> * </sup></h5>
											<ul>
												<li>Automotive Research Association of India (ARAI)/ Automotive Research Association of India (ARAI)</li>
												<li>International Centre for Automotive Technology (ICAT) / International Centre for Automotive Technology (ICAT)</li>
												<li>Central Institute of Road Transport (CIRT) / Central Institute of Road Transport (CIRT) </li>
											</ul>
											
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_caravan_approval_letter" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>											
										</div>
									</div>
									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”. / ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ  <sup> * </sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" style="color:red;" download=""><u>Click here to download</u></a></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">											
											<p>"Data saving please wait"</p>
									</div>									
									<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 2 / ಹಿಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ </a>
										<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
									</div>
								</fieldset>
							<?php }?>

								<fieldset id="agent-other-det" class="wizard-fieldset agent-other-det">
									
									<!--<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
										<a href="javascript:;" class="form-wizard-save-btn float-center">Save as draft</a>
										<input type="submit" name="app_submit" value="Submit" class="form-wizard-submit float-right">
									</div>-->
								
									<div class="other-detail-option">
										<div class="other-det">
											<h4>Memberships of International tour<br> associations, if any / ಅಂತಾರಾಷ್ಟ್ರೀಯ ಪ್ರವಾಸ ಸಂಘಗಳ ಸದಸ್ಯತ್ವಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></h4>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck2" onclick="javascript:yesnoCheck('yesCheck2','ifYes2','international_member');" name="off_international_membership" value="Yes">							
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck2" onclick="javascript:yesnoCheck('noCheck2','ifYes2','international_member');" name="off_international_membership" value="No">
											<label for="no">No</label>											
										</div>										
										<!--div class="other-dept-text">
											<textarea name="off_international_membership" class="wizard-required"></textarea>					<div class="wizard-form-error"></div>				
										</div-->
										<div class="agent-form" style="display:none;" id="ifYes2">
											<div class="form_label">
												<p>Applicant to specify the Membership of International Tour Associations / ಅಂತರರಾಷ್ಟ್ರೀಯ ಪ್ರವಾಸ ಸಂಘಗಳ ಸದಸ್ಯತ್ವವನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲು ಅರ್ಜಿದಾರ<sup>*</sup></p>
											</div>
											<div class="other-dept-text">
												<textarea id="international_member" name="off_international_membership_details"></textarea>
											</div>									
										</div>
									</div>

									<div class="other-detail-option">
										<div class="other-det">
											<h4>Steps taken to promote domestic<br> tourists' activity / ದೇಶೀಯ ಪ್ರವಾಸಿಗರ ಚಟುವಟಿಕೆಯನ್ನು ಉತ್ತೇಜಿಸಲು ತೆಗೆದುಕೊಂಡ ಕ್ರಮಗಳು<sup>*</sup></h4>
										</div>										
										<div class="other-dept-text">
											<textarea name="off_promote_domestic_activity" class="wizard-required"></textarea>						
											<div class="wizard-form-error"></div>			
										</div>
									</div>
									<div class="other-detail-option">
										<div class="other-det">
											<h4>Special programmes arranged for<br> Foreign Tourists, if any / ವಿದೇಶಿ ಪ್ರವಾಸಿಗರಿಗಾಗಿ ಏರ್ಪಡಿಸಲಾದ ವಿಶೇಷ ಕಾರ್ಯಕ್ರಮಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></h4>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck3" onclick="javascript:yesnoCheck('yesCheck3','ifYes3','special_programe');" name="off_prog_arranged_foreign_tourist" value="yes">				
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck3" onclick="javascript:yesnoCheck('noCheck3','ifYes3','special_programe');" name="off_prog_arranged_foreign_tourist" value="no">
											<label for="no">No</label>		
										</div>	

										<div class="agent-form" style="display:none;" id="ifYes3">
											<div class="form_label">
												<p style="font-style: italic;">Applicant to specify details of the programmes arranged for foreign tourist in India or Abroad / ಭಾರತ ಅಥವಾ ವಿದೇಶದಲ್ಲಿ ವಿದೇಶಿ ಪ್ರವಾಸಿಗರಿಗೆ ಏರ್ಪಡಿಸಿರುವ ಕಾರ್ಯಕ್ರಮಗಳ ವಿವರಗಳನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲು ಅರ್ಜಿದಾರ<sup>*</sup></p>
											</div>
											<!-- prabha -->
											<div class="other-dept-text">											
												<textarea id="special_programe" name="off_prog_arranged_foreign_tourist_details"></textarea>
											</div>									
										</div>
										<!--div class="other-dept-text">
											<textarea name="off_prog_arranged_foreign_tourist" class="wizard-required"></textarea>					<div class="wizard-form-error"></div>				
										</div-->
									</div>								
									<div class="other-detail-option">
												<div class="other-det">
														<h4>Do you want to make payment<sup>*</sup></h4>
												</div>
												<div class="form_input">
													<input type="radio"  id="payment_yes" onclick="javascript:payment_enable('add','ajaxformsubmit','payment_yes','payment_no')" value="yes">
													<!--  -->
													<label for="yes">Yes</label>
													<input type="radio"  id="payment_no" onclick="javascript:payment_enable('add','ajaxformsubmit','payment_no','payment_yes')" value="no">
													<!--  -->
													<label for="no">No</label>											
												</div>							
									</div>
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">
											<p>"Data saving please wait"</p>
									</div>
									<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 3/ ಹಿಂದಿನದು</a>
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center draftdata" style="left: 34%;" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ</a> -->
										<input type="hidden" id="image_counter" value="0">
										<a href="javascript:;" id="ajaxformsubmit" class="form-wizard-next-btn float-right disable-click disabled-link">Application Fee / ಅರ್ಜಿಯ ಶುಲ್ಕ</a>
									</div>
								</fieldset>	
								
								<fieldset id="payment-det" class="wizard-fieldset payment-det">		
							</form>	
									<div class="other-detail-option">
										<div class="agent-application">				
											<div class="user-payment-details">
												<div class="user-payment">
													<div class="payment-title">
														<h3>Payment</h3>
													</div>
													<div class="payment-details">
														<div class="payment-amount">
															<p>Payable Amount</p>
															<p>Pament Method</p>
														</div>
														<div class="payment-value">
															<p>Rs. 500.00</p>
															<p>Online payment</p>
														</div>
													</div>
													
															<div class="payment-options">
														

													<input type="text" style="display:none;" id="applmob" value=""/>
													<input type="text" style="display:none;" id="applemail" value=""/>
													<input type="text" style="display:none;" id="card_holder_name_ida" value=""/>
													<!--form name="razorpay-form" id="razorpay-formnew" action="<?php echo $callback_urlnew; ?>" method="POST">
													



<input type="text" name="insertidd" style="display:none;"  id="insertidd">

               <input id="ORDER_ID" type="hidden" tabindex="1" maxlength="20" size="20" name="ORDER_ID" autocomplete="off"
            value="<?php echo  "KTTF" . rand(10000,99999999)?>">
            <input id="CUST_ID" type="hidden" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001">
            <input id="INDUSTRY_TYPE_ID" type="hidden" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Travel">
            <input id="CHANNEL_ID" type="hidden" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
            <input title="TXN_AMOUNT" type="hidden" tabindex="10" type="text" name="TXN_AMOUNT" value="1">





													</form>
													<input  id="pay-btn" style="float:right;"  onclick="razorpaySubmitnew(this);" value="Pay Now" class="btn btn-primary" /-->

	<button type="button" style="float:right;" id="JsCheckoutPayment" name="submit" class="btn btn-primary">Pay Now2</button>
														<!-- razoor pay ends -->
													</div>

													<br>									
<p id="payload" style="display:none;" class="payloadc">Please Wait.. Processing..</p>
												</div>
											</div>
										</div>
									</div>
							
									<div class="form-group clearfix">
										<!--a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a-->
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center">Save as draft</a> -->
										<!--input type="submit" name="app_submit" value="Submit" class="form-wizard-submit float-right"--> 										
									</div>
								</fieldset>	
								<?php }								
								if($pid == 0 && $prod_id == 4)
								 include('hotel.php') ?>
								 <?php 
								if($pid == 0 && $prod_id == 5)
								 include('Restaurant.php') ?>
								 <?php 
								if($pid == 0 && $prod_id == 6)
								 include('amusement.php') ?>
								 <?php 
								if($pid == 0 && $prod_id == 7)
								 include('guesthouse.php') ?>
								<?php 
								if($pid == 0 && $prod_id == 8)
								 include('homestay.php') ?>

								<?php if($pid!=0 && $new_pid<=3)
								{?>
									<!-- edit option  -->
								<form  method="post" role="form" enctype="multipart form-data" id="formSave123">
									<fieldset id="general-verify" class="wizard-fieldset general-verify show">
										<input hidden type="text" name="" id="proId" value="<?php echo $new_pid ?>">
										<input style="display:none;" type="text" name="pg_orderid" id="pg_orderid" value="<?php echo $result['orderId']; ?>">
											<div class="agent-form">
												<div class="form_label">
													<!-- <p>Full Name of the Entity / ಸಂಸ್ಥೆಯ ಪೂರ್ಣ ಹೆಸರು<sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)<br>(ಸಂಸ್ಥೆ/ಕಂಪನಿ/ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ/ಮಾಲೀಕತ್ವ)</p> -->
														<p>Trade Name / ವ್ಯಾಪಾರ ಹೆಸರು <sup> * </sup></p>
												</div>
												<div class="form_input">
													<input type="hidden" name="product_id" id="eproduct_id" value="">
													<input type="text" style="text-transform:capitalize;" name="applicant_name" onkeypress="return isNumbera(event,'albhabet')" id="eapplication_name"  value="">
													<!-- <div class="wizard-form-error"></div> -->
													<input type="hidden" name="insid_draft" style="display:none;"  id="insid_draft" value="<?php echo($pid);?> ">
												</div>	
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Legal Name / ಕಾನೂನು ಹೆಸರು <sup> * </sup></p>
												</div>
												<div class="form_input">
													<input type="text" onkeypress="return isNumbera(event,'albhabet')" style="text-transform:capitalize;" name="legal_name" id="elegal_name" value="" class="">
												</div>
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>In which name you need a certificate to be printed ? / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ನಿಮಗೆ ಮುದ್ರಿಸಲು ಪ್ರಮಾಣಪತ್ರ ಬೇಕು <sup> * </sup></p>
												</div>
												<div class="form_input">
												<select name="certificate_name" id="ecertificate_name" class="form-control wizard-required">
													<option value="">Select Type</option>
													<option value="1">Legal name</option>
													<option value="2">Trade Name</option>
												</select>
												<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Entity Type / ಸಂಸ್ಥೆಯ ಪ್ರಕಾರ <sup>*</sup></p>													
												</div>
												<div class="form_input">
													<select name="org_type_id" id="eorg_type_id" class="form-control wizard-required">
														<option value="0">Select Entity Type</option>
														<?php
															$this->db->where('isactive', '1');
															// here we select every column of the table
															$q = $this->db->get('m_organization_nature');
															$data = $q->result_array();
															foreach ($data as $row):
														?>
														<option value="<?php echo $row['id']; ?>">
														<?php echo $row['name']; ?></option>
														<?php endforeach; ?>
													</select>
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Date of Registration/Incorporation of the Entity<br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Karnataka Shops and Establishment Act)/"ಸಂಸ್ಥೆಯ ನೋಂದಣಿ / ಸಂಯೋಜನೆಯ ದಿನಾಂಕ* (ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956 /2013 ಅಥವಾ ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ ಪ್ರಕಾರ)" <sup>*</sup> </p>
												</div>
												<div class="form_input">
													<input type="date" name="org_commencement_date" id="eorg_commencement_date" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Date of registration of entity as per Karnataka shops and establishment act/  ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ಘಟಕ ನೋಂದಣಿಯಾದ ದಿನಾಂಕ <sup> * </sup></p>
												</div>
												<div class="form_input">
													<input type="date" name="org_shop_date" id="eorg_shop_date" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<?php if($pid==0 && $prod_id ==3) {?>
											<div class="agent-form">
												<div class="form_label">
													<p>Date of issue of Trade License/ ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನೀಡಲಾದ ದಿನಾಂಕ <sup> * </sup></p>
												</div>
												<div class="form_input">
													<input type="date" name="trade_lic_date" id="etrade_lic_date" class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form" >
												<div class="form_label">
													<p>Copy of Trade License / ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></p>
												</div>
												<div class="form_input_file">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_tradelic_upload">
														<input id="trade_lic" name="img_trade_lic" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
													<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_lic_firm">
														<a id="a_trade_lic" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" value="trade_lic" name="trade_lic" Sdivname="div_tradelic_upload" hdivname="div_lic_firm">Remove</button>
													</div>
												</div>	
											</div>	

										<?php }?>
											<div class="agent-form">
												<div class="form_label">			
													<p>Recognised Under Ministry of Tourism, Government of India/ ಭಾರತ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಮಾನ್ಯತೆ ಪಡೆದಿದೆಯೇ? <sup>*</sup></p>
												</div>
												<div class="form_input">
													<input type="radio" id="yesCheck_d" onclick="javascript:yesnoCheck_d1('yesCheck_d','ifYes','div_reg_upload');" name="central_gov_approved" value="yes">
													<label for="yes">Yes</label>
													<input type="radio" id="noCheck_d" onclick="javascript:yesnoCheck_d1('noCheck_d','ifYes','div_reg_upload');" name="central_gov_approved" value="no">
													<label for="no">No</label>											
												</div>									
											</div>
											<div class="agent-form" style="display:none;" id="ifYes">
												<div class="form_label">
													<p>Upload Registration Document / ನೋಂದಣಿ ಡಾಕ್ಯುಮೆಂಟ್ ಅನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ<sup>*</sup></p>
												</div>
												<div class="form_input_file">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_reg_upload">
														<input id="reg_firm" name="img_central_gov_registration" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
													<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_reg_firm" style="display: none">
														<a id="a_reg_document" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" value="reg_document" name="reg_document" Sdivname="div_reg_upload" hdivname="div_reg_firm">Remove</button>
													</div>
												</div>	
											</div>									
											<div class="agent-form">
												<div class="form_label">
													<p>Full Name of the properator / Directors / Partners/ಮಾಲೀಕ / ಮಾಲೀಕರು / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪೂರ್ಣ ಹೆಸರು:<sup> * </sup></p>
													<!-- <p>Applicants Name <br> ಅರ್ಜಿದಾರರ ಹೆಸರು <sup> * </sup></p> -->
												<!-- <?php if($new_pid != 2){?>
													<p>Name of Proprietor / Directors / Partners <br> ಮಾಲೀಕರ / ನಿರ್ದೇಶಕರ / ಪಾಲುದಾರರ ಹೆಸರು <sup> * </sup></p><?php }?>
												<?php if($new_pid == 2){?>
													<p>Full Name of the properator / Directors / Partners <sup> * </sup></p>
												<?php }?> -->
													
												</div>
												<div class="form_input">
													<input type="text" onkeypress="return isNumbera(event,'albhabet')" name="proprietor_name" id="eproperitor_name"  class="wizard-required">
													<div class="wizard-form-error"></div>
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>GST Identification Number /ಜಿ ಎಸ್ ಟಿ ಗುರುತಿನ ಸಂಖ್ಯೆ <sup>*</sup></p>
												</div>
												<div class="form_input">
													<input type="text" maxlength="15" name="gst_number" id="egst_number" value="" class="wizard-required">
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>PAN Number / ಪ್ಯಾನ್ ಸಂಖ್ಯೆ <sup>*</sup></p>
												</div>
												<div class="form_input">
													<input type="text" maxlength="10" name="pan_number" id="epan_number" value="" class="wizard-required">
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು URL</p>
												</div>
												<div class="form_input">
													<input type="text" name="website_name" id="ewebsite_name" value="">
												</div>									
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Official email id of the Entity / ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ </p>
												</div>
												<div class="form_input">
													<input type="email" name="official_email" id="eofficial_email" class="" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="">
													<!--<sup>*</sup> wizard-required <div class="wizard-form-error"></div> -->
												</div>		
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Whether a Member of Any Recognised Trade Body? / ಯಾವುದೇ ಮಾನ್ಯತೆ ಪಡೆದ ವ್ಯಾಪಾರ ಸಂಸ್ಥೆಯ ಸದಸ್ಯರಾಗಿರುವಿರಾ? <sup>*</sup></p>
												</div>
												<div class="form_input">
													<!-- onchange='Checktrade(this.value);' -->
													<select name="member_recognised_trade" id="emember_recognised_trade" class="form-control wizard-required" onchange='Checktrade(this.value,"emember_recognised_trade_details");'>
														<option value="0">Select Recognised Trade Body</option>
														<option value="The Travel Agents Association of India(TAAI)">The Travel Agents Association of India(TAAI)</option>
														<option value="Indian Association of Tour Operators(IATO)">Indian Association of Tour Operators(IATO)</option>
														<option value="Travel Agents Federation of India(TAFI)">Travel Agents Federation of India(TAFI)</option>
														<option value="International Air Transport Association(IATA)">International Air Transport Association(IATA)</option>
														<option value="Others">Others – Please specify</option>
													</select>
													<input type="text" name="member_recognised_trade_details" id="emember_recognised_trade_details" onkeypress="return isNumbera(event,'albhabet')" id="eothertrade" style='margin-top:10px;display:none;'/>
													<div class="wizard-form-error"></div>
												</div>													
											</div>
											<div class="agent-form">
												<div class="form_label">
													<p>Whether the member of Karnataka Tourism Society (KTS)? / ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ಸೊಸೈಟಿಯ (KTS) ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup>*</sup></p>
												</div>
												<div class="form_input">
													<input type="radio" id="yesCheck_kts" onclick="javascript:yesnoCheck_d1('yesCheck_kts','ifYes_kts','div_member_kts_upload');" name="member_kts" value="yes">	
													<label for="yes">Yes</label>
													<input type="radio" id="noCheck_kts" onclick="javascript:yesnoCheck_d1('noCheck_kts','ifYes_kts','div_member_kts_upload');" name="member_kts" value="no">
													<label for="no">No</label>	
													<input hidden type="text" name="member_recognised_trade_new" id="emember_recognised_trade_new" >
												</div>		
											</div>
											<div class="agent-form" style="display:none;" id="ifYes_kts">
												<div class="form_label">
													<p>Upload Registration Document / ನೋಂದಣಿ ಡಾಕ್ಯುಮೆಂಟ್ ಅನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ<sup>*</sup></p>
												</div>
												<div class="form_input_file">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_member_kts_upload">
														<input id="img_member_kts" name="img_member_kts" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_member_kts" style="display: none">
														<a id="a_member_kts" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" value="reg_document" name="member_kts" Sdivname="div_member_kts_upload" hdivname="div_member_kts">Remove</button>
													</div>
												</div>
											</div>
											<div  class="agent-form" style="display:none;" id="nodiv">
												<span><a style="color: red;" href="https://www.karnatakatourismsociety.org/" target="_blank">Note: Register in KTS <span style='color:blue'>https://www.karnatakatourismsociety.org</span> to avail Benefits from Government</a></span>
											</div>
											<div class="form-heading-location">
												<h4>Registered Office Address / ನೋಂದಾಯಿತ ಕಚೇರಿ ವಿಳಾಸ </h4>
												<span>[Applicant to mention only the details of office address for which registration under Department of Tourism is required]/["ಅರ್ಜಿದಾರರು ಪ್ರವಾಸೋದ್ಯಮ ಇಲಾಖೆಯ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿಗೆ ಅಗತ್ಯವಿರುವ ಕಚೇರಿ ವಿಳಾಸದ ವಿವರಗಳನ್ನು ಮಾತ್ರ ನಮೂದಿಸಬೇಕು."]</span>
														<!--span><input type="checkbox" name="sameas" id="sameas"/>Same as above</span-->
											</div>
											<div class="agent-loc-off-address">
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1<sup>*</sup></p>
													</div>
													<div class="agent-form-input">
														<input type="text" name="org_loc_add1" id="eloc_addr1" class="wizard-required">
														<div class="wizard-form-error"></div>
													</div>									
												</div>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2 </p>
														<!-- <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup> -->
													</div>
													<div class="agent-form-input">
														<input type="text" name="org_loc_add2" id="eloc_addr2" class="">
														<!-- <div class="wizard-form-error"></div> -->
													</div>									
												</div>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>District / ಜಿಲ್ಲೆ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
													</div>
													<div class="agent-form-input">
														<select name="org_loc_district_id" id="eloc_district" class="form-control wizard-required" onchange="showtaluk(0,'eloc_taluk_office','eloc_district')">
															<option value="0">Select District</option>
															<?php
																$this->db->where(array('state_id' => '17'));
																$clients = $this->db->get('m_district')->result_array();
																foreach ($clients as $row):	?>
																<option value="<?php echo $row['id']; ?>">
																<?php echo $row['name']; ?></option>
																<?php endforeach; ?>
														</select>
													    <div class="wizard-form-error"></div>
													</div>									
												</div>
														
														
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Taluk / ತಾಲೂಕು <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
													</div>
													<div class="agent-form-input">
														<select name="org_loc_taluk_id" class="form-control wizard-required org_taluk" id="eloc_taluk_office">
															<option value="">Select Taluk</option>
														</select>
														<div class="wizard-form-error"></div>
													</div>									
												</div>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>City / Town / Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
													</div>
													<div class="agent-form-input">
														<input type="text"  id="eorg_loc_city" name="org_loc_city" class="wizard-required">
														<div class="wizard-form-error"></div>
													</div>									
												</div>
														

												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
													</div>
													<div class="agent-form-input">
														<input type="text"  id="eorg_loc_landmark" name="org_loc_landmark" class="wizard-required">
														<div class="wizard-form-error"></div>
													</div>									
												</div>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
													</div>
													<div class="agent-form-input">
														<input type="text" maxlength="6" onkeypress="return isNumber(event)" name="org_loc_pincode_id" id="eorg_loc_pincode_id" class="wizard-required"  onpaste="return false">
														<div class="wizard-form-error"></div>
													</div>									
												</div>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
													</div>
													<div class="agent-form-input">
														<input type="text" maxlength="10" name="org_loc_mobile" onkeypress="return isNumber(event)" class="wizard-required" id="eloc_mob"  onpaste="return false">
															<div class="wizard-form-error"></div>
													</div>									
												</div>
												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Telephone Number /ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>
													</div>
													<div class="agent-form-input">
														<input type="text" name="org_loc_telephone" onkeypress="return isNumber(event)" id="eloc_tele" maxlength="10" onpaste="return false">
														<div class="wizard-form-error"></div>
													</div>									
												</div>

												<div class="agent-form-field">
													<div class="agent-form-text">
														<p>Total Build Area(Sq.ft) / ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ)<sup>*</sup></p>
													</div>
													<div class="agent-form-input">
													    <input type="text" id="etotalbuildfuna" onkeypress="return isNumbera(event,'number')"class="wizard-required"  name="org_total_build_sqft" onpaste="return false" onkeyup="totalbuildfun('etotalbuildfuna')">
														<div class="wizard-form-error"></div> 
													</div>									
												</div>
											</div>
											<div class="form-heading">
												<h4>Other Office Addresses / ಇತರ ಕಚೇರಿ ವಿಳಾಸಗಳು</h4>
											</div>
											<div class="agent-off-address">
												<div class="agent-form-field">
													<div class="agent-form-text">
														<h6 style="color:red;">Note: Please Enter "0" if there is no other offices/ಸೂಚನೆ: ಬೇರೆ ಯಾವುದೇ ಕಚೇರಿಗಳಿಲ್ಲದಿದ್ದರೆ ದಯವಿಟ್ಟು "0" ಅನ್ನು ನಮೂದಿಸಿ</h6>
														<p>Number of Offices in Karnataka / ಕರ್ನಾಟಕದಲ್ಲಿರುವ ಕಚೇರಿಗಳ ಸಂಖ್ಯೆ<sup> * </sup></p>
													</div>
													<div class="agent-form-input">
														<input type="text" name="Nuumber_offices" id="eno_off" class="wizard-required" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" onchange="chkval()">
														<div class="wizard-form-error"></div>
													</div>									
												</div>
												<div id="other_address_div" style="display: none">
													<div class="other-off-head other-off-no">
														<h4 id="address_1">Address 1/ವಿಳಾಸದ 1</h4>
													</div>
													<div class="other-off-addre">
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1<sup>*</sup></p>
															</div>
															<div class="agent-form-input">
																<input type="text" name="org_add1[]" id="eorg_addr1" class="">
																<div class="wizard-form-error"></div>
															</div>									
														</div>
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2 </p>
																<!-- <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup> -->
															</div>
															<div class="agent-form-input">
																<input type="text" name="org_add2[]" id="eorg_addr2" class="">
															</div>									
														</div>										
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>District / ಜಿಲ್ಲೆ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
															</div>
															<div class="agent-form-input">
																<select name="org_district_id[]" id="eorg_district" class="form-control org_city" onchange="showtaluk(0,'eorg_taluk','eorg_district')">
																<option value="">Select District</option>
																<?php
																	$this->db->where(array('state_id' => '17'));
																	$clients = $this->db->get('m_district')->result_array();
																	foreach ($clients as $row):
																	?>
																	<option value="<?php echo $row['id']; ?>">
																	<?php echo $row['name']; ?></option>
																	<?php endforeach; ?>
																</select>												
															</div>
														</div>
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>Taluk / ತಾಲೂಕು <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
															</div>
															<div class="agent-form-input">
																<select name="org_taluk[]"  class="org_taluk" id="eorg_taluk">
																	<option value="">Select Taluk</option>	
																</select>				
															</div>									
														</div>
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>City/Town/Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
															</div>
															<div class="agent-form-input">
																<input type="text" name="org_city[]" class="" id="eorg_town">
															</div>
														</div>										
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
															</div>
															<div class="agent-form-input">
																<input type="text" maxlength="6" name="org_pincode_id[]" onkeypress="return isNumber(event)" id="eorg_pincode"  class="" onpaste="return false">
															</div>									
														</div>
														<div class="agent-form-field">
															<div class="agent-form-text">
																<p>Contact Number/ಸಂಪರ್ಕ ಸಂಖ್ಯೆ<sup><?php if($new_pid == 2 || $new_pid == 3){ ?> * <?php }?></sup></p>
															</div>
															<div class="agent-form-input">
																<input type="text" name="org_mobile[]" onkeypress="return isNumber(event)" maxlength="10" onpaste="return false" class="" id="eorg_mob">		
															</div>									
														</div>
														<div class="form-group col-md-12"><hr class="new4"></div>
													</div>												
													<input type="hidden" name="remove_ids" id="remove_ids">
												</div>
												<a class="add_button disable-click">Add / ಸೇರಿಸಿ</a>
												<!-- <br>
												<div class="form-group col-md-12"><hr class="new4"></div> -->
												<?php if ($new_pid == 2 || $new_pid==3){ ?>
													<div class="tour-operator">
														<div class="tour-orepator-vehicle  col-md-12">
															<div class="form-group col-md-6">
															<label><?php echo ($new_pid == 2 ? "Number of Vehicles Viz AC Coaches, Non-AC Coaches, Mini Coaches, Cars and Boats operated as tourist Vehicles / ಎಸಿ ಕೋಚ್‌ಗಳು, ಎಸಿ ರಹಿತ ಕೋಚ್‌ಗಳು, ಮಿನಿ ಕೋಚ್‌ಗಳು, ಕಾರುಗಳು ಮತ್ತು ಬೋಟ್‌ಗಳು ಸೇರಿದಂತೆ ಪ್ರವಾಸಿ ವಾಹನಗಳಾಗಿ ಕಾರ್ಯನಿರ್ವಹಿಸುವ ವಾಹನಗಳ ಸಂಖ್ಯೆ":"Number of Caravans/Campervans /ಕಾರವಾನ್/ಕ್ಯಾಂಪರ್‌ವಾನ್‌ಗಳ ಸಂಖ್ಯೆ") ?> </label>
															</div>
															<div class="form-group col-md-6">
																<input type="text" name="veh_count" id="veh_count">
															</div>	
														</div>
														<div class="vehicle-detail">
															<div class="multi-field-wrapper">
																<div class="multi-field-head">
																	<div class="form-group col-md-12">
																		<div class="form-group col-md-3">
																			<label><?php echo ($new_pid == 2 ? "Vehicle Type/ವಾಹನದ ಪ್ರಕಾರ *":"Caravan Type/ಕಾರವಾನ್ ಪ್ರಕಾರ *") ?>
																			</label>	
																		</div>
																		<input type="hidden" name="vehicleId[]" id="evehicleId">
																		<div class="form-group col-md-3">
																			<?php if($new_pid==2){?>
																				<select class="vehicle-form wizard-required dropdownchange" name="vehicle_type[]" id="evehicle_type" required="" >
																					<option value="" showvalue="othervalue">Vehicle Type</option>
																					<option value="Cars" showvalue="othervalue">Car</option>
																					<option value="Cars" showvalue="othervalue">Bus</option>
																					<option value="AC Coaches" showvalue="othervalue">AC Bus</option>
																					<option value="Non-AC Coaches" showvalue="othervalue">Non-AC Bus</option>
																					<option value="Mini Coaches" showvalue="othervalue">Mini Coaches</option>																					
																					<option value="Boats" showvalue="othervalue">Boats</option>
																					<option value="Others" showvalue="othervalue">Others</option>
																				</select>
																				<br> &nbsp;
																				<input style="display: none;" id="othervalue" type="text" name="othervalue[]"  >
																			<?php }?>
																			<?php if($new_pid==3){?>
																				<!-- this is for caravan so don't change the name and id -->
																				<input type="text" name="vehicle_type[]" id="evehicle_type">
																			<?php }?>	
																		</div>
																		<div class="form-group col-md-3">
																			<label>Permit Type / ನೀಡಲಾದ ಅನುಮತಿ ಪ್ರಕಾರ *</label>
																		</div>
																		<div class="form-group col-md-3">
																			<select class="vehicle-form wizard-required" id="epermit_type" name="permit_type[]" required="">
																				<option value="">Permit Type</option>
																				<option value="Karnataka Permit" >Karnataka Permit</option>
																				<option value="All India Permit">All India Permit</option>
																			</select>
																			<div class="wizard-form-error"></div>
																		</div>
																	</div>
																	<div class="form-group col-md-12">
																		<div class="form-group col-md-3">
																			<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit Number/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಿಗೆ ಸಂಖ್ಯೆ":"Caravan Vehicle Permit Number/ಕಾರವಾನ್ ವಾಹನದ ಪರವಾನಿಗೆ ಸಂಖ್ಯೆ")?>  *</label>
																		</div>
																		<div class="form-group col-md-3">
																			<input class="vehicle-form" type="text" id="etourist_permit" name="tourist_permit[]">
																		</div>
																		<div class="form-group col-md-3">
																			<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Registration Number/ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ:":"Caravan Vehicle Registration Number/ಕಾರವಾನ್ ವಾಹನದ ನೋಂದಣಿ ಸಂಖ್ಯೆ:") ?> *
																			</label>
																		</div>
																		<div class="form-group col-md-3">
																			<input class="vehicle-form" type="text" maxlength="15" id="eregistration_no" name="registration_no[]">
																		</div>
																	</div>
																	<div class="form-group col-md-12">
																		<div class="form-group col-md-3">
																			<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Registration in the name of/  ಈ ಹೆಸರಿನಲ್ಲಿ ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಮಾಡಲಾಗಿದೆ :":"Caravan Registration in the name of/ಯಾವ ಹೆಸರಿನಲ್ಲಿ ಕಾರವಾನ್ ನೋಂದಣಿ ಮಾಡಲಾಗಿದೆ:") ?>* </label>	
																		</div>
																		<div class="form-group col-md-3">
																			<input class="vehicle-form" type="text" id="eregistration_name" name="registration_name[]" style="text-transform:capitalize;" onkeypress="return isNumbera(event,'albhabet')">		
																		</div>
																		<div class="form-group col-md-3">
																			<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit Start date/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಿಗೆ ಆರಂಭದ ದಿನಾಂಕ:":"Caravan vehicle permit start date/ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಿಗೆ ಆರಂಭದ ದಿನಾಂಕ:")?></label>
																		</div>
																		<div class="form-group col-md-3">
																			<input type="date" name="tourist_permit_date[]" id="etourist_permit_date" class="wizard-required datefreeze" >
																			<!-- <input type="date" name="tourist_permit_date[]" id="etourist_permit_date" class="vehicle-form"> -->
																		</div>
																	</div>
																	<div class="form-group col-md-12">
																		<div class="form-group col-md-3">
																			<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit End date/ಪ್ರವಾಸಿ ವಾಹನ ಅನುಮತಿಯ ಅಂತಿಮ ದಿನಾಂಕ:":"Caravan vehicle permit end date/ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಿಗೆ ಅಂತಿಮ ದಿನಾಂಕ:")?></label>
																			<!-- <label>Vehicle end date:</label> -->
																		</div>
																		<div class="form-group col-md-3">
																			<input type="date" name="tourist_permit_end_date[]" id="etourist_permit_end_date" class="vehicle-form">
																		</div>
																	</div>
																</div> 
															</div>
															<div class="form-group col-md-12"><hr class="new4"></div>
														</div>	
														
														<div class="vehicle-detail_new">
														</div>
														<!-- class="form-add" class="add-field" <i class="fa fa-plus"></i>-->
														<input type="hidden" name="vehremove_ids" id="vehremove_ids">
														<div class="form-add">	
															<button type="button" class="add-field" onclick="addnewvehicle('edit')"> <i class="fa fa-plus"></i>Add</button>
															<!-- <button class="btn btn-success" onclick="addnewvehicle()">Add</button> -->
															<!-- <button class="btn btn-danger" disabled="disabled" id="remove_vehicle" onclick="removevehicle()" >Remove</button> -->
														</div> 
													</div>
												<?php } ?>				
											</div>
											<div class="alert-error" id="totalbuilderr" style="display:none;margin-top: 26px;text-align: center;">
												<!--span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span--> 
												<?php echo "Since the Total Built Up area is less than 150 sq. ft, the application will not be moved further.";?>
											</div>
											<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">												
												<p>"Data saving please wait"</p>
											</div>
											<div class="form-group clearfix" id="totalbuildnext">
												<!-- <a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
												<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft /ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a> -->


										<a href="javascript:;" class="form-wizard-next-btn float-right" id="nextpage"  style="display: none;">Next1 / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right draftdata" id="draftdata">Next/ ಮುಂದಿನದು</a>
											</div>
									</fieldset>
									<?php if ($new_pid == 1 ){ ?>
									<fieldset class="wizard-fieldset comment-section">
											<div class="form-required">
												<div class="form-required-area">
													<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
													<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB) / ಅನುಮತಿಸಲಾದ ಡಾಕ್ಯುಮೆಂಟ್ ಪ್ರಕಾರ .JPG, .PNG, .PDF (2MB ಗಿಂತ ಕಡಿಮೆ )</h5>
												</div>										
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Registration/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ 333 <sup>*</sup></h5></div>									
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_registration_upload">
														<input onchange="singleFileUpload('eimg_registration_certificate');" name="img_registration_certificate" id="eimg_registration_certificate" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_registration_certificate" style="display:none">
														<a id="a_registration_certificate" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="registration_certificate" 
														docname='eimg_registration_certificate' Sdivname="div_registration_upload" hdivname="div_registration_certificate">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-appli-form-padd.new">
									<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or</li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or </li>
											<li> In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li><br>
									<br>ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
											<li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ</li>
											<li>"ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</li></p>
									</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ</h5>
													<sup> *</sup>
												</div>						
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload">
														<input onchange="singleFileUpload('eimg_certificate_shops');" name="img_certificate_shops" type="file" id="eimg_certificate_shops" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
														<a id="a_certificate_shops" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="certificate_shops" docname="eimg_certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ<sup>*</sup> </h5>
													<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt/ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು. </p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_bank_upload">
														<input onchange="singleFileUpload('eimg_bank_reference');" name="img_bank_reference" id="eimg_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_bank_referencee" style="display:none" >
														<a id="a_bank_referencee" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_bank_reference" value="bank_referencee" name="bank_referencee" Sdivname="div_bank_upload" hdivname="div_bank_referencee">Remove</button>
													</div>
												</div>
											</div>
											<!-- <div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Certificate from Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ <sup>*</sup> </h5>													
													<p>Documentary proof of turn over in Indian or foreign exchange from tour related activities operations during the previous financial year which should not beless than Rs. 7.5 Lakh“ / ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಪ್ರವಾಸಿ ಸಾರಿಗೆ ಸಂಬಂಧಿತ ಸಕ್ರಿಯ ಚಟುವಟಿಕೆಗಳಿಂದ ಮಾಡಲಾದ  ಭಾರತೀಯಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದ ಟರ್ನ್ ಓವರ್ ಕುರಿತು ದಸ್ತಾವೇಜಿನ ಪುರಾವೆ. ಟರ್ನ್ ಓವರ್ 7.5 ಲಕ್ಷ ರೂ ಗಳಿಗಿಂತ ಕಡಿಮೆ ಇರಬಾರದು.<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ<br>• Profit & Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್ </p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_img_ca_upload">
														<input name="img_ca_certificate" id="eimg_ca_certificate" type="file" class="file-upload-field wizard-required " value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														 <div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_ca_certificate" style="display:none">
														<a id="a_img_ca" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn"name="ca_certificate" Sdivname="div_img_ca_upload" hdivname="div_ca_certificate">Remove</button>
													</div>
												</div>
											</div>	 -->								
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>List of Directors / Partners / Name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup>*</sup></h5>
													<p>List of Directors/Partners or name of the Proprietor/ ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_list_patners_upload">
														<input onchange="singleFileUpload('eimg_list_patners');" name="img_list_patners" id="eimg_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_list_patners" style="display:none">
														<a id="a_list_partners" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_list_patners" name="list_patners" Sdivname="div_list_patners_upload" hdivname="div_list_patners">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Brochures or Leaflets /ಕರಪತ್ರಗಳು <sup>*</sup></h5>
													<p>Brochures or leaflets brought out by the firms having all information about their activities/ "ಸಂಸ್ಥೆಗಳು ಹೊರತಂದಿರುವ ಮತ್ತು ಸಂಸ್ಥೆಗಳ  ಚಟುವಟಿಕೆಗಳ ಕುರಿತು ಎಲ್ಲ ಮಾಹಿತಿಗಳನ್ನು ಹೊಂದಿರುವ ಕರಪತ್ರಗಳು"</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_brochures_upload">
														<input onchange="singleFileUpload('eimg_brochures');" name="img_brochures" id="eimg_brochures" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_img_brochures" style="display:none">
														<a id="a_img_brochers" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_brochures"  name="img_brochures" Sdivname="div_brochures_upload" hdivname="div_img_brochures">Remove</button>
													</div>						
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Details of Office Premises / ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು<sup>*</sup></h5>
													<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ </p>				
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_premises_upload">
														<input onchange="singleFileUpload('eimg_off_premises');" name="img_off_premises" id="eimg_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_premises" style="display:none">
														<a id="a_premises" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_premises" name="off_premises" Sdivname="div_premises_upload" hdivname="div_off_premises">Remove</button>
													</div> 
												</div>
											</div>
											<!-- <div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Labour Department Certificate / ಕಾರ್ಮಿಕ ಇಲಾಖೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_labor_dep_upload">
														<input name="img_labour_department" id="eimg_labour_department" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_labour_department" style="display:none">
														<a id="a_labor_department" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="labour_department" Sdivname="div_labor_dep_upload" hdivname="div_labour_department">Remove</button>
													</div> 
												</div>
											</div> -->
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup>* </sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_photoarrested_upload">
														<input onchange="singleFileUpload('eimg_md_photo_attested');" name="img_md_photo_attested" id="eimg_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_md_photo_attested" style="display:none">
														<a id="a_photo_attested" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_md_photo_attested" name="photo_attested" Sdivname="div_photoarrested_upload" hdivname="div_md_photo_attested">Remove</button>
													</div> 
												</div>										
											</div>
								<div class="field-app-form">
									<div class="field-appli-form-padd">
										<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
										<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
									</div>										
								<div class="field-comment-sec">
									<div class="file-upload-wrapper" data-text="Select your file!" id="div_powerof_attorney_upload">
										<input onchange="singleFileUpload('eimg_power_of_attorney');" name="img_power_of_attorney" id="eimg_power_of_attorney" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
										<div class="wizard-form-error"></div>
									</div>
									<div class="agent-form-file-view1" id="div_power_of_attorney" style="display:none">
										<a id="a_powerof_attorney" href="" target="_blank">View</a>
										<button class="btn btn-danger removebtn" docname="eimg_power_of_attorney" name="power_of_attorney" Sdivname="div_powerof_attorney_upload" hdivname="div_power_of_attorney">Remove</button>
									</div> 
								</div>										
							</div>

<!-- <div class="field-app-form">
<div class="field-appli-form-padd">
	<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
	<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
</div>	
<div class="field-comment-sec">
	<div class="form_input" id="eyes_d4">
		<input   type="radio" class="checkupload" id="eyesCheck_d4" onclick="javascript:yesnoCheck_doc('eyesCheck_d4','div_powerof_attorney_upload','eyes_d4');"  value="1">	
		<label for="yes">Power Of Attorney here / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ</label>
		<input type="radio" class="checkupload" id="enoCheck_d4" onclick="javascript:yesnoCheck_doc('enoCheck_d4','div_powerof_attorney_upload','eyes_d4');"  value="2">
		<label for="no">Board Resolution / ಮಂಡಳಿ ನಿರ್ಣಯ</label>
	</div>
	<div class="file-upload-wrapper" data-text="Select your file!" id="div_powerof_attorney_upload">
		<input onchange="singleFileUpload('eimg_power_of_attorney');" name="img_power_of_attorney" id="eimg_power_of_attorney" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
		 <div class="error_div"></div>  
	</div>
	<div class="agent-form-file-view1" id="div_power_of_attorney" style="display:none">
		<a id="a_powerof_attorney" href="" target="_blank">View</a>
		<button class="btn btn-danger removebtn" docname="eimg_power_of_attorney" name="power_of_attorney" Sdivname="div_powerof_attorney_upload" hdivname="div_power_of_attorney">Remove</button>
	</div>
</div>
</div> -->
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h6>	
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
														<input onchange="singleFileUpload('eimg_off_buil_exterior');" name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
														<a id="a_builexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_buil_exterior" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
													</div> 
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of the Office Building Interior / <sup>*</sup> ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ</h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
														<input onchange="singleFileUpload('eimg_off_buil_interior');" name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
														<a id="a_buildInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_buil_interior" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
													</div>
												</div>
											</div>

											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup> * </sup> </h6>											
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_boardentity_upload">
														<input onchange="singleFileUpload('eimg_board_entity');" name="img_board_entity" id="eimg_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_board_entity" style="display:none">
														<a id="a_boardentityr" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_board_entity" name="board_entity" Sdivname="div_boardentity_upload" hdivname="div_board_entity">Remove</button>
													</div>
												</div>
											</div>


											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copy of GST Registration Certificate / ಜಿ ಎಸ್ ಟಿ  ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_gstregis_upload">
														<input onchange="singleFileUpload('eimg_gst_regis');" name="img_gst_regis" id="eimg_gst_regis" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_gst_regis" style="display:none">
														<a id="a_gstregis" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_gst_regis" name="gstregis" Sdivname="div_gstregis_upload" hdivname="div_gst_regis">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_pan_upload">
														<input onchange="singleFileUpload('eimg_pan_copy');" name="img_pan_copy" id="eimg_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_pan_copy" style="display:none">
														<a id="a_pancopy" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_pan_copy" name="pan" Sdivname="div_pan_upload" hdivname="div_pan_copy">Remove</button>
													</div> 
												</div>
											</div>	
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Declaration stating that the travel agent on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website/ " ಪ್ರತಿ ತಿಂಗಳು ತಪ್ಪದೇ  ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆಯನ್ನು ಅರ್ಜಿದಾರನು ಕಡ್ಡಾಯವಾಗಿ ಅಪಲೋಡ್ ಮಾಡಬೇಕು."<sup>*</sup><br><a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>"style="color:red;" download><u>Click here to download</u></a></h6>
												</div>
												<div class="field-comment-sec">
													<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_arrivaldetail_upload">
														<input onchange="singleFileUpload('eimg_tourist_arrival_details');" name="img_tourist_arrival_details" id="eimg_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_tourist_arrival_details" style="display:none">
														<a id="a_arrivaldetail" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_tourist_arrival_details" name="arrival_details" Sdivname="div_arrivaldetail_upload" hdivname="div_tourist_arrival_details">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”. / "ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ<sup>*</sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" style="color:red;" download=""><u>Click here to download</u></a></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="pledge-download">
														<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
													</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_pledge_upload">
														<input onchange="singleFileUpload('eimg_pledge_commitment');" name="img_pledge_commitment" id="eimg_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_pledge_commitment" style="display:none">
														<a id="a_pledge" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_pledge_commitment" name="pledge" Sdivname="div_pledge_upload" hdivname="div_pledge_commitment">Remove</button>
													</div>
												</div>
											</div>
											<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">											
												<p>"Data saving please wait"</p>
											</div>
											<div class="form-group clearfix">
												<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous   / ಹಿಂದಿನದು</a>
												<!-- <a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft /ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ </a>
												<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a> -->


										<a href="javascript:;" class="form-wizard-next-btn float-right" id="nextpage1"  style="display: none;">Next1 / ಮುಂದಿನದು</a>
										<a href="javascript:;" class="form-wizard-next-btn float-right draftdata_stage3" id="draftdata_stage3">Next / ಮುಂದಿನದು</a>


											</div>
									</fieldset>	
									<?php } ?>
									<!-- Product Tourist Transport Operator	Edit -->
									<?php if ($new_pid == 2 ){ ?>
									<fieldset class="wizard-fieldset comment-section">
											<div class="form-required">
												<div class="form-required-area">
													<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
													<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB) / ಅನುಮತಿಸಲಾದ ಡಾಕ್ಯುಮೆಂಟ್ ಪ್ರಕಾರ .JPG, .PNG, .PDF (2MB ಗಿಂತ ಕಡಿಮೆ)</h5>
												</div>										
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Registration/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
																									</div>									
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_registration_upload">
														<input name="img_registration_certificate" id="eimg_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_registration_certificate" style="display:none">
														<a id="a_registration_certificate" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_registration_certificate" name="registration_certificate" Sdivname="div_registration_upload" hdivname="div_registration_certificate">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-appli-form-padd.new">
									<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or</li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or </li>
											<li> In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li><br>
									<br>ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
											<li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ</li>
											<li>"ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</li></p>
									</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ </h5>
													<sup> *</sup>
												</div>						
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload">
														<input name="img_certificate_shops" type="file" id="eimg_certificate_shops" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
														<a id="a_certificate_shops" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_certificate_shops" name="certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ	 </h5>
													<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/water bill) / property or municipality tax receipt/ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p><sup>	*	</sup>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_bank_upload">
														<input name="img_bank_reference" id="eimg_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_bank_referencee" style="display:none" >
														<a id="a_bank_referencee" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_bank_reference" value="bank_referencee" name="bank_referencee" Sdivname="div_bank_upload" hdivname="div_bank_referencee">Remove</button>
													</div>
												</div>
											</div>
											<!-- <div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Certificate from Chartered Accountant/ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ <sup>*</sup></h5>													
													<p>Documentary proof of turn over in Indian or foreign exchange from Tourist transport related activated operations during the previous financial year which should not be less than Rs. 7.5 Lakh“/ ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಪ್ರವಾಸಿ ಸಾರಿಗೆ ಸಂಬಂಧಿತ ಸಕ್ರಿಯ ಚಟುವಟಿಕೆಗಳಿಂದ ಮಾಡಲಾದ  ಭಾರತೀಯಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದ ಟರ್ನ್ ಓವರ್ ಕುರಿತು ದಸ್ತಾವೇಜಿನ ಪುರಾವೆ. ಟರ್ನ್ ಓವರ್ 7.5 ಲಕ್ಷ ರೂ ಗಳಿಗಿಂತ ಕಡಿಮೆ ಇರಬಾರದು.<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <br>• Profit & Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್ </p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_img_ca_upload">
														<input name="img_ca_certificate" id="eimg_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_ca_certificate" style="display:none">
														<a id="a_img_ca" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn"name="ca_certificate" Sdivname="div_img_ca_upload" hdivname="div_ca_certificate">Remove</button>
													</div>
												</div>
											</div>	 -->								
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>List of Directors / Partners / Name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></h5>
													<!-- <p>List of Directors/Partners or name of the Proprietor.</p> -->
												</div>
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_list_patners_upload">
														<input name="img_list_patners" id="eimg_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_list_patners" style="display:none">
														<a id="a_list_partners" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_list_patners" name="list_patners" Sdivname="div_list_patners_upload" hdivname="div_list_patners">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Brochures or Leaflets /ಕರಪತ್ರಗಳು <sup> * </sup></h5>
													<p>Brochures or leaflets brought out by the firms having all information about their activities /"ಸಂಸ್ಥೆಗಳು ಹೊರತಂದಿರುವ ಮತ್ತು ಸಂಸ್ಥೆಗಳ  ಚಟುವಟಿಕೆಗಳ ಕುರಿತು ಎಲ್ಲ ಮಾಹಿತಿಗಳನ್ನು ಹೊಂದಿರುವ ಕರಪತ್ರಗಳು"</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_brochures_upload">
														<input name="img_brochures" id="eimg_brochures" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_img_brochures" style="display:none">
														<a id="a_img_brochers" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_brochures" name="img_brochures" Sdivname="div_brochures_upload" hdivname="div_img_brochures">Remove</button>
													</div>						
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copy of GST Registration Certificate / ಜಿ ಎಸ್ ಟಿ  ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_gstregis_upload">
														<input name="img_gst_regis" id="eimg_gst_regis" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_gst_regis" style="display:none">
														<a id="a_gstregis" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_gst_regis" name="gstregis" Sdivname="div_gstregis_upload" hdivname="div_gst_regis">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup>*</sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_pan_upload">
														<input name="img_pan_copy" id="eimg_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>			
													</div>
													<div class="agent-form-file-view1" id="div_pan_copy" style="display:none">
														<a id="a_pancopy" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_pan_copy" name="pan" Sdivname="div_pan_upload" hdivname="div_pan_copy">Remove</button>
													</div> 
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copies of State Permit valid for Karnataka / 
														All-India Permit tourist permits issued by the concerned Transport Department for 
														Tourist Vehicles / ಕರ್ನಾಟಕ ರಾಜ್ಯದಲ್ಲಿ  ಮಾನ್ಯವಾಗುವ ರಾಜ್ಯ ಪರವಾನಗಿಯ ಪ್ರತಿಗಳು / ಪ್ರವಾಸಿ ವಾಹನಗಳಿಗಾಗಿ ಸಂಬಂಧಿತ ಸಾರಿಗೆ ಇಲಾಖೆಯಿಂದ ನೀಡಲಾದ ಪ್ರವಾಸಿ ಪರವಾನಗಿ ಪ್ರತಿಗಳು<sup> * </sup></h6>
													<p>For more than 1 vehicle valid permits for all the vehicles must be uploaded in a single pdf / "1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು  ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು."</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_statepermit_upload">
														<input name="img_state_permit" id="eimg_state_permit" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_state_permit" style="display:none">
														<a id="a_state_permit" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_state_permit" name="permit" Sdivname="div_statepermit_upload" hdivname="div_pan_copy">Remove</button>
													</div> 
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Registration Certificate of Tourist Vehicles/ ಪ್ರವಾಸಿ ವಾಹನಗಳ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ </h6>
													<!-- <sup> * </sup> -->
													<p>For more than 1 vehicle valid registration certificate for all the vehicles must be uploaded in a single pdf / 1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು  ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_tourvehicle_upload">
														<input name="img_tourist_vehicle" id="eimg_tourist_vehicle" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_tourist_vehicle" style="display:none">
														<a id="a_tourist_vehicle" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_tourist_vehicle" name="tourist_vehicle" Sdivname="div_tourvehicle_upload" hdivname="div_tourist_vehicle">Remove</button>
													</div> 
												</div>
											</div>	
																				

											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5> Details of Office Premises / ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು <sup> * </sup></h5>
													<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ</p>				
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_premises_upload">
														<input name="img_off_premises" id="eimg_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_premises" style="display:none">
														<a id="a_premises" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_premises" name="off_premises" Sdivname="div_premises_upload" hdivname="div_off_premises">Remove</button>
													</div> 
												</div>
											</div>
											<!-- <div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Labour Department Certificate / ಕಾರ್ಮಿಕ ಇಲಾಖೆ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_labor_dep_upload">
														<input name="img_labour_department" id="eimg_labour_department" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_labour_department" style="display:none">
														<a id="a_labor_department" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="labour_department" Sdivname="div_labor_dep_upload" hdivname="div_labour_department">Remove</button>
													</div> 
												</div>
											</div> -->
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ	<sup>	*	</sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_photoarrested_upload">
														<input name="img_md_photo_attested" id="eimg_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_md_photo_attested" style="display:none">
														<a id="a_photo_attested" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_md_photo_attested" name="photo_attested" Sdivname="div_photoarrested_upload" hdivname="div_md_photo_attested">Remove</button>
													</div> 
												</div>										
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd"></div>										
													<div class="field-comment-sec" >											
														<input type="checkbox" class="checkupload" id="auth_rep" onclick="javascript:enable_attoney();" value="1">&nbsp;&nbsp;
														<input type="text" hidden="" id="auth_rep_val" name="auth_rep_val" >
														<label><h5>Authorized Representative of the Entity / ಘಟಕದ ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿ</h5></label>
													</div>
											</div>
											<div class="field-app-form" style="display: none" id="attorney_boardresolution">
												<div class="field-appli-form-padd">
													<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
													<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
												</div>	
												<div class="field-comment-sec">
													<div class="form_input" id="eyes_d4">
														<input type="radio" class="checkupload" id="eyesCheck_d4" onclick="javascript:yesnoCheck_doc('eyesCheck_d4','div_powerof_attorney_upload','eyes_d4');"  value="1">	
														<label for="yes">Power Of Attorney</label>
														<input type="radio" class="checkupload" id="enoCheck_d4" onclick="javascript:yesnoCheck_doc('enoCheck_d4','div_powerof_attorney_upload','eyes_d4');"  value="2">
														<label for="no">Board Resolution</label>
													</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_powerof_attorney_upload">
														<input name="img_power_of_attorney" id="eimg_power_of_attorney" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<!-- <div class="error_div"></div> -->
													</div>
													<div class="agent-form-file-view1" id="div_power_of_attorney" style="display:none">
														<a id="a_powerof_attorney" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_power_of_attorney" name="power_of_attorney" Sdivname="div_powerof_attorney_upload" hdivname="div_power_of_attorney">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup>  * </sup></h6>											
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
														<input name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
														<a id="a_builexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_buil_exterior" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
													</div> 
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of the Office Building Interior / <sup>*</sup> ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ</h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
														<input name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
														<a id="a_buildInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_buil_interior" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup> * </sup> </h6>											
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_boardentity_upload">
														<input name="img_board_entity" id="eimg_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_board_entity" style="display:none">
														<a id="a_boardentityr" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_board_entity" name="board_entity" Sdivname="div_boardentity_upload" hdivname="div_board_entity">Remove</button>
													</div>
												</div>
											</div>

											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of at least 1 Tourist Vehicle Exterior/ಕನಿಷ್ಠ 1 ಪ್ರವಾಸಿ ವಾಹನಗಳ ಫೋಟೋಗ್ರಫಿ <sup> * </sup> </h6>											
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_vehicleexterior_upload">
														<input name="img_vehicle_exterior" id="eimg_vehicle_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_vehicle_exterior" style="display:none">
														<a id="a_vehicleexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="vehicle_exterior" Sdivname="div_vehicleexterior_upload" hdivname="div_vehicle_exterior">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of at least 1 Tourist Vehicle Interior/ಕನಿಷ್ಠ 1 ಪ್ರವಾಸಿ ವಾಹನ ಒಳಾಂಗಣದ ಫೋಟೋಗ್ರಫಿ <sup>  *  </sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_vehicleinterior_upload">
														<input name="img_vehicle_interior" id="eimg_vehicle_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_vehicle_interior" style="display:none">
														<a id="a_vehicleInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="vehicle_interior" Sdivname="div_vehicleinterior_upload" hdivname="div_vehicle_interior">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Declaration stating that the TTO on a monthly basis shall mandatorily share/
														upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka 
														Tourism Website/ "ಟಿಟಿಒಗಳು ಮಾಸಿಕ ಆಧಾರದ ಮೇಲೆ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬುದರ ಕುರಿತು ಘೋಷಣೆ" <sup> * </sup></h6>
												</div>
												<div class="field-comment-sec">
													<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><i class="fa fa-download" aria-hidden="true"></i></a>
											</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_arrivaldetail_upload">
														<input name="img_tourist_arrival_details" id="eimg_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_tourist_arrival_details" style="display:none">
														<a id="a_arrivaldetail" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_tourist_arrival_details" name="arrival_details" Sdivname="div_arrivaldetail_upload" hdivname="div_tourist_arrival_details">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”. / <br>"ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ.<sup>  *  </sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" style="color:red;" download=""><u>Click here to download</u></a></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="pledge-download">
														<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
													</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_pledge_upload">
														<input name="img_pledge_commitment" id="eimg_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_pledge_commitment" style="display:none">
														<a id="a_pledge" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_pledge_commitment" name="pledge" Sdivname="div_pledge_upload" hdivname="div_pledge_commitment">Remove</button>
													</div>
												</div>
											</div>	
											<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">											
												<p>"Data saving please wait"</p>
											</div>										
											<div class="form-group clearfix">
												<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 1221 / ಹಿಂದಿನದು</a>
												<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft /ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ </a>
												<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
											</div>
									</fieldset>	
									<?php } ?>
									
									<!-- Caravan Tourism Edit -->
								<?php if ($new_pid == 3 ){ ?>		
								<fieldset class="wizard-fieldset comment-section">
											<div class="form-required">
												<div class="form-required-area">
													<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
													<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB) / ಅನುಮತಿಸಲಾದ ಡಾಕ್ಯುಮೆಂಟ್ ಪ್ರಕಾರ .JPG, .PNG, .PDF (2MB ಗಿಂತ ಕಡಿಮೆ) </h5>
												</div>										
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Registration/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></h5>
																									</div>									
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_registration_upload">
														<input name="img_registration_certificate"  id="eimg_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_registration_certificate" style="display:none">
														<a id="a_registration_certificate" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_registration_certificate" name="registration_certificate" Sdivname="div_registration_upload" hdivname="div_registration_certificate">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-appli-form-padd.new">
									<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<li>Should be a Company registered under The Indian Companies Act 1956/2013 or</li>
											<li>A Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or </li>
											<li> In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished </li><br>
									<br>ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
											<li>ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ</li>
											<li>ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ</li>
											<li>"ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</li></p>
									</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Registration certificate under Karnataka shops and Establishment act / ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ </h5>
													<sup> *</sup>
												</div>						
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload">
														<input name="img_certificate_shops" type="file" id="eimg_certificate_shops" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
														<a id="a_certificate_shops" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_certificate_shops" name="certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ<sup>*</sup> </h5>
													<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt/ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು. </p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_bank_upload">
														<input name="img_bank_reference" id="eimg_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_bank_referencee" style="display:none" >
														<a id="a_bank_referencee" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_bank_reference" value="bank_referencee" name="bank_referencee" Sdivname="div_bank_upload" hdivname="div_bank_referencee">Remove</button>
													</div>
												</div>
											</div>
											<!-- <div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Certificate from Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ <sup>*</sup></h5>													
													<p>Documentary proof of turn over in Indian or foreign exchange from caravan tourism related activities operations during the previous financial year / " ಕಾರವಾನ್ ಪ್ರವಾಸೋದ್ಯಮ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳಿಂದ ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಗಳಿಸಲಾದ ಭಾರತೀಯ ಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯ ಟರ್ನ್ ಒವರ್ ಕುರಿತು ದಸ್ತಾವೇಜು"<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ<br>• Profit & Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_img_ca_upload">
														<input name="img_ca_certificate" id="eimg_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_ca_certificate" style="display:none">
														<a id="a_img_ca" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn"name="ca_certificate" Sdivname="div_img_ca_upload" hdivname="div_ca_certificate">Remove</button>
													</div>
												</div>
											</div> -->									
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>List of Directors / Partners / Name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup>*</sup></h5>
													<!-- <p>List of Directors/Partners or name of the Proprietor.</p> -->
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_list_patners_upload">
														<input name="img_list_patners" id="eimg_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_list_patners" style="display:none">
														<a id="a_list_partners" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_list_patners" name="list_patners" Sdivname="div_list_patners_upload" hdivname="div_list_patners">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Copies of State Permit valid for Karnataka / All-India Permit for tourism activities or tourism related activities issued by the concerned Transport Department and R.C. of Caravan/ ಸಂಬಂಧಿತ ಸಾರಿಗೆ ಇಲಾಖೆಗಳಿಂದ ಮತ್ತು ಕಾರವಾನ್ ನ ಆರ್.ಸಿ. ಯಿಂದ ನೀಡಲಾದ ರಾಜ್ಯ ರಹದಾರಿ/ಅಖಿಲ ಭಾರತ ರಹದಾರಿ (ಪ್ರವಾಸೋದ್ಯಮ ಚಟುವಟಿಕೆಗಳು ಅಥವಾ ಪ್ರವಾಸೋದ್ಯಮ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳಿಗೆ)  <sup> * </sup></h5>
													<p>For more than 1 vehicle valid permits for all the vehicles must be uploaded in a single pdf/ "1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು."</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_caravan_rc_upload">
														<input name="img_caravan_rc" id="eimg_caravan_rc" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_caravan_rc" style="display:none">
														<a id="a_caravan_rc" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_caravan_rc" name="caravan_rc" Sdivname="div_caravan_rc_upload" hdivname="div_caravan_rc">Remove</button>
													</div>										
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Details of Office Premises / ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು<sup>*</sup></h5>
													<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ</p>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_premises_upload">
														<input name="img_off_premises" id="eimg_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_premises" style="display:none">
														<a id="a_premises" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_premises" name="off_premises" Sdivname="div_premises_upload" hdivname="div_off_premises">Remove</button>
													</div> 
												</div>
											</div>
											
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup>*</sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_photoarrested_upload">
														<input name="img_md_photo_attested" id="eimg_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_md_photo_attested" style="display:none">
														<a id="a_photo_attested" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_md_photo_attested" name="photo_attested" Sdivname="div_photoarrested_upload" hdivname="div_md_photo_attested">Remove</button>
													</div> 
												</div>										
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd"></div>										
													<div class="field-comment-sec">
														<input type="checkbox" class="checkupload" id="auth_rep" onclick="javascript:enable_attoney();" value="1">&nbsp;&nbsp;
														<input type="text" hidden="" id="auth_rep_val" name="auth_rep_val" >
														<label><h5>Authorized Representative of the Entity / ಘಟಕದ ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿ </h5></label>
													</div>
											</div>
											<div class="field-app-form" style="display: none" id="attorney_boardresolution">
												<div class="field-appli-form-padd">
													<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup> * </sup></h5>
													<p>(only in case of  Authorized Representative) / (ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
												</div>	
												<div class="field-comment-sec">
													<div class="form_input" id="eyes_d4">
														<input type="radio" class="checkupload" id="eyesCheck_d4" onclick="javascript:yesnoCheck_doc('eyesCheck_d4','div_powerof_attorney_upload','eyes_d4');"  value="1">	
														<label for="yes">Power Of Attorney</label>
														<input type="radio" class="checkupload" id="enoCheck_d4" onclick="javascript:yesnoCheck_doc('enoCheck_d4','div_powerof_attorney_upload','eyes_d4');"  value="2">
														<label for="no">Board Resolution</label>
													</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_powerof_attorney_upload">
														<input name="img_power_of_attorney" id="eimg_power_of_attorney" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<!-- <div class="error_div"></div> -->
													</div>
													<div class="agent-form-file-view1" id="div_power_of_attorney" style="display:none">
														<a id="a_powerof_attorney" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_power_of_attorney" name="power_of_attorney" Sdivname="div_powerof_attorney_upload" hdivname="div_power_of_attorney">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h6>	
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
														<input name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
														<a id="a_builexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_buil_exterior" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
													</div> 
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of the Office Building Interior / <sup>*</sup> ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ</h6>	
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
														<input name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
														<a id="a_buildInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_off_buil_interior" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Photograph of at least 1 Caravan Interior / ಕಾರವಾನ್ ಒಳಾಂಗಣದ ಕನಿಷ್ಠ 1 ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
													All the mandatory features to be captured/ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ಲಕ್ಷಣಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_caravan_interior_upload">
														<input name="img_caravan_interior" id="eimg_caravan_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_caravan_interior" style="display:none">
														<a id="a_caravanInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_caravan_interior" name="caravan_interior" Sdivname="div_caravan_interior_upload" hdivname="div_caravan_interior">Remove</button>
													</div>										
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Photograph of the at least 1 Caravan Exterior / ಕಾರವಾನ್ ಹೊರಾಂಗಣದ ಕನಿಷ್ಠ 1 ಛಾಯಾಚಿತ್ರ <sup> *</sup></h5>
													All the mandatory features to be captured / ಎಲ್ಲಾ ಕಡ್ಡಾಯ ಲಕ್ಷಣಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_caravan_exterior_upload">
														<input name="img_caravan_exterior" id="eimg_caravan_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_caravan_exterior" style="display:none">
														<a id="a_caravanexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_caravan_exterior" name="caravan_exterior" Sdivname="div_caravan_exterior_upload" hdivname="div_caravan_exterior">Remove</button>
													</div>												
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ) ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup> * </sup> </h6>		
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_boardentity_upload">
														<input name="img_board_entity" id="eimg_board_entity" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_board_entity" style="display:none">
														<a id="a_boardentityr" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_board_entity" name="board_entity" Sdivname="div_boardentity_upload" hdivname="div_board_entity">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copy of GST Registration Certificate / ಜಿ ಎಸ್ ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_gstregis_upload">
														<input name="img_gst_regis" id="eimg_gst_regis" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_gst_regis" style="display:none">
														<a id="a_gstregis" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_gst_regis" name="gstregis" Sdivname="div_gstregis_upload" hdivname="div_gst_regis">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h6>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_pan_upload">
														<input name="img_pan_copy" id="eimg_pan_copy" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_pan_copy" style="display:none">
														<a id="a_pancopy" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_pan_copy" name="pan" Sdivname="div_pan_upload" hdivname="div_pan_copy">Remove</button>
													</div> 
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Certificate for the Caravan(s) to show its compliance to the Automotive Industry Standards (AIS) -124- Procedure for Type Approval/ "ಆಟೋಮೋಟಿವ್ ಇಂಡಸ್ಟ್ರಿ ಸ್ಟ್ಯಾಂಡರ್ಡ್ಸ್ (ಎಐಎಸ್) -124- ಟೈಪ್ ಅನುಮೋದನೆಗಾಗಿ ಅದರ ಅನುಸರಣೆಯನ್ನು ತೋರಿಸಲು ಕಾರವಾನ್ (ಗಳಿಗೆ) ಪ್ರಮಾಣಪತ್ರ" <sup> * </sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_caravan_ais_upload">
														<input name="img_caravan_ais_certificate" id="eimg_caravan_ais_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_caravan_ais" style="display:none">
														<a id="a_caravanais" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_caravan_ais_certificate" name="caravan_ais" Sdivname="div_caravan_ais_upload" hdivname="div_caravan_ais">Remove</button>
													</div>											
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>Certificate of Motor Caravans for compliance to Central Motor Vehicles Rules,issued by Ministry of Road Transport and Highways/ Karnataka Motor Vehicle Rules 
													(as applicable)/ "ರಸ್ತೆ ಸಾರಿಗೆ ಮತ್ತು ಹೆದ್ದಾರಿಗಳ ಸಚಿವಾಲಯ / ಕರ್ನಾಟಕ ಮೋಟಾರು ವಾಹನ ನಿಯಮಗಳು ಅಡಿಯಲ್ಲಿ ನೀಡಲಾದ ಕೇಂದ್ರ ಮೋಟಾರು ವಾಹನ ನಿಯಮಗಳ ಅನುಸರಣೆಗಾಗಿ ಮೋಟಾರ್ ಕಾರವಾನ್ ಗಳ  ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವಂತೆ)"<sup> * </sup></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_caravan_ministry_certificate_upload">
														<input name="img_caravan_ministry_certificate" id="eimg_caravan_ministry_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_caravan_ministry_certificate" style="display:none">
														<a id="a_caravan_ministry" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_caravan_ministry_certificate" name="caravan_ministry" Sdivname="div_caravan_ministry_certificate_upload" hdivname="div_caravan_ministry_certificate">Remove</button>
													</div>											
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Declaration stating that the Caravan Operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website/"ಕಾರವಾನ್ ಆಪರೇಟರ್ ಪ್ರತಿ ತಿಂಗಳು ತಪ್ಪದೇ  ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬುದರ ಕುರಿತು ಘೋಷಣೆ." <sup> * </sup><br><a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>"style="color:red;" download><u>Click here to download</u></a></h6>
												</div>										
												<div class="field-comment-sec" >
													<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/declaration_format.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
											</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_arrivaldetail_upload">
														<input name="img_tourist_arrival_details" id="eimg_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_tourist_arrival_details" style="display:none">
														<a id="a_arrivaldetail" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_tourist_arrival_details"  name="tourist_arrival_details" Sdivname="div_arrivaldetail_upload" hdivname="div_tourist_arrival_details">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h6>Approval letter for the Caravan(s) from any of the below-mentioned authorities/ಕೆಳಗಿನ ಯಾವುದೇ ಅಧಿಕಾರಿಗಳಿಂದ ಕ್ಯಾರಾವಾನ್ (ಗಳಿಗೆ) ಗೆ ಅನುಮೋದನೆ  ಪತ್ರ. <sup> * </sup></h6>
													<ul>
														<li>Automotive Research Association of India (ARAI) /Automotive Research Association of India (ARAI)</li>
														<li>International Centre for Automotive Technology (ICAT) / International Centre for Automotive Technology (ICAT)</li>
														<li>Central Institute of Road Transport (CIRT)/ Central Institute of Road Transport (CIRT)</li>
													</ul>
												</div>										
												<div class="field-comment-sec" >
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_caravan_approval_letter_upload">
														<input name="img_caravan_approval_letter" id="eimg_caravan_approval_letter" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>	
													<div class="agent-form-file-view1" id="div_caravan_approval_letter" style="display:none">
														<a id="a_caravan_approval_letter" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_caravan_approval_letter" name="caravan_approval_letter" Sdivname="div_caravan_approval_letter_upload" hdivname="div_caravan_approval_letter">Remove</button>
													</div>
												</div>
											</div>
											<div class="field-app-form">
												<div class="field-appli-form-padd">
													<h5>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”. / "ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ<sup>*</sup><br><a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" style="color:red;" download=""><u>Click here to download</u></a></h5>
												</div>										
												<div class="field-comment-sec">
													<div class="pledge-download">
														<a href="<?php echo base_url().'theme/user/images/pledge.pdf';?>" download><!--i class="fa fa-download" aria-hidden="true"></i--></a>
													</div>
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_pledge_upload">
														<input name="img_pledge_commitment" id="eimg_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_pledge_commitment" style="display:none">
														<a id="a_pledge" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" docname="eimg_pledge_commitment" name="pledge" Sdivname="div_pledge_upload" hdivname="div_pledge_commitment">Remove</button>
													</div>
												</div>
											</div>
											<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">											
												<p>"Data saving please wait"</p>
											</div>
											<div class="form-group clearfix">
												<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 4/ ಹಿಂದಿನದು </a>
												<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft /ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ </a>
												<a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
											</div>
								</fieldset>	
								<?php } ?>
									
										<fieldset id="agent-other-det" class="wizard-fieldset agent-other-det">									
											<div class="other-detail-option">
												<div class="other-det">
													<h4>Memberships of International tour<br> associations, if any / ಅಂತಾರಾಷ್ಟ್ರೀಯ ಪ್ರವಾಸ ಸಂಘಗಳ ಸದಸ್ಯತ್ವಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></h4>
												</div>
												<div class="form_input">
													<input type="radio" id="yesCheck2" onclick="javascript:yesnoCheck('yesCheck2','ifYes2','international_member');" name="off_international_membership" value="Yes">
													<label for="yes">Yes</label>
													<input type="radio" id="noCheck2" onclick="javascript:yesnoCheck('noCheck2','ifYes2','international_member');" name="off_international_membership" value="No">
													<label for="no">No</label>											
												</div>										
												<!--div class="other-dept-text">
													<textarea name="off_international_membership" class="wizard-required"></textarea>					<div class="wizard-form-error"></div>				
												</div-->
												<div class="agent-form" style="display:none;" id="ifYes2">
													<div class="form_label">
														<p>Applicant to specify the Membership of International Tour Associations / ಅಂತಾರಾಷ್ಟ್ರೀಯ ಪ್ರವಾಸ ಸಂಘಗಳ ಸದಸ್ಯತ್ವಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></p>
													</div>
													<div class="other-dept-text">
														<textarea id="international_member" name="off_international_membership_details"></textarea>
													</div>									
												</div>
											</div>

											<div class="other-detail-option">
												<div class="other-det">
													<h4>Steps taken to promote domestic<br> tourists' activity / ದೇಶೀಯ ಪ್ರವಾಸಿಗರ ಚಟುವಟಿಕೆಯನ್ನು ಉತ್ತೇಜಿಸಲು ತೆಗೆದುಕೊಂಡ ಕ್ರಮಗಳು<sup>*</sup></h4>
												</div>										
												<div class="other-dept-text">
													<textarea name="off_promote_domestic_activity" id="eoff_promote_domestic_activity" class="wizard-required"></textarea>
													<div class="wizard-form-error"></div>			
												</div>
											</div>
											<div class="other-detail-option">
												<div class="other-det">
													<h4>Special programmes arranged for<br> Foreign Tourists, if any  / ವಿದೇಶಿ ಪ್ರವಾಸಿಗರಿಗಾಗಿ ಏರ್ಪಡಿಸಲಾದ ವಿಶೇಷ ಕಾರ್ಯಕ್ರಮಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></h4>
												</div>
												<div class="form_input">
													<input type="radio" id="yesCheck_d3" onclick="javascript:yesnoCheck_d1('yesCheck_d3','ifYes3','especial_programe');" name="off_prog_arranged_foreign_tourist" value="yes">				
													<label for="yes">Yes</label>
													<input type="radio" id="noCheck_d3" onclick="javascript:yesnoCheck_d1('yesCheck_d3','ifYes3','especial_programe');" name="off_prog_arranged_foreign_tourist" value="no" >
													<label for="no">No</label>											
												</div>	
												<div class="agent-form" style="display:none;" id="ifYes3">
													<div class="form_label">
														<p style="font-style: italic;">Applicant to specify details of the programmes arranged for foreign tourist in India or Abroad / ಭಾರತ ಅಥವಾ ವಿದೇಶದಲ್ಲಿ ವಿದೇಶಿ ಪ್ರವಾಸಿಗರಿಗೆ ಏರ್ಪಡಿಸಿರುವ ಕಾರ್ಯಕ್ರಮಗಳ ವಿವರಗಳನ್ನು ನಿರ್ದಿಷ್ಟಪಡಿಸಲು ಅರ್ಜಿದಾರ<sup>*</sup></p>
													</div>
													<div class="other-dept-text">
														<textarea id="especial_programe" name="off_prog_arranged_foreign_tourist_details"></textarea>
													</div>
												</div>
														<!--div class="other-dept-text">
															<textarea name="off_prog_arranged_foreign_tourist" class="wizard-required"></textarea>					<div class="wizard-form-error"></div>				
														</div-->
											</div>	
											<div class="other-detail-option">
												<div class="other-det">
														<h4>Do you want to make payment/ನೀವು ಪಾವತಿ ಮಾಡಲು ಬಯಸುವಿರಾ<sup>*</sup></h4>
												</div>
												<div class="form_input">
													<input type="radio"  id="payment_yes" onclick="javascript:payment_enable('edit','ajaxformsubmit','payment_yes','payment_no')" value="yes">
													<!--  -->
													<label for="yes">Yes</label>
													<input type="radio"  id="payment_no" onclick="javascript:payment_enable('edit','ajaxformsubmit','payment_no','payment_yes')" value="no">
													<!--  -->
													<label for="no">No</label>											
												</div>							
											</div>
											<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">											
												<p>"Data saving please wait"</p>
											</div>
											<div class="form-group clearfix">
												<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous 5/ಹಿಂದಿನದು</a>
												<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a>
												<a href="javascript:;" id="ajaxformsubmit" class="form-wizard-next-btn float-right disable-click">Application Fee 2 / ಅರ್ಜಿ ಶುಲ್ಕ</a>

												<!-- <a href="javascript:;" id="ajaxformsubmit" class="form-wizard-next-btn float-right">Application Fee 123 / ಅರ್ಜಿಯ ಶುಲ್ಕ</a>--> 

											</div>
									    </fieldset>
										<fieldset id="payment-det" class="wizard-fieldset payment-det">							
									</form>	

									<div class="other-detail-option">
										<div class="agent-application">				
											<div class="user-payment-details">
												<div class="user-payment">
													<div class="payment-title">
														<h3>Payment/ಪಾವತಿ</h3>
													</div>
													<div class="payment-details">
														<div class="payment-amount">
															<p>Payable Amount</p>
															<p>Pament Method</p>
														</div>
														<div class="payment-value">
															<p>Rs. 500.00</p>
															<p>Online payment</p>
														</div>
													</div>
												
													<div class="payment-options">
														
														<!--form name="razorpay-form" id="razorpay-formnew" action="<?php echo $callback_urlnew; ?>" method="POST">
														   <input type="text" name="insertidd" style="display:none;"  id="insertidd">
											               <input id="ORDER_ID" type="hidden" tabindex="1" maxlength="20" size="20" name="ORDER_ID" autocomplete="off"
											            value="<?php echo  "KTTF" . rand(10000,99999999)?>">
											            <input id="CUST_ID" type="hidden" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001">
											            <input id="INDUSTRY_TYPE_ID" type="hidden" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Travel">
											            <input id="CHANNEL_ID" type="hidden" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
											            <input title="TXN_AMOUNT" type="hidden" tabindex="10" type="text" name="TXN_AMOUNT" value="1">
														</form>
														<input  id="pay-btn" style="float:right;"  onclick="razorpaySubmitnew(this);" value="Pay Now" class="btn btn-primary" /-->
														<button type="button" style="float:right;" id="JsCheckoutPayment" name="submit" class="btn btn-primary">Pay Now 1</button>
															<!-- razoor pay ends -->
													</div>
													<br>									
														<p id="payload" style="display:none;" class="payloadc">Please Wait.. Processing..</p>
												</div>
											</div>
										</div>
									</div>
							
									<div class="form-group clearfix">
										<!--a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a-->
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center">Save as draft</a> -->
										<!--input type="submit" name="app_submit" value="Submit" class="form-wizard-submit float-right"-->
									</div>
								</fieldset>	
							<?php }
							if($pid != 0 && $new_pid == 4)
								 include('hotel.php') ?>
								 <?php 
								if($pid != 0 && $new_pid ==5)
								 include('Restaurant.php') ?>
								 <?php 
								if($pid != 0 && $new_pid ==6)
								 include('amusement.php') ?>
								 <?php 
								if($pid != 0 && $new_pid ==7)
								 include('guesthouse.php') ?>
								 <?php if($pid != 0 && $new_pid ==8)
								 include('homestay.php') ?>

						</div>
					</div>
				</div>
			</section>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<!-- <script src="admin/js/dataTables.min.js"></script>-->

<script type="text/javascript">

// $("#eimg_registration_certificate").on('change',function()
// { 
	
// 	var insid = document.getElementById("insid_draft").value ;
// 	var path = "<?php echo base_url();?>applications/application_filesave?insid="+insid;    
// 	 alert(path);
// 	var appName = $("#appName").val();
// 	var form = $('#formSave123')[0];
//     var formData = new FormData(form);
// 	//alert(formData);
// 		// var form = $('#formSave123')[0];
// 	 //    var formData = new FormData(form); 
// 	  //alert(form);  
// 		// var appName = $("#appName").val();
// 		// var form = $('#formSave123')[0];  
// 	 //   	//alert(from);alert(to);
	   	 
// 	$.ajax({
// 		    type: 'POST',
// 		   	url: path,
// 		    //data: form.serialize(),
// 			processData: false,
//             contentType: false, 
//             data: formData,
//              beforeSend: function() {
//                   $('#cover-spin').show();
//            },
// 		    success: function(data) 
// 		    {
// 				if(data=="Record Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
// 				{
// 					alert(data);
// 				}
// 				else
// 				{
// 					alert("else");
// 					 // $("#savemsg").hide();
// 					 // $(".draftdata").removeClass("disable-click");
// 				  //    var dataval=data.split("/");
// 		    //  		 sucval= dataval[0]; 
// 		    //   		 insid= dataval[1];
// 		    //    		 document.getElementById("insid_draft").value = insid;

// 					   // var replaceUrl="<?php echo base_url();?>dashboard";
// 					   // window.location.replace(replaceUrl);

// 					 // var replaceUrl = window.open(url, '_blank');
// 					 //  win.focus();
// 				}
// 			},
// 			  complete:function(defSimilar){
//                 $('#cover-spin').hide();
//                 $('#nextpage').click();
//                // $('#nextfeepage').click(); 
//             } 
// 	});
 
// });


$("#ajaxformsubmit").on('click',function()
{
	var path 		= "<?php echo base_url();?>applications/application_save";
	var appName = $("#appName").val();
	var form = $('#formSave123')[0];
    var formData = new FormData(form);
    var from = new Date($('input[name="tourist_permit_date[]"]').val());
	var to   = new Date($('input[name="tourist_permit_end_date[]"]').val());
	
    	if(to<from)
	    {
	    	alert("To date is less than from Date");	       
	        return false;
	    }
	    else
	    { 
			    $.ajax({
						    type: 'POST',
						    url: path,
						     //data: form.serialize(),
							processData: false,
			            	contentType: false,
			            	data: formData,
			          //   	beforeSend: function() {
					        //     $('#cover-spin').show(); 
					        //     setTimeout(function(){ $('#cover-spin').hide();  }, 180000); // 3 min

					        // },
						    success: function(data) 
						    {
						    	// console.log(data);
								if(data=="Application Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
								{
									alert('Applicant details not saved. Please try after some time.');
								}
								else
								{
								       var dataval=data.split("/");
								       sucval= dataval[0]; 
								       insid= dataval[1];
								       appmob= dataval[2];
								       appemail= dataval[3];
								       appname= dataval[4];
								       document.getElementById("insertidd").value = insid;  
								       document.getElementById("applmob").value = appmob;  
								       document.getElementById("applemail").value = appemail;       
								       document.getElementById("card_holder_name_id").value = appname;  
								       document.getElementById("card_holder_name_ida").value = appname;  
								       document.getElementById("merchant_product_info_id").value = insid;
								       document.getElementById("razorpay_payment_id").value = insid; 
								}
							},
							// complete:function(defSimilar){
				   //              $('#cover-spin').hide();
				   //          } 
					  });
		}
});

function addRoomDetails(){ 
	//var app_id = 1;
	var app_id = $('#insid_draft').val(); 
	var hs_accommodation_type = $('#ehs_accommodation_type').val();  
	var eroom_no = $('#eroom_no').val(); 
	var etariff_rs = $('#etariff_rs').val(); 
	var echarge_rs = $('#echarge_rs').val(); 
	var ehs_child_concession = $('#ehs_child_concession').val();  
	var path 		= '<?php echo base_url();?>applications/homestay_room_details?hs_accommodation_type='+ hs_accommodation_type+'&eroom_no='+eroom_no+'&etariff_rs='+etariff_rs+'&echarge_rs='+echarge_rs+'&app_id='+app_id;
 
	 $.ajax({
		    type: 'POST',
		    url: path,
		     //data: form.serialize(),
			processData: false,
	    	contentType: false, 
		    success: function(data) 
		    {
		    	//console.log(data); 

				 getRoomDetails(app_id);
				 // getRoomDetails();
			}, 
	  }); 

}  

function getRoomDetails(app_id){
	// var app_id = $('#insid_draft').val(); 
	// alert(app_id);
	var path 		= '<?php echo base_url();?>applications/get_homestay_room_details?app_id='+app_id;
 
	 $.ajax({
		    type: 'POST',
		    url: path,
		     //data: form.serialize(),
			processData: false,
	    	contentType: false, 
		    success: function(data) 
		    {
		    	 
		    	var data = JSON.parse(data); // pase in important 
		    	//console.log("2 = "+data); 
 
				var len= data.length; 
				//console.log("len = "+len); 
 
	            	for(var i=0; i<len; i++){
		                var id = data[i].id;
		                var app_id = data[i].app_id;
		                var hs_accommodation_type = data[i].hs_accommodation_type;
		                var no_of_rooms = data[i].no_of_rooms;
		                var hs_tariff_rs = data[i].hs_tariff_rs;
		                var extra_charge_rs = data[i].extra_charge_rs;

		                var tr_str = tr_str+" <tr>" +
		                    "<td align='center'>" + (i+1) + "</td>" +
		                    "<td align='center'>" + hs_accommodation_type + "</td>" +
		                    "<td align='center'>" + no_of_rooms + "</td>" +
		                    "<td align='center'>" + hs_tariff_rs + "</td>" +
		                    "<td align='center'>" + extra_charge_rs + "</td>" +
		                    '<td><input type="button" class="new-remove-button" value="Remove" onclick="deleteRoomDetails('+id+')" id="removeButton"></td>'+
		                    "</tr>";  

		                   //console.log(tr_str);  wait
		                
            		} 
            		$("#userTabletbody").html(tr_str);

			}, 
	  });

}

// $(function(){
// 	var app_id = $('#insid_draft').val();
//     getRoomDetails(app_id);
// });

function deleteRoomDetails(id){
 
	var app_id = $('#insid_draft').val();  
	 var path = '<?php echo base_url();?>applications/delete_homestay_room?id='+id;
 
	 $.ajax({
		    type: 'POST',
		    url: path,
		     //data: form.serialize(),
			processData: false,
	    	contentType: false, 
		    success: function(data) 
		    {
		    	 
		    	//var data = JSON.parse(data); // pase in important 
		    	//console.log("2 = "+data);  
			 	 //getRoomDetails(); 
			}, 
	  });

	//ajax success, load  getRoomDetails() // pass app_id 
}

function singleFileUpload(doc_img_name){
	 
		// const fileSize = input.files[0].size / 1024 / 1024;
	   
	var doc_img_name_e = doc_img_name.substring(1);
	var insid_draft = $('#insid_draft').val(); 

	//console.log("selected doc_img_name => "+doc_img_name+" insid_draft=> "+insid_draft);

	var myFormData = new FormData();
	var file1 = $("#"+doc_img_name).prop("files")[0];
		myFormData.append(doc_img_name_e, file1);
		myFormData.append('id', insid_draft);
		myFormData.append('key', doc_img_name_e);
		//alert(file1);
		//formData.append('key_file1', file1);
		$.ajax({
				url: '<?php  echo base_url(); ?>applications/fil1upload',
				type: 'POST',
				data: myFormData,
				// async: false,
				cache: false,
				contentType: false,
				processData: false,
				beforeSend: function(){
					// $('#cover-spin').show();
					//$("#btnphotoSubmit").attr("disabled", true);
				},
				success: function (returndata) {
					var imageCounter = parseInt($('#image_counter').val())+1;
					//console.log("imageCounter=> "+imageCounter);
					$('#image_counter').val(imageCounter);
					if(imageCounter>=7){
						//console.log("imageCounter=> "+imageCounter);
						$("#ajaxformsubmit").removeClass("disabled-link");


					}
					if(doc_img_name == 'eimg_registration_certificate'){
					
					const fi = document.getElementById('eimg_registration_certificate');
					// const fi = document.getElementsByClassName('eimg_registration_certificate');
					// alert(document.getElementById('eimg_registration_certificate'));
					 
					 // Check if any file is selected.
				        if (fi.files.length > 0) {
				        	
				            for (const i = 0; i <= fi.files.length - 1; i++) {
				  				
				                const fsize = fi.files.item(i).size;
				                const file = Math.round((fsize / 1024));

				                // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "File too Big, please select a file less than 2mb");
				                    document.getElementById('eimg_registration_certificate').value = null;
				                 } 
				                // else if (file < 2048) {
				                //     alert( 
				                //       "File too small, please select a file greater than 2mb");
				                // } 
				                else {
								    $("#eimg_registration_certificate").removeClass("wizard-required");
									$("#div_registration_certificate").show()
									$("#div_registration_upload").hide(); 
									$("#a_registration_certificate").attr("href", '<?php  echo base_url(); ?>' +'upload/img_registration_certificate/'+returndata);  	 
				                }
				            }
				        }
					}

					// if(doc_img_name == 'eimg_certificate_shops'){
					// 	$("#eimg_certificate_shops").removeClass("wizard-required");
					// 	$("#div_certificate_shops_upload").hide();
					// 	$("#div_certificate_shops").show();				
					// 	$("#a_certificate_shops").attr("href", '<?php  echo base_url(); ?>' +'upload/img_certificate_shops/'+returndata);
						 
					// }
					if(doc_img_name == 'eimg_bank_reference'){
						$("#eimg_bank_reference").removeClass("wizard-required");
						$("#div_bank_referencee").show();
						$("#div_bank_upload").hide();
						$("#a_bank_referencee").attr("href", '<?php  echo base_url(); ?>' +'upload/img_bank_reference/'+returndata); 
						 
					}
					if(doc_img_name == 'eimg_off_premises'){
						$("#eimg_off_premises").removeClass("wizard-required");
						$("#div_off_premises").show();
						$("#div_premises_upload").hide();					
						$("#a_premises").attr("href", '<?php  echo base_url(); ?>' +'upload/img_off_premises/'+returndata);
						 
					}
					// if(doc_img_name == 'eimg_off_buil_interior'){
					// 	$("#eimg_off_buil_interior").removeClass("wizard-required");
					// 	$("#div_off_buil_interior").show();
					// 	$("#div_buildInterior_upload").hide();
					// 	$("#a_buildInterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_off_buil_interior/'+returndata);
						 
					// }
					// if(doc_img_name == 'eimg_off_buil_exterior'){
					// 	$("#eimg_off_buil_exterior").removeClass("wizard-required");
					// 	$("#div_off_buil_exterior").show()
					// 	$("#div_builexterior_upload").hide();
					// 	$("#a_builexterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_off_buil_exterior/'+returndata);
						 
					// }
					if(doc_img_name == 'eimg_occupancy_certificate'){
						$("#eimg_occupancy_certificate").removeClass("wizard-required");
						$("#div_occupancy_upload").hide();
						$("#div_occupancy_certificate").show();				
						$("#a_occupancy").attr("href", '<?php  echo base_url(); ?>' +'upload/img_occupancy_certificate/'+returndata);
					}
					if(doc_img_name == 'eimg_gst_regis'){
						$("#eimg_gst_regis").removeClass("wizard-required");
						$("#div_gst_regis").show();
						$("#div_gstregis_upload").hide();
						$("#a_gstregis").attr("href", '<?php  echo base_url(); ?>' +'upload/img_gst_regis/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_pan_copy'){
						$("#eimg_pan_copy").removeClass("wizard-required");
						$("#div_pan_copy").show();
						$("#div_pan_upload").hide();				
						$("#a_pancopy").attr("href", '<?php  echo base_url(); ?>' +'upload/img_pan_copy/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_fssai_certificate'){
						$("#eimg_fssai_certificate").removeClass("wizard-required");
						$("#div_fssai_upload").hide();
						$("#div_fssai_certificate").show();				
						$("#a_fssai").attr("href", '<?php  echo base_url(); ?>' +'upload/img_fssai_certificate/'+returndata);
						 
					}
					// if(doc_img_name == 'eimg_noobj_certificate'){
					// 	$("#eimg_noobj_certificate").removeClass("wizard-required");
					// 	$("#div_noobj_upload").hide();
					// 	$("#div_noobj_certificate").show();				
					// 	$("#a_noobj_certificate").attr("href", '<?php  echo base_url(); ?>' +'upload/img_noobj_certificate/'+returndata);
						 
					// }
					if(doc_img_name == 'eimg_license'){
						$("#eimg_license").removeClass("wizard-required");
						$("#div_license_upload").hide();
						$("#div_license").show();				
						$("#a_license").attr("href", '<?php  echo base_url(); ?>' +'upload/img_license/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_pollution_noc'){
						$("#eimg_pollution_noc").removeClass("wizard-required");
						$("#div_pollutionnoc_upload").hide();
						$("#div_pollution_noc").show();				
						$("#a_pollution_noc").attr("href", '<?php  echo base_url(); ?>' +'upload/img_pollution_noc/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_bar_permit'){
						$("#eimg_bar_permit").removeClass("wizard-required");
						$("#div_bar_permit_upload").hide();
						$("#div_bar_permit").show();				
						$("#a_bar_permit").attr("href", '<?php  echo base_url(); ?>' +'upload/img_bar_permit/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_tourist_arrival_details'){
						$("#eimg_tourist_arrival_details").removeClass("wizard-required");
						$("#div_tourist_arrival_details").show();
						$("#div_arrivaldetail_upload").hide();
						$("#a_arrivaldetail").attr("href", '<?php  echo base_url(); ?>' +'upload/img_tourist_arrival_details/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_board_entity'){
						$("#eimg_board_entity").removeClass("wizard-required");
						$("#div_board_entity").show();
						$("#div_boardentity_upload").hide();
						$("#a_boardentityr").attr("href", '<?php  echo base_url(); ?>' +'upload/img_board_entity/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_pledge_commitment'){
						$("#eimg_pledge_commitment").removeClass("wizard-required");
						$("#div_pledge_commitment").show();
						$("#div_pledge_upload").hide();					
						$("#a_pledge").attr("href", '<?php  echo base_url(); ?>' +'upload/img_pledge_commitment/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_noc_environment'){
						 $("#eimg_noc_environment").removeClass("wizard-required");
						$("#div_noc_environment_upload").hide();
						$("#div_noc_environment").show();				
						$("#a_noc_environment").attr("href", '<?php  echo base_url(); ?>' +'upload/img_noc_environment/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_noc_airport'){
						 $("#eimg_noc_airport").removeClass("wizard-required");
						$("#div_noc_airport_upload").hide();
						$("#div_noc_airport").show();				
						$("#a_noc_airport").attr("href", '<?php  echo base_url(); ?>' +'upload/img_noc_airport/'+returndata);
						 
					}
					if(doc_img_name == 'eimg_crz_clearance'){
					 	$("#eimg_crz_clearance").removeClass("wizard-required");
						$("#div_crz_clearance_upload").hide();
						$("#div_crz_clearance").show();				
						$("#a_crz_clearance").attr("href", '<?php  echo base_url(); ?>' +'upload/img_crz_clearance/'+returndata);
						 
					}

					if(doc_img_name == 'eimg_list_patners'){
					 	$("#eimg_list_patners").removeClass("wizard-required");
						$("#div_list_patners").show()
						$("#div_list_patners_upload").hide();
						$("#a_list_partners").attr("href", '<?php  echo base_url(); ?>' +'upload/img_list_patners/'+returndata);
					}
					if(doc_img_name == 'eimg_brochures'){ 
						$("#eimg_brochures").removeClass("wizard-required");
						$("#div_img_brochures").show();
						$("#div_brochures_upload").hide();
						$("#a_img_brochers").attr("href", '<?php  echo base_url(); ?>' +'upload/img_brochures/'+returndata );
					}

					if(doc_img_name == 'eimg_md_photo_attested'){ 
						$("#eimg_md_photo_attested").removeClass("wizard-required");
						$("#div_md_photo_attested").show();
						$("#div_photoarrested_upload").hide();
						$("#a_photo_attested").attr("href", '<?php  echo base_url(); ?>' +'upload/img_md_photo_attested/'+returndata);
						 
					}

 
					if(doc_img_name == 'eimg_power_of_attorney'){ 
					 
						$("#eimg_power_of_attorney").removeClass("wizard-required");				
						$("#div_power_of_attorney").show();
						$("#div_powerof_attorney_upload").hide();
						$("#a_powerof_attorney").attr("href", '<?php  echo base_url(); ?>' +'upload/img_power_of_attorney/'+returndata); 
					 }

					 if(doc_img_name == 'eimg_state_permit'){
					 	$("#eimg_state_permit").removeClass("wizard-required");
						$("#div_state_permit").show();
						$("#div_statepermit_upload").hide();				
						$("#a_state_permit").attr("href", '<?php  echo base_url(); ?>' +'upload/img_state_permit/'+returndata);
					 }
					 if(doc_img_name == 'eimg_tourist_vehicle'){
					 	$("#eimg_tourist_vehicle").removeClass("wizard-required");
						$("#div_tourist_vehicle").show();
						$("#div_tourvehicle_upload").hide();				
						$("#a_tourist_vehicle").attr("href", '<?php  echo base_url(); ?>' +'upload/img_tourist_vehicle/'+returndata);
					 }
					 if(doc_img_name == 'eimg_vehicle_interior'){
					 	$("#eimg_vehicle_interior").removeClass("wizard-required");
						$("#div_vehicle_interior").show();
						$("#div_vehicleinterior_upload").hide();				
						$("#a_vehicleInterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_vehicle_interior/'+returndata);
					 }
					  if(doc_img_name == 'eimg_vehicle_interior'){
					 	$("#eimg_vehicle_interior").removeClass("wizard-required");
						$("#div_vehicle_interior").show();
						$("#div_vehicleinterior_upload").hide();				
						$("#a_vehicleInterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_vehicle_interior/'+returndata);
					 }
					  if(doc_img_name == 'eimg_vehicle_interior'){
					 	$("#eimg_vehicle_interior").removeClass("wizard-required");
						$("#div_vehicle_interior").show();
						$("#div_vehicleinterior_upload").hide();				
						$("#a_vehicleInterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_vehicle_interior/'+returndata);
					 }
					  if(doc_img_name == 'eimg_vehicle_interior'){
					 	$("#eimg_vehicle_interior").removeClass("wizard-required");
						$("#div_vehicle_interior").show();
						$("#div_vehicleinterior_upload").hide();				
						$("#a_vehicleInterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_vehicle_interior/'+returndata);
					 }

					 if(doc_img_name == 'eimg_owner_certificate'){
						var fi = document.getElementById('eimg_owner_certificate');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_owner_certificate').value = null;
				                 }
							        else{     

									$("#eimg_owner_certificate").removeClass("wizard-required");
									$("#div_owner_certificate").show();
									$("#div_owner_certificate_upload").hide();				
									$("#a_owner_certificate").attr("href", '<?php  echo base_url(); ?>' +'upload/img_owner_certificate/'+returndata);
								}
							}		 
						}
			        }

			         if(doc_img_name == 'eimg_off_buil_interior'){
						var fi = document.getElementById('eimg_off_buil_interior');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_off_buil_interior').value = null;
				                 }
							        else{     

									$("#eimg_off_buil_interior").removeClass("wizard-required");
									$("#div_off_buil_interior").show();
									$("#div_buildInterior_upload").hide();
									$("#a_buildInterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_off_buil_interior/'+returndata);
								}
							}		 
						}
			        } 

			         if(doc_img_name == 'eimg_off_buil_exterior'){
						var fi = document.getElementById('eimg_off_buil_exterior');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_off_buil_exterior').value = null;
				                 }
							        else{     

									$("#eimg_off_buil_exterior").removeClass("wizard-required");
									$("#div_off_buil_exterior").show()
									$("#div_builexterior_upload").hide();
									$("#a_builexterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_off_buil_exterior/'+returndata);
								}
							}		 
						}
			        } 

			        if(doc_img_name == 'eimg_certificate_shops'){
						var fi = document.getElementById('eimg_certificate_shops');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_certificate_shops').value = null;
				                 }
							        else{     

									$("#eimg_certificate_shops").removeClass("wizard-required");
									$("#div_certificate_shops_upload").hide();
									$("#div_certificate_shops").show();				
									$("#a_certificate_shops").attr("href", '<?php  echo base_url(); ?>' +'upload/img_certificate_shops/'+returndata);
						 
								}
							}		 
						}
			        }
 
			         if(doc_img_name == 'eimg_adhaar_permit'){
						var fi = document.getElementById('eimg_adhaar_permit');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_adhaar_permit').value = null;
				                 }
							        else{     

									$("#eimg_adhaar_permit").removeClass("wizard-required");
									$("#div_adhaar_permit").show();
									$("#div_adhaar_permit_upload").hide();				
									$("#a_adhaar_permit").attr("href", '<?php  echo base_url(); ?>' +'upload/img_adhaar_permit/'+returndata);
								}
							}		 
						}
			        }

			         if(doc_img_name == 'eimg_built_front_view'){
						var fi = document.getElementById('eimg_built_front_view');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_built_front_view').value = null;
				                 }
							        else{     

									$("#eimg_built_front_view").removeClass("wizard-required");
									$("#div_buil_front").show();
									$("#div_buil_front_upload").hide();				
									$("#a_builfront").attr("href", '<?php  echo base_url(); ?>' +'upload/img_built_front_view/'+returndata);
								}
							}		 
						}
			        } 

			        if(doc_img_name == 'eimg_room_interior'){
						var fi = document.getElementById('eimg_room_interior');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_room_interior').value = null;
				                 }
							        else{     

									$("#eimg_room_interior").removeClass("wizard-required");
									$("#div_room_interior").show();
									$("#div_room_interior_upload").hide();				
									$("#a_room_interior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_room_interior/'+returndata);
								}
							}		 
						}
			        } 

			         if(doc_img_name == 'eimg_room_exterior'){
						var fi = document.getElementById('eimg_room_exterior');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_room_exterior').value = null;
				                 }
							        else{     

									$("#eimg_room_exterior").removeClass("wizard-required");
									$("#div_room_exterior").show();
									$("#div_room_exterior_upload").hide();				
									$("#a_builexterior").attr("href", '<?php  echo base_url(); ?>' +'upload/img_room_exterior/'+returndata);
								}
							}		 
						}
			        }

			        if(doc_img_name == 'eimg_local_certificate'){
						var fi = document.getElementById('eimg_local_certificate');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_local_certificate').value = null;
				                 }
							        else{     

									$("#a_local_certificate").removeClass("wizard-required");
									$("#div_local_certificate").show();
									$("#div_local_certificate_upload").hide();				
									$("#a_local_certificate").attr("href", '<?php  echo base_url(); ?>' +'upload/img_local_certificate/'+returndata);
								}
							}		 
						}
			        } 

			        if(doc_img_name == 'eimg_noobj_certificate'){
						var fi = document.getElementById('eimg_noobj_certificate');
				        if (fi.files.length > 0) {
				            for (var i = 0; i <= fi.files.length - 1; i++) {	
				                var fsize = fi.files.item(i).size;
				                var file = Math.round((fsize / 1024));
				              // The size of the file 4096.
				                if (file >= 2048) {
				                    alert(
				                      "The file size is too large. Please upload a file less than 2MB");
				                    document.getElementById('eimg_noobj_certificate').value = null;
				                 }
							        else{     

									$("#eimg_noobj_certificate").removeClass("wizard-required");
									$("#div_noobj_upload").hide();
									$("#div_noobj_certificate").show();				
									$("#a_noobj_certificate").attr("href", '<?php  echo base_url(); ?>' +'upload/img_noobj_certificate/'+returndata);
								}
							}		 
						}
			        } 
					   

					//console.log('imageCounter=> '+imageCounter);

					//console.log(returndata);
					 return false; 
					if(returndata==1){
						swal("Profile photo uploaded successfully!!", {
							  icon: "success",
						});  
						setTimeout(function(){  location.reload(); }, 1000);   
					}else if(returndata==-1){
						swal("Alert", "Please attach file", "error"); 
						return false; 
					}else{
						swal("Alert", "Please try after sometime", "error");
						return false;
					}
					 
				},
				complete: function(){
					// $('#cover-spin').hide();
					// $("#btnphotoSubmit").attr("disabled", false);
				}
		}); 

}

// $("#eimg_registration_certificate_old").on('change',function()
// { 
// 	var insid_draft = $('#insid_draft').val(); 
// 	var myFormData = new FormData();
// 	var file1 = $("#eimg_registration_certificate").prop("files")[0];
// 		myFormData.append('img_registration_certificate', file1);
// 		myFormData.append('id', insid_draft);
// 		myFormData.append('key', 'img_registration_certificate');
// 		//formData.append('key_file1', file1);
// 		$.ajax({
// 				url: '<?php  echo base_url(); ?>applications/fil1upload',
// 				type: 'POST',
// 				data: myFormData,
// 				// async: false,
// 				cache: false,
// 				contentType: false,
// 				processData: false,
// 				beforeSend: function(){
// 					$('#cover-spin').show();
// 					//$("#btnphotoSubmit").attr("disabled", true);
// 				},
// 				success: function (returndata) {

// 					$("#eimg_registration_certificate").removeClass("wizard-required");
// 						$("#div_registration_certificate").show()
// 						$("#div_registration_upload").hide(); 
// 						$("#a_registration_certificate").attr("href", '<?php  echo base_url(); ?>' +'upload/img_registration_certificate/'+returndata); 


// 					console.log(returndata);
// 					 return false; 
// 					if(returndata==1){
// 						swal("Profile photo uploaded successfully!!", {
// 							  icon: "success",
// 						});  
// 						setTimeout(function(){  location.reload(); }, 1000);   
// 					}else if(returndata==-1){
// 						swal("Alert", "Please attach file", "error"); 
// 						return false; 
// 					}else{
// 						swal("Alert", "Please try after sometime", "error");
// 						return false;
// 					}
					 
// 				},
// 				complete: function(){
// 					$('#cover-spin').hide();
// 					$("#btnphotoSubmit").attr("disabled", false);
// 				}
// 		}); 

// });
  

$(".draftdata").on('click',function()
{
		// alert("test123");
		$("#draftdata").addClass("disable-click");
		$("#savemsg").show();
		var path 	= "<?php echo base_url();?>applications/application_savedraft";
		var appName = $("#appName").val();
		var form = $('#formSave123')[0];
	    var formData = new FormData(form); 
	  	// console.log(document.getElementsByName('tourist_permit_date').value);
	  	// console.log($('input[name="tourist_permit_date"]').val());
	  	// console.log($('input[name="tourist_permit_end_date"]').val());
	    var from = new Date($('input[name="tourist_permit_date[]"]').val());
	    var to   = new Date($('input[name="tourist_permit_end_date[]"]').val());	    
	   	//alert(from);alert(to);
	   	
	    if(to<from)
	    {
	    	alert("To date is less than from Date");	       
	        return false;
	    }
	    else
	    {    
	    	//alert("else");
		    $.ajax({
					    type: 'POST',
					   	url: path,
					    //data: form.serialize(),
						processData: false,
			            contentType: false,
			            data: formData,
			             beforeSend: function() {
			                  $('#cover-spin').show();
			           },
					    success: function(data) 
					    {
							if(data=="Record Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
							{
								alert(data);
							}
							else
							{
								 $("#savemsg").hide();
								 $(".draftdata").removeClass("disable-click");
							     var dataval=data.split("/");
					     		 sucval= dataval[0]; 
					      		 insid= dataval[1];
					       		 document.getElementById("insid_draft").value = insid;
					       		 
					       		 //console.log("insid=> "+insid); 
								   // var replaceUrl="<?php echo base_url();?>dashboard";
								   // window.location.replace(replaceUrl); 
							}
						},
						  complete:function(defSimilar){
			                $('#cover-spin').hide();
			                $('#nextpage').click(); 
			                //alert($( "#draftdata" ).hasClass( "nextpage_stage3" ) );
			              
			            } 
				});
    	}
});

$(".draftdata_stage3").on('click',function()
{ 
		$("#draftdata_stage3").addClass("disable-click");
		$("#savemsg").show();
		var path 	= "<?php echo base_url();?>applications/application_savedraft";
		var appName = $("#appName").val();
		var form = $('#formSave123')[0];
	    var formData = new FormData(form); 
	  	// console.log(document.getElementsByName('tourist_permit_date').value);
	  	// console.log($('input[name="tourist_permit_date"]').val());
	  	// console.log($('input[name="tourist_permit_end_date"]').val());
	    var from = new Date($('input[name="tourist_permit_date[]"]').val());
	    var to   = new Date($('input[name="tourist_permit_end_date[]"]').val());	    
	   	//alert(from);alert(to);
	   	
	    if(to<from)
	    {
	    	alert("To date is less than from Date");	       
	        return false;
	    }
	    else
	    {    
	    	//alert("else");
		    $.ajax({
					    type: 'POST',
					   	url: path,
					    //data: form.serialize(),
						processData: false,
			            contentType: false,
			            data: formData,
			             beforeSend: function() {
			                  $('#cover-spin').show();
			           },
					    success: function(data) 
					    {
							if(data=="Record Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
							{
								alert(data);
							}
							else
							{
								 $("#savemsg").hide();
								 $(".draftdata").removeClass("disable-click");
							     var dataval=data.split("/");
					     		 sucval= dataval[0]; 
					      		 insid= dataval[1];
					       		 document.getElementById("insid_draft").value = insid;

								   // var replaceUrl="<?php echo base_url();?>dashboard";
								   // window.location.replace(replaceUrl); 
							}
						},
						  complete:function(defSimilar){
			                $('#cover-spin').hide();
			                $('#nextpage1').click(); 
			                //alert($( "#draftdata" ).hasClass( "nextpage_stage3" ) );
 
			            } 
				});
    	}
});
$(".draftdata_stage2").on('click',function()
{
		
		$("#draftdata_stage3").addClass("disable-click");
		$("#savemsg").show();
		var path 	= "<?php echo base_url();?>applications/application_savedraft";
		var appName = $("#appName").val();
		var form = $('#formSave123')[0];
	    var formData = new FormData(form); 
	  	// console.log(document.getElementsByName('tourist_permit_date').value);
	  	// console.log($('input[name="tourist_permit_date"]').val());
	  	// console.log($('input[name="tourist_permit_end_date"]').val());
	    var from = new Date($('input[name="tourist_permit_date[]"]').val());
	    var to   = new Date($('input[name="tourist_permit_end_date[]"]').val());	    
	   	//alert(from);alert(to);
	   	
	    if(to<from)
	    {
	    	alert("To date is less than from Date");	       
	        return false;
	    }
	    else
	    {    
	    	//alert("else");
		    $.ajax({
					    type: 'POST',
					   	url: path,
					    //data: form.serialize(),
						processData: false,
			            contentType: false,
			            data: formData,
			             beforeSend: function() {
			                  $('#cover-spin').show();
			           },
					    success: function(data) 
					    {
							if(data=="Record Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
							{
								alert(data);
							}
							else
							{
								 $("#savemsg").hide();
								 $(".draftdata").removeClass("disable-click");
							     var dataval=data.split("/");
					     		 sucval= dataval[0]; 
					      		 insid= dataval[1];
					       		 document.getElementById("insid_draft").value = insid;

								   // var replaceUrl="<?php echo base_url();?>dashboard";
								   // window.location.replace(replaceUrl); 
							}
						},
						  complete:function(defSimilar){
			                $('#cover-spin').hide();
			                $('#nextpage2').click(); 
			                //alert($( "#draftdata" ).hasClass( "nextpage_stage3" ) );
 
			            } 
				});
    	}
});


$(document).ready(function(){

	$('#example123').DataTable({
        "scrollX": true 
    });
    $("#insid_draft").val(<?php echo $pid ;?>); 
    $("#eproduct_id").val(<?php echo $prod_id; ?>);
	var dtToday = new Date();
    $('input[name="tourist_permit_date[]"]').attr('maxDate', dtToday);
	//$("#org_commencement_date" ).date({ minDate: 0});
	// $(".org_city").on('change',function(){
	// 	//console.log($(this).val());	
	// 	var districtid	= $(this).val();
	// 	//console.log(districtid);
	// 	//alert(countryid);
	// 	var BASE_URL = "<?php echo base_url();?>";
	// 	var path 		= BASE_URL+'applications/get_taluk';
	// 	//alert(path);
	// 	    $.ajax({
	// 		    type: 'POST',
	// 		    url: path,				
	// 		    data: {districtid : districtid},
	// 		   success:function(html){
 //                    // $('.org_taluk').html(html);
 //                    $("#eloc_taluk_office").html(html);
 //                }
	// 		});
	// });
	var BASE_URL = "<?php echo base_url();?>";
	var pid="<?php echo $pid ;?>";
	if(pid!=0)
	{
		//alert(pid);
			var path 	 = BASE_URL+'applications/draftedit';
			$.ajax({
				type: 'POST',
				dataType: "json",
				url: path,				
				data: {id : pid},
				success:function(data)
				{
		            //console.log(data['applicationDetails']);
		            // console.log(data['applicationDetails'][0]['enable_attoney']);
		            // console.log(data['vehicleDetails']);	
		            // console.log(data['applicationDetails'][0]['org_shop_date']);
		            $("#eproduct_id").val(data['applicationDetails'][0]['product_id']);
		            $("#eapplication_name").val(data['applicationDetails'][0]['applicant_name']);
					$("#eproperitor_name").val(data['applicationDetails'][0]['proprietor_name']);
		            $("#eorg_type_id").val(data['applicationDetails'][0]['org_type_id']);
		            $("#ecertificate_name").val(data['applicationDetails'][0]['certificate_name']);
		            $("#ecategory_type").val(data['applicationDetails'][0]['category_type']);
		            $('#eorg_commencement_date').val(data['applicationDetails'][0]['org_commencement_date']);
		            $('#eorg_shop_date').val(data['applicationDetails'][0]['org_shop_date']);
		            $("#egst_number").val(data['applicationDetails'][0]['gst_number']);
		            $("#epan_number").val(data['applicationDetails'][0]['pan_number']);
		            $("#ewebsite_name").val(data['applicationDetails'][0]['website_name']);
		            $("#eofficial_email").val(data['applicationDetails'][0]['official_email']);	
		            $("#etrade_lic_date").val(data['applicationDetails'][0]['trade_lic_date']);
		            // console.log(data['applicationDetails'][0]['hotel_name']);
		            $("#ehotel_name").val(data['applicationDetails'][0]['hotel_name']);

		            $("#eorg_registration_date").val(data['applicationDetails'][0]['org_registration_date']);
		            $("#eno_beds").val(data['applicationDetails'][0]['no_bed']);
		            $("#eownername").val(data['applicationDetails'][0]['owner_name']);
		            $("#emobileNo").val(data['applicationDetails'][0]['owner_mobile']);
		            $("#eowner_email").val(data['applicationDetails'][0]['owner_email']);
		            $("#eorg_loc_mobile").val(data['applicationDetails'][0]['other_off_contact']);
		            $("#eorg_loc_telephone").val(data['applicationDetails'][0]['org_loc_telephone']);
		            $("#ehotelemail").val(data['applicationDetails'][0]['other_email']);
		            $("#etotal_hotel_build_area").val(data['applicationDetails'][0]['total_hotel_build_area']);
		            $("#evisitor_capacity").val(data['applicationDetails'][0]['visitor_capacity']);
		            $("#eamusement_commencement_date").val(data['applicationDetails'][0]['amusement_commencement_date']);
		            $("#cat_restaurant").val(data['applicationDetails'][0]['cat_restaurant']);
		            $("#eno_rooms").val(data['applicationDetails'][0]['no_rooms']);
		           	$("#eorg_state").val(data['applicationDetails'][0]['org_state']);
		           
		            if(data['applicationDetails'][0]['img_MoT']!=null)
			        {
			           	$('#yesCheck_dmot').prop('checked',true);
			           	$("#ifYesmot").show();
			           	if(data['applicationDetails'][0]['img_MoT']!=null)
			           	{
			           		$("#a_mot").attr("href", '<?php echo base_url();?>' +'upload/img_MoT/'+data['applicationDetails'][0]['img_MoT']);	
			           		$("#div_mot_firm").show();
			           		$("#div_mot_upload").hide();
			           	}
			        }
			        else
			        {
			        	$('#noCheck_dmot').prop('checked',true);
			        }

		            if(data['applicationDetails'][0]['central_gov_approved']=='Yes')
			        {
			           	$('#yesCheck_d').prop('checked',true);
			           	$("#ifYes").show();
			           	if(data['applicationDetails'][0]['img_central_gov_registration']!=null)
			           	{
			           		$("#a_reg_document").attr("href", '<?php echo base_url();?>' +'upload/img_central_gov_registration/'+data['applicationDetails'][0]['img_central_gov_registration']);	
			           		$("#div_reg_firm").show();
			           		$("#div_reg_upload").hide();
			           	}
			        }
		            if(data['applicationDetails'][0]['central_gov_approved']=='No')
		            {
		            	$('#noCheck_d').prop('checked',true);	
		            }
		            if(data['applicationDetails'][0]['org_loc_add1']!=null)
		            {
		            	$("#eloc_addr1").val(data['applicationDetails'][0]['org_loc_add1']);	
		            }
		            if(data['applicationDetails'][0]['org_loc_add2']!=null)
		            {
		            	$("#eloc_addr2").val(data['applicationDetails'][0]['org_loc_add2']);	
		            }
		            $("#eloc_district").val(data['applicationDetails'][0]['district_id']);
		            var path 		= "<?php echo base_url();?>"+'applications/get_taluk';
					    $.ajax({
						    type: 'POST',
						    url: path,	
						    dataType : 'html',			
						    data: {districtid : data['applicationDetails'][0]['district_id']},
						   success:function(html)
						   {			
						   		//eloc_taluk_office		   	
			                    $('#eloc_taluk_office').html(html);
			                    $("#eloc_taluk_office").val(data['applicationDetails'][0]['org_loc_taluk_id']).attr("selected","selected");
			                    // console.log(data['applicationDetails'][0]['org_loc_taluk_id']);
			                }
						});
		            //$("#eloc_taluk").val(data['applicationDetails'][0]['org_taluk']);
		            if(data['applicationDetails'][0]['org_loc_city']!=null)
		            {
		            	$("#eorg_loc_city").val(data['applicationDetails'][0]['org_loc_city']);	
		            }
		            if(data['applicationDetails'][0]['org_loc_landmark']!=null)
		            {
		            	$("#eorg_loc_landmark").val(data['applicationDetails'][0]['org_loc_landmark']);	
		            }
		            if(data['applicationDetails'][0]['org_loc_pincode_id']!=0)
		            {
		            	$("#eorg_loc_pincode_id").val(data['applicationDetails'][0]['org_loc_pincode_id']);	
		            }
		            if(data['applicationDetails'][0]['org_loc_mobile']!=0)
		            {
		            	$("#eloc_mob").val(data['applicationDetails'][0]['org_loc_mobile']);
		            }
		            if(data['applicationDetails'][0]['org_loc_telephone']!=0)
		            {
		            	$("#eloc_tele").val(data['applicationDetails'][0]['org_loc_telephone']);
		            }
		            if(data['applicationDetails'][0]['org_total_build_sqft']!=0)
		            {
		            	$("#etotalbuildfuna").val(data['applicationDetails'][0]['org_total_build_sqft']);
		            }
		            $("#eorg_addr1").val((data['applicationDetails'][0]['other_off_addr1']!=null ? data['applicationDetails'][0]['other_off_addr1'] : ''));
		            $("#eorg_addr2").val(data['applicationDetails'][0]['other_off_addr2']);
		            $("#eorg_district").val(data['applicationDetails'][0]['other_off_district_id']);
		            $("#eorg_landmark").val(data['applicationDetails'][0]['org_landmark']);
		            
		            $("#eorg_mob").val(data['applicationDetails'][0]['other_off_contact']);
		            $("#emember_recognised_trade").val(data['applicationDetails'][0]['member_recognised_trade']);
		            if(data['applicationDetails'][0]['member_recognised_trade']=='Others')
		            {
		            	$("#emember_recognised_trade_other").show();
		            	$("#emember_recognised_trade_other").val(data['applicationDetails'][0]['member_recognised_trade_other']);	
		            }
		            $("#erestaurant_type").val(data['applicationDetails'][0]['restaurant_type']);
		            $("#eemail_id_hotel").val(data['applicationDetails'][0]['email_id_hotel']);
		            $("#ehotel_mbl_no").val(data['applicationDetails'][0]['hotel_mbl_no']);
		            $("#ehotel_resort").val(data['applicationDetails'][0]['hotel_resort']);
		            $("#elegal_name").val(data['applicationDetails'][0]['legal_name']); 
		            $("#epermanent_emp_male").val(data['applicationDetails'][0]['permanent_emp_male']); 
		            $("#epermanent_emp_female").val(data['applicationDetails'][0]['permanent_emp_female']);
		            $("#eoutsourced_emp_male").val(data['applicationDetails'][0]['outsourced_emp_male']);
		            $("#eoutsourced_emp_female").val(data['applicationDetails'][0]['outsourced_emp_female']);
		            if(data['applicationDetails'][0]['org_state']!=17)
		            {
		            	$("#eloc_districtnew").show();
		            	$("#eloc_taluk_office_new").show();
		            	$("#eloc_districtnew").val(data['applicationDetails'][0]['new_district']);
						$("#eloc_taluk_office_new").val(data['applicationDetails'][0]['new_taluk']);	
		            }
		            if(data['applicationDetails'][0]['org_state']==17)
		            {
		            	$("#eloc_taluk_office").show();
		            	$("#eloc_district").show();
		            	$("#eloc_districtnew").hide();
		            	$("#eloc_taluk_office_new").hide();
		            }
		            
					var path 		= "<?php echo base_url();?>"+'applications/get_taluk';
					    $.ajax({
						    type: 'POST',
						    url: path,				
						    data: {districtid : data['applicationDetails'][0]['other_off_district_id']},
						    success:function(html){
			                    $('#eorg_taluk').html(html);
			                    if(data['applicationDetails'][0]['other_off_taluk']!=null)
			                    {
			                    	$("#eorg_taluk").val(data['applicationDetails'][0]['other_off_taluk']).attr("selected","selected");
			                    }
			                    // $("#eloc_taluk_office").val(data['applicationDetails'][0]['other_off_taluk']).attr("selected","selected");
			                    //
			                }
						});
						//other_off_city
					$("#eorg_town").val((data['applicationDetails'][0]['other_off_city']=='null' ? '' : data['applicationDetails'][0]['other_off_city']));
					$("#eorg_pincode").val((data['applicationDetails'][0]['other_off_pincode_id']==0 ? '' : data['applicationDetails'][0]['other_off_pincode_id']));
					$("#eno_off").val((data['applicationDetails'][0]['other_office_count']=='null' ? '' : data['applicationDetails'][0]['other_office_count']));
					var BASE_URL = "<?php echo base_url();?>";
					// alert(BASE_URL);
					var imgCnt = 0;
					if(data['applicationDetails'][0]['img_registration_certificate']!=null)
					{
						$("#eimg_registration_certificate").removeClass("wizard-required");
						$("#div_registration_certificate").show()
						$("#div_registration_upload").hide();
						$("#a_registration_certificate").attr("href", BASE_URL +'upload/img_registration_certificate/'+data['applicationDetails'][0]['img_registration_certificate']);    
						 imgCnt++;       		
					}
					if(data['applicationDetails'][0]['img_bank_reference']!=null)
					{
						$("#eimg_bank_reference").removeClass("wizard-required");
						$("#div_bank_referencee").show();
						$("#div_bank_upload").hide();
						$("#a_bank_referencee").attr("href", BASE_URL +'upload/img_bank_reference/'+data['applicationDetails'][0]['img_bank_reference']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_ca_certificate']!=null)
					{
						$("#eimg_bank_reference").removeClass("wizard-required");
						$("#div_ca_certificate").show();
						$("#div_img_ca_upload").hide();				
						$("#a_img_ca").attr("href", BASE_URL +'upload/img_ca_certificate/'+data['applicationDetails'][0]['img_ca_certificate']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_list_patners']!=null)
					{
						$("#eimg_list_patners").removeClass("wizard-required");
						$("#div_list_patners").show()
						$("#div_list_patners_upload").hide();
						$("#a_list_partners").attr("href", BASE_URL +'upload/img_list_patners/'+data['applicationDetails'][0]['img_list_patners']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_brochures']!=null)
					{
						$("#eimg_brochures").removeClass("wizard-required");
						$("#div_img_brochures").show();
						$("#div_brochures_upload").hide();
						$("#a_img_brochers").attr("href", BASE_URL +'upload/img_brochures/'+data['applicationDetails'][0]['img_brochures']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_off_premises']!=null)
					{
						$("#eimg_off_premises").removeClass("wizard-required");
						$("#div_off_premises").show();
						$("#div_premises_upload").hide();					
						$("#a_premises").attr("href", BASE_URL +'upload/img_off_premises/'+data['applicationDetails'][0]['img_off_premises']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_labour_department']!=null)
					{
						$("#eimg_labour_department").removeClass("wizard-required");
						$("#div_labour_department").show();
						$("#div_labor_dep_upload").hide();
						$("#a_labor_department").attr("href", BASE_URL +'upload/img_labour_department/'+data['applicationDetails'][0]['img_labour_department']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_md_photo_attested']!=null)
					{
						$("#eimg_md_photo_attested").removeClass("wizard-required");
						$("#div_md_photo_attested").show();
						$("#div_photoarrested_upload").hide();
						$("#a_photo_attested").attr("href", BASE_URL +'upload/img_md_photo_attested/'+data['applicationDetails'][0]['img_md_photo_attested']);
						 imgCnt++;
					}
					
					if(data['applicationDetails'][0]['img_board_entity']!=null)
					{
						$("#eimg_board_entity").removeClass("wizard-required");
						$("#div_board_entity").show();
						$("#div_boardentity_upload").hide();
						$("#a_boardentityr").attr("href", BASE_URL +'upload/img_board_entity/'+data['applicationDetails'][0]['img_board_entity']);
						 imgCnt++;
					}

					if(data['applicationDetails'][0]['img_power_of_attorney']!=null)
					{
						$("#eimg_power_of_attorney").removeClass("wizard-required");
						$("#div_power_of_attorney").show();
						$("#div_powerof_attorney_upload").hide();
						$("#a_powerof_attorney").attr("href", BASE_URL +'upload/img_power_of_attorney/'+data['applicationDetails'][0]['img_power_of_attorney']);
						 imgCnt++;
					} 
				 
					if(data['applicationDetails'][0]['img_adhaar_permit']!=null)
					{
						$("#eimg_adhaar_permit").removeClass("wizard-required");
						$("#div_adhaar_permit").show();
						$("#div_adhaar_permit_upload").hide();
						$("#a_adhaar_permit").attr("href", BASE_URL +'upload/img_adhaar_permit/'+data['applicationDetails'][0]['img_adhaar_permit']);
						 imgCnt++;
					}


					if(data['applicationDetails'][0]['img_owner_certificate']!=null)
					{
						$("#eimg_owner_certificate").removeClass("wizard-required");
						$("#div_owner_certificate").show();
						$("#div_owner_certificate_upload").hide();
						$("#a_owner_certificate").attr("href", BASE_URL +'upload/img_owner_certificate/'+data['applicationDetails'][0]['img_owner_certificate']);
						 imgCnt++;
					}
 


					if(data['applicationDetails'][0]['img_built_front_view']!=null)
					{
						$("#eimg_built_front_view").removeClass("wizard-required");
						$("#div_buil_front").show();
						$("#div_buil_front_upload").hide();
						$("#a_builfront").attr("href", BASE_URL +'upload/img_built_front_view/'+data['applicationDetails'][0]['img_built_front_view']);
						 imgCnt++;
					} 

					if(data['applicationDetails'][0]['img_room_interior']!=null)
					{
						$("#eimg_room_interior").removeClass("wizard-required");
						$("#div_room_interior").show();
						$("#div_room_interior_upload").hide();
						$("#a_room_interior").attr("href", BASE_URL +'upload/img_room_interior/'+data['applicationDetails'][0]['img_room_interior']);
						 imgCnt++;
					}
 

			        if(data['applicationDetails'][0]['img_room_exterior']!=null)
					{
						$("#eimg_room_exterior").removeClass("wizard-required");
						$("#div_room_exterior").show();
						$("#div_room_exterior_upload").hide();
						$("#a_builexterior").attr("href", BASE_URL +'upload/img_room_exterior/'+data['applicationDetails'][0]['img_room_exterior']);
						 imgCnt++;
					} 

			        if(data['applicationDetails'][0]['img_local_certificate']!=null)
					{
						$("#eimg_local_certificate").removeClass("wizard-required");
						$("#div_local_certificate").show();
						$("#div_local_certificate_upload").hide();
						$("#a_local_certificate").attr("href", BASE_URL +'upload/img_local_certificate/'+data['applicationDetails'][0]['img_local_certificate']);
						 imgCnt++;
					} 

					 

					if(data['applicationDetails'][0]['img_off_buil_exterior']!=null)
					{
						$("#eimg_off_buil_exterior").removeClass("wizard-required");
						$("#div_off_buil_exterior").show()
						$("#div_builexterior_upload").hide();
						$("#a_builexterior").attr("href", BASE_URL +'upload/img_off_buil_exterior/'+data['applicationDetails'][0]['img_off_buil_exterior']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_off_buil_interior']!=null)
					{
						$("#eimg_off_buil_interior").removeClass("wizard-required");
						$("#div_off_buil_interior").show();
						$("#div_buildInterior_upload").hide();
						$("#a_buildInterior").attr("href", BASE_URL +'upload/img_off_buil_interior/'+data['applicationDetails'][0]['img_off_buil_interior']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_gst_regis']!=null)
					{
						$("#eimg_gst_regis").removeClass("wizard-required");
						$("#div_gst_regis").show();
						$("#div_gstregis_upload").hide();
						$("#a_gstregis").attr("href", BASE_URL +'upload/img_gst_regis/'+data['applicationDetails'][0]['img_gst_regis']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_tourist_arrival_details']!=null)
					{
						$("#eimg_tourist_arrival_details").removeClass("wizard-required");
						$("#div_tourist_arrival_details").show();
						$("#div_arrivaldetail_upload").hide();
						$("#a_arrivaldetail").attr("href", BASE_URL +'upload/img_tourist_arrival_details/'+data['applicationDetails'][0]['img_tourist_arrival_details']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_pledge_commitment']!=null)
					{
						$("#eimg_pledge_commitment").removeClass("wizard-required");
						$("#div_pledge_commitment").show();
						$("#div_pledge_upload").hide();					
						$("#a_pledge").attr("href", BASE_URL +'upload/img_pledge_commitment/'+data['applicationDetails'][0]['img_pledge_commitment']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_pan_copy']!=null)
					{
						$("#eimg_pan_copy").removeClass("wizard-required");
						$("#div_pan_copy").show();
						$("#div_pan_upload").hide();				
						$("#a_pancopy").attr("href", BASE_URL +'upload/img_pan_copy/'+data['applicationDetails'][0]['img_pan_copy']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_state_permit']!=null)
					{
						$("#eimg_state_permit").removeClass("wizard-required");
						$("#div_state_permit").show();
						$("#div_statepermit_upload").hide();				
						$("#a_state_permit").attr("href", BASE_URL +'upload/img_state_permit/'+data['applicationDetails'][0]['img_state_permit']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_tourist_vehicle']!=null)
					{
						$("#eimg_tourist_vehicle").removeClass("wizard-required");
						$("#div_tourist_vehicle").show();
						$("#div_tourvehicle_upload").hide();				
						$("#a_tourist_vehicle").attr("href", BASE_URL +'upload/img_tourist_vehicle/'+data['applicationDetails'][0]['img_tourist_vehicle']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_vehicle_exterior']!=null)
					{
						$("#eimg_vehicle_exterior").removeClass("wizard-required");
						$("#div_vehicle_exterior").show();
						$("#div_vehicleexterior_upload").hide();				
						$("#a_vehicleexterior").attr("href", BASE_URL +'upload/img_vehicle_exterior/'+data['applicationDetails'][0]['img_vehicle_exterior']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_vehicle_interior']!=null)
					{
						$("#eimg_vehicle_interior").removeClass("wizard-required");
						$("#div_vehicle_interior").show();
						$("#div_vehicleinterior_upload").hide();				
						$("#a_vehicleInterior").attr("href", BASE_URL +'upload/img_vehicle_interior/'+data['applicationDetails'][0]['img_vehicle_interior']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_caravan_rc']!=null)
					{
						$("#eimg_caravan_rc").removeClass("wizard-required");
						$("#div_caravan_rc").show();
						$("#div_caravan_rc_upload").hide();				
						$("#a_caravan_rc").attr("href", BASE_URL +'upload/img_caravan_rc/'+data['applicationDetails'][0]['img_caravan_rc']);
						 imgCnt++;
					}
					
					if(data['applicationDetails'][0]['img_caravan_exterior']!=null)
					{
						$("#eimg_caravan_exterior").removeClass("wizard-required");
						$("#div_caravan_exterior").show();
						$("#div_caravan_exterior_upload").hide();				
						$("#a_caravanexterior").attr("href", BASE_URL +'upload/img_caravan_exterior/'+data['applicationDetails'][0]['img_caravan_exterior']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_caravan_interior']!=null)
					{
						$("#eimg_caravan_interior").removeClass("wizard-required");
						$("#div_caravan_interior").show();
						$("#div_caravan_interior_upload").hide();				
						$("#a_caravanInterior").attr("href", BASE_URL +'upload/img_caravan_interior/'+data['applicationDetails'][0]['img_caravan_interior']);
						 imgCnt++;
					}
					//console.log(data['applicationDetails'][0]['img_caravan_ais_certificate']);
					if(data['applicationDetails'][0]['img_caravan_ais_certificate']!=null)
					{
						$("#eimg_caravan_ais_certificate").removeClass("wizard-required");
						$("#div_caravan_ais").show();
						$("#div_caravan_ais_upload").hide();				
						$("#a_caravanais").attr("href", BASE_URL +'upload/img_caravan_ais_certificate/'+data['applicationDetails'][0]['img_caravan_ais_certificate']);
						 imgCnt++;
					}
					if(data['applicationDetails'][0]['img_caravan_ministry_certificate']!=null)
					{
						$("#eimg_caravan_ministry_certificate").removeClass("wizard-required");
						$("#div_caravan_ministry_certificate").show();
						$("#div_caravan_ministry_certificate_upload").hide();				
						$("#a_caravan_ministry").attr("href", BASE_URL +'upload/img_caravan_ministry_certificate/'+data['applicationDetails'][0]['img_caravan_ministry_certificate']);
						 imgCnt++;  
					}
					 

					console.log(data['applicationDetails'][0]['img_caravan_approval_letter']);
					if(data['applicationDetails'][0]['img_caravan_approval_letter']!=null)
					{
						$("#eimg_caravan_approval_letter").removeClass("wizard-required");
						$("#div_caravan_approval_letter_upload").hide();
						$("#div_caravan_approval_letter").show();				
						$("#a_caravan_approval_letter").attr("href", BASE_URL +'upload/img_caravan_approval_letter/'+data['applicationDetails'][0]['img_caravan_approval_letter']);
						imgCnt++; 
					}
					//console.log("trade");
					//console.log(data['applicationDetails'][0]['img_trade_lic']);
					if(data['applicationDetails'][0]['img_trade_lic']!=null)
					{
						$("#eimg_trade_lic").removeClass("wizard-required");
						$("#div_tradelic_upload").hide();
						$("#div_lic_firm").show();				
						$("#a_trade_lic").attr("href", BASE_URL +'upload/img_trade_lic/'+data['applicationDetails'][0]['img_trade_lic']);
						imgCnt++; 
					}
					else
					{
						$("#div_lic_firm").hide();
					}
					if(data['applicationDetails'][0]['img_noobj_certificate']!=null)
					{
						$("#eimg_noobj_certificate").removeClass("wizard-required");
						$("#div_noobj_upload").hide();
						$("#div_noobj_certificate").show();				
						$("#a_noobj_certificate").attr("href", BASE_URL +'upload/img_noobj_certificate/'+data['applicationDetails'][0]['img_noobj_certificate']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_license']!=null)
					{
						$("#eimg_license").removeClass("wizard-required");
						$("#div_license_upload").hide();
						$("#div_license").show();				
						$("#a_license").attr("href", BASE_URL +'upload/img_license/'+data['applicationDetails'][0]['img_license']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_pollution_noc']!=null)
					{
						$("#eimg_pollution_noc").removeClass("wizard-required");
						$("#div_pollutionnoc_upload").hide();
						$("#div_pollution_noc").show();				
						$("#a_pollution_noc").attr("href", BASE_URL +'upload/img_pollution_noc/'+data['applicationDetails'][0]['img_pollution_noc']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_bar_permit']!=null)
					{
						$("#eimg_bar_permit").removeClass("wizard-required");
						$("#div_bar_permit_upload").hide();
						$("#div_bar_permit").show();				
						$("#a_bar_permit").attr("href", BASE_URL +'upload/img_bar_permit/'+data['applicationDetails'][0]['img_bar_permit']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_restrooms_certificate']!=null)
					{
						$("#eimg_restrooms_certificate").removeClass("wizard-required");
						$("#div_restrooms_upload").hide();
						$("#div_restrooms_certificate").show();				
						$("#a_restrooms_certificate").attr("href", BASE_URL +'upload/img_restrooms_certificate/'+data['applicationDetails'][0]['img_restrooms_certificate']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_heritage_certificate']!=null)
					{
						$("#eimg_heritage_certificate").removeClass("wizard-required");
						$("#div_heritage_upload").hide();
						$("#div_heritage_certificate").show();				
						$("#a_heritage_certificate").attr("href", BASE_URL +'upload/img_heritage_certificate/'+data['applicationDetails'][0]['img_heritage_certificate']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_occupancy_certificate']!=null)
					{
						$("#eimg_occupancy_certificate").removeClass("wizard-required");
						$("#div_occupancy_upload").hide();
						$("#div_occupancy_certificate").show();				
						$("#a_occupancy").attr("href", BASE_URL +'upload/img_occupancy_certificate/'+data['applicationDetails'][0]['img_occupancy_certificate']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_fssai_certificate']!=null)
					{
						$("#eimg_fssai_certificate").removeClass("wizard-required");
						$("#div_fssai_upload").hide();
						$("#div_fssai_certificate").show();				
						$("#a_fssai").attr("href", BASE_URL +'upload/img_fssai_certificate/'+data['applicationDetails'][0]['img_fssai_certificate']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_commercial_certificate']!=null)
					{
						$("#eimg_commercial_certificate").removeClass("wizard-required");
						$("#div_commercial_upload").hide();
						$("#div_commercial_certificate").show();				
						$("#a_commercial_certificate").attr("href", BASE_URL +'upload/img_commercial_certificate/'+data['applicationDetails'][0]['img_commercial_certificate']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_certificate_shops']!=null)
					{
						$("#eimg_certificate_shops").removeClass("wizard-required");
						$("#div_certificate_shops_upload").hide();
						$("#div_certificate_shops").show();				
						$("#a_certificate_shops").attr("href", BASE_URL +'upload/img_certificate_shops/'+data['applicationDetails'][0]['img_certificate_shops']);
						imgCnt++; 
					}
					// console.log("new123");
					// console.log(data['applicationDetails'][0]['img_member_kts']);					
					if(data['applicationDetails'][0]['img_member_kts']!=null)
					{
						$("#eimg_member_kts").removeClass("wizard-required");
						$('#yesCheck_kts').prop('checked',true);
						$("#div_member_kts_upload").hide();
						$("#div_member_kts").show();
						$("#ifYes_kts").show();
						$("#a_member_kts").attr("href", BASE_URL +'upload/img_member_kts/'+data['applicationDetails'][0]['img_member_kts']);
						imgCnt++; 
					}
					else
					{
						$('#noCheck_kts').prop('checked',true);
					}
					if(data['applicationDetails'][0]['img_clearence_cer']!=null)
					{
						$("#eimg_clearence_cer").removeClass("wizard-required");
						$("#div_clearence_cer_upload").hide();
						$("#div_clearence_cer").show();				
						$("#a_clearence_cer").attr("href", BASE_URL +'upload/img_clearence_cer/'+data['applicationDetails'][0]['img_clearence_cer']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_iaapi']!=null)
					{
						$("#eimg_iaapi").removeClass("wizard-required");
						$("#div_iaapi_upload").hide();
						$("#div_iaapi").show();				
						$("#a_iaapi").attr("href", BASE_URL +'upload/img_iaapi/'+data['applicationDetails'][0]['img_iaapi']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_declaration_amusement']!=null)
					{
						$("#eimg_declaration_amusement").removeClass("wizard-required");
						$("#div_declaration_amusement_upload").hide();
						$("#div_declaration_amusement").show();				
						$("#a_declaration_amusement").attr("href", BASE_URL +'upload/img_declaration_amusement/'+data['applicationDetails'][0]['img_declaration_amusement']);
						imgCnt++; 
					}
					if(data['applicationDetails'][0]['img_noc_environment']!=null)
					{
						$("#eimg_noc_environment").removeClass("wizard-required");
						$("#div_noc_environment_upload").hide();
						$("#div_noc_environment").show();				
						$("#a_noc_environment").attr("href", BASE_URL +'upload/img_noc_environment/'+data['applicationDetails'][0]['img_noc_environment']);
						 
					}
					if(data['applicationDetails'][0]['img_noc_airport']!=null)
					{
						$("#eimg_noc_airport").removeClass("wizard-required");
						$("#div_noc_airport_upload").hide();
						$("#div_noc_airport").show();				
						$("#a_noc_airport").attr("href", BASE_URL +'upload/img_noc_airport/'+data['applicationDetails'][0]['img_noc_airport']);
						 
					}
					if(data['applicationDetails'][0]['img_crz_clearance']!=null)
					{
						$("#eimg_crz_clearance").removeClass("wizard-required");
						$("#div_crz_clearance_upload").hide();
						$("#div_crz_clearance").show();				
						$("#a_crz_clearance").attr("href", BASE_URL +'upload/img_crz_clearance/'+data['applicationDetails'][0]['img_crz_clearance']);
						
					}
					
					//console.log(data['applicationDetails'][0]['off_international_membership']);
					if(data['applicationDetails'][0]['off_international_membership']=='Yes')
			        {		        	
			        	// $("#img_crz_clearance").removeClass("wizard-required");
			           	$('#yesCheck2').prop('checked',true);
			           	document.getElementById('ifYes2').style.display = 'block';
						document.getElementById('international_member').classList.add("wizard-required");
						$('#international_member').val(data['applicationDetails'][0]['off_international_membership_details']);
						imgCnt++; 
			        } 
			        if(data['applicationDetails'][0]['off_international_membership']=='No')
		            {
		            	$('#noCheck2').prop('checked',true);
		            	document.getElementById('ifYes2').style.display = 'none';
						document.getElementById('international_member').classList.add("wizard-required");	
		            } 
		    //         if(data['applicationDetails'][0]['off_international_membership']=='No')
		    //         {
		    //         	$('#yesCheck2').prop('checked',true);
		    //         	document.getElementById('ifYes2').style.display = 'block';
						// document.getElementById('international_member').classList.add("wizard-required");	
		    //         } 
		            $('#eoff_promote_domestic_activity').val(data['applicationDetails'][0]['off_promote_domestic_activity']); 
		            if(data['applicationDetails'][0]['off_prog_arranged_foreign_tourist']=='Yes')
			        {		        	
			           	$('#yesCheck_d3').prop('checked',true);
						document.getElementById('ifYes3').style.display = 'block';
						document.getElementById('especial_programe').classList.add("wizard-required");
						$('#especial_programe').val(data['applicationDetails'][0]['off_prog_arranged_foreign_tourist_details']);
						imgCnt++; 
			        } 
		            if(data['applicationDetails'][0]['off_international_membership']=='No')
		            {
		            	$('#noCheck_d3').prop('checked',true);
		            	document.getElementById('ifYes3').style.display = 'none';
						document.getElementById('especial_programe').classList.remove("wizard-required");
		            }
		            $('#image_counter').val(imgCnt); 
		            if(imgCnt>=19){
						console.log("Edit API call imageCounter=> "+imgCnt);
						$("#ajaxformsubmit").removeClass("disabled-link");
					}
		            var wrapper = $('.other-off-addre');
					var z=0;
					var count=$("div[class*='other-off-no']").length;
	        		var len=(count+1);
	        		// console.log(data['applicationDetails'].length);
	        		// console.log(data['applicationDetails']);
					if(data['applicationDetails'].length>0)
					{	
						$("#eorg_addr1").add("wizard-required");
						if( data['applicationDetails'][0]['product_id']<=3 )
						{
							if(data['applicationDetails'][0]['other_office_count']>0)
							{
								$("#other_address_div").show();		
							}
							var field_type="address";			
							var newlength=(data['applicationDetails'].length-parseInt(1));
							//console.log(data['applicationDetails'][z]);
							for(z=1;z<=newlength;z++)
							{
								// console.log(z);
								// console.log(data['applicationDetails'][z]['office_id']);
								var select_district=data['applicationDetails'][z]['other_off_district_id'];
								//console.log("select_district"+ select_district);
								var dropdown_select;var append_div;
								var i=0;
								//console.log(data[z]['other_off_taluk']);
								var select_taluk=data['applicationDetails'][z]['other_off_taluk'];
								var BASE_URL = "<?php echo base_url();?>";
								var path 		= BASE_URL+'applications/get_taluk';
								dropdown_select ='<div class="agent-form-input"><select name="org_taluk[]" id="eorg_taluk_'+z+'">';
								
								$.ajax({
									    type: 'POST',
									    url: path,
									    async: false,			
									    data: {districtid : select_district},
									   	success:function(html)
									  	 {
									   	 	dropdown_select +=html;
						                }
								});
								dropdown_select +='</select></div>';
								/*value=<?php if($row['id']){ ?>'+select_district+'<?php  echo ' selected="selected"'; } ?>*/

								//console.log(data['applicationDetails'][z]);
								//<label>Address '+ (z+parseInt(1)) +' </label>

								$(wrapper).append('<div class="other-off-addre" id="address_'+z+'"><div id="other-off-no" class="other-off-no"></div><div class="agent-form-field"><div class="agent-form-text"><p>Address Line 1/ವಿಳಾಸದ ಸಾಲು 1<sup>*</sup></p></div><div class="agent-form-input"><input type="text" name="org_add1[]" id="org_addr1" class="new_required" value="'+(data['applicationDetails'][z]['other_off_addr1']=='null' ? '' : data['applicationDetails'][z]['other_off_addr1'])+'"><div class="wizard-form-error"></div></div></div><div class="agent-form-field"><div class="agent-form-text"><p>Address Line 2/ವಿಳಾಸದ ಸಾಲು 2<sup></sup></p></div><div class="agent-form-input"><input type="text" name="org_add2[]" id="org_addr2" class="" value="'+(data['applicationDetails'][z]['other_off_addr2']=='null' ? '' : data['applicationDetails'][z]['other_off_addr2'])+'"></div></div><div class="agent-form-field"><div class="agent-form-text"><p>District/ಜಿಲ್ಲೆ<sup></sup></p></div><div class="agent-form-input"><select name="org_district_id[]" id="org_city_'+z+'" class="form-control org_city new_required" onchange="showtaluk('+z+',0)"><option value="">Select District</option><?php $this->db->where(array('state_id' => '17')); $clients = $this->db->get('m_district')->result_array(); foreach ($clients as $row): ?><option value="<?php echo $row['id'];?>"><?php echo $row['name']; ?></option><?php endforeach; ?></select></div></div><div class="agent-form-field"><div class="agent-form-text"><p>Taluk/ತಾಲ್ಲೂಕು<sup></sup></p></div>'+dropdown_select+'</div><div class="agent-form-field"><div class="agent-form-text"><p>City/Town/Village/ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ<sup></sup></p></div><div class="agent-form-input"><input type="text" name="org_city[]" class="new_required" id="org_town" value="'+(data['applicationDetails'][z]['other_off_city']=='null' ? '' : data['applicationDetails'][z]['other_off_city'])+'"></div></div><div class="agent-form-field"><div class="agent-form-text"><p>Pincode/ಪಿನ್ ಕೋಡ್<sup></sup></p></div><div class="agent-form-input"><input type="text" maxlength="6" name="org_pincode_id[]" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" onpaste="return false" id="org_pincode" class="new_required" value="'+(data['applicationDetails'][z]['other_off_pincode_id']=='0' ? '' : data['applicationDetails'][z]['other_off_pincode_Pid'])+'"></div></div><div class="agent-form-field"><div class="agent-form-text"><p>Contact Number/ಸಂಪರ್ಕ ಸಂಖ್ಯೆ<sup></sup></p></div><div class="agent-form-input"><input type="text" maxlength="10" name="org_mobile[]" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" onpaste="return false" class="new_required" id="org_mob" value="'+(data['applicationDetails'][z]['other_off_contact']=='null' ?'': data['applicationDetails'][z]['other_off_contact'])+'"></div></div><button class="btn btn-danger" style="margin-left: 90%;" onclick="removeaddress(\'' + field_type + '\','+(data['applicationDetails'][z]['office_id']+','+z)+')">Remove</button><br><hr class="new4">');
								//$(".other-off-no").children("label").text("Address " + z);
								// $(wrapper).append(append_div);
								$("#org_city_"+z).val(select_district);
								$("#eorg_taluk_"+z).val(data['applicationDetails'][z]['other_off_taluk']).attr("selected","selected");
							}	
						}
					}
					// $(".newcheckbox").each(function(){
					//     $("#mycheckbox").click()
					// });

					var hotelacc_len=data['hotelaccomodation'].length;
					// console.log(hotelacc_len);
					if(hotelacc_len> 0)
					{
						for (var i = 0; i <hotelacc_len; i++) 
						{							
							var val=(data['hotelaccomodation'][i]['accommodation_type']);
							// console.log(val);
							if(val!='')
							{
								// console.log($("#accom_checkbox").find('[value="' + val + '"]'));
								$("#accom_checkbox").find('[value="' + val + '"]').prop("checked", true);
							}
							if(data['hotelaccomodation'][i]['other_facility']!=null)
							{
								$("#othervalueadd").show();
								$("#othervalueadd").val(data['hotelaccomodation'][i]['other_facility']);
							}
							else
							{
								$("#othervalueadd").hide();
								$("#othervalueadd").val('');
							}							
						}	
					}
					// console.log(data['hotelfacility']);
					var hotelfac_len=data['hotelfacility'].length;
					if(hotelfac_len> 0)
					{
						for (var i = 0; i <hotelfac_len; i++) 
						{							
							var val=(data['hotelfacility'][i]['facility_type']);
							
							if(val!='')
							{
								// console.log($("#facility_checkbox"));
								$("#facility_checkbox").find('[value="' + val + '"]').prop("checked", true);
							}
							if(data['hotelfacility'][i]['other_facility']!=null )
							{
								$("#othervaluefacility").show();
								$("#othervaluefacility").val(data['hotelfacility'][i]['other_facility']);
							}
							else
							{
								$("#othervaluefacility").hide();
								$("#othervaluefacility").val('');
							}
						}	
					}
					// facility_checkbox

					//console.log(data['vehicleDetails']); 
					var field_vehicle='vehicle';
					var vcount=data['vehicleDetails'].length;           
		            var veh_count=data['vehicleDetails'][0]['no_of_vehicle'];
		            $("#veh_count").val(veh_count);
					var wrapper_new = $('.vehicle-detail_new'); //Input field wrapper 
					//console.log(vcount);
					if(vcount!=0 )
					{
						// console.log(data['vehicleDetails'][0]['other_vehicle']);
						// console.log(data['vehicleDetails'][0]);
						$("#evehicleId").val(data['vehicleDetails'][0]['vehicleId']);
						$("#epermit_type").val(data['vehicleDetails'][0]['permit_type']);
						// var prodId=<?php echo $new_pid?>;						
						// //alert(prodId);
						// if(prodId==3)
						// {
						// 	$("#evehicle_type").val(data['vehicleDetails'][0]['vehicle_type']);	
						// }
						// else
						// {
							
						// }
						$("#evehicle_type").val(data['vehicleDetails'][0]['vehicle_type']).attr("selected","selected");
						// console.log(data['vehicleDetails'][0]['vehicle_type']);

						if(data['vehicleDetails'][0]['vehicle_type']=='Others')
						{
							$("#othervalue").css('display','block');
							$("#othervalue").val(data['vehicleDetails'][0]['other_vehicle']);
						}
						$("#eregistration_no").val(data['vehicleDetails'][0]['registeration_no']);	
						$("#eregistration_name").val(data['vehicleDetails'][0]['regitration_name']);
						$("#etourist_permit").val(data['vehicleDetails'][0]['tourist_permit']);
						var newenddate=data['vehicleDetails'][0]['end_date'];
						document.getElementById('etourist_permit_end_date').value = newenddate;
						$("#etourist_permit_date").val(data['vehicleDetails'][0]['permitdate']);
						$("#etourist_permit_end_date").val(data['vehicleDetails'][0]['end_date']);	
						$('input[name="tourist_permit_date[]"]').attr('max', data['vehicleDetails'][0]['permitdate']);
						$('input[name="tourist_permit_end_date[]"]').attr('min', data['vehicleDetails'][0]['permitdate']);
						// console.log(<?php echo ($new_pid)?>);
					}
					if(vcount>1)
					{
							// console.log("vcount: " +vcount);
							//console.log(data['vehicleDetails']);
							for(var j=1;j<vcount;j++)
							{
								// console.log(j);
								//console.log(data['vehicleDetails'][j]);
								var num_alp="albhabet";
								var reg_no=data['vehicleDetails'][j]['registeration_no'];
								var vehtype=data['vehicleDetails'][j]['vehicle_type'];
								// console.log(vehtype);
								var otherveh=data['vehicleDetails'][j]['other_vehicle'];
								otherveh=(otherveh=="null"?'':otherveh)
								// console.log(otherveh);
								var reg_name=data['vehicleDetails'][j]['regitration_name'];
								var permit=	data['vehicleDetails'][j]['tourist_permit'];	
								var startdate=data['vehicleDetails'][j]['permitdate'];
								var enddate=data['vehicleDetails'][j]['end_date'];
								var permittype=data['vehicleDetails'][j]['permit_type'];
								$('input[name="tourist_permit_date[]"]').attr('max', startdate);
							    $('input[name="tourist_permit_end_date[]"]').attr('min',startdate);
								// console.log(reg_name);'<div class="vehicle-detail" id='+j
								//'<div class="vehicle-detail" id='+j+'>'+</div>

								//'<div class="form-group col-md-12" ><label class="vehicledetail_label">Vehicle '+j+' </label></div>'

								$(wrapper_new).append('<div class="vehicle-detail" id="vehicle_'+j+'">'+
									'<div class="multi-field-wrapper"><div class="multi-field-head">'+
									'<div class="form-group col-md-12">'+
									'<div class="form-group col-md-3">'+
									'<label><?php echo ($new_pid == 2 ? "Vehicle Type/ವಾಹನ ಪ್ರಕಾರ*:"  : "Caravan Type/ಕ್ಯಾರಾವಾನ್ ಪ್ರಕಾರ*") ?></label></div>'+
									'<input type="hidden" name="vehicleId[]" value='+data['vehicleDetails'][j]['vehicleId']+'><div class="form-group col-md-3">'+
									'<?php if($new_pid == 2){?><select class="vehicle-form dropdownchange" name="vehicle_type[]" showvalue="othervalue'+j+'">'+
									'<option value="">Vehicle Type </option>'+
									'<option '+(vehtype=="AC Coaches" ? 'selected' : '')+' showvalue="othervalue'+j+'">AC Coaches</option>'+
									'<option '+(vehtype=="Non-AC Coaches" ? 'selected' : '')+' showvalue="othervalue'+j+'">Non-AC Coaches</option>'+
									'<option '+(vehtype=="Mini Coaches" ? 'selected' : '')+ ' showvalue="othervalue'+j+'">Mini Coaches</option>'+
									'<option '+(vehtype=="Cars" ? 'selected' : '')+' showvalue="othervalue'+j+'">Cars</option>'+
									'<option '+(vehtype=="Boats" ? 'selected' : '')+' showvalue="othervalue'+j+'">Boats</option>'+
									'<option '+(vehtype=="Others" ? 'selected' : '')+' showvalue="othervalue'+j+'">Others</option></select>'+
									'<br>&nbsp;<input '+(vehtype=="Others" ? 'style="display: block;"' : 'style="display: none;"')+
									'id="othervalue'+j+'" type="text" name="othervalue[]" value='+otherveh+'>'+
									'<?php } if($new_pid == 3){?>'+
									'<input type="text" name="vehicle_type[]"><?php }?></div>'+
									'<div class="form-group col-md-3">'+
									'<label>Permit Type /ಅನುಮತಿ ಪ್ರಕಾರ</label>'+
									'</div>'+
									'<div class="form-group col-md-3">'+
									'<select class="vehicle-form wizard-required " name="permit_type[]" required="">'+
										'<option '+(permittype=="Karnataka Permit" ? 'selected' : '')+ ' value="Karnataka Permit" >Karnataka Permit</option>'+
										'<option '+(permittype=="All India Permit" ? 'selected' : '')+ ' value="All India Permit">All India Permit</option>'+
									'</select>'+
									'<div class="wizard-form-error"></div>'+
									'</div></div>'+
									'<div class="form-group col-md-12">'+
									'<div class="form-group col-md-3">'+
									'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit Number/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಗಿ ಸಂಖ್ಯೆ *":"Caravan Vehicle Permit Number/ಕ್ಯಾರಾವಾನ್ ವಾಹನ ಪರವಾನಗಿ ಸಂಖ್ಯೆ: *")?></label>'+
									'</div>'+
									'<div class="form-group col-md-3">'+
									'<input class="vehicle-form" type="text" name="tourist_permit[]" value="'+permit+'">'+
									'</div>'+
									'<div class="form-group col-md-3">'+
									'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Registration in the name of/ ಪ್ರವಾಸಿ ವಾಹನದ ನೋಂದಣಿ ಇವರ ಹೆಸರಿನಲ್ಲಿದೆ : *":"Caravan Registration in the name of/ಹೆಸರಿನಲ್ಲಿ ಕ್ಯಾರಾವಾನ್ ನೋಂದಣಿ:*") ?></label></div>'+
									'<div class="form-group col-md-3">'+
									'<input class="vehicle-form" type="text" name="registration_name[]" style="text-transform:capitalize" onkeypress="return isNumbera(event,\'' + num_alp + '\')" value="'+reg_name+'"></div></div>'+
									'<div class="form-group col-md-12">'+
									'<div class="form-group col-md-3">'+
									'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Registration Number/ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ:*":"Caravan Vehicle Registration Number/ಕ್ಯಾರಾವಾನ್ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ:*")?></label></div>'+
									'<div class="form-group col-md-3">'+
									'<input class="vehicle-form" type="text" name="registration_no[]" maxlength="15" value="'+reg_no+'" ></div>'+
									'<div class="form-group col-md-3">'+
									'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit Start date/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಗಿ ಪ್ರಾರಂಭವಾಗುವ ದಿನಾಂಕ:*":"Caravan vehicle permit start date/ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಗಿ ಪ್ರಾರಂಭ ದಿನಾಂಕ:*")?></label></div>'+
									'<div class="form-group col-md-3"><input type="date" name="tourist_permit_date[]" id="tourist_permit_date" class="vehicle-form datefreeze" value="'+startdate+'"></div></div>'+
									'<div class="form-group col-md-12">'+
									'<div class="form-group col-md-3">'+
									'<label><?php echo ($new_pid == 2 ? " Tourist Vehicle Permit End date/ಪ್ರವಾಸಿ ವಾಹನ ಅಂತಿಮ ದಿನಾಂಕ:*":"Caravan vehicle permit end date/ಕಾರವಾನ್ ವಾಹನ ಅನುಮತಿ ಅಂತಿಮ ದಿನಾಂಕ:*")?></label></div>'+
									'<div class="form-group col-md-3">'+
									'<input type="date" name="tourist_permit_end_date[]" id="tourist_permit_date" class="vehicle-form" value="'+enddate+'">'+
									'</div></div><div class="form-group col-md-12" style=" padding-left: 89%;"><button class="btn btn-danger" onclick="removeaddress(\'' + field_vehicle + '\','+data['vehicleDetails'][j]['vehicleId']+','+j+')">'+
									'Remove</button></div><div class="form-group col-md-12"><hr class="new4"></div></div></div></div>');
							} 
					}
		        }
			});
	}	
});


$(document).on('change', '.org_city', function (e) 
{
	// alert("showtaluk");
	// console.log(this);
     var val = this.value;        
    	// console.log(val);
      var element = $(this).find('option:selected');  
      var myTag = element.attr("talk_attr");  
      // console.log(myTag); 
      var BASE_URL = "<?php echo base_url();?>";
	  var path 		= BASE_URL+'applications/get_taluk';	
	  $.ajax({
				    type: 'POST',
				    url: path,				
				    data: {districtid : val},
				    success:function(html)
				    {
				    	$('#'+myTag).html(html);
	                    //$('.org_taluk').html(html);
	                    // if(type==0)
	                    // {
	                    // 	//$('.org_taluk').html(html);
	                    // 	$('#eorg_taluk_'+id).html(html);
	                    // 	$('#org_taluk_'+id).html(html);
	                    // }
	                    // else
	                    // {
	                    // 	$('#'+myTag).html(html);
	                    // }	
	                    } 
					});
		});

function showtaluk(id,type,distId)
{	
	// alert(id);
	//alert("org_city");
	var districtid	=0;
	if(type!=0)
	{
		districtid=$('#'+distId+' :selected').val();	
	}
	else
	{
		districtid=$('#org_city_'+id+' :selected').val();		
	}
	var BASE_URL = "<?php echo base_url();?>";
	var path 		= BASE_URL+'applications/get_taluk';	
	$.ajax({
			    type: 'POST',
			    url: path,				
			    data: {districtid : districtid},
			    success:function(html)
			    {
                    //$('.org_taluk').html(html);
                    if(type==0)
                    {
                    	//$('.org_taluk').html(html);
                    	$('#eorg_taluk_'+id).html(html);
                    	$('#org_taluk_'+id).html(html);
                    }
                    else
                    {
                    	$('#'+type).html(html);
                    }
                }
	});
}

$(".removebtn").on('click',function()
{
	// To decsrese the image counter.
	var imageCounter = parseInt($('#image_counter').val())-1;
	console.log("Remove imageCounter=> "+imageCounter);
	$('#image_counter').val(imageCounter);

	$("#formSave123").submit(function(e){
        e.preventDefault();
    });

	var text = $(this).attr('name');
	var show_div = $(this).attr('Sdivname');
	console.log(show_div);
	var hide_div=$(this).attr('hdivname');
	console.log(hide_div);
	var docname=($(this).attr('docname'));
	// if(show_div=="div_powerof_attorney_upload")
	// {
	// 	$("#eyes_d4").show();
	// 	$("#"+hide_div).hide();	
	// }
	// else
	// {
		$("#"+show_div).show();
		$("#"+hide_div).hide();	
		$("#"+docname).addClass("wizard-required");
	// }
});

$("#loc_district").on('change',function(){
		var districtid	= $(this).val();
		//alert(countryid);
		  var BASE_URL = "<?php echo base_url();?>";
		  var path 	= BASE_URL+'applications/get_talukloc';
		//alert(path);
		    $.ajax({
			    type: 'POST',
			    url: path,				
			    data: {districtid : districtid},
			   success:function(html){
                    $('#loc_taluk').html(html);
                }
			});
	});

function yesnoCheck_doc(id,div,radio_div) 
{
    if ((document.getElementById(id).checked) || (document.getElementById(id).checked)) {    	
        document.getElementById(radio_div).style.display = 'none';
        document.getElementById(div).style.display = 'block';
		// document.getElementById('reg_firm').classList.add("wizard-required");	
		$('#file_type').val($('input[id="'+id+'"]:checked').val());		
    }
    else {
    	document.getElementById("div_attorney_upload").style.display = 'none';
    	document.getElementById('yes_d4').style.display = 'block';
		// document.getElementById('reg_firm').classList.remove("wizard-required");
	}
}

function yesnoCheck(id,div_id,error_class) 
{
	var val=$('input[id="'+id+'"]:checked').val();
    if (val=='yes' || val=='Yes') {
        document.getElementById(div_id).style.display = 'block';
		// document.getElementById('reg_firm').classList.add("wizard-required");
    }
    else {
		document.getElementById(div_id).style.display = 'none';
		// document.getElementById('reg_firm').classList.remove("wizard-required");
	}
}

function yesnoCheck_d1(id,div_id,error_class) 
{	
	// console.log(error_class);
	var val=$('input[id="'+id+'"]:checked').val();
	// var link_val=$("#a_reg_document").attr('href');	
	if (val=='yes' || val=='Yes') 
	{
		// console.log(div_id);
		document.getElementById("nodiv").style.display='none';
		document.getElementById(div_id).style.display = 'block';
		// if(link_val!='' && error_class=='div_reg_upload')
		// {
		// 	document.getElementById(error_class).style.display='none';
		// }
		// else
		// {
		// 	document.getElementById(error_class).style.display = 'block';
		// }
		document.getElementById('reg_firm').classList.add("wizard-required");
		
	}
    else 
    {    	
		document.getElementById(div_id).style.display = 'none';
		document.getElementById("nodiv").style.display='block';
		document.getElementById('reg_firm').classList.remove("wizard-required");
	}
	$("#emember_recognised_trade_new").val(val);
	// console.log($("#emember_recognised_trade_new").val());
}
function payment_enable(type,value,id,unchk)
{
	var val=$('input[id="'+id+'"]:checked').val();
	if(type=='edit')
	{
		if(val=='yes')
		{
			$("#"+value).removeClass("disable-click");
			$("#"+unchk).prop('checked', false);
		}
		else
		{
			$("#"+value).addClass("disable-click");
			$("#"+unchk).prop('checked', false);
		}
	}
	else
	{
		if(val=='yes')
		{
			$("#"+value).removeClass("disable-click");
			$("#"+unchk).prop('checked', false);
		}
		else
		{
			$("#"+value).addClass("disable-click");
			$("#"+unchk).prop('checked', false);
		}	
	}
	
	// if (document.getElementById('payment').checked) {
	// 	alert("checked");
 //  		//  document.getElementById('ifYes').style.display = 'block';
 //  		//  document.getElementById("div_reg_upload").style.display = 'block';
	// 	// document.getElementById('reg_firm').classList.add("wizard-required");
 //    }
 //    else 
 //    {
 //    	alert("unchecked");
	// 	// document.getElementById('ifYes').style.display = 'none';
	// 	// document.getElementById('reg_firm').classList.remove("wizard-required");
	// }
}

/*function yesnoCheck_d1() 
{
    if (document.getElementById('yesCheck_d').checked) {
        document.getElementById('ifYes').style.display = 'block';
        document.getElementById("div_reg_upload").style.display = 'block';
		document.getElementById('reg_firm').classList.add("wizard-required");
    }
    else 
    {
		document.getElementById('ifYes').style.display = 'none';
		document.getElementById('reg_firm').classList.remove("wizard-required");
	}
}*/

// function yesnoCheck_d3() 
// {
//     if (document.getElementById('yesCheck_d3').checked) {
//         document.getElementById('ifYes3').style.display = 'block';
// 		document.getElementById('especial_programe').classList.add("wizard-required");
//     }
//     else {
// 		document.getElementById('ifYes3').style.display = 'none';
// 		document.getElementById('especial_programe').classList.remove("wizard-required");
// 	}
// }

$(".form_input_file").on("change", ".file-upload-field", function(){ 
    $(this).parent(".file-upload-wrapper").attr("data-text",$(this).val().replace(/.*(\/|\\)/, ''));
});

$(".field-comment-sec").on("change", ".file-upload-field", function(){ 
	//alert(".field-comment-sec");
    $(this).parent(".file-upload-wrapper").attr("data-text", $(this).val().replace(/.*(\/|\\)/, '') );
});

function Checktrade(val,id)
{
 	var element=document.getElementById(id); 	
	 if(val=='Others'){
	   element.style.display='block';
	   document.getElementById(id).classList.add("wizard-required");	   
	 }
	 else  {
	   element.style.display='none';
	   document.getElementById(id).classList.remove("wizard-required");
	   
	 }
}

function isNumber(evt) 
{
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function isNumbera(evt,type) 
{
	var regex='';
	if(type=="albhabet")
	{
		regex = new RegExp("^[A-Z a-z]");
	}
	if(type=="number")
	{
		regex = new RegExp("^[0-9.]");
	}
	var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
    if (!regex.test(key)) 
    {
        event.preventDefault();
        return false;
    }
    return true;
}

/*function isNumberb(evt) {
   var regex = new RegExp("^[0-9.]");
        var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    return true;
}
*/

function totalbuildfun(id) 
{
  var x = document.getElementById(id).value;
  console.log(x);
  if(x < 150){
  	$('#totalbuildnext').hide();
  	$('#totalbuilderr').show();
  }
  else{
  	$('#totalbuildnext').show();
  	$('#totalbuilderr').hide();
  }
}


var razorpay_pay_btn, instance;
function razorpaySubmit(el) 
{
		var mobilee = document.getElementById("applmob").value;
    	var emaill = document.getElementById("applemail").value;
    	var namee = document.getElementById("card_holder_name_ida").value;

        var options = {
            key:            "<?php echo $key_id; ?>",
            amount:         "<?php echo $total; ?>",
            name:           "<?php echo $name; ?>",
            description:    "Order # <?php echo $merchant_order_id; ?>",
            netbanking:     true,
            currency:       "<?php echo $currency_code; ?>", // INR
            prefill: {
                name:       namee,
                email:      emaill,
                contact:    mobilee
            },
            notes: {
                soolegal_order_id: "<?php echo $merchant_order_id; ?>",
            },
            handler: function (transaction) {
                document.getElementById('razorpay_payment_id').value = transaction.razorpay_payment_id;
                document.getElementById('razorpay-form').submit();
            },
            "modal": {
                "ondismiss": function(){
                    location.reload()
                }
            }
        };

        if(typeof Razorpay == 'undefined') {
                setTimeout(razorpaySubmit, 200);
                if(!razorpay_pay_btn && el) {
                    razorpay_pay_btn    = el;
                    el.disabled         = true;
                    el.value            = 'Please wait...';  
                }
            } else {
                if(!instance) {
                    instance = new Razorpay(options);
                    if(razorpay_pay_btn) {
                    razorpay_pay_btn.disabled   = false;
                    razorpay_pay_btn.value      = "Pay Now";
                    }
                }
                instance.open();
            }
}

function razorpaySubmitnew() 
{
		//alert('testt');
		$("#payload").show();
		setTimeout("document.getElementById('razorpay-formnew').submit();", 7000);
                //document.getElementById('razorpay-formnew').submit();       
}

$(document).ready(function()
{	
	// console.log($('input[name="Nuumber_offices"]'));
	// var maxField=$('.Nuumber_offices').val();
	
    //var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var removeButton = $('.remove_button'); //Add button selector
    var wrapper = $('.other-off-addre'); //Input field wrapper   
    var x = 1; //Initial field counter is 1
    //Once add button is clicked
    $(addButton).click(function(){
    	var maxField=$('input[name="Nuumber_offices"]').val();
    	console.log(maxField);
        //Check maximum number of input fields       
        var field_type_add="address";
        var count=$("div[class*='other-off-no']").length;
        var len=(count+1);
       	console.log(count);
        if(count < maxField)
        {
            x++; //Increment field counter
            //<label>Address ' + len +' </label>            
            $(wrapper).append('<div class="other-off-addre" id="address_'+count+'"><div id="other-off-no" class="other-off-no"></div> '+
			'<div class="agent-form-field"><div class="agent-form-text"><p>Address Line 1/ವಿಳಾಸದ ಸಾಲು 1<sup>*</sup></p></div><div class="agent-form-input"><input type="text" name="org_add1[]" id="org_addr1" class="new_required">'+
			'<div class="wizard-form-error"></div></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"><p>Address Line 2/ವಿಳಾಸದ ಸಾಲು 2<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p></div>'+
			'<div class="agent-form-input "><input type="text" name="org_add2[]" id="org_addr2" class=""><?php if($prod_id == 2 || $prod_id == 3){ ?>'+
			'<?php }?></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"><p>District/ಜಿಲ್ಲೆ<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p></div>'+
			'<div class="agent-form-input"><select name="org_district_id[] new_required" id="org_city_'+len+'" class="form-control org_city" onchange="showtaluk('+len+',0)"><option value="">Select District</option><?php $this->db->where(array('state_id' => '17')); $clients = $this->db->get('m_district')->result_array(); foreach ($clients as $row): ?><option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option><?php endforeach; ?></select><?php if($prod_id == 2 || $prod_id == 3){ ?><div class="wizard-form-error"></div><?php }?></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"><p>Taluk/ತಾಲ್ಲೂಕು<sup></sup></p></div>'+
			'<div class="agent-form-input"><select name="org_taluk[]" class="org_taluk new_required <?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?>" id="org_taluk_'+len+'"><option value="">Select Taluk</option></select><?php if($prod_id == 2 || $prod_id == 3){ ?>'+
			'<div class="wizard-form-error"></div><?php }?></div></div>'+
			'<div class="agent-form-field">'+
			'<div class="agent-form-text"><p>City/Town/Village/ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></sup></p></div>'+
			'<div class="agent-form-input"><input type="text" name="org_city[]" class="new_required" id="org_town"><?php if($prod_id == 2 || $prod_id == 3){ ?>'+
			'<div class="wizard-form-error"></div><?php }?></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"><p>Pincode/ಪಿನ್ ಕೋಡ್<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p></div>'+
			'<div class="agent-form-input"><input type="text" maxlength="6" name="org_pincode_id[]" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" onpaste="return false" id="org_pincode"  class="new_required"><?php if($prod_id == 2 || $prod_id == 3){ ?>'+
			'<div class="wizard-form-error"></div><?php }?></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"><p>Contact Number/ಸಂಪರ್ಕ ಸಂಖ್ಯೆ<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p></div>'+
			'<div class="agent-form-input"><input type="text" name="org_mobile[]" maxlength="10" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" onpaste="return false" class="new_required" id="org_mob"><?php if($prod_id == 2 || $prod_id == 3){ ?><div class="wizard-form-error"></div><?php }?></div></div>'+
			'<button class="btn btn-danger" style="margin-left: 90%;" onclick="removeaddress(\'' + field_type_add + '\',0,'+count+')">Remove</button><br><hr class="new4"></div>');
			 //Add field html
			//$(".other-off-no").children("label").text("Address " + x);			
        }
        else
        {
			//alert('Maximum 10 Address Only Allowed.');
			alert('Reached Maximum');
		}		
    });
    //Once remove button is clicked
  //   $(removeButton).click(function(){
		// if (x > 1) {
		// x--;
		// $(".other-off-addre" + ":last").remove();
		// }
  //   });
  $(wrapper).on('click', '.remove_button', function(e)
  {
        e.preventDefault();
        $(this).parent(".other-off-addre").remove(); //Remove field html
        x--; //Decrement field counter
    });
});
function addnewvehicle(type)
{		
	var total_count=$("#veh_count").val();	
	var count=$("div[class*='vehicle-detail']").length;	
	//console.log(count);
	var newWrapper = $('.vehicle-detail_new');
	var field_veh='vehicle';
	var num_alp='albhabet';
	// if(count>=1)
	// {
	// 	//alert("1");
	// 	$("#remove_vehicle").removeAttr('disabled');
	// }	
	if(count==1)
	{
		count=0;
	}
	else
	{
		count=count;
	}
	var cnt_val=(count==1?(count+1):(count-1));	
	// console.log('count'+count);
	// console.log("cnt_val"+cnt_val);
	if(total_count!='')
	{
		if(count<=total_count)
		{
			if(type=='add')
			{
				//alert(type);
				//<label>Address ' + cnt_val +' </label>

				$(newWrapper).append('<div class="vehicle-detail" id="vehicle_'+cnt_val+'">'+
				'<div class="multi-field-wrapper"> '+
				'<div class="multi-field-head">'+'<div class="form-group col-md-12">'+
				'<div class="form-group col-md-3">'+
				'<label><?php echo ($prod_id == 2 ? "Vehicle Type/ವಾಹನ ಪ್ರಕಾರ*":"Caravan Type/ಕ್ಯಾರಾವಾನ್ ಪ್ರಕಾರ*") ?></label></div>'+
				'<div class="form-group col-md-3"><input type="hidden" name="vehicleId[]" value=0>'+
				'<?php if($prod_id == 2){?>'+
				'<select class="vehicle-form dropdownchange" name="vehicle_type[]" required="">'+
				'<option value="">Vehicle Type</option>'+
				'<option value="Cars" showvalue="othervalue'+cnt_val+'">Cars</option>'+
				'<option value="Bus" showvalue="othervalue'+cnt_val+'">Bus</option>'+
				'<option value="AC Coaches" showvalue="othervalue'+cnt_val+'">AC Bus</option>'+
				'<option value="Non-AC Coaches" showvalue="othervalue'+cnt_val+'">Non-AC Bus</option>'+
				'<option value="Mini Coaches" showvalue="othervalue'+cnt_val+'">Mini Coaches</option>'+
				'<option value="Boats" showvalue="othervalue'+cnt_val+'">Boats</option>'+
				'<option value="Others" showvalue="othervalue'+cnt_val+'">Others</option></select>'+
				'<br>&nbsp;<input style="display:none;" id="othervalue'+cnt_val+'" type="text" name="othervalue[]" value="">'+
				'<?php } if($prod_id==3){?>'+
				'<input type="text" name="vehicle_type[]"><?php }?> </div>'+
				'<div class="form-group col-md-3">'+
				'<label>Permit Type / ಅನುಮತಿ ಪ್ರಕಾರ *</label></div>'+
				'<div class="form-group col-md-3">'+
				'<select class="vehicle-form wizard-required " name="permit_type[]" required="">'+
				'<option value="">Permit Type</option><option value="Karnataka Permit">Karnataka Permit</option>'+
				'<option value="All India Permit">All India Permit</option></select>'+
				'<div class="wizard-form-error"></div></div></div>'+			    
			    '<div class="form-group col-md-12">'+'<div class="form-group col-md-3">'+
			    '<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Permit Number/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಗಿ ಸಂಖ್ಯೆ*":"Caravan Vehicle Permit Number/ಕ್ಯಾರಾವಾನ್ ವಾಹನ ಪರವಾನಗಿ ಸಂಖ್ಯೆ*")?></label>'+'</div>'+
				'<div class="form-group col-md-3">'+'<input class="vehicle-form" type="text" name="tourist_permit[]"></div>'+
				'<div class="form-group col-md-3">'+
				'<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Registration Number/ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ:*":"Caravan Vehicle Registration Number/ಕ್ಯಾರಾವಾನ್ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ*:") ?></label></div>'+
				'<div class="form-group col-md-3">'+
				'<input class="vehicle-form" maxlength="15" type="text" name="registration_no[]">'+
				'</div>'+
				'<div class="form-group col-md-12">'+'<div class="form-group col-md-3">'+
				'<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Registration in the name of/ ಪ್ರವಾಸಿ ವಾಹನದ ನೋಂದಣಿ ಇವರ ಹೆಸರಿನಲ್ಲಿದೆ :":"Caravan Registration in the name of/ಹೆಸರಿನಲ್ಲಿ ಕ್ಯಾರಾವಾನ್ ನೋಂದಣಿ*:") ?></label></div>'+
				'<div class="form-group col-md-3">'+
				'<input class="vehicle-form" type="text" name="registration_name[]" style="text-transform:capitalize" onkeypress="return isNumbera(event,\'' + num_alp + '\')">'+			    
				'</div>'+'<div class="form-group col-md-3">'+
				'<label><?php echo ($prod_id == 2 ? "Tourist Vehicle Permit Start date/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಗಿ ಪ್ರಾರಂಭವಾಗುವ ದಿನಾಂಕ:*":"Caravan vehicle permit start date/ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಗಿ ಪ್ರಾರಂಭ ದಿನಾಂಕ:*")?></label></div>'+
				'<div class="form-group col-md-3"><input type="date"  name="tourist_permit_date[]" class="vehicle-form datefreeze"></div></div>'+
				'<div class="form-group col-md-3"><label><?php echo ($prod_id == 2 ? "Tourist Vehicle Permit End date/ಪ್ರವಾಸಿ ವಾಹನ ಅಂತಿಮ ದಿನಾಂಕ:":"Caravan vehicle permit end date/ಕಾರವಾನ್ ವಾಹನ ಅನುಮತಿ ಅಂತಿಮ ದಿನಾಂಕ:")?></label></div>'+
				'<div class="form-group col-md-3"><input type="date" name="tourist_permit_end_date[]" class="vehicle-form"></div></div>'+
				'<div class="form-group col-md-12" style=" padding-left: 89%;"><button class="btn btn-danger" onclick="removeaddress(\'' + field_veh + '\',0,'+cnt_val+')">'+
				'Remove</button></div></div></div><div class="form-group col-md-12"><hr class="new4"></div></div>');
			}
			else if(type=='edit')
			{
				//<label>Address ' + cnt_val +' </label>
				$(newWrapper).append('<div class="vehicle-detail" id="vehicle_'+cnt_val+'">'+
				'<div class="multi-field-wrapper"> '+
				'<div class="multi-field-head">'+'<div class="form-group col-md-12">'+
				'<div class="form-group col-md-3">'+
				'<label><?php echo ($new_pid == 2 ? "Vehicle Type/ವಾಹನ ಪ್ರಕಾರ*":"Caravan Type/ಕ್ಯಾರಾವಾನ್ ಪ್ರಕಾರ*") ?></label></div>'+
				'<div class="form-group col-md-3"><input type="hidden" name="vehicleId[]" value=0>'+
				'<?php if($new_pid == 2){?>'+
				'<select class="vehicle-form dropdownchange" name="vehicle_type[]" required="">'+
				'<option value="">Vehicle Type</option>'+
				'<option value="Cars" showvalue="othervalue'+cnt_val+'">Cars</option>'+
				'<option value="Bus" showvalue="othervalue'+cnt_val+'">Bus</option>'+
				'<option value="AC Coaches" showvalue="othervalue'+cnt_val+'">AC Bus</option>'+
				'<option value="Non-AC Coaches" showvalue="othervalue'+cnt_val+'">Non-AC Bus</option>'+
				'<option value="Mini Coaches" showvalue="othervalue'+cnt_val+'">Mini Coaches</option>'+
				'<option value="Boats" showvalue="othervalue'+cnt_val+'">Boats</option>'+
				'<option value="Others" showvalue="othervalue'+cnt_val+'">Others</option></select>'+
				'<br>&nbsp;<input style="display:none;" id="othervalue'+cnt_val+'" type="text" name="othervalue[]" value="">'+
				'<?php } if($new_pid==3){?>'+
				'<input type="text" name="vehicle_type[]"><?php }?> </div>'+
				'<div class="form-group col-md-3">'+
				'<label>Permit Type/ ಅನುಮತಿ ಪ್ರಕಾರ *</label></div>'+
				'<div class="form-group col-md-3">'+
				'<select class="vehicle-form wizard-required " name="permit_type[]" required="">'+
				'<option value="">Permit Type</option><option value="Karnataka Permit">Karnataka Permit</option>'+
				'<option value="All India Permit">All India Permit</option></select>'+
				'<div class="wizard-form-error"></div></div></div>'+			    
			    '<div class="form-group col-md-12">'+'<div class="form-group col-md-3">'+
			    '<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit Number/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಗಿ ಸಂಖ್ಯೆ*":"Caravan Vehicle Permit Number/ಕ್ಯಾರಾವಾನ್ ವಾಹನ ಪರವಾನಗಿ ಸಂಖ್ಯೆ*")?></label>'+'</div>'+
				'<div class="form-group col-md-3">'+'<input class="vehicle-form" type="text" name="tourist_permit[]"></div>'+
				'<div class="form-group col-md-3">'+
				'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Registration Number/ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ:*":"Caravan Vehicle Registration Number/ಕ್ಯಾರಾವಾನ್ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ*:") ?></label></div>'+
				'<div class="form-group col-md-3">'+
				'<input class="vehicle-form" maxlength="15" type="text" name="registration_no[]">'+
				'</div>'+
				'<div class="form-group col-md-12">'+'<div class="form-group col-md-3">'+
				'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Registration in the name of/ ಪ್ರವಾಸಿ ವಾಹನದ ನೋಂದಣಿ ಇವರ ಹೆಸರಿನಲ್ಲಿದೆ :":"Caravan Registration in the name of/ಹೆಸರಿನಲ್ಲಿ ಕ್ಯಾರಾವಾನ್ ನೋಂದಣಿ*:") ?></label></div>'+
				'<div class="form-group col-md-3">'+
				'<input class="vehicle-form" type="text" name="registration_name[]" style="text-transform:capitalize" onkeypress="return isNumbera(event,\'' + num_alp + '\')">'+			    
				'</div>'+'<div class="form-group col-md-3">'+
				'<label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit Start date/ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಗಿ ಪ್ರಾರಂಭವಾಗುವ ದಿನಾಂಕ:*":"Caravan vehicle permit start date/ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಗಿ ಪ್ರಾರಂಭ ದಿನಾಂಕ:*")?></label></div>'+
				'<div class="form-group col-md-3"><input type="date" name="tourist_permit_date[]" class="vehicle-form datefreeze"></div></div>'+
				'<div class="form-group col-md-3"><label><?php echo ($new_pid == 2 ? "Tourist Vehicle Permit End date/ಪ್ರವಾಸಿ ವಾಹನ ಅಂತಿಮ ದಿನಾಂಕ:":"Caravan vehicle permit end date/ಕಾರವಾನ್ ವಾಹನ ಅನುಮತಿ ಅಂತಿಮ ದಿನಾಂಕ:")?></label></div>'+
				'<div class="form-group col-md-3"><input type="date" name="tourist_permit_end_date[]" class="vehicle-form"></div></div>'+
				'<div class="form-group col-md-12" style=" padding-left: 89%;"><button class="btn btn-danger" onclick="removeaddress(\'' + field_veh + '\',0,'+cnt_val+')">'+
				'Remove</button></div></div></div><div class="form-group col-md-12"><hr class="new4"></div></div>');
			}
		}
		else
		{
			alert("Reached Maximum");
		}
	}
	else
	{
		alert("Please Enter the Vehicle Count");
	}
	var dtToday = new Date();
    // alert(dtToday);
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;
    $('input[name="tourist_permit_date[]"]').attr('max', maxDate); 

}
var delete_addressvalue=[];
var delete_vehiclevalue=[];
function removeaddress(type,pid,id)
{
	
	if(type=='address')
	{
		// alert(id);
		// alert(type);
		$("#address_"+id).remove();
		if(pid!=0)
		{
			delete_addressvalue.push(pid);		
			$("#remove_ids").val(JSON.stringify(delete_addressvalue));	
		}
		//console.log($("#remove_ids").val());
	}
	else if(type=='vehicle')
	{
		//alert(type);
		$("#vehicle_"+id).remove();
		if(pid!=0)
		{
			delete_vehiclevalue.push(pid);
			$("#vehremove_ids").val(JSON.stringify(delete_vehiclevalue));
		}
		//alert("removed");
	}	
}

$(document).on('change', '.dropdownchange', function (e) 
{
    	var val = this.value;        
        var element = $(this).find('option:selected');  
        var myTag = element.attr("showvalue");            
        (val=='Others' ? $("#"+myTag).css('display','block') : $("#"+myTag).css('display','none'));
});
$(document).on('change', '.datefreeze', function (e) 
{
    	var val = this.value; 
	 	$('input[name="tourist_permit_end_date[]"]').attr('min', val);
});

function enable_attoney()
{
	if ($('#auth_rep').is(":checked"))
	{
	  // it is checked	    
	  	$("#attorney_boardresolution").show();
		$('input[name="auth_rep_val"]').val('1');		
		$('input[name="img_power_of_attorney"]').addClass("wizard-required");
		$(".error_div").addClass("wizard-form-error");
		$("#div_powerof_attorney_upload").hide();
		//new_required_attrony
	}
	else
	{		
		$("#attorney_boardresolution").hide();
		$('input[name="auth_rep_val"]').val('0');		
		$("#div_powerof_attorney_upload").show();
		$(".error_div").removeClass("wizard-form-error");
		$('input[name="img_power_of_attorney"]').removeClass("wizard-required");
	}	
}
function chkval()
{
	var no_office=$('input[name="Nuumber_offices"]').val();
	//alert(no_office);
	if(no_office>0)
	{
		$("#other_address_div").show();
		$(".new_required").addClass("wizard-required");
		$(".add_button").removeClass("disable-click");		
	}
	else
	{
		$("#other_address_div").hide();
		$(".new_required").removeClass("wizard-required");
		$(".add_button").addClass("disable-click");
	}
}
</script>
<?php if(!empty($pid)){
	//echo $pid;
 $comm_date = $this->db->get_where('application', array('id' => $pid))->row()->org_commencement_date;
 //echo $commsplit[1];
 ?>
<script>
$(function(){
	var comm_d = <?php echo "'".$comm_date."'" ?>;
	var maxDate = comm_d;
	//alert(maxDate);
	$('#eorg_commencement_date').attr('max', maxDate);
});
</script>
<?php
}
?>
<!----End NEWW------>
<!----Start NEWW------>
<script>

$(function(){
    var dtToday = new Date();
    // alert(dtToday);
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

    // or instead:
    // var maxDate = dtToday.toISOString().substr(0, 10);

    //alert(maxDate);
    $('#org_commencement_date').attr('max', maxDate);
    $('#etrade_lic_date').attr('max', maxDate);    
    $('#org_shop_date').attr('max', maxDate);
    $('input[name="tourist_permit_date[]"]').attr('max', maxDate);    
});
</script>
<style>
hr.new4 {
  border: 1px solid red;
}
a.add_button {background: #0e984c;color: #fff;padding: 10px 20px;border-radius:3px;cursor:pointer;}
.other-off-head h4, .other-off-no label{color: #ca0027;font-size: 25px;}
a.remove_button {float: right;margin: 15px 0 0;background: #ca0027;color: #fff;padding: 10px;border-radius: 3px;cursor:pointer;}
.other-off-addre {float: left;position: relative;width: 100%;margin-bottom: 20px;}
.multi-field-wrapper .multi-field .vehicle-form {width: 100%;background: #fff;border: none;border-radius: 10px;box-shadow: 0 0 3px 0 #000;padding: 5px;}
.tour-operator {float: left;position: relative;width: 100%;background: #fbfbfb;padding: 15px 0px;}
.tour-operator .add-field {border: none;background: none;text-decoration: underline;}
.tour-operator .add-field .fa-plus {background: #ca0027;color: #fff;padding: 3px 5px;margin: 5px;font-size: 12px;border-radius: 3px;}
.tour-operator .add-field .fa-plus::after {content: "";border: 2px solid #ca0027;left: 44%;width: 17px;height: 21px;top: 6px;position: absolute;border-top: none;border-right: none;display:none;}
.tour-operator .form-add {float: left;position: relative;width: 100%;text-align: right;}
.tour-operator .remove-field {border: none;color: #fff;background: #ca0027;margin-top: 5px;padding: 5px 10px;}
.tour-operator .tour-orepator-head {float: left;position: relative;width: 100%;margin:10px 0;}
.tour-operator .tour-orepator-head h3 {font-size: 22px;}
.tour-operator .tour-orepator-vehicle {float: left;position: relative;width: 100%;margin:10px 0;padding-left: 20px;}
.tour-operator .tour-orepator-vehicle h4 {font-size: 20px;}
.form-wizard .form-group {text-align: center;}
.disable-click{pointer-events:none;}
sup{color:#ca0027;}
@media only screen and (max-width: 480px){.form-wizard .form-group {margin: 10px;}}
/*.vehicledetail_label {color: #ca0027;font-size: 25px;text-align:left !important;}*/

</style>

<style>

	/* Siva Prasad Reddy Starts*/
	.admin-dashboard .agent-application .form-wizard .agent-form .form_input input {
    width: 100%;
    border-radius: 5px;
    border: 1px solid #929292;
    padding: 5px 20px;
    color:grey;
}
    .form-wizard .form-control {
    font-weight: 300;
    height: auto !important;
    padding: 5px 20px;
    color: #000;
    background-color: #fff;
    border: 1px solid #929292;
    border-radius: 5px;
    font-size: 20px;
}
     .admin-dashboard .agent-application .form-wizard .agent-loc-off-address .agent-form-field .agent-form-input input[type="text"] {
    width: 100%;
    padding: 5px 10px;
    border-radius: 5px;
    border: 1px solid #929292;

}
     .admin-dashboard .agent-application .form-wizard .agent-loc-off-address .agent-form-field .agent-form-input select {
    width: 100%;
    padding: 5px 10px;
    border-radius: 5px;
    border: 1px solid #929292;

}    
     .admin-dashboard .agent-application .form-wizard .agent-off-address .agent-form-field .agent-form-input input[type="text"] {
    width: 100%;
    padding: 5px 10px;
    border-radius: 5px;
    border: 1px solid #929292;
}
     .admin-dashboard .agent-application .form-wizard {
    padding: 3%;
    margin: auto;
    width: 100%;
    background: #fff;
    box-shadow: 0 0 4px 0 #333;
}
     
   .element.style {
    text-transform: lowercase;

}
     .admin-dashboard .agent-application .form-wizard .agent-form .form_input input {
    width: 100%;
    border-radius: 5px;
    border: 1px solid #929292;
    padding: 5px 20px;
    color: black;
    font-weight: 300;
}
    .agent-form-new{
	width: 100%!important;
}

fieldset.wizard-fieldset.general-verify {
    padding: 0 5%!important;
}

fieldset.comment-section,.agent-other-det{
	 padding: 0 5%;
}
  field-appli-form-padd.new
  {
  	width: 100%!important;
  }
 
}
.form-wizard .wizard-fieldset {
    display:visible!important;
}
.admin-dashboard .agent-application .form-wizard .agent-off-address .agent-form-field .agent-form-input input[type="text"] {
    width: 70%;
    padding: 5px 10px;
    border-radius: 5px;
    border: 1px solid #929292;
}
    a.add_button {
    background: #0e984c;
    color: #fff;
    padding: 8px 20px;
    border-radius: 5px;
    cursor: pointer;
}
    .admin-dashboard .agent-application .field-app-form .field-comment-sec .file-upload-wrapper {
    position: relative;
    width: 90%;
    height: 60px;
    margin: auto;
}
.admin-dashboard .agent-application {
    float: left;
    position: relative;
    width: 100%;
    padding: 0px;
}
.no-gutters>[class*=col-] {
    padding-right: 0;
    padding-left: 0;
    margin-top: 20px;
    margin-bottom: 20px;
}
.admin-dashboard .agent-application .form-wizard .agent-form .form_input_file .file-upload-wrapper:before {
  
    pointer-events: none;
    border-radius: 5px;
}
.admin-dashboard .agent-application .form-wizard .agent-form .form_input_file .file-upload-wrapper:after {
   
    border-radius: 5px;
    border: 1px solid;
}
/* Siva Prasad Reddy End*/


.payloadc{
	text-align: center;
	font-size: 18px;
	font-weight: 600;
	font-style: italic;
	color: blue;
}
.payment-options{
	margin-bottom: 20px;
}


</style>


 <script type="application/javascript">
         document.getElementById("JsCheckoutPayment").addEventListener("click", function(){
			openJsCheckoutPopup('<?php echo $result['orderId']?>','<?php echo $result['txnToken']?>','<?php echo $result['amount']?>','<?php echo $result['amounta']?>');
         	}
         );

         
      </script>
      
<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};


    $(document).ready(function()
{	
	// console.log($('input[name="Nuumber_offices"]'));
	// var maxField=$('.Nuumber_offices').val();
	
    //var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button'); //Add button selector
    var removeButton = $('.remove_button'); //Add button selector
    var wrapper = $('.other-off-addre'); //Input field wrapper   
    var x = 1; //Initial field counter is 1
    //Once add button is clicked
    $(addButton).click(function(){
    	var maxField=$('input[name="Nuumber_offices_new"]').val();
    	console.log(maxField);
        //Check maximum number of input fields       
        var field_type_add="address";
        var count=$("div[class*='other-off-no']").length;
        var len=(count+1);
       	console.log(count);
        if(count < maxField)
        {
            x++; //Increment field counter
            //<label>Address ' + len +' </label>            
            $(wrapper).append('<div class="other-off-addre" id="address_'+count+'"><div id="other-off-no" class="other-off-no"></div> '+
			'<div class="agent-form-field"><div class="agent-form-text"><p>   Tourist attraction name  / ಪ್ರವಾಸಿ ಆಕರ್ಷಣೆಯ ಹೆಸರು <sup> * </sup></p></div><div class="agent-form-input"><input  type="text" class="form-control wizard-required" id="etourist_name" name="tourist_name" >'+
			'<div class="wizard-form-error"></div></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"> <p>   Category  / ವರ್ಗ  <sup> * </sup></p></div>'+
			'<div class="agent-form-input "><select name="category_type" id="ecategory_type" class="form-control wizard-required"><option value="">Select Category</option><option value="1">Adventure Tourism</option> <option value="4">Coastal Tourism</option><option value="2">Eco Tourism</option> <option value="3">Heritage Tourism</option><option value="5">Leisure Tourism</option><option value="6">Religious Tourism</option> <option value="7">Theme Park</option> <option value="8">Wildlife Tourism</option></select>  <?php if($prod_id == 2 || $prod_id == 3){ ?>'+
			'<?php }?></div></div>'+
			'<div class="agent-form-field"><div class="agent-form-text"><p>Distance (km)  / ದೂರ (ಕಿಮೀ)<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p></div>'+
			'<div class="agent-form-input"><input type="text" maxlength="6" name="distance" onkeypress="return isNumber(event)" id="edistance"  class="form-control wizard-required" onpaste="return false"><div class="wizard-form-error"></div><?php if($prod_id == 2 || $prod_id == 3){ ?><div class="wizard-form-error"></div><?php }?></div></div>'+
			'<button class="btn btn-danger" style="margin-left: 90%;" onclick="removeaddress(\'' + field_type_add + '\',0,'+count+')">Remove</button><br><hr class="new4"></div>');
			 //Add field html
			//$(".other-off-no").children("label").text("Address " + x);		

        }
        else
        {
			//alert('Maximum 10 Address Only Allowed.');
			alert('Reached Maximum');
		}		
    });
    //Once remove button is clicked
  //   $(removeButton).click(function(){
		// if (x > 1) {
		// x--;
		// $(".other-off-addre" + ":last").remove();
		// }
  //   });
  $(wrapper).on('click', '.remove_button', function(e)
  {
        e.preventDefault();
        $(this).parent(".other-off-addre").remove(); //Remove field html
        x--; //Decrement field counter
    });
});

 function chkval()
{
	var no_office=$('input[name="Nuumber_offices_new"]').val();
	// alert(no_office);
	if(no_office>0)
	{
		$("#other_address_div").show();
		$(".new_required").addClass("wizard-required");
		$(".add_button").removeClass("disable-click");		
	}
	else
	{
		$("#other_address_div").hide();
		$(".new_required").removeClass("wizard-required");
		$(".add_button").addClass("disable-click");
	}
}
</script>
<?php include 'include/footer.php';?>
