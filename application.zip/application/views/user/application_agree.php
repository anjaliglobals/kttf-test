<?php include 'include/header.php';?>

	


	<div class="admin-dashboard">

		<div class="travel-agent-dashboard">
		<!--Search button-->	
		 <form method="post" action="<?php echo base_url().'applications/application_agree';?>">
                <div class="form-group">
                    
                    <input type="text" name="searchfi" style="width:77%;"  autocomplete="off">
                    <!--input type="submit" name="btnsearch" value="submit"-->
                    <button type="submit" name="btnsearch" class="btn btn-primary" style="background-color: #ececec;border-color:#ececec;">
  <i class="fa fa-search" style="color:#ca0027;"aria-hidden="true"></i>
</button>
<a href="<?php echo base_url().'applications/application_agree';?>"><span style="color: #fff;background-color: #ca0027;padding: 5px 6px 7px 6px;border-radius: 5px;">Clear</span></a>
                </div>

            </form>	




		   <!-- Search button ends-->
			<div class="container">

         
				<div id="mixedSlider_new">
					<div class="MS-content">						
						<?php 
						//print_r($pro_agree);
						if(empty($pro_agree)){
							echo "<p style='color: #ca1326;text-align: center;padding: 80px;font-weight: 600;'>No Product Details Found.</p>";
						}
							foreach($pro_agree as $pro_ag)
							{  ?>
						<div class="row"style="border-radius: 10px">
							<div class ="border-cs" id="border_cs">
							    <div class="col-sm-3" style="background-color:white;border:1px; ">
							    	<div data-id = "<?php echo $pro_ag -> id ?>" class="item <?php if($pro_ag->isactive=='1'): echo 'agent'; else:echo ''; ?><?php endif; ?>">
										<div class="imgTitle">								
											<img src="<?php echo base_url().'theme/user/images/'. $pro_ag -> image; ?>" alt="" />
											<!--<p><?php echo $pro_ag -> id ?></p> -->
											
										</div>
							    	</div>
							     </div>	

							    <div class="col-sm-9" style="background-color:white;">
							    	<div class= "new-cs-div">
							    		<h4 class="blogTitle"><?php echo $pro_ag -> name ?> </h4>
							    		<p style=" text-align: justify;height: 200px;overflow: auto;"><?php echo $pro_ag -> short_description ?></p>
							    		<button  style="float:right"data-id = "<?php echo $pro_ag -> id ?>" class="btn btn-warning item">Apply</button>

							    	</div>

							    </div>
						
																					   
					</div>
						</div>	

				<?php   }?>	

			</div>
          <button  style="float:right" onclick="topFunction()" id="myBtn2" title="Go to top">&#11180;</button>
		</div>
		
		<div id="myModal" class="modal">		  
			<div class="modal-content">
				<div class="modal-header">
					<h3 style="    padding-left: inherit;">GENERAL TERMS AND CONDITIONS / ಸಾಮಾನ್ಯ ನಿಯಮಗಳು ಮತ್ತು ನಿಬಂಧನೆಗಳು</h3>
					<span class="close pop-close">&times;</span>					
				</div>
				<div id="modelcont" class="model-cont">
					<p>test1</p>
				</div>
			</div>
		</div>
	</div>
	
<style>
.modal {display: none;position: fixed;z-index: 9;padding-top: 1px;left: 0;top: 0;width: 100%;height: 100%;background-color: rgba(0,0,0,0.4);}/*overflow: auto;*/
.modal-content {position: relative;background-color: #fefefe;margin: auto;padding: 0;border: 1px solid #888;width: 83%;box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);-webkit-animation-name: animatetop;-webkit-animation-duration: 0.4s;animation-name: animatetop;animation-duration: 0.4s;top:10%;}
@-webkit-keyframes animatetop {from {top:-300px; opacity:0} to {top:0; opacity:1}}
@keyframes animatetop {from {top:-300px; opacity:0}to {top:0; opacity:1}}
.modal-header {padding: 25px;border: none;text-align: center;}
.modal-header .pop-close {cursor: pointer;}
.modal-body {padding: 2px 16px;}
.modal-footer {padding: 16px;}
.modal-footer .agent-pop {background: #ffcc01;padding: 10px 20px;border-radius: 5px;color: #000;margin-right: 20px;}
.modal-footer .button-agent {background: #ca0026;padding: 12px 20px;border-radius: 2px;color: #fff;font-weight: 100;opacity: 1;font-size: 16px;text-shadow:none;cursor:pointer;}
.close:not(:disabled):not(.disabled):focus, .close:not(:disabled):not(.disabled):hover{opacity:1}
.modal-footer .button-agent:hover {opacity: 1;}

.container { margin:0px auto;max-width: 100%;}
#mixedSlider {position: relative;}
#mixedSlider .MS-content {white-space: nowrap;overflow: hidden;margin: 0 5%;}
#mixedSlider .MS-content .item {display: inline-block;width: 31.3333%;position: relative;vertical-align: top;overflow: hidden;height: auto;white-space: normal;min-height:500px;box-shadow:0 0 5px 0 #000;margin:1%;border-radius:10px;background:#e9e5e4;}
#mixedSlider .MS-content .item.agent {background:#fff;cursor:pointer;}
#mixedSlider .MS-content .item:hover {//background:#fff;}
#mixedSlider .MS-content .item .imgTitle {position: relative;border-radius: 15px;box-shadow: 0 0 5px 0 #000;text-align:center;}
#mixedSlider .MS-content .item .imgTitle .blogTitle {text-align: center;color: #ca0027;position: relative;width: 100%;padding:10px;font-size: 20px;}
#mixedSlider .MS-content .item .imgTitle img {height: auto;padding:50px 0 10px;}
#mixedSlider .MS-content .item p {font-size: 14px;margin: 2px 10px 0 5px;padding: 0 10px;text-align: justify;}
#mixedSlider .MS-controls button {position: absolute;border: none;background-color: transparent;outline: 0;font-size: 50px;top: 45%;color: rgba(0, 0, 0, 0.4);transition: 0.15s linear;}
#mixedSlider .MS-controls button:hover {color: rgba(0, 0, 0, 0.8);}
#mixedSlider .MS-controls .MS-left {left: 0px;}
#mixedSlider .MS-controls .MS-right {right: 0px;}

.agreecheck{float: left;width: 100%;margin-left: 3%;font-weight:bold;}
 .agreed{width: 4%;height: 17px;}
 .disable-click{display:none;}
@media (max-width: 992px) {
  #mixedSlider .MS-content .item {width: 48%;min-height:630px;}
  #mixedSlider .MS-controls button {font-size: 30px;}
  #basicSlider .MS-content .item { width: 25%; }
  .agreed{width: 20%;height: 17px;}	
}
@media (max-width: 767px) {
	#mixedSlider .MS-controls button {font-size: 20px;}
	#mixedSlider .MS-content .item {width: 98%;min-height:680px;}
	#mixedSlider .MS-controls .MS-right {right: -10px;}
	#mixedSlider .MS-controls .MS-left {left: -10px;}
	.agreed{width: 20%;height: 17px;}	
}


.fa-angle-left{
	    color: #ca0027;
    font-size: 85px;

}
.fa-angle-right{
	color: #ca0027;
    font-size: 85px;
}
.modal-body{
	height: 330px;
    overflow: scroll;
    background-color: #ececec;;
}
.modal-footer{
	background-color: #ffff;
}

.agent{
	display: flex;
    justify-content: center;
    padding: 50px;
    margin: 30px;
}
   /*siva prasad reddy Start*/
.new-cs-div{
	/*border: 1px solid black;*/
    padding: 50px;
    margin: 30px;
    	border-radius: 5px;
    }

.row{
	border: 1px;
	border-radius: 5px;
	margin-bottom: 25px;
	}
.border-cs{
	display: -webkit-inline-box; 
	 /* border: 1px solid black;*/
	 
	 border-radius: 0px;
	 box-shadow: 0 5px 10px 0 rgb(193 193 193 / 58%), 0 5px 20px 0 rgb(0 0 0 / 12%);
}
		

#myBtn2 {
  display: none;
  position: fixed;
  bottom: 3%;
  right: 5%;
  z-index: 99;
  font-size: 35px;
  border: none;
  outline: none;
  background-color: #ca0027;
  color: white;
  cursor: pointer;
  padding: 0px;
  border-radius: 100%;
  padding-left: 16px;
  padding-right: 16px;
}

#myBtn2:hover {
  background-color: #555;
}
.form-group{


  width: 30%;
  font-size: 16px;
  margin-bottom:1%;
  margin-left:70%;
  margin-top: 1%;
}
.html {
    background: #ececec!important;
}
.modal-body {
    height: 350px;
    overflow: scroll;
    background-color: white;
}
</style>	
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script> 
<?php include 'include/footer.php';?>
<script>
		$('#mixedSlider').multislider({duration: 750,interval: 10000,slideAll:false});
		var modal = document.getElementById("myModal");
		var span = document.getElementsByClassName("close")[0];
		//alert(span);
		//$(".item").on("click", function() {modal.style.display = "block";});
		//$(".close").on("click", function() {modal.style.display = "none";});
		
		window.onclick = function(event) {if (event.target == modal) {modal.style.display = "none";}}

</script>


<script>
$(document).ready(function(){
     $(".item").click(function(){
    	// $(".newbtn").click(function(){
        var id =$(this).data('id');
		//alert(id);
        var url = '<?php echo base_url()."UserAjax/pro_popup_desc"; ?>';
        $.ajax({
            url:url,
            method:"post",
            data:{proid:id},
            success:function(response){				
                $("#modelcont").html(response);
				modal.style.display = "block";
				$(".close").on("click", function() {modal.style.display = "none";});
            }
        })
    })
})
</script>


<script type="text/javascript">
    function valueChanged()
    {
        if($('#agreed').is(":checked"))   
            $(".disable-click").show();
        else
            $(".disable-click").hide();
    }
</script>

  <script>
  $('.new-cs-div').mouseenter(function(){
     $(this).css('background', '#EAE5E3');
});
  //#EAE5E3
 $('.new-cs-div').mouseleave(function(){
    $(this).css('background', 'white');
});
</script>

<script>
	//Siva prasad
//Get the button
var mybutton = document.getElementById("myBtn2");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>

