<?php include 'include/header.php';?>
<?php //print_r($appdetails); ?>
<?php foreach($appdetails as $appdet){ 
$application_approve_date = $appdet->licence_issued_date;
$application_approve_date = strtotime($application_approve_date);
// echo date('d/m/Y', $application_approve_date);
$expiry_date = strtotime('+ 3 year', $application_approve_date);
// echo date('d/m/Y', $expiry_date);
$current_date = $appdet->confirmed_date;
$current_date = strtotime($current_date);
?>
	<div id="print-report" class="certi">
	<table style="max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px 4%;border-collapse: inherit;border-bottom:none;">
		<tbody>			
			<tr>
				<td style="text-align:center;">
					<img style="max-width:100%" src="<?php echo base_url().'theme/user/images/head-logo.jpg';?>">
				</td>				
			</tr>
			<tr>
				<td style="text-align:left;padding-left:03%;width: 100%;">
					<p>Number:<span style="color:#ca0027;"> 2458732/54</p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<p><span style="font-size:40px;font-family: 'Times New Roman';">CERTIFICATE</span> <br>of Accreditation </p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<hr align="center" style="width:80%;"></hr>
				</td>				
			</tr>
			<tr>
				<td style="text-align:center;width: 100%;">
					<p> to this organization, about issuing an accreditation letter from the Tourism Department</p>
				</td>				
			</tr>
			<tr>
				<td style="text-align:left;float:left;">
					<p>This office letter number:<b> 24154dfvd545</b> </p>
				</td>
				<td style="text-align:left;width: 200px;float:right;">
					<p>Date:<b> <?php echo date('d-m-Y', $application_approve_date) ?> </b> </p>
				</td>				
			</tr>			
			<tr>
				<td style="text-align:center;">
					<p style="margin: 20px 0 10px;"><span style="font-size:30px;font-weight: 600;text-transform: uppercase;">Deputy Director (Tourism), Department of Tourism</span></p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:left;">
					<p style="margin: 10px 0;">Letter from <b><?php echo $appdet->applicant_name;?> </b> </p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:left;">
					<p style="margin: 10px 0;">Number: PRE / UPFA /<b> <?php echo $appdet->application_id;?></b>, Date: <b><?php echo date('d-m-Y', $current_date);?></b> </p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:left;">
					<p style="margin: 20px 0;">Travel from the Department of Tourism for the foregoing This office circular of affiliation reference (1), which permits organizations </p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:left;">
					<p style="margin: 10px 0;">Tours & Travels, <b><?php echo $appdet->org_loc_add1.", ".$appdet->org_loc_add2;?> <?php echo ", ". $this->db->get_where('m_taluk', array('id' => $appdet->org_loc_taluk_id))->row()->name; ?><?php echo ", ". $this->db->get_where('m_district', array('id' => $appdet->org_loc_district_id))->row()->name; ?></b>  </p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:left;">
					<p style="margin: 10px 0;">This serve as tours and travel operators Of the reference (2) to issue an accreditation from the Department of Tourism to submit Appeal to Deputy Director, Tourism Department, <b>----------</b> Have submitted Deputy Director, Department of Tourism, <b>--------</b> Visit the agency, inspect the location, and submit the letter of reference (3) Considering the report, the date for the agency is: <b><?php echo date('d-m-Y', $application_approve_date) ?></b> to <b><?php echo date('d-m-Y', $expiry_date); ?></b>  </p>
				</td>								
			</tr>
		</tbody>
	</table>
	<table style="max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;border-top:none;">
		<tbody>
			
			<tr>
				<td style="text-align:left;">
					<p style="margin: 10px 0;"><b>Accredited by the Department of Tourism under the following conditions: </b> </p>
					<p>* The travel agency is approved by the Department of Tourism, Government of Karnataka Only guides should be hired.</p>
					<p>*Department of travel agency office at any time The officer / staff have the authority to inspect.</p>
					<p>* For any restrictions imposed by the travel agency department from time to time to be committed.</p>
					<p>* Travel agency complaint / advisory book, bill / receipt books correct must be managed in a way.</p>
					<p>* They shouldn’t be involved in any activity that is prohibited and against the law. Travel law is by law in the interests of tourists visiting the state</p>
					<p>* Incase of any changes by the agencies, the concerned department needs to be informed on priority.</p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:left;">
					<p>The validity of the institution's certificate expires on:<b> <?php echo date('d-m-Y', $expiry_date); ?></b> </p>
					<p>Submit the application to the department within 30 days of expiry</p>
					<p>stay updated. If the application isn’t submitted on time, the accreditation will discontinue for a period of two years. </p>
				</td>								
			</tr>
			<tr>
				<td style="text-align:right;">
					<p><b>Directors</b></p>
					<p><b>Tourism</b></p>
				</td>								
			</tr>
		</tbody>		
	</table>
</div>
<div class="certi">
				<button type="button" onclick="printDiv('print-report')">Print</button>
			</div>
<script>
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}


	</script>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Times%20New%20Roman" rel="stylesheet"> 
	<style>	
.certi {float: left;position: relative;width: 100%;margin: 10px 0;text-align: center;}	
@media screen, print {
         table{max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;}
		img{max-width:100%;}

      }
		
	</style>
<style  media="print">	
         table{max-width:980;min-width:320px;margin:auto;width:100%;border:3px solid #ca0027;font-family: 'Montserrat', sans-serif;font-size:18px;padding: 20px;border-collapse: inherit;}
		img{max-width:100%;}
.certi {float: left;position: relative;width: 100%;margin: 10px 0;}
b{color:#ca0027;}
	</style>
<?php } ?>
<?php include 'include/footer.php';?>
