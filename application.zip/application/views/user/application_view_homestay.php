<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<?php if($this->session->flashdata('msg')):?>
		<div class="alert">
		<span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
		</div>
	<?php endif; ?>
<!--NEWW-->
<?php 

if(empty($appnot_det)){

}
else{

	?>

<div class="container-fluid" style="overflow-x:auto;overflow-y:hidden;" >

<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
<thead >
<tr class="success" style="background-color:#495057;color:#fff">
<th style="width:10%;">Sl_No</th> 
<th>Messages</th>
<th>Date</th>
<th>Stage</th>
<th >Updated From</th>
</tr> 
</thead>
<?php 
 	$counter = 1;
    foreach($appnot_det as $noti_det){ 
?>      
<tr>
<td><?php echo $counter++;?></td>  
<td style="text-align:;"><?php echo $noti_det->message; ?></td>
<td style="text-align:;"><?php echo date("d/m/Y H:i:s",strtotime($noti_det->crtdate)); ?></td>
<td style="text-align:;"><?php echo $this->db->get_where('m_stage', array('order_stage' => $noti_det->app_stage))->row()->stage_description; ?></td>
<td style="text-align:;"><?php echo $noti_det->crtname; ?></td>
</tr>
<?php 
}
?>
</table>
</div>
<style>
th {
    color: #fff!important;
}
</style>

<?php
}
?>
<!--end NEWW-->

  <!--  <?php print_r($appdetails);?>  --> 
<!--		   print_r($appdet->product_id);-->
  <?php foreach($appdetails as $appdet){  ?>
  	<div class="form-wizard">

	<div class="agent-form-file-view1">
		<?php if($appdet->licence_issued_date != NULL)
		{ ?>
		<!-- <a href="<?php echo base_url();?>applications/certificate/<?php echo $appdet->application_id;?>" target="_blank">View Certificate</a> -->

		<?php } 
		if($appdet ->dsc_pdf_file != NULL) {?> 

		<a href="<?php echo base_url();?>upload/dsc_pdf_file/<?php echo $appdet->dsc_pdf_file; ?>" target="_blank">View DSC File &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
		<?php } ?>
		
	<!-- </div>

	<div class="agent-form-file-view1"> -->
		<?php if($appdet->is_confirmed == 1)
		{ ?>
		<a href="<?php echo base_url();?>applications/pay_acg/<?php echo $appdet->application_id;?>" target="_blank">View Acknowledgement</a>
		<?php } ?>
	</div></div>
	

<?php if($appdet->is_confirmed==0 && $appdet->status_code==0 && $appdet->isdraft==0){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/application_makepay/<?php echo $appdet->id; ?>">Click Here to Make Payment</a>
</div> 
<?php } ?>

<?php if($appdet->is_confirmed==1 && $appdet->app_status==2 ){ ?>
<div class="agent-form-file-view1">
<!--span style="color:#ca0127;font-weight:700;">If, Any document  or Any Changes ,Please Click Here &nbsp;&nbsp;&nbsp;&nbsp;</span-->
	<!-- <a href="<?php echo base_url();?>applications/application_edit/<?php echo $appdet->id; ?>">EDIT</a> -->
	<!-- <a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a> -->
</div> 
  <?php } ?>

<?php if($appdet->isdraft==1){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a>
</div> 
 <?php } ?>
	<div class="admin-dashboard">				
		<div class="agent-application-view">
			<div class="application-view-options">
				<div class="application-info-view">
				<?php if($appdet->licence_no != ''): ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Number / ಪರವಾನಗಿ ಸಂಖ್ಯೆ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->licence_no; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Issued Date / ಪರವಾನಗಿ ನೀಡಿದ ದಿನಾಂಕ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->licence_issued_date)); ?></p>
						</div>										
					</div>
				<?php endif;?>
				<?php if($appdet->iteration > 0 and $appdet->resent_verifi == 0 ): ?>
				<div class="form-heading-view">
					<h4>Resend for clarification</h4>
				</div>
				<form method="post" role="form" enctype="multipart/form-data"  id="refileupload">
					<input type="hidden" name="appid" value=<?php echo $appdet->id?>>
				<div class="agent-form-view" class="col-md-12">
					<table id='dataTableExample_resend' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
							<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th>
								<th>Document Name</th>
								<th>Comments</th>
								<th>Resubmit</th>								
							</tr> 
						</thead> 
					</table><div style="color:green" id="msg">  </div>
					<div style="align-items: center">
						<button class="btn btn-success" onclick="saveupload()">Save</button>
					</div>
				</div>
				</form>
				<?php endif;?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Applicant ID / ಅರ್ಜಿದಾರರ ಐಡಿ <sup> *</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->application_id; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Application Date / ಅರ್ಜಿ ದಿನಾಂಕ <sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y H:i:s",strtotime($appdet->confirmed_date)); ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Owner Name  / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div>

					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name Of The Entity/ಘಟಕದ ಪೂರ್ಣ ಹೆಸರು<sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)/(ಸಂಸ್ಥೆ / ಕಂಪನಿ / ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳು ಸಹಭಾಗಿತ್ವ / ಮಾಲೀಕತ್ವ)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div> -->

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile No / ಮೊಬೈಲ್ ನಂ <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_mobile; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Telephone  / ದೂರವಾಣಿ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_telephone; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Email  / ಇಮೇಲ್ ಐಡಿ <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->official_email; ?></p>
						</div>										
					</div>
					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name Of The Entity / ಘಟಕದ ಪೂರ್ಣ ಹೆಸರು <sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)/ ಸಂಸ್ಥೆ/ಕಂಪನಿ/ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ/ಮಾಲೀಕತ್ವ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div> -->

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Aadhaar Number / ಆಧಾರ್ ಸಂಖ್ಯೆ <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->official_aadhaar; ?></p>
						</div>										
					</div>						
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Name of Homestay  / ಹೋಂಸ್ಟೇ ಹೆಸರು <sup> * </sup></p>		
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->homestay_name; ?></p>
						</div>										
					</div>				
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District / ಜಿಲ್ಲೆ  <sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $appdet->org_loc_district_id))->row()->name; ?></p>
						</div>										
					</div>
					<!--  
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Recognised under Ministry of Tourism, Government of India/ಭಾರತ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಗುರುತಿಸಲ್ಪಟ್ಟಿದೆ <sup> * </sup></p>
								 /ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿಸಲಾಗಿದೆ, ಭಾರತ ಸರ್ಕಾರ 
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->central_gov_approved; ?></p>
						</div>										
					</div>
					<?php if ( $appdet->central_gov_approved == Yes) { ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Details of Registered under Ministry of Tourism, Government of India/ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯ, ಭಾರತ ಸರ್ಕಾರದ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ವಿವರಗಳು<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<a href="<?php echo base_url();?>upload/img_central_gov_registration/<?php echo $appdet->img_central_gov_registration; ?>" target="_blank">View</a>
						</div>										
					</div>
					<?php } ?>-->				
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk / ತಾಲೂಕು <sup> * </sup></p>		
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $appdet->org_loc_taluk_id))->row()->name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City / Town / Village <br> ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							
							<p><?php echo $appdet->org_loc_city; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address /   ವಿಳಾಸ <sup> * </sup></p>
										
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add1; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup> * </sup></p>
								<!-- <?php if($appdet->product_id==1){?><sup>*</sup><?php }?>-->		 				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Website Name / ಜಾಲತಾಣ</p>
							<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup><?php }?> -->					
						</div> 
						<div class="form_input_view">
							<p><?php echo $appdet->website_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date on which Homestay became Operational 
												 / ಹೋಂಸ್ಟೇ ಕಾರ್ಯಾರಂಭ ಮಾಡಿದ ದಿನಾಂಕ <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y H:i:s",strtotime($appdet->org_registration_date)); ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Is your Homestay Approved by the Department ?  / ನಿಮ್ಮ ಹೋಂಸ್ಟೇ ಇಲಾಖೆಯಿಂದ ಅನುಮೋದಿತವಾಗಿದೆಯೇ? <sup> * </sup></p>							
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->central_gov_approved; ?></p>
						</div>
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Is your Homestay a Heritage Building ? / ನಿಮ್ಮ ಹೋಂಸ್ಟೇ ಒಂದು ಪಾರಂಪರಿಕ ಕಟ್ಟಡ <sup> * </sup></p>							
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->homestay_her_built; ?></p>
						</div>
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Is WIFI Facility Available ?  / ವೈಫೈ ಸೌಲಭ್ಯವಿದೆಯೇ ? <sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->homestay_wifi_ava; ?></p>
						</div>
					</div>				
<!-- 					<div class="form-heading-view">
						<h4>Transportation Facilities / ಸಾರಿಗೆ ಸೌಲಭ್ಯಗಳು</h4>
					</div> -->
					<div class="form_label_view">
						<br><br><h4><b>Transportation Facilities / ಸಾರಿಗೆ ಸೌಲಭ್ಯಗಳು<sup>*</sup></b></h4>
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
						<p>   Nearest Bus Stand / ಹತ್ತಿರದ ಬಸ್ ನಿಲ್ದಾಣ <sup> * </sup></p>
									 
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->near_bus_stand; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>   Distance(km) / ದೂರ (ಕಿಮೀ)<sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->bus_distance; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>   Nearest Railway Station / ಹತ್ತಿರದ ರೈಲು ನಿಲ್ದಾಣ <sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->near_rail_station; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>   Distance(km) / ದೂರ (ಕಿಮೀ)<sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->rail_distance; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>   Nearest Airport / ಹತ್ತಿರದ ವಿಮಾನ ನಿಲ್ದಾಣ <sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->near_airport; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>  Distance(km) / ದೂರ (ಕಿಮೀ) <sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->air_distance; ?></p>
						</div>										
					</div>				
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>   Pick Up and Drop facility offered ? / ಪಿಕ್ ಅಪ್ ಮತ್ತು ಡ್ರಾಪ್ ಸೌಲಭ್ಯವನ್ನು ನೀಡಲಾಗಿದೆ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->pickup_facility; ?></p>
						</div>										
					</div>

				
				<div class="form-heading-view">
					<br><h4><b>Nearest Tourist Spots  / ಹತ್ತಿರದ ಪ್ರವಾಸಿ ತಾಣಗಳು</b></h4>
				</div>

					<div class="agent-form-view">
						<div class="form_label_view"> 
							<p>Tourist attraction name  / ಪ್ರವಾಸಿ ಆಕರ್ಷಣೆಯ ಹೆಸರು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->tourist_name_1 ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>  Room Category  / ವರ್ಗ  <sup> * </sup></p>					
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->category_type_1; ?></p>
						</div>										
					</div>
					 

					<?php if(count($homesdet)>0) {?>
					<div class="form-heading-view">
						<h4>Other Office Address / ಇತರ ಕಚೇರಿ ವಿಳಾಸಗಳು</h4>
					</div>
					<div class="agent-form-view">
						<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
						<tr class="success" style="background-color:#495057;color:#fff">
						<th style="width:10%;">Sl_No</th> 
						<th>Tourist attraction name / ಪ್ರವಾಸಿ ಆಕರ್ಷಣೆಯ ಹೆಸರು</th>
						<th>Room Category / ವರ್ಗ</th>
						<th>Distance (km)  / ದೂರ (ಕಿಮೀ) </th> 
						</tr> 
						</thead>
						<?php 
							// print_r($homesdet);
						 	$counter = 1;
						    foreach($homesdet as $tourist_det){ 
						?>      
						<tr>
						<td><?php echo $counter++;?></td>  
						<td style="text-align:;"><?php echo $tourist_det->tourist_name; ?></td>
						<td style="text-align:;"><?php echo $tourist_det->category_type; ?></td>
						<td style="text-align:;"><?php echo $tourist_det->distance; ?></td>
						 
						<?php 
						}
						?>
						</table>
					</div>
					<?php }?>
					

					<br/><br/>
					<br/>
					<div class="agent-form-view">
						<div class="form_label_view">
							<br><h4><b> Room and Tarrif Details / ಕೊಠಡಿ ಮತ್ತು ಟ್ಯಾರಿಫ್ ವಿವರಗಳು <sup>*</sup></b></h4>
						</div>
						 <!-- <?php print_r($hotelaccomodation)?>  -->
						<div class="agent-form-view">
								<table id='dataTableExample_acc' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
								<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:20%;">Category / ಕೊಠಡಿ ವರ್ಗ  </th> 
								<th>No of Rooms   / ಕೊಠಡಿಗಳ ಸಂಖ್ಯೆ  </th>	
								<th> Tariff (Rs.)  / ಸುಂಕ (ರೂ.)</th>	
								<th>  Extra Charge Per Person (Rs)  / ಪ್ರತಿ ವ್ಯಕ್ತಿಗೆ ಹೆಚ್ಚುವರಿ ಶುಲ್ಕ (ರೂ.) </th>	
								<th> Is there Child Concession ? / ಮಕ್ಕಳ ರಿಯಾಯಿತಿ ಇದೆಯೇ  </th>	
								</tr> 
								</thead>
								<!-- <?php  
									//print_r($addressdet);
								 	// $counter = 1;
								    // foreach($hotelaccomodation as $hotelacco){ 
								 ?>       -->
								<tr>
								<td><p><?php echo $appdet->hs_accommodation_type;?></p></td>  
								<td><p><?php echo $appdet->no_of_rooms;?></p></td>  
								<td><p><?php echo $appdet->hs_tariff_rs;?></p></td> 
								<td><p><?php echo $appdet->extra_charge_rs;?></p></td> 
								<td><p><?php echo $appdet->hs_child_concession;?></p></td>  
								<!-- <?php  
								// }
								?> -->
								</table>
						</div>
					</div>

					
					<div class="agent-form-view">
						<div class="form_label_view">
							<br><h4><b>Activities Available / ಚಟುವಟಿಕೆಗಳು ಲಭ್ಯವಿದೆ<sup>*</sup></b></h4>
						</div>
						<div class="agent-form-view">
							<div class="form_label_view">
									<p>Services Available / ಸೇವೆಗಳು ಲಭ್ಯವಿದೆ  <sup> * </sup></p>
							</div>
							<div class="form_input_view">
								<p><?php echo $appdet->hs_services_avail; ?></p>
							</div>										
						</div>
						<div class="agent-form-view">
							<div class="form_label_view">
									<p>Vegetarian Food Offered / ಸಸ್ಯಾಹಾರಿ ಆಹಾರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ  <sup> * </sup></p>
							</div>
							<div class="form_input_view">
								<p><?php echo $appdet->hs_veg_food; ?></p>
							</div>										
						</div>
						<div class="agent-form-view">
							<div class="form_label_view">
									<p>Non-Vegetarian Food Offered / ಮಾಂಸಾಹಾರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ  <sup> * </sup></p>
							</div>
							<div class="form_input_view">
								<p><?php echo $appdet->hs_nonveg_food; ?></p>
							</div>										
						</div>

					</div>
							
					<!-- <?php print_r($hotelfacility)?>  -->
				<!-- 	<div class="agent-form-view">
						<div class="form_label_view">
							<h4>Room and Tarrif Details / ಕೊಠಡಿ ಮತ್ತು ಟ್ಯಾರಿಫ್ ವಿವರಗಳು<sup>*</sup></h4>
						</div>
						<div class="agent-form-view">
								<table id='dataTableExample_acc' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
								<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th> 
								<th>Facilities</th>		
								<th>Other Facilities</th>					
								</tr> 
								</thead>
								<?php 
									//print_r($addressdet);
								 	$counter = 1;
								    foreach($hotelfacility as $hotel_facility){ 
								?>      
								<tr>
								<td><?php echo $counter++;?></td>  
								<td style="text-align:;"><?php echo $hotel_facility->facility_type; ?></td>
								<td style="text-align:;"><?php echo $hotel_facility->other_facility; ?></td>	
								</tr>
								<?php 
								}
								?>
								</table>
						</div>									
					</div> -->
					
					<!-- <div class="form-heading-view">
						<h4>Registered Hotel/ Resort Address / ನೋಂದಾಯಿತ ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ವಿಳಾಸ</h4>
					</div> -->
				<!-- 	<?php print_r($addressdet);?> -->
				
				<!-- 	<?php if(count($addressdet)>0) { ; ?>
					<div class="form-heading-view">
						<h4>Other Office Address/ಇತರ ಕಚೇರಿ ವಿಳಾಸಗಳು</h4>
					</div>
					<div class="agent-form-view">
						<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
						<tr class="success" style="background-color:#495057;color:#fff">
						<th style="width:10%;">Sl_No</th> 
						<th>Address 1 / ವಿಳಾಸದ 1</th>
						<th>Address 2 / ವಿಳಾಸದ 2</th>
						<th>District / ಜಿಲ್ಲೆ</th>
						<th>Taluk / ತಾಲ್ಲೂಕು</th>	
						<th>City/Town/Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ</th>			
						<th>Pincode / ಪಿನ್ಕೋಡ್</th>
						<th>Contact Number / ಸಂಪರ್ಕ ಸಂಖ್ಯೆ</th>
						</tr> 
						</thead>
						<?php 
							//print_r($addressdet);
						 	$counter = 1;
						    foreach($addressdet as $address_det){ 
						?>      
						<tr>
						<td><?php echo $counter++;?></td>  
						<td style="text-align:;"><?php echo $address_det->other_off_addr1; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_addr2; ?></td>
						<td style="text-align:;"><?php echo $this->db->get_where('m_district', array('id' => $address_det->other_off_district_id))->row()->name;?></td>
						<td style="text-align:;"><?php echo $this->db->get_where('m_taluk', array('id' => $address_det->other_off_taluk))->row()->name; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_city; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_pincode_id; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_contact; ?></td></tr>

						<?php 
						}
						?>
						</table>
					</div>
					<?php }?> -->
				<!-- </div> -->

				<br/><br/>
				<br/>
				<div class="agent-application-document-view">
					<div class="form-heading-view">
						<h4><b>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</b></h4>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Owner Photo / ಮಾಲೀಕರ ಫೋಟೋ <sup>*</sup></h5>
		
						</div>	
						<?php if($appdet->img_owner_certificate!=null){?> 
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_owner_certificate/<?php echo $appdet->img_owner_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }  ?>
					</div>
					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Commencement Certificate of the Hotel/Resort <sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_commercial_certificate!="" || $appdet->img_commercial_certificate!=null){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_commercial_certificate/<?php echo $appdet->img_commercial_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div> -->
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Aadhaar  Card / ಆಧಾರ್ ಕಾರ್ಡ್<sup>*</sup></h5>	
												
						</div>
						<?php if($appdet->img_adhaar_permit!="" || $appdet->img_adhaar_permit!=null){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_adhaar_permit/<?php echo $appdet->img_adhaar_permit; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate of Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಪ್ರಮಾಣಪತ್ರ
								<sup>*</sup></h5>
							<p>Documentary proof of turn over in Indian or foreign exchange from Hotel/Resort related activities operations during the previous financial year 
							<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಅಕ್ಷರದ ತಲೆಯ ಮೇಲೆ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್‌ನ ಪ್ರಮಾಣಪತ್ರ<br>• Profit &amp; Loss statement/ ಲಾಭ &amp; ನಷ್ಟ ಹೇಳಿಕೆs.</p>
						</div>	
						<?php if($appdet->img_ca_certificate!=null) {?> 
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
					<?php } ?>
					</div> -->

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
								<h5>Photograph of Homestay Exterior / ಹೋಂಸ್ಟೇ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h5>
								<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
						</div>
						<?php if($appdet->img_off_buil_exterior!=null) {?> 									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of Homestay Front View/ ಹೋಮ್‌ಸ್ಟೇ ಮುಂಭಾಗದ ನೋಟದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h5>
								<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
						</div>	
						<?php if($appdet->img_built_front_view!=null) {?> 								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_built_front_view/<?php echo $appdet->img_built_front_view; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
								<h5>Photograph of Homestay Room Interiors / ಹೋಮ್‌ಸ್ಟೇ ಕೊಠಡಿಯ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h5>
								<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>						
						</div>		
						<?php if($appdet->img_room_interior!=null) {?> 							
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_room_interior/<?php echo $appdet->img_room_interior; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of Homestay Bathroom Interiors /ಹೋಮ್‌ಸ್ಟೇ ಬಾತ್‌ರೂಮ್ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h5>
							<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>						
						</div>			
						<?php if($appdet->img_room_exterior!=null) {?>						
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_room_exterior/<?php echo $appdet->img_room_exterior; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>

					<!--div class="allply-form-view">
							<div class="apply-agent-file-view">
								<h5>Copy of Trade License / ವ್ಯಾಪಾರ ಪರವಾನಗಿಯ ಪ್ರತಿ <sup> * </sup></h5>
							</div>
							<?php if($appdet->img_trade_lic!=null) {?>	
							<div class="agent-form-file-view">
								<a href="<?php echo base_url();?>upload/img_trade_lic/<?php echo $appdet->img_trade_lic; ?>" target="_blank">View</a>
							</div>	
							<?php } ?>									
					</div-->

					<div class="allply-form-view">
							<div class="apply-agent-file-view">
								<h5>Homestay Ownership Document (front page of the document carrying name of the owner)
									/ ಹೋಂಸ್ಟೇ ಮಾಲೀಕತ್ವದ ದಾಖಲೆ (ಮಾಲೀಕರ ಹೆಸರನ್ನು ಹೊಂದಿರುವ ಡಾಕ್ಯುಮೆಂಟ್‌ನ ಮೊದಲ ಪುಟ) <sup> * </sup></h5>
							</div>
							<?php if($appdet->img_certificate_shops!=null) {?>	
							<div class="agent-form-file-view">
								<a href="<?php echo base_url();?>upload/img_certificate_shops/<?php echo $appdet->img_certificate_shops; ?>" target="_blank">View</a>
							</div>	
							<?php } ?>									
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Police Station /ಪೊಲೀಸ್ ಠಾಣೆಯಿಂದ ಎನ್‌ಒಸಿ <sup> * </sup></h5>
						</div>	
						<?php if($appdet->img_noobj_certificate!=null) {?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_noobj_certificate/<?php echo $appdet->img_noobj_certificate; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Local Bodies  / ಸ್ಥಳೀಯ ಸಂಸ್ಥೆಗಳಿಂದ ಎನ್‌ಒಸಿ <sup> * </sup></h5>						
						</div>
						<?php if($appdet->img_local_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_local_certificate/<?php echo $appdet->img_local_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					
					
					
					<!--div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Police Department / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್ಒಸಿ <sup>*</sup></h5>
						</div>
						<?php if($appdet->img_commercial_certificate!="" || $appdet->img_commercial_certificate!=null){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_commercial_certificate/<?php echo $appdet->img_commercial_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div-->

			  </div>			
			</div>
		</div>
	</div>
<?php } ?>
<style>
.agent-form-file-view1 {float: left;position: relative;width: 100%;padding: 30px 4%;text-align: right;}
.agent-form-file-view1 a {background: #178597;color: #fff;padding: 10px 20px;border-radius: 3px;}
.admin-dashboard .agent-application-view .application-view-options .application-info-view .agent-form-view .form_input_view a{background: #ca0027;color: #fff;padding: 5px 20px;border-radius: 5px;}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php include 'include/footer.php';?>
<script type="text/javascript">
$(document).ready( function() 
{
  		//alert("test");
		//alert("loadvehicle data");
		var application_id=<?php echo($appdet->id)?>;
		var BASE_URL = "<?php echo base_url();?>";
		var path = BASE_URL+'applications/vehicledata';		
		var table = $('#dataTableExample_vehicle').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path,
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'vehicle_type' },
				        { data: 'permit_type'},
				        { data: 'regitration_name' },
				        { data: 'registeration_no' },
				        { data: 'tourist_permit' },
				        { data: 'permitdate' }, 
				        { data: 'enddate' }
				    ]
    	});	
		var path_resend = BASE_URL+'applications/resenddate';
		var tablenew = $('#dataTableExample_resend').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path_resend,
				        //dataType: "json",
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 				   
				     	{ data: 'sno' },
				     	{ data: 'Registration/Incorporation Certificate' },
				     	{ data: 'comments' },
				     	{
                            "data": null,                          
                            render:function(data, type, row)
                            {
                            	//console.log(data.DocumentType);
                                return '<div class="form_input_file">'+
								'<div class="file-upload-wrapper" data-text="Select your file!"><input id="reg_firm" name='+data.DocumentType+' type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf"></div></div>'+
								   '<input type="hidden" class="tablecount" name="filenames[]" id="filename'+data.sno+'" value='+data.DocumentType+'>'
                            },
                            "targets": -1
                        }                        
				    ]
    	});

		// var table = $('#dataTableExample_resend').DataTable(
		// {
		// 	ajax: {
		// 	 			type: 'POST',
		// 		        url: path,
		// 		        dataSrc: '',
		// 		        data:{
		// 		             appId:application_id
		// 		        }
		// 		    },	

		// 		    searching:false,
		// 		    paging:false,
		// 		    info: false,
		// 		    columns: [ 
		// 		     	{ data: 'slno' },				        
		// 		        {
  //                           "data": null,                          
  //                           render:function(data, type, row)
  //                           {
  //                             if(data.DocumentType)
  //                             {
  //                               return '<input type="checkbox" id="logout_late_'+data.emp_id+'" checked onclick="angular.element(this).scope().activelatelogout('+data.emp_id+')">'  
  //                             }                            
  //                           },
  //                           "targets": -1
  //                       },
		// 		        { data: 'reg_certificate' },				        
		// 		        { data: 'reg_certificate_details' }				        
		// 		    ]
  //   	});
});	
function saveupload()
{
	$("#refileupload").submit(function(e){
        e.preventDefault();
    });
    var path 		= "<?php echo base_url();?>applications/reupload";	
    var form = $('#refileupload')[0];
    var formData = new FormData(form);
    $.ajax({
			type: 'POST',
			url: path,
			 //data: form.serialize(),
			processData: false,
			contentType: false,
			data: formData,
			beforeSend: function() {
		            $('#cover-spin').show(); 
	            setTimeout(function(){ $('#cover-spin').hide();  }, 180000); // 3 min

	        },
			success: function(data) 
			{
				// console.log(data);
				if(data=="Application Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
				{
					alert('Applicant details not saved. Please try after some time.');
				}
				else
				{
					//alert("Files are upated successfully") ;
					$('#msg').html('Files are upated successfully');
				}
			},
			 complete:function(defSimilar){
                $('#cover-spin').hide();
            } 

		});

}
</script>

