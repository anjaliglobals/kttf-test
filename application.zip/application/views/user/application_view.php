<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<?php if($this->session->flashdata('msg')):?>
		<div class="alert">
		<span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
		</div>
	<?php endif; ?>
<!--NEWW-->
<?php
if(empty($appnot_det))
{

}
else{

?>
<div class="container-fluid" style="overflow-x:auto;overflow-y:hidden;" >
<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
<thead >
<tr class="success" style="background-color:#495057;color:#fff">
<th style="width:10%;">Sl_No</th> 
<th>Messages</th>
<th>Date</th>
<th>Stage</th>
<th >Updated From</th>
</tr> 
</thead>
<?php 
 	$counter = 1;
    foreach($appnot_det as $noti_det){ 
?>      
<tr>
<td><?php echo $counter++;?></td>  
<td style="text-align:;"><?php echo $noti_det->message; ?></td>
<td style="text-align:;"><?php echo date("d/m/Y H:i:s",strtotime($noti_det->crtdate)); ?></td>
<td style="text-align:;"><?php echo $this->db->get_where('m_stage', array('order_stage' => $noti_det->app_stage))->row()->stage_description; ?></td>
<td style="text-align:;"><?php echo $noti_det->crtname; ?></td>
</tr>
<?php 
}
?>
</table>
</div>
<style>
th {
    color: #fff!important;
}
</style>

<?php
}
?>
<!--end NEWW-->

 <!-- <?php print_r($appdetails);?>    -->
<!--		   print_r($appdet->product_id);-->
  <?php foreach($appdetails as $appdet){  ?>

	<div class="agent-form-file-view1">
		<?php if($appdet->licence_issued_date != NULL)
		{ ?>
		<a href="<?php echo base_url();?>applications/certificate/<?php echo $appdet->application_id;?>" target="_blank">View Certificate</a>
		<?php } ?>
	</div>

	<div class="agent-form-file-view1">
		<?php if($appdet->is_confirmed == 1)
		{ ?>
		<a href="<?php echo base_url();?>applications/pay_acg/<?php echo $appdet->application_id;?>" target="_blank">View Acknowledgement</a>
		<?php } ?>
	</div>
	

<?php if($appdet->is_confirmed==0 && $appdet->status_code==0 && $appdet->isdraft==0){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/application_makepay/<?php echo $appdet->id; ?>">Click Here to Make Payment</a>
</div> 
<?php } ?>

<?php if($appdet->is_confirmed==1 && $appdet->app_status==2 ){ ?>
<div class="agent-form-file-view1">
<!--span style="color:#ca0127;font-weight:700;">If, Any document  or Any Changes ,Please Click Here &nbsp;&nbsp;&nbsp;&nbsp;</span-->
	<!-- <a href="<?php echo base_url();?>applications/application_edit/<?php echo $appdet->id; ?>">EDIT</a> -->
	<!-- <a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a> -->
</div> 
  <?php } ?>

<?php if($appdet->isdraft==1){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a>
</div> 
 <?php } ?>


	<div class="admin-dashboard">				
		<div class="agent-application-view">
			<div class="application-view-options">
				<div class="application-info-view">
				<?php if($appdet->licence_no != ''): ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Number / ಪರವಾನಗಿ ಸಂಖ್ಯೆ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->licence_no; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Issued Date / ಪರವಾನಗಿ ನೀಡಿದ ದಿನಾಂಕ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->licence_issued_date)); ?></p>
						</div>										
					</div>
				<?php endif;?>
				<?php if($appdet->iteration > 0 and $appdet->resent_verifi == 0 ): ?>
				<div class="form-heading-view">
					<h4>Resend for clarification</h4>
				</div>
				<form method="post" role="form" enctype="multipart/form-data"  id="refileupload">
					<input type="hidden" name="appid" value=<?php echo $appdet->id?>>
				<div class="agent-form-view" class="col-md-12">
					<table id='dataTableExample_resend' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
							<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th>
								<th>Document Name</th>
								<th>Comments</th>
								<th>Resubmit</th>								
							</tr> 
						</thead>
					</table>
					<div style="align-items: center">
						<button class="btn btn-success" onclick="saveupload()">Save</button>
					</div>
				</div>
				</form>
				<?php endif;?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Applicant ID / ಅರ್ಜಿದಾರರ ಐಡಿ <sup> *</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->application_id; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Application Date / ಅರ್ಜಿ ದಿನಾಂಕ<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y H:i:s",strtotime($appdet->confirmed_date)); ?></p>
						</div>										
					</div>
					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name Of The Entity/ಸಂಸ್ಥೆಯ ಪೂರ್ಣ ಹೆಸರು<sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)/(ಸಂಸ್ಥೆ/ಕಂಪನಿ/ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ/ಮಾಲೀಕತ್ವ)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div> -->
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Trade Name / ವ್ಯಾಪಾರ ಹೆಸರು <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Legal Name / ಕಾನೂನು ಹೆಸರು <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->legal_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>In which name you need a certificate to be printed ? / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ನಿಮಗೆ ಮುದ್ರಿಸಲು ಪ್ರಮಾಣಪತ್ರ ಬೇಕು  <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php if($appdet->certificate_name== '1'){
								echo "Legal Name";
							}?></p>
							<p><?php if($appdet->certificate_name== '2'){
								echo "Trade Name";
							}?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Entity Type / ಸಂಸ್ಥೆಯ ಪ್ರಕಾರ<sup>*</sup></p>	
						</div>
						<div class="form_input_view">
							<p><?php if($appdet->org_type_id ==1){echo "Proprietary Concern";}
								else if($appdet->org_type_id ==2){echo "Partnership";}
								else if($appdet->org_type_id ==3){echo "Company";}
								else if($appdet->org_type_id ==4){echo "Private Limited Company";}
							  else if($appdet->org_type_id ==5){echo "Public Limited Company";}
								else if($appdet->org_type_id ==6){echo "Limited Liabilities Partnership";}
						?></p>
						</div>										
					</div>						
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of Registration/Incorporation of the Entity <br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Shops and Establishment Act) /ಸಂಸ್ಥೆಯ ನೋಂದಣಿ / ಸಂಯೋಜನೆಯ ದಿನಾಂಕ (ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956 /2013 ಅಥವಾ ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯ್ದೆ ಪ್ರಕಾರ) <sup>*</sup></p>				
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->org_commencement_date));  ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of registration of entity as per Karnataka shops and establishment act/  ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ಘಟಕ ನೋಂದಣಿಯಾದ ದಿನಾಂಕ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->org_shop_date));  ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of issue of Trade License/ ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನೀಡಲಾದ ದಿನಾಂಕ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->trade_lic_date));  ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
							<div class="form_label_view">
								<p>Copy of Trade License / ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></p>
							</div>
							<div class="form_input_view">
								<a href="<?php echo base_url();?>upload/img_trade_lic/<?php echo $appdet->img_trade_lic; ?>" target="_blank">View</a>
							</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Recognised under Ministry of Tourism, Government of India /ಭಾರತ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಮಾನ್ಯತೆ ಪಡೆದಿದೆಯೇ?<sup> * </sup></p>
								<!-- /ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿಸಲಾಗಿದೆ, ಭಾರತ ಸರ್ಕಾರ -->
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->central_gov_approved; ?></p>
						</div>										
					</div>
					<?php if ( $appdet->central_gov_approved == Yes) { ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Details of Registered under Ministry of Tourism, Government of India/ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯ, ಭಾರತ ಸರ್ಕಾರದ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ವಿವರಗಳು<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<a href="<?php echo base_url();?>upload/img_central_gov_registration/<?php echo $appdet->img_central_gov_registration; ?>" target="_blank">View</a>
						</div>										
					</div>
					<?php } ?>				
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Name of the properator / Directors / Partners/ ಮಾಲೀಕರು / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಹೆಸರು <sup> * </sup></p>				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->proprietor_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>GST Identification Number/ GST ಗುರುತಿನ ಸಂಖ್ಯೆ <sup>*</sup>
								<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup> <?php } ?> -->
							</p>						
						</div>
						<div class="form_input_view">
							
							<p><?php echo $appdet->gst_number;?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>PAN Number / ಪ್ಯಾನ್ ಸಂಖ್ಯೆ <?php if($appdet->product_id==1){?>
							<!-- 	<sup>*</sup> -->
							<?php }?></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->pan_number; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು URL
								<!-- <?php if($appdet->product_id==1){?><sup>*</sup><?php }?>--></p>		 				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->website_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Official email id of the Entity / ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ
							<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup><?php }?> --></p>						
						</div> 
						<div class="form_input_view">
							<p><?php echo $appdet->official_email; ?></p>
						</div>										
					</div>	
				
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Whether a member of any recognised trade body? / ಯಾವುದೇ ಮಾನ್ಯತೆ ಪಡೆದ ವ್ಯಾಪಾರ ಸಂಸ್ಥೆಯ ಸದಸ್ಯರಾಗಿರುವಿರಾ? <sup>*</sup></p>	
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_recognised_trade; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Whether the member of Karnataka Tourism Society (KTS)? / ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ಸೊಸೈಟಿಯ (ಕೆಟಿಎಸ್) ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup>*</sup></p>	
							<p>(if yes, please upload the valid KTS license) / (ಹೌದು ಎಂದಾದರೆ, ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ  KTS ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_kts; ?></p>
							<?php if($appdet->member_kts=='yes'){?>
							<div class="form_input_view">
							<a href="<?php echo base_url();?>upload/img_member_kts/<?php echo $appdet->img_member_kts; ?>" target="_blank">View</a>
							</div>
						<?php }?>
						</div>										
					</div>
				<?php if($appdet->member_recognised_trade_details): ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Member Recognised Trade Details / ಸದಸ್ಯ ಮಾನ್ಯತೆ ಪಡೆದ ವ್ಯಾಪಾರ ವಿವರಗಳು</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_recognised_trade_details; ?></p>
						</div>										
					</div>			
				<?php endif; ?>	
				<div class="form-heading-view">
						<h4>Office Address / ಕಚೇರಿ ವಿಳಾಸ</h4>
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address 1/ ವಿಳಾಸದ 1  <sup> * </sup></p>				
									 
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add1; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address 2 / ವಿಳಾಸದ 2 <!--sup> * </sup--></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add2; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District / ಜಿಲ್ಲೆ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $appdet->org_loc_district_id))->row()->name; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk / ತಾಲ್ಲೂಕು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $appdet->org_loc_taluk_id))->row()->name; ?></p>
						</div>										
					</div>				
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City / Town / Village/ ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_city; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view"> 
							<p>Nearest Landmark /ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್ <sup> * </sup></p>	
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_landmark ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode/ಪಿನ್‌ಕೋಡ್ <sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number/ಮೊಬೈಲ್ ನಂಬರ್	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_mobile; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Telephone Number/ ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_telephone; ?></p>
						</div>										
					</div>
					<?php if(count($addressdet)>0) {?>
					<div class="form-heading-view">
						<h4>Other Office Address / ಇತರ ಕಚೇರಿ ವಿಳಾಸಗಳು</h4>
					</div>
					<div class="agent-form-view">
						<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
						<tr class="success" style="background-color:#495057;color:#fff">
						<th style="width:10%;">Sl_No</th> 
						<th>Address 1 / ವಿಳಾಸ  1</th>
						<th>Address 2 / ವಿಳಾಸ  2</th>
						<th>District / ಜಿಲ್ಲೆ </th>
						<th>Taluk / ತಾಲೂಕು </th>	
						<th>City/Town/Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ</th>			
						<th>Pincode / ಪಿನ್‌ಕೋಡ್ </th>
						<th>Contact Number / ಸಂಪರ್ಕ ಸಂಖ್ಯೆ</th>
						</tr> 
						</thead>
						<?php 
							//print_r($addressdet);
						 	$counter = 1;
						    foreach($addressdet as $address_det){ 
						?>      
						<tr>
						<td><?php echo $counter++;?></td>  
						<td style="text-align:;"><?php echo $address_det->other_off_addr1; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_addr2; ?></td>
						<td style="text-align:;"><?php echo $this->db->get_where('m_district', array('id' => $address_det->other_off_district_id))->row()->name;?></td>
						<td style="text-align:;"><?php echo $this->db->get_where('m_taluk', array('id' => $address_det->other_off_taluk))->row()->name; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_city; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_pincode_id; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_contact; ?></td></tr>

						<?php 
						}
						?>
						</table>
					</div>
					<?php }?>
					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Address 1<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_add1; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address 2<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_add2; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $appdet->org_district_id))->row()->name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $appdet->org_taluk))->row()->name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City/Town/Village<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_city; ?></p>
						</div>										
					</div>					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Contact Number<sup></sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_mobile; ?></p>
						</div>										
					</div> -->
					
					
					<!--<div class="agent-form-view">
						<div class="form_label_view">
							<p>Location/Area Type <sup>*</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_type; ?></p>
						</div>										
					</div>-->
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total build area(Sq.ft)/ಒಟ್ಟು ನಿರ್ಮಾಣ ಪ್ರದೇಶ (ಚದರ.ಅಡಿ)<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_total_build_sqft; ?></p>
						</div>										
					</div>
					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Receiption area(Sq.ft)<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_total_reception_sqft; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Accessibility to toilet<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_acc_toilet_mtrs; ?></p>
						</div>										
					</div>	-->							
				</div>
				<div class="agent-application-document-view">
					<div class="form-heading-view">
						<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
					</div>

						<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Upload Registration Document</h5>
							<p>Registration certificate - Registered as commercial establishment under Karnataka State Shops and commercial establishment act 1961)</p>
						</div>									
						<!-- <div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_central_gov_registration/<?php echo $appdet->img_central_gov_registration; ?>" target="_blank">View</a>
						</div> 
					</div> -->

				<?php if($appdet->product_id==1){?>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration/Incorporation Certificate/ ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>
							<p>Documentary proof to be uploaded in compliance with the any one of the below act / ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or / ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ
								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / "ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_registration_certificate/<?php echo $appdet->img_registration_certificate; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration certificate under Karnataka shops and Establishment act/ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_certificate_shops!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_certificate_shops/<?php echo $appdet->img_certificate_shops; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Address Proof/ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></h5>
							<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt/ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bank_reference/<?php echo $appdet->img_bank_reference; ?>" target="_blank">View</a>
						</div>
					</div>
					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate of Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಪ್ರಮಾಣಪತ್ರ
								<!-- /ಶಾಸನಬದ್ಧ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ನ ಪ್ರಮಾಣಪತ್ರ  <sup>*</sup>
								</h5>
							<p>Documentary proof of turn over in Indian or foreign exchange from tour related activities operations during the previous financial year which should not beless than Rs. 7.5 Lakh“ / ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಪ್ರವಾಸ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳ ಕಾರ್ಯಾಚರಣೆಗಳಿಂದ ಭಾರತೀಯ ಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದಲ್ಲಿ ತಿರುವು ಪಡೆದ ಸಾಕ್ಷ್ಯಚಿತ್ರ ಪುರಾವೆಗಳು ರೂ. 7.5 ಲಕ್ಷ
<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಅಕ್ಷರದ ತಲೆಯ ಮೇಲೆ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್‌ನ ಪ್ರಮಾಣಪತ್ರ<br>• Profit &amp; Loss statement/ ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್.</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
					</div> -->
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<!-- <h5>List of Directors/Partners/ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪಟ್ಟಿ <sup>*</sup></h5> -->
							<h5>List of Directors/ Partners or name of the Proprietor / ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು<sup>*</sup></h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_list_patners/<?php echo $appdet->img_list_patners; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Brochures or Leaflets / ಕರಪತ್ರಗಳು </h5>
							<p>Brochures or leaflets brought out by the firms having all information about their activities/ "ಸಂಸ್ಥೆಗಳು ಹೊರತಂದಿರುವ ಮತ್ತು ಸಂಸ್ಥೆಗಳ  ಚಟುವಟಿಕೆಗಳ ಕುರಿತು ಎಲ್ಲ ಮಾಹಿತಿಗಳನ್ನು ಹೊಂದಿರುವ ಕರಪತ್ರಗಳು"</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_brochures/<?php echo $appdet->img_brochures; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Details of Office Premises/ ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು </h5>
							<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ </p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_premises/<?php echo $appdet->img_off_premises; ?>" target="_blank">View</a>
						</div>
					</div>
					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Labour Department Certificate/ಕಾರ್ಮಿಕ ಇಲಾಖೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup> </h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_labour_department/<?php echo $appdet->img_labour_department; ?>" target="_blank">View</a>
						</div>
					</div> -->
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity / ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup>*</sup></h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_md_photo_attested/<?php echo $appdet->img_md_photo_attested; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Power of Attorney/ Board Resolution / ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ <sup>*</sup></h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_power_of_attorney/<?php echo $appdet->img_power_of_attorney; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of the Office Building Exterior/ ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of the Office Building Interior / ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_interior/<?php echo $appdet->img_off_buil_interior; ?>" target="_blank">View</a>
						</div>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of GST Registration Certificate/ ಜಿ ಎಸ್ ಟಿ  ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ</h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_gst_regis/<?php echo $appdet->img_gst_regis; ?>" target="_blank">View</a>
						</div>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_board_entity/<?php echo $appdet->img_board_entity; ?>" target="_blank">View</a>
						</div>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Declaration stating that the travel agent on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website / " ಪ್ರತಿ ತಿಂಗಳು ತಪ್ಪದೇ  ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆಯನ್ನು ಅರ್ಜಿದಾರನು ಕಡ್ಡಾಯವಾಗಿ ಅಪಲೋಡ್ ಮಾಡಬೇಕು." *.</h5>							
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_arrival_details/<?php echo $appdet->img_tourist_arrival_details; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ "ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ .</h5>							
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pledge_commitment/<?php echo $appdet->img_pledge_commitment; ?>" target="_blank">View</a>
						</div>
					</div>
					
				<?php } ?>
				<?php if($appdet->product_id==2){?>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration/Incorporation Certificate/ ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>
							<p>Documentary proof to be uploaded in compliance with the any one of the below act / ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or/ ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ
								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished/ "ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</p>
						</div>	
						<?php if($appdet->img_registration_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_registration_certificate/<?php echo $appdet->img_registration_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration certificate under Karnataka shops and Establishment act/ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_certificate_shops!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_certificate_shops/<?php echo $appdet->img_certificate_shops; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Address Proof/ ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></h5>
							<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt/ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p>
						</div>
						<?php if($appdet->img_bank_reference!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bank_reference/<?php echo $appdet->img_bank_reference; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5> Certificate of Chartered Accountant/ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ </h5>
							<p>Documentary proof of turn over in Indian or foreign exchange from Tourist transport related activated operations during the previous financial year which should not beless than Rs. 7.5 Lakh / ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಪ್ರವಾಸಿ ಸಾರಿಗೆ ಸಂಬಂಧಿತ ಸಕ್ರಿಯ ಚಟುವಟಿಕೆಗಳಿಂದ ಮಾಡಲಾದ  ಭಾರತೀಯಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯದ ಟರ್ನ್ ಓವರ್ ಕುರಿತು ದಸ್ತಾವೇಜಿನ ಪುರಾವೆ. ಟರ್ನ್ ಓವರ್ 7.5 ಲಕ್ಷ ರೂ ಗಳಿಗಿಂತ ಕಡಿಮೆ ಇರಬಾರದು. <br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ<br>• Profit &amp; Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್ </p>
						</div>	
						<?php if($appdet->img_ca_certificate!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div> -->
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<!-- <h5> List of Directors/Partners/ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪಟ್ಟಿ* <sup> * </sup></h5> -->
							<h5>List of Directors/Partners or name of the Proprietor/ ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></h5>
						</div>	
						<?php if($appdet->img_list_patners!=""){?>							
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_list_patners/<?php echo $appdet->img_list_patners; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Brochures or Leaflets/ ಕರಪತ್ರಗಳು  </h5>
							<p>Brochures or leaflets brought out by the firms having all information about their activities/ "ಸಂಸ್ಥೆಗಳು ಹೊರತಂದಿರುವ ಮತ್ತು ಸಂಸ್ಥೆಗಳ  ಚಟುವಟಿಕೆಗಳ ಕುರಿತು ಎಲ್ಲ ಮಾಹಿತಿಗಳನ್ನು ಹೊಂದಿರುವ ಕರಪತ್ರಗಳು"</p>
						</div>	
						<?php if($appdet->img_brochures!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_brochures/<?php echo $appdet->img_brochures; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of GST Registration Certificate/ಜಿ ಎಸ್ ಟಿ  ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ <sup> * </sup></h5>
						</div>
						<?php if($appdet->img_gst_regis!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_gst_regis/<?php echo $appdet->img_gst_regis; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup></h5>							
						</div>
						<?php if($appdet->img_pan_copy!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pan_copy/<?php echo $appdet->img_pan_copy; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copies of State Permit valid for Karnataka / All-India Permit tourist permits issued by the concerned Transport Department for Tourist Vehicles / ಕರ್ನಾಟಕ ರಾಜ್ಯದಲ್ಲಿ  ಮಾನ್ಯವಾಗುವ ರಾಜ್ಯ ಪರವಾನಗಿಯ ಪ್ರತಿಗಳು / ಪ್ರವಾಸಿ ವಾಹನಗಳಿಗಾಗಿ ಸಂಬಂಧಿತ ಸಾರಿಗೆ ಇಲಾಖೆಯಿಂದ ನೀಡಲಾದ ಪ್ರವಾಸಿ ಪರವಾನಗಿ ಪ್ರತಿಗಳು<sup> * </sup></h5>
							<p>For more than 1 vehicle valid permits for all the vehicles must be uploaded in a single pdf / "1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು  ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು."</p>
						</div>
						<?php if($appdet->img_state_permit!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_state_permit/<?php echo $appdet->img_state_permit; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration Certificate of Tourist Vehicles/ ಪ್ರವಾಸಿ ವಾಹನಗಳ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
							<p>For more than 1 vehicle valid registration certificate for all the vehicles must be uploaded in a single pdf/ 1 ಕ್ಕಿಂತ ಹೆಚ್ಚು ವಾಹನಗಳಿಗಾಗಿ, ಎಲ್ಲಾ ವಾಹನಗಳ ಮಾನ್ಯ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು  ಒಂದೇ ಪಿಡಿಎಫ್‌ನಲ್ಲಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು</p>
						</div>
						<?php if($appdet->img_tourist_vehicle!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_vehicle/<?php echo $appdet->img_tourist_vehicle; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Details of Office Premises/ ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು</h5>
							<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties / ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ</p>
						</div>	
						<?php if($appdet->img_off_premises!=""){?>							
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_premises/<?php echo $appdet->img_off_premises; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Labour Department Certificate/ಕಾರ್ಮಿಕ ಇಲಾಖೆ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup> </h5>
						</div>
						<?php if($appdet->img_labour_department!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_labour_department/<?php echo $appdet->img_labour_department; ?>" target="_blank">View</a>
						</div>
						<?php }?>	
					</div> -->
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Attested photograph of Proprietor / Partners /Authorized Representative of the Entity/ ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
						</div>
						<?php if($appdet->img_md_photo_attested!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_md_photo_attested/<?php echo $appdet->img_md_photo_attested; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5> Power of Attorney/ Board Resolution/ ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ<sup> * </sup> </h5>
							<p>only in case of Authorized Representative / ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ</p>
						</div>
						<?php if($appdet->img_power_of_attorney!=""){?>							<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_power_of_attorney/<?php echo $appdet->img_power_of_attorney; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of the Office Building Exterior/ ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>	
						<?php if($appdet->img_off_buil_exterior!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of the Office Building Interior/ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_off_buil_interior!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_interior/<?php echo $appdet->img_off_buil_interior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view" hidden>
						<div class="apply-agent-file-view">
							<h5>Photograph of at least 1 Tourist Vehicle Exterior/ಕನಿಷ್ಠ 1 ಪ್ರವಾಸಿ ವಾಹನಗಳ ಫೋಟೋಗ್ರಫಿ<sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_vehicle_exterior!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_vehicle_exterior/<?php echo $appdet->img_vehicle_exterior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view" hidden>
						<div class="apply-agent-file-view">
							<h5>Photograph of at least 1 Tourist Vehicle Interior/ಕನಿಷ್ಠ 1 ಪ್ರವಾಸಿ ವಾಹನ ಒಳಾಂಗಣದ ಫೋಟೋಗ್ರಫಿ<sup>*</sup></h5>							
						</div>	
						<?php if($appdet->img_vehicle_interior!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_vehicle_interior/<?php echo $appdet->img_vehicle_interior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view" >
						<div class="apply-agent-file-view">
							<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ<sup>*</sup>
							</h5>						
						</div>	
						<?php if($appdet->img_board_entity!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_board_entity/<?php echo $appdet->img_board_entity; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Declaration stating that the TTO on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website/ "ಟಿಟಿಒಗಳು ಮಾಸಿಕ ಆಧಾರದ ಮೇಲೆ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬುದರ ಕುರಿತು ಘೋಷಣೆ". <sup> * </sup></h5>							
						</div>	
						<?php if($appdet->img_tourist_arrival_details!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_arrival_details/<?php echo $appdet->img_tourist_arrival_details; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ.<sup> * </sup> </h5>							
						</div>
						<?php if($appdet->img_pledge_commitment!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pledge_commitment/<?php echo $appdet->img_pledge_commitment; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
				<?php } ?>
				<?php if($appdet->product_id==3){?>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration/Incorporation Certificate / ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>
							<p>Documentary proof to be uploaded in compliance with the any one of the below act/ ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or/ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ
								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / "ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</p>
						</div>	
						<?php if($appdet->img_registration_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_registration_certificate/<?php echo $appdet->img_registration_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>	
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration certificate under Karnataka shops and Establishment act /ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></h5>			
						</div>
						<?php if($appdet->img_certificate_shops!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_certificate_shops/<?php echo $appdet->img_certificate_shops; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Address Proof / ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></h5>
							<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt/ ಯಾವುದೇ ಯುಟಿಲಿಟಿ ಬಿಲ್ ಅಂದರೆ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಗ್ಯಾಸ್/ನೀರಿನ ಬಿಲ್ ಅಥವಾ ಪುರಸಭೆ ತೆರಿಗೆ ರಶೀದಿ. ಈ ರಶೀದಿಗಳು ಅರ್ಜಿಯ ದಿನಾಂಕದಿಂದ  ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು.</p>
						</div>	
						<?php if($appdet->img_bank_reference!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bank_reference/<?php echo $appdet->img_bank_reference; ?>" target="_blank">View</a>
						</div>
						<?php }?>	
					</div>
				<!-- 	<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate from Chartered Accountant/ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಅವರಿಂದ ಪಡೆದ ಪ್ರಮಾಣ ಪತ್ರ</h5>
							<p>Documentary proof of turn over in Indian or foreign exchange from caravan tourism related activities operations during the previous financial year/ " ಕಾರವಾನ್ ಪ್ರವಾಸೋದ್ಯಮ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳಿಂದ ಹಿಂದಿನ ಹಣಕಾಸು ವರ್ಷದಲ್ಲಿ ಗಳಿಸಲಾದ ಭಾರತೀಯ ಅಥವಾ ವಿದೇಶಿ ವಿನಿಮಯ ಟರ್ನ್ ಒವರ್ ಕುರಿತು ದಸ್ತಾವೇಜು" <br>• Certificate of Chartered Accountant on original letter head/ ಮೂಲ ಲೆಟರ್ ಹೆಡ್ ನಲ್ಲಿ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ರಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <br>• Profit &amp; Loss statement / ಲಾಭ ಮತ್ತು ನಷ್ಟದ ಸ್ಟೇಟಮೆಂಟ್</p>
						</div>	
						<?php if($appdet->img_ca_certificate!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div> -->
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<!-- <h5>List of Directors/Partners/ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪಟ್ಟಿ  <sup> * </sup></h5> -->
							<h5>List of Directors/Partners or name of the Proprietor/ ನಿರ್ದೇಶಕರ ಪಟ್ಟಿ / ಪಾಲುದಾರರು / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_list_patners/<?php echo $appdet->img_list_patners; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copies of State Permit valid for Karnataka / All-India Permit for tourism activities or tourism related activities issued by the concerned Transport Department and R.C. of Caravan/ ಸಂಬಂಧಿತ ಸಾರಿಗೆ ಇಲಾಖೆಗಳಿಂದ ಮತ್ತು ಕಾರವಾನ್ ನ ಆರ್.ಸಿ. ಯಿಂದ ನೀಡಲಾದ ರಾಜ್ಯ ರಹದಾರಿ/ಅಖಿಲ ಭಾರತ ರಹದಾರಿ (ಪ್ರವಾಸೋದ್ಯಮ ಚಟುವಟಿಕೆಗಳು ಅಥವಾ ಪ್ರವಾಸೋದ್ಯಮ ಸಂಬಂಧಿತ ಚಟುವಟಿಕೆಗಳಿಗೆ) </h5>
						</div>		
						<?php if($appdet->img_caravan_rc!=""){?>	 							
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_caravan_rc/<?php echo $appdet->img_caravan_rc; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Details of Office Premises/ ಕಚೇರಿ ಸ್ಥಳದ ವಿವರಗಳು <sup> * </sup></h5>
							<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties/ ಒಡೆತನದ ಆಸ್ತಿಗಳ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ/ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ</p>
						</div>		
						<?php if($appdet->img_off_premises!=""){?>						
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_premises/<?php echo $appdet->img_off_premises; ?>" target="_blank">View</a>
						</div>
					<?php }?> 
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Attested photograph of Proprietor / Partners /Authorized Representative of the Entity / ಮಾಲೀಕ / ಪಾಲುದಾರರು / ಘಟಕದ  ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ  ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
						</div>
						<?php if($appdet->img_md_photo_attested!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_md_photo_attested/<?php echo $appdet->img_md_photo_attested; ?>" target="_blank">View</a>
						</div>
							<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Power of Attorney/ Board Resolution/ ಪವರ್ ಆಫ್ ಅಟಾರ್ನಿ/ ಮಂಡಳಿ ನಿರ್ಣಯ<sup> * </sup> </h5>
							<p>only in case of Authorized Representative/(ಅಧಿಕೃತ ಪ್ರತಿನಿಧಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಮಾತ್ರ)</p>
						</div>
						<?php if($appdet->img_power_of_attorney!=""){?>										
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_power_of_attorney/<?php echo $appdet->img_power_of_attorney; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of the Office Building Exterior / ಕಚೇರಿಯ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>	
						<?php if($appdet->img_off_buil_exterior!=""){?>		
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of the Office Building Interior/ ಕಚೇರಿಯ  ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_off_buil_interior!=""){?>										
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_interior/<?php echo $appdet->img_off_buil_interior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of at least 1 Caravan Interior/ ಕಾರವಾನ್ ಒಳಾಂಗಣದ ಕನಿಷ್ಠ 1 ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>	
						<?php if($appdet->img_caravan_interior!=""){?>		
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_caravan_interior/<?php echo $appdet->img_caravan_interior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of at least 1 Caravan Exterior / ಕಾರವಾನ್ ಹೊರಾಂಗಣದ ಕನಿಷ್ಠ 1 ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>							
						</div>	
						<?php if($appdet->img_caravan_exterior!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_caravan_exterior/<?php echo $appdet->img_caravan_exterior; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view" >
						<div class="apply-agent-file-view">
							<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ) ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup>*</sup></h5>							
						</div>	
						<?php if($appdet->img_board_entity!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_board_entity/<?php echo $appdet->img_board_entity; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of GST Registration Certificate/ ಜಿ ಎಸ್ ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ</h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_gst_regis/<?php echo $appdet->img_gst_regis; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of PAN/ ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ </h5>							
						</div>
						<?php if($appdet->img_pan_copy!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pan_copy/<?php echo $appdet->img_pan_copy; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate for the Caravan(s) to show its compliance to the Automotive Industry Standards (AIS) -124- Procedure for Type Approval/"ಆಟೋಮೋಟಿವ್ ಇಂಡಸ್ಟ್ರಿ ಸ್ಟ್ಯಾಂಡರ್ಡ್ಸ್ (ಎಐಎಸ್) -124- ಟೈಪ್ ಅನುಮೋದನೆಗಾಗಿ ಅದರ ಅನುಸರಣೆಯನ್ನು ತೋರಿಸಲು ಕಾರವಾನ್ (ಗಳಿಗೆ) ಪ್ರಮಾಣಪತ್ರ"<sup> *</sup></h5>		
						</div>
						<?php if($appdet->img_caravan_ais_certificate!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_caravan_ais_certificate/<?php echo $appdet->img_caravan_ais_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate of Motor Caravans for compliance to Central Motor Vehicles Rules, issued by Ministry of Road Transport and Highways/ Karnataka Motor Vehicle Rules ( as applicable)/ "ರಸ್ತೆ ಸಾರಿಗೆ ಮತ್ತು ಹೆದ್ದಾರಿಗಳ ಸಚಿವಾಲಯ / ಕರ್ನಾಟಕ ಮೋಟಾರು ವಾಹನ ನಿಯಮಗಳು ಅಡಿಯಲ್ಲಿ ನೀಡಲಾದ ಕೇಂದ್ರ ಮೋಟಾರು ವಾಹನ ನಿಯಮಗಳ ಅನುಸರಣೆಗಾಗಿ ಮೋಟಾರ್ ಕಾರವಾನ್ ಗಳ  ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವಂತೆ)" <sup> *</sup></h5>
						</div>			
						<?php if($appdet->img_caravan_ministry_certificate!=""){?>							
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_caravan_ministry_certificate/<?php echo $appdet->img_caravan_ministry_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Declaration stating that the Caravan Operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website/ "ಕಾರವಾನ್ ಆಪರೇಟರ್ ಪ್ರತಿ ತಿಂಗಳು ತಪ್ಪದೇ  ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿಮತ್ತು ದೇಶೀಯ) ಕಡ್ಡಾಯವಾಗಿ ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬುದರ ಕುರಿತು ಘೋಷಣೆ." <sup> *</sup></h5>
						</div>
						<?php if($appdet->img_tourist_arrival_details!=""){?>										
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_arrival_details/<?php echo $appdet->img_tourist_arrival_details; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Approval letter for the Caravan(s) from any of the below-mentioned authorities/ ಕೆಳಗಿನ ಯಾವುದೇ ಸಂಸ್ಥೆಗಳಿಂದ ಪಡೆದ ಕಾರವಾನ್ ಗಳ ಅನುಮೋದನೆ ಪತ್ರ </h5>
							<ul>
								<li>Automotive Research Association of India (ARAI)/ Automotive Research Association of India (ARAI)</li>
								<li>International Centre for Automotive Technology (ICAT)/ International Centre for Automotive Technology (ICAT)</li>
								<li>Central Institute of Road Transport (CIRT)/ Central Institute of Road Transport (CIRT)</li>
							</ul>							
						</div>	
						<?php if($appdet->img_caravan_approval_letter!=""){?>
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_caravan_approval_letter/<?php echo $appdet->img_caravan_approval_letter; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/"ಗೌರವಾನ್ವಿತ  ಮತ್ತು ಸುರಕ್ಷಿತ  ಪ್ರವಾಸೋದ್ಯಮ  ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ. <sup> * </sup> </h5>							
						</div>
						<?php if($appdet->img_pledge_commitment!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pledge_commitment/<?php echo $appdet->img_pledge_commitment; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					
				<?php } ?>
				</div>
				<div class="agent-details-view">
					<!-- <div class="other-detials-view">
						<div class="other-det-view">
							<p>Details of activity undertaken by the<br> firm besides acting as a Travel Agent<sup>*</sup></p>
						</div>										
						<div class="other-dept-text-view">
							<p><?php echo $appdet->off_activity; ?></p>
						</div>
					</div> -->
					
					<?php 
					if($appdet->product_id==2)
					{ ?>						
						<div class="agent-form-view">
							<table id='dataTableExample_vehicle' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
							<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th> 
								<th>Vehicle Type /ವಾಹನದ ಪ್ರಕಾರ</th>
								<th>Permit Type / ನೀಡಲಾದ ಅನುಮತಿ ಪ್ರಕಾರ</th>
								<th>Tourist Vehicle Registration in the Name of /  ಈ ಹೆಸರಿನಲ್ಲಿ ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಮಾಡಲಾಗಿದೆ </th>
								<th>Tourist Vehicle Registration Number / ಪ್ರವಾಸಿ ವಾಹನ ನೋಂದಣಿ ಸಂಖ್ಯೆ</th>
								<th>Tourist Vehicle Permit Number / ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಿಗೆ ಸಂಖ್ಯೆ</th>
								<th>Tourist Vehicle Permit Start date / ಪ್ರವಾಸಿ ವಾಹನ ಪರವಾನಿಗೆ ಆರಂಭದ ದಿನಾಂಕ</th>
								<th>Tourist Vehicle Permit End date / ಪ್ರವಾಸಿ ವಾಹನ ಅನುಮತಿಯ ಅಂತಿಮ ದಿನಾಂಕ</th>
								</tr> 
							</thead>
							</table>
						</div>
					<?php } if($appdet->product_id==3){?>
						<div class="agent-form-view">
							<table id='dataTableExample_vehicle' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
							<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th> 
								<th>Caravan Type / ಕಾರವಾನ್ ಪ್ರಕಾರ </th>
								<th>Permit Type / ನೀಡಲಾದ ಅನುಮತಿ ಪ್ರಕಾರ</th>
								<th>Caravan Registration in the Name / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ಕಾರವಾನ್ ನೋಂದಣಿ ಮಾಡಲಾಗಿದೆ</th>
								<th>Caravan Vehicle Registration Number / ಕಾರವಾನ್ ವಾಹನದ ನೋಂದಣಿ ಸಂಖ್ಯೆ</th>
								<th>Caravan Vehicle Permit Number/ ಕಾರವಾನ್ ವಾಹನದ ಪರವಾನಿಗೆ ಸಂಖ್ಯೆ</th>
								<th>Caravan Vehicle Permit Start date / ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಿಗೆ ಆರಂಭದ ದಿನಾಂಕ</th>
								<th>Caravan Vehicle Permit End date / ಕಾರವಾನ್ ವಾಹನ ಪರವಾನಿಗೆ ಅಂತಿಮ ದಿನಾಂಕ</th>
								</tr> 
							</thead>
							</table>
						</div>
					<?php }?>
					<div class="other-detials-view">
						<div class="other-det-view">
							<p>Memberships of International tour<br> associations, if any/ಅಂತಾರಾಷ್ಟ್ರೀಯ ಪ್ರವಾಸ ಸಂಘಗಳ ಸದಸ್ಯತ್ವಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></p>							 
						</div>										
						<div class="other-dept-text-view">
							<p><?php echo $appdet->off_international_membership; ?> <?php if($appdet->off_international_membership=="Yes"){echo " - ".$appdet->off_international_membership_details;}else{}?></p>
						</div>
					</div>
					<div class="other-detials-view">
						<div class="other-det-view">
							<p>Steps taken to promote domestic<br> tourists' activity /ದೇಶೀಯ ಪ್ರವಾಸಿಗರ ಚಟುವಟಿಕೆಯನ್ನು ಉತ್ತೇಜಿಸಲು ತೆಗೆದುಕೊಂಡ ಕ್ರಮಗಳು<sup>*</sup></p>
						</div>										
						<div class="other-dept-text-view">
							<p><?php echo $appdet->off_promote_domestic_activity; ?></p>
						</div>
					</div>
					<div class="other-detials-view">
						<div class="other-det-view">
							<p>Special programmes arranged for<br> Foreign Tourists, if any/ ವಿದೇಶಿ ಪ್ರವಾಸಿಗರಿಗಾಗಿ ಏರ್ಪಡಿಸಲಾದ ವಿಶೇಷ ಕಾರ್ಯಕ್ರಮಗಳು, ಯಾವುದಾದರೂ ಇದ್ದರೆ <sup>*</sup></p>
						</div>										
						<div class="other-dept-text-view">
							<p><?php echo $appdet->off_prog_arranged_foreign_tourist; ?>  <?php if($appdet->off_prog_arranged_foreign_tourist=="Yes"){echo " - ".$appdet->off_prog_arranged_foreign_tourist_details;}else{}?> </p>
						</div>
					</div>
				</div>			
			</div>			
		</div>
	</div>
<?php } ?>
<style>
.agent-form-file-view1 {float: left;position: relative;width: 100%;padding: 30px 4%;text-align: right;}
.agent-form-file-view1 a {background: #178597;color: #fff;padding: 10px 20px;border-radius: 3px;}
.admin-dashboard .agent-application-view .application-view-options .application-info-view .agent-form-view .form_input_view a{background: #ca0027;color: #fff;padding: 5px 20px;border-radius: 5px;}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php include 'include/footer.php';?>
<script type="text/javascript">
$(document).ready( function() 
{
  		//alert("test");
		//alert("loadvehicle data");
		var application_id=<?php echo($appdet->id)?>;
		var BASE_URL = "<?php echo base_url();?>";
		var path = BASE_URL+'applications/vehicledata';		
		var table = $('#dataTableExample_vehicle').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path,
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'vehicle_type' },
				        { data: 'permit_type'},
				        { data: 'regitration_name' },
				        { data: 'registeration_no' },
				        { data: 'tourist_permit' },
				        { data: 'permitdate' }, 
				        { data: 'enddate' }
				    ]
    	});	
		var path_resend = BASE_URL+'applications/resenddate';
		var tablenew = $('#dataTableExample_resend').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path_resend,
				        //dataType: "json",
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 				   
				     	{ data: 'sno' },
				     	{ data: 'Registration/Incorporation Certificate' },
				     	{ data: 'comments' },
				     	{
                            "data": null,                          
                            render:function(data, type, row)
                            {
                            	//console.log(data.DocumentType);
                                return '<div class="form_input_file">'+
								'<div class="file-upload-wrapper" data-text="Select your file!"><input id="reg_firm" name='+data.DocumentType+' type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf"></div></div>'+
								   '<input type="hidden" class="tablecount" name="filenames[]" id="filename'+data.sno+'" value='+data.DocumentType+'>'
                            },
                            "targets": -1
                        }                        
				    ]
    	});

		// var table = $('#dataTableExample_resend').DataTable(
		// {
		// 	ajax: {
		// 	 			type: 'POST',
		// 		        url: path,
		// 		        dataSrc: '',
		// 		        data:{
		// 		             appId:application_id
		// 		        }
		// 		    },	

		// 		    searching:false,
		// 		    paging:false,
		// 		    info: false,
		// 		    columns: [ 
		// 		     	{ data: 'slno' },				        
		// 		        {
  //                           "data": null,                          
  //                           render:function(data, type, row)
  //                           {
  //                             if(data.DocumentType)
  //                             {
  //                               return '<input type="checkbox" id="logout_late_'+data.emp_id+'" checked onclick="angular.element(this).scope().activelatelogout('+data.emp_id+')">'  
  //                             }                            
  //                           },
  //                           "targets": -1
  //                       },
		// 		        { data: 'reg_certificate' },				        
		// 		        { data: 'reg_certificate_details' }				        
		// 		    ]
  //   	});
});	
function saveupload()
{
	$("#refileupload").submit(function(e){
        e.preventDefault();
    });
    var path 		= "<?php echo base_url();?>applications/reupload";	
    var form = $('#refileupload')[0];
    var formData = new FormData(form);
    $.ajax({
			type: 'POST',
			url: path,
			 //data: form.serialize(),
			processData: false,
			contentType: false,
			data: formData,
			success: function(data) 
			{
				// console.log(data);
				if(data=="Application Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
				{
					alert('Applicant details not saved. Please try after some time.');
				}
				else
				{
					alert("Files are upated successfully") ;
				}
			}
		});

}
</script>

