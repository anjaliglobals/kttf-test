<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<?php if($this->session->flashdata('msg')):?>
		<div class="alert">
		<span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
		</div>
	<?php endif; ?>
<!--NEWW-->
<?php 

if(empty($appnot_det)){

}
else{

	?>

<div class="container-fluid" style="overflow-x:auto;overflow-y:hidden;" >

<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
<thead >
<tr class="success" style="background-color:#495057;color:#fff">
<th style="width:10%;">Sl_No</th> 
<th>Messages</th>
<th>Date</th>
<th>Stage</th>
<th >Updated From</th>
</tr> 
</thead>
<?php 
 	$counter = 1;
    foreach($appnot_det as $noti_det){ 
?>      
<tr>
<td><?php echo $counter++;?></td>  
<td style="text-align:;"><?php echo $noti_det->message; ?></td>
<td style="text-align:;"><?php echo date("d/m/Y H:i:s",strtotime($noti_det->crtdate)); ?></td>
<td style="text-align:;"><?php echo $this->db->get_where('m_stage', array('order_stage' => $noti_det->app_stage))->row()->stage_description; ?></td>
<td style="text-align:;"><?php echo $noti_det->crtname; ?></td>
</tr>
<?php 
}
?>
</table>
</div>
<style>
th {
    color: #fff!important;
}
</style>

<?php
}
?>
<!--end NEWW-->

  <!-- <?php print_r($appdetails);?>   -->
<!--		   print_r($appdet->product_id);-->
  <?php foreach($appdetails as $appdet){  ?>

	<div class="agent-form-file-view1">
		<?php if($appdet->licence_issued_date != NULL)
		{ ?>
		<a href="<?php echo base_url();?>applications/certificate/<?php echo $appdet->application_id;?>" target="_blank">View Certificate</a>
		<?php } ?>
	</div>

	<div class="agent-form-file-view1">
		<?php if($appdet->is_confirmed == 1)
		{ ?>
		<a href="<?php echo base_url();?>applications/pay_acg/<?php echo $appdet->application_id;?>" target="_blank">View Acknowledgement</a>
		<?php } ?>
	</div>
	

<?php if($appdet->is_confirmed==0 && $appdet->status_code==0 && $appdet->isdraft==0){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/application_makepay/<?php echo $appdet->id; ?>">Click Here to Make Payment</a>
</div> 
<?php } ?>

<?php if($appdet->is_confirmed==1 && $appdet->app_status==2 ){ ?>
<div class="agent-form-file-view1">
<!--span style="color:#ca0127;font-weight:700;">If, Any document  or Any Changes ,Please Click Here &nbsp;&nbsp;&nbsp;&nbsp;</span-->
	<!-- <a href="<?php echo base_url();?>applications/application_edit/<?php echo $appdet->id; ?>">EDIT</a> -->
	<!-- <a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a> -->
</div> 
  <?php } ?>

<?php if($appdet->isdraft==1){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a>
</div> 
 <?php } ?>
	<div class="admin-dashboard">				
		<div class="agent-application-view">
			<div class="application-view-options">
				<div class="application-info-view">
				<?php if($appdet->licence_no != ''): ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Number / ಪರವಾನಗಿ ಸಂಖ್ಯೆ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->licence_no; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Issued Date / ಪರವಾನಗಿ ನೀಡಿದ ದಿನಾಂಕ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->licence_issued_date)); ?></p>
						</div>										
					</div>
				<?php endif;?>
				<?php if($appdet->iteration > 0 and $appdet->resent_verifi == 0 ): ?>
				<div class="form-heading-view">
					<h4>Resend for clarification</h4>
				</div>
				<form method="post" role="form" enctype="multipart/form-data"  id="refileupload">
					<input type="hidden" name="appid" value=<?php echo $appdet->id?>>
				<div class="agent-form-view" class="col-md-12">
					<table id='dataTableExample_resend' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
							<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th>
								<th>Document Name</th>
								<th>Comments</th>
								<th>Resubmit</th>								
							</tr> 
						</thead>
					</table>
					<div style="align-items: center">
						<button class="btn btn-success" onclick="saveupload()">Save</button>
					</div>
				</div>
				</form>
				<?php endif;?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Applicant ID / ಅರ್ಜಿದಾರರ ಐಡಿ <sup> *</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->application_id; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Application Date / ಅರ್ಜಿ ದಿನಾಂಕ<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y H:i:s",strtotime($appdet->confirmed_date)); ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name Of The Entity/ಘಟಕದ ಪೂರ್ಣ ಹೆಸರು<sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)/(ಸಂಸ್ಥೆ / ಕಂಪನಿ / ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳು ಸಹಭಾಗಿತ್ವ / ಮಾಲೀಕತ್ವ)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Entity Type/ಘಟಕದ ಪ್ರಕಾರs<sup>*</sup></p>	
						</div>
						<div class="form_input_view">
							<p><?php if($appdet->org_type_id ==1){echo "Proprietary Concern";}
								else if($appdet->org_type_id ==2){echo "Partnership";}
								else if($appdet->org_type_id ==3){echo "Company";}
								else if($appdet->org_type_id ==4){echo "Private Limited Company";}
							  else if($appdet->org_type_id ==5){echo "Public Limited Company";}
								else if($appdet->org_type_id ==6){echo "Limited Liabilities Partnership";}
						?></p>
						</div>										
					</div>						
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of Registration/Incorporation of the Entity <br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Shops and Establishment Act)/ನೋಂದಣಿಯ ದಿನಾಂಕ / ಘಟಕದ ಸಂಯೋಜನೆ (ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಥವಾ ಭಾರತೀಯ ಸಹಭಾಗಿತ್ವ ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆ ಸಹಭಾಗಿತ್ವ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಅಂಗಡಿಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯ್ದೆಯ ಪ್ರಕಾರ) <sup>*</sup></p>				
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->org_commencement_date));  ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name of the properator / Directors / Partners/ಮಾಲೀಕ / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪೂರ್ಣ ಹೆಸರು <sup> * </sup></p>				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->proprietor_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>GST Identification Number/ GST ಗುರುತಿನ ಸಂಖ್ಯೆ <sup>*</sup>
								<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup> <?php } ?> -->
							</p>						
						</div>
						<div class="form_input_view">
							
							<p><?php echo $appdet->gst_number;?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>PAN Number / PAN ಸಂಖ್ಯೆ<?php if($appdet->product_id==1){?>
							<!-- 	<sup>*</sup> -->
							<?php }?></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->pan_number; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು ಲಿಂಕ್
								<!-- <?php if($appdet->product_id==1){?><sup>*</sup><?php }?>--></p>		 				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->website_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Official email id of the Entity / ಘಟಕದ ಅಧಿಕೃತ ಇಮೇಲ್ ID
							<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup><?php }?> --></p>						
						</div> 
						<div class="form_input_view">
							<p><?php echo $appdet->official_email; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Whether the member of Karnataka Tourism Society (KTS)?<sup>*</sup></p>	
							<!-- <p>(if yes, please upload the valid KTS license)</p> -->
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_recognised_trade; ?></p>
						</div>										
					</div>
					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Whether a Member of any recognized Hotel & Restaurant Association?<sup>*</sup></p>								
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_recognised_trade; ?></p>
						</div>										
					</div> -->
				<div class="form-heading-view">
						<h4>Registered Office Address</h4>
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 1  <sup> * </sup></p>				
									 
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add1; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 2  <!--sup> * </sup--></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add2; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District/ಜಿಲ್ಲೆ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $appdet->org_loc_district_id))->row()->name; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk/ತಾಲ್ಲೂಕು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $appdet->org_loc_taluk_id))->row()->name; ?></p>
						</div>										
					</div>				
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City / Town / Village/ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_city; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view"> 
							<p>Nearest Landmark/ಹತ್ತಿರದ ಗುರುತು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_landmark ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode/ಪಿನ್ ಕೋಡ್	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number/ಮೊಬೈಲ್ ಸಂಖ್ಯೆ	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_mobile; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Telephone Number/ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_telephone; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total build area(Sq.ft)/ಒಟ್ಟು ನಿರ್ಮಾಣ ಪ್ರದೇಶ (ಚದರ ಅಡಿ)<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_total_build_sqft; ?></p>
						</div>										
					</div>
					<div class="form-heading-view">
						<h4>Amusement Park Details</h4>
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Name of the Amusement Park<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->hotel_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of Commencement of Amusement Park<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->amusement_commencement_date; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of registration under Indian Association of Amusement Parks and Industries (IAAPI)<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_registration_date; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total Visitor Capacity of the Amusement Park<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->visitor_capacity; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total Built up Area of the Hotel/Resort (in Sq. Ft)</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->total_hotel_build_area; ?></p>
						</div>										
					</div>
					<!-- <?php print_r($hotelfacility)?> -->
					<div class="agent-form-view">
						<div class="form_label_view">
							<h5>Facilities Available in the Hotel & Resort<sup>*</sup></h5>
						</div>
						<div class="agent-form-view">
								<table id='dataTableExample_acc' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
								<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th> 
								<th>Facilities</th>						
								</tr> 
								</thead>
								<?php 
									//print_r($addressdet);
								 	$counter = 1;
								    foreach($hotelfacility as $hotel_facility){ 
								?>      
								<tr>
								<td><?php echo $counter++;?></td>  
								<td style="text-align:;"><?php echo $hotel_facility->facility_type; ?></td>
								</tr>
								<?php 
								}
								?>
								</table>
						</div>									
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Name of the Owner/ Manager of the Amusement Park<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->owner_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->owner_mobile; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Email Id of the Owner/ Manager of the Amusement Park <sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->owner_email; ?></p>
						</div>										
					</div>
					<!-- <?php print_r($addressdet)?> -->
					<div class="form-heading-view">
						<h4>Registered Address of Amusement Park</h4>
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 1  <sup> * </sup></p>				
									 
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_addr1; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 2  <!--sup> * </sup--></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_addr2;  ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District/ಜಿಲ್ಲೆ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $addressdet[0]->other_off_district_id))->row()->name; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk/ತಾಲ್ಲೂಕು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $addressdet[0]->other_off_taluk))->row()->name; ?></p>
						</div>										
					</div>				
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City / Town / Village/ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_city; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view"> 
							<p>Nearest Landmark/ಹತ್ತಿರದ ಗುರುತು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->org_landmark ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode/ಪಿನ್ ಕೋಡ್	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number/ಮೊಬೈಲ್ ಸಂಖ್ಯೆ	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_contact; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Official Email Id of the Hotel/ Resort</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_email; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Telephone Number/ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_telephone; ?></p>
						</div>										
					</div>
				</div>
				<div class="agent-application-document-view">
					<div class="form-heading-view">
						<h4>Required Documents / ಅಗತ್ಯವಿರುವ ದಾಖಲೆಗಳು</h4>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration/Incorporation Certificate/ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ<sup>*</sup></h5>
							<p>Documentary proof to be uploaded in compliance with the any one of the below act / ಕೆಳಗಿನ ಯಾವುದೇ ಕಾಯಿದೆಯ ಅನುಸಾರವಾಗಿ ಅಪ್‌ಲೋಡ್ ಮಾಡಲು ದಾಖಲೆಗಳ ಸಾಕ್ಷಿ:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or / ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆ ಸಹಭಾಗಿತ್ವ ಕಾಯ್ದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಒಂದು ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆ ಸಹಭಾಗಿತ್ವ ಅಥವಾ 
								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / ಏಕಮಾತ್ರ ಮಾಲೀಕತ್ವ ಸಂದರ್ಭದಲ್ಲಿ, ಅಂಗಡಿಗಳು ಮತ್ತು ಸ್ಥಾಪನಾ ಕಾಯ್ದೆ ಅಥವಾ GST ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಅಡಿಯಲ್ಲಿ ನೋಂದಣಿ ಒದಗಿಸಬೇಕಾಗಿದೆ</p>
						</div>	
						<?php if($appdet->img_registration_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_registration_certificate/<?php echo $appdet->img_registration_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>	
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Commencement Certificate of the Amusement Park <sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_commercial_certificate!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_commercial_certificate/<?php echo $appdet->img_commercial_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration under Indian Association of Amusement Parks and Industries (IAAPI)  <sup>*</sup></h5>	
						</div>
						<?php if($appdet->img_iaapi!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_iaapi/<?php echo $appdet->img_iaapi; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration certificate under Karnataka shops and Establishment act/ಕರ್ನಾಟಕ ಅಂಗಡಿಗಳ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯ್ದೆ <sup>*</sup></h5>	
							<p>(for Amusement Park)</p>						
						</div>
						<?php if($appdet->img_certificate_shops!=""){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_certificate_shops/<?php echo $appdet->img_certificate_shops; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate of Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಪ್ರಮಾಣಪತ್ರ
								<sup>*</sup></h5>
							<p>Documentary proof of turn over in Indian or foreign exchange from Hotel/Resort related activities operations during the previous financial year 
							<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಅಕ್ಷರದ ತಲೆಯ ಮೇಲೆ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್‌ನ ಪ್ರಮಾಣಪತ್ರ<br>• Profit &amp; Loss statement/ ಲಾಭ &amp; ನಷ್ಟ ಹೇಳಿಕೆs.</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Address Proof of the Amusement Park <sup>*</sup></h5>
							<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/water bill) / property or municipality tax receipt).</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bank_reference/<?php echo $appdet->img_bank_reference; ?>" target="_blank">View</a>
						</div>
					</div>
					 
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Details of Amusement Park Premises <sup>*</sup></h5>							
							<p>Rent agreement/Lease Agreement in case of Rented property. Sale Deed & Property Tax in the case of owned properties</p>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_premises/<?php echo $appdet->img_off_premises; ?>" target="_blank">View</a>
						</div>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photographs of Amusement Park Interior <sup>*</sup></h5>	
							<p>At least 10 pictures must be uploaded capturing all the mandatory facilities/ features to be including the name of the park</p>						
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_interior/<?php echo $appdet->img_off_buil_interior; ?>" target="_blank">View</a>
						</div>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photographs of Amusement Park Exterior<sup>*</sup></h5>
							<p>At least 10 pictures must be uploaded capturing all the mandatory facilities/ features to be including the name of the park</p>							
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
							<div class="apply-agent-file-view">
								<h5>Sanctioned Building Plans/Occupancy Certificate <sup> * </sup></h5>
							</div>
							<div class="agent-form-file-view">
								<a href="<?php echo base_url();?>upload/img_occupancy_certificate/<?php echo $appdet->img_occupancy_certificate; ?>" target="_blank">View</a>
							</div>										
					</div>
					<div class="allply-form-view">
							<div class="apply-agent-file-view">
								<h5>Copy of Trade License / ವ್ಯಾಪಾರ ಪರವಾನಗಿಯ ಪ್ರತಿ <sup> * </sup></h5>
							</div>
							<div class="agent-form-file-view">
								<a href="<?php echo base_url();?>upload/img_trade_lic/<?php echo $appdet->img_trade_lic; ?>" target="_blank">View</a>
							</div>										
					</div>

					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of GST Registration Certificate/GST ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರದ ಪ್ರತಿ< <sup> * </sup></h5>
						</div>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_gst_regis/<?php echo $appdet->img_gst_regis; ?>" target="_blank">View</a>
						</div>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of PAN/PAN ನ ಪ್ರತಿ</h5>							
						</div>
						<?php if($appdet->img_pan_copy!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pan_copy/<?php echo $appdet->img_pan_copy; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate from FSSAI <sup> * </sup> </h5>							
						</div>
						<?php if($appdet->img_fssai_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_fssai_certificate/<?php echo $appdet->img_fssai_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>No-Objection Certificate from Fire department</h5>							
						</div>
						<?php if($appdet->img_noobj_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_noobj_certificate/<?php echo $appdet->img_noobj_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate/ license from Municipality / corporation / panchayat to show that your establishment is registered as an Amusement Park <sup> * </sup></h5>							
						</div>
						<?php if($appdet->img_license!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_license/<?php echo $appdet->img_license; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Clearance Certificate from Health Officer /Sanitary Inspector issued to your establishment from sanitary/ hygienic point of view<sup> * </sup></h5>							
						</div>
						<?php if($appdet->img_clearence_cer!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_clearence_cer/<?php echo $appdet->img_clearence_cer; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ "ಸುರಕ್ಷಿತ ಮತ್ತು ಗೌರವಾನ್ವಿತ ಪ್ರವಾಸೋದ್ಯಮ" ದ ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞೆಯ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ . <sup> *</sup></h5>							
						</div>	
						<?php if($appdet->img_pledge_commitment!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pledge_commitment/<?php echo $appdet->img_pledge_commitment; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Declaration stating that the amusement park owner/manager on a monthly basis shall mandatorily share/upload the Tourist Arrival details (Foreign& Domestic) on the Karnataka Tourism Website <sup> *</sup></h5>							
						</div>		
						<?php if($appdet->img_tourist_arrival_details!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_arrival_details/<?php echo $appdet->img_tourist_arrival_details; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Declaration from the Authorized Representative of the Entity / Directors / Partners of the Entity stating that “The Amusement Park is in compliance with the "IS 15475: Code of Recommended Practice for Amusement Rides Safety" and "IS 15492: Code of Recommended Practice for Safety in Water Parks" as set out by the Bureau of Indian Standards, as is applicable for the amenities available at the Amusement Park”</h5>
						</div>	
						<?php if($appdet->img_declaration_amusement!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_declaration_amusement/<?php echo $appdet->img_declaration_amusement; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>				
			  </div>			
			</div>
		</div>
	</div>
<?php } ?>
<style>
.agent-form-file-view1 {float: left;position: relative;width: 100%;padding: 30px 4%;text-align: right;}
.agent-form-file-view1 a {background: #178597;color: #fff;padding: 10px 20px;border-radius: 3px;}
.admin-dashboard .agent-application-view .application-view-options .application-info-view .agent-form-view .form_input_view a{background: #ca0027;color: #fff;padding: 5px 20px;border-radius: 5px;}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php include 'include/footer.php';?>
<script type="text/javascript">
$(document).ready( function() 
{
  		//alert("test");
		//alert("loadvehicle data");
		var application_id=<?php echo($appdet->id)?>;
		var BASE_URL = "<?php echo base_url();?>";
		var path = BASE_URL+'applications/vehicledata';		
		var table = $('#dataTableExample_vehicle').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path,
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'vehicle_type' },
				        { data: 'permit_type'},
				        { data: 'regitration_name' },
				        { data: 'registeration_no' },
				        { data: 'tourist_permit' },
				        { data: 'permitdate' }, 
				        { data: 'enddate' }
				    ]
    	});	
		var path_resend = BASE_URL+'applications/resenddate';
		var tablenew = $('#dataTableExample_resend').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path_resend,
				        //dataType: "json",
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 				   
				     	{ data: 'sno' },
				     	{ data: 'Registration/Incorporation Certificate' },
				     	{ data: 'comments' },
				     	{
                            "data": null,                          
                            render:function(data, type, row)
                            {
                            	//console.log(data.DocumentType);
                                return '<div class="form_input_file">'+
								'<div class="file-upload-wrapper" data-text="Select your file!"><input id="reg_firm" name='+data.DocumentType+' type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf"></div></div>'+
								   '<input type="hidden" class="tablecount" name="filenames[]" id="filename'+data.sno+'" value='+data.DocumentType+'>'
                            },
                            "targets": -1
                        }                        
				    ]
    	});

		// var table = $('#dataTableExample_resend').DataTable(
		// {
		// 	ajax: {
		// 	 			type: 'POST',
		// 		        url: path,
		// 		        dataSrc: '',
		// 		        data:{
		// 		             appId:application_id
		// 		        }
		// 		    },	

		// 		    searching:false,
		// 		    paging:false,
		// 		    info: false,
		// 		    columns: [ 
		// 		     	{ data: 'slno' },				        
		// 		        {
  //                           "data": null,                          
  //                           render:function(data, type, row)
  //                           {
  //                             if(data.DocumentType)
  //                             {
  //                               return '<input type="checkbox" id="logout_late_'+data.emp_id+'" checked onclick="angular.element(this).scope().activelatelogout('+data.emp_id+')">'  
  //                             }                            
  //                           },
  //                           "targets": -1
  //                       },
		// 		        { data: 'reg_certificate' },				        
		// 		        { data: 'reg_certificate_details' }				        
		// 		    ]
  //   	});
});	
function saveupload()
{
	$("#refileupload").submit(function(e){
        e.preventDefault();
    });
    var path 		= "<?php echo base_url();?>applications/reupload";	
    var form = $('#refileupload')[0];
    var formData = new FormData(form);
    $.ajax({
			type: 'POST',
			url: path,
			 //data: form.serialize(),
			processData: false,
			contentType: false,
			data: formData,
			success: function(data) 
			{
				// console.log(data);
				if(data=="Application Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
				{
					alert('Applicant details not saved. Please try after some time.');
				}
				else
				{
					alert("Files are upated successfully") ;
				}
			}
		});

}
</script>

