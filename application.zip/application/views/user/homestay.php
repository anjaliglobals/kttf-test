<style type="text/css">
	.form-wizard .form-wizard-steps li {
    width: 33%!important;
    float: left;
    position: relative;
}

.admin-dashboard .agent-application .form-wizard .agent-off-address {
    width: 100%;
    margin: auto;
}

.new-add-button {
    background: #0e984c;
    border-color: #0e984c;
    color: #fff;
    padding: 8px 10px;
    border-radius: 5px;
    cursor: pointer;
    font-size:16px;
}

.new-remove-button  {
    color: #fff;
    background-color: #dc3545;
    border-color: #dc3545;
    padding: 8px 10px;
    border-radius: 5px;
    font-size:16px;
}
	
</style>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 -->
<form  method="post" role="form" enctype="multipart/form-data"  id="formSave123">
								<fieldset id="general-verify" class="wizard-fieldset general-verify show">
									<?php if($prod_id!=0){  ?>
										<input hidden type="text" id="proId" value="<?php echo $prod_id ?>">
									<?php }?>
									<?php if($new_pid!=0){  ?>
										<input hidden type="text" id="proId" value="<?php echo $new_pid ?>">
									<?php }?>	

						<h4><b>1) Promoter Details  / ನೋಂದಾಯಿತ ಕಚೇರಿ ವಿಳಾಸ</b></h4>	<br>			
									<input style="display:none" type="text" name="pg_orderid" id="pg_orderid" value="<?php echo $result['orderId']; ?>">

									<div class="agent-form">
										<div class="form_label">
											<p>Owner Name  / ಮಾಲೀಕರ ಹೆಸರು <sup> * </sup></p>
											<!-- <sup>*</sup> -->
										</div>
										<div class="form_input">
											<input hidden type="text" id="eproduct_id" name="product_id" >
											<input  type="text" onkeypress="return isNumbera(event,'albhabet')" id="eapplication_name" name="applicant_name" class="form-control wizard-required">


											<input style="display:none;" type="text" class="" name="insid_draft"  id="insid_draft" >
											<div class="wizard-form-error"></div><br> 
										</div>									
									</div>
 
								 	<div class="agent-form">
										<div class="form_label">
											<p>Mobile No / ಮೊಬೈಲ್ ನಂ <sup> * </sup></p>
											<!-- <sup>*</sup> -->
										</div>
										<div class="form_input">
											<input type="text" maxlength="10" name="org_loc_mobile" pattern="[6789][0-9]{9}" onkeypress="return isNumber(event)" class="form-control wizard-required" id="eloc_mob"  onpaste="return false">
											<!-- <input  type="text" id="e_mobile" name="mobile" class="form-control wizard-required"> -->
											<div class="wizard-form-error"></div><br> 
										</div>									
									</div>
 
 									<div class="agent-form">
										<div class="form_label">
											<p>Telephone  / ದೂರವಾಣಿ</p>
											<!-- <sup>*</sup> -->
										</div>
										<div class="form_input">
											<!-- <input  type="text" id="e_telephone" name="telephone" class="form-control wizard-required"> -->
											<input type="text" name="org_loc_telephone" pattern="[6789][0-9]{9}" maxlength="10" onkeypress="return isNumber(event)"  id="eloc_tele"  onpaste="return false">
											<!-- <div class="wizard-form-error"></div><br>  -->
										</div>									
									</div>
 
 									<div class="agent-form">
										<div class="form_label">
											<p>Email  / ಇಮೇಲ್ ಐಡಿ <sup> * </sup></p>
											<!-- <sup>*</sup> -->
										</div>
										<div class="form_input">
											<input type="text" id="eofficial_email" name="official_email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" class="form-control wizard-required">
											<div id="valid"></div>
										</div>									
									</div> 
 
 									<div class="agent-form">
										<div class="form_label">
											<p>Aadhaar Number / ಆಧಾರ್ ಸಂಖ್ಯೆ <sup> * </sup></p>
											<!-- <sup>*</sup> -->
										</div>
										<div class="form_input">
											<input  type="text" id="eofficial_aadhaar" name="official_aadhaar" maxlength="12" onkeypress="return isNumber(event)" class="form-control wizard-required">
											<div class="wizard-form-error"></div><br> 
										</div>									
									</div>

						<h4><b>2) Homestay Details  / ಹೋಮ್ಸ್ಟೇ ವಿವರಗಳು</b></h4>	<br>

									<div class="agent-form">
										<div class="form_label">
											<p>Name of Homestay  / ಹೋಂಸ್ಟೇ ಹೆಸರು <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input onkeypress="return isNumbera(event,'albhabet')" type="text" id="ehomestay_name" name="homestay_name" class="form-control wizard-required">
										<div class="wizard-form-error"></div>
										</div>									
									</div>

									<div class="agent-form">
										<div class="form_label">
											<p>District / ಜಿಲ್ಲೆ  <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <select name="org_loc_district_id" id="eloc_district"  class="form-control wizard-required" onchange="showtaluk(0,'eloc_taluk_office','eloc_district')">
												  <option class="hide" value="0">Select District</option>
												  <?php
												  	$this->db->where(array('state_id' => '17'));
												  	$this->db->where(array('isactive' => '1'));
													$clients = $this->db->get('m_district')->result_array();
													foreach ($clients as $row):	?>
													<option value="<?php echo $row['id']; ?>">
													<?php echo $row['name']; ?></option>
												  <?php endforeach; ?>
											</select>
										<div class="wizard-form-error"></div>
										</div>									
									</div>

									<!-- <div class="agent-form-field">
										<div class="agent-form-text">
											<p>District / ಜಿಲ್ಲೆ  <sup> * </sup></p>
										</div>
										<div class="agent-form-input">
											<select name="org_loc_district_id" id="eloc_district"  class="form-control wizard-required" onchange="showtaluk(0,'eloc_taluk_office','eloc_district')">
												  <option class="hide" value="0">Select District</option>
												  <?php
												  	$this->db->where(array('state_id' => '17'));
												  	$this->db->where(array('isactive' => '1'));
													$clients = $this->db->get('m_district')->result_array();
													foreach ($clients as $row):	?>
													<option value="<?php echo $row['id']; ?>">
													<?php echo $row['name']; ?></option>
												  <?php endforeach; ?>
											</select>
											
											<div class="wizard-form-error"></div>
										</div>									
									</div>
 -->
									
 									<div class="agent-form">
										<div class="form_label">
											<p>Taluk / ತಾಲೂಕು <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <select name="org_loc_taluk_id" id="eloc_taluk_office"   class="form-control wizard-required">
												<option value="">Select Taluk</option>
											</select>
										<div class="wizard-form-error"></div>
										</div>									
									</div>
									
									<!-- <div class="agent-form-field">
										<div class="agent-form-text">
											<p>Taluk / ತಾಲೂಕು <sup> * </sup></p>
										</div>
										<div class="agent-form-input">
											<select name="org_loc_taluk_id" id="eloc_taluk_office"   class="form-control wizard-required">
												<option value="">Select Taluk</option>
											</select>													
											<div class="wizard-form-error"></div>
										</div>									
									</div> -->

									<div class="agent-form">
										<div class="form_label">
											<p>City / Town / Village <br> ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input type="text" id="eorg_loc_city" name="org_loc_city" class="wizard-required" value="Village">
										<div class="wizard-form-error"></div>
										</div>									
									</div>
									
									
									<!-- <div class="agent-form-field">
										<div class="agent-form-text">
											<p>City / Town / Village <br> ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>
										</div>
										<div class="agent-form-input">
											<input type="text" id="eorg_loc_city" name="org_loc_city" class="wizard-required" value="Village">
											<div class="wizard-form-error"></div>
										</div>									
									</div> -->
									
									<div class="agent-form">
										<div class="form_label">
											<p>Address /   ವಿಳಾಸ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" name="org_loc_add1" id="eorg_loc_add1" class="form-control wizard-required">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Pincode / ಪಿನ್‌ಕೋಡ್ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="text" maxlength="6" name="org_pincode_id[]" onkeypress="return isNumber(event)" id="eorg_pincode_id"  class="wizard-required" onpaste="return false">
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Website Name / ಜಾಲತಾಣ</p>
										</div>
										<div class="form_input">
											<input type="text" name="website_name" id="ewebsite_name" class="form-control wizard-required" value="">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<!-- <div class="agent-form">
										<div class="form_label">
											<p>Website  / ಜಾಲತಾಣ 	</p>
										</div>
										<div class="agent-form-input">
											<input type="text" maxlength="10" name="org_mobile[]" onkeypress="return isNumber(event)" class="wizard-required" id="eorg_loc_mobile"   onpaste="return false">
											<div class="wizard-form-error"></div>
										</div>										
									</div> -->
									<div class="agent-form">
										<div class="form_label">
									<p>Date on which Homestay became Operational 
												 / ಹೋಂಸ್ಟೇ ಕಾರ್ಯಾರಂಭ ಮಾಡಿದ ದಿನಾಂಕ <sup> * </sup></p>
										</div>
										
										<div class="form_input">
											<input type="date" name="org_registration_date"  class="form-control wizard-required datemax" id="eHomestay_opr_date">
										<div class="wizard-form-error"></div>
																				
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Is your Homestay Approved by the Department ?  / ನಿಮ್ಮ ಹೋಂಸ್ಟೇ ಇಲಾಖೆಯಿಂದ ಅನುಮೋದಿತವಾಗಿದೆಯೇ? <sup> * </sup></p>
										</div>
										<div class="form_input">
										<input type="radio" id="yesCheck_hsapp" onclick="javascript:yesnoCheck_d1('yesCheck_hsapp','ifYes_hsapp','div_reg_upload');" name="central_gov_approved" value="yes">
										<label for="yes">Yes</label>
										<input type="radio" id="noCheck_hsapp" onclick="javascript:yesnoCheck_d1('noCheck_hsapp','ifYes_hsapp','div_reg_upload');" name="central_gov_approved" value="yes"> 
										<label for="no">No</label>	
										<div class="wizard-form-error"></div>
										</div>	

										 

									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Is your Homestay a Heritage Building ? / ನಿಮ್ಮ ಹೋಂಸ್ಟೇ ಒಂದು ಪಾರಂಪರಿಕ ಕಟ್ಟಡ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck_hsher" onclick="javascript:yesnoCheck_d1('yesCheck_hsher','ifYes_hsher','div_her_upload');" name="homestay_her_built" value="yes">Yes
										<input type="radio" id="noCheck_hsher" onclick="javascript:yesnoCheck_d1('noCheck_hsher','ifYes_hsher','div_her_upload');" name="homestay_her_built" value="no"> No
										<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Is WIFI Facility Available ?  / ವೈಫೈ ಸೌಲಭ್ಯವಿದೆಯೇ ? <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck_wifi" onclick="javascript:yesnoCheck_d1('yesCheck_wifi','ifYes','div_wifi_upload');" name="homestay_wifi_ava" value="yes">Yes
										<input type="radio" id="noCheck_wifi" onclick="javascript:yesnoCheck_d1('noCheck_wifi','ifYes','div_wifi_upload');" name="homestay_wifi_ava" value="no"> No
										<div class="wizard-form-error"></div>
										</div>									
									</div>
								</div>

							<h4><b>3) Transportation Facilities  / ಸಾರಿಗೆ ಸೌಲಭ್ಯಗಳು </b></h4>	<br>	
								<div class="row">
									<div class="col-lg-6">
										<div class="agent-form">
										<div class="form_label">
											<p>   Nearest Bus Stand / ಹತ್ತಿರದ ಬಸ್ ನಿಲ್ದಾಣ <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input  type="text" id="enear_bus_stand" name="near_bus_stand" class="form-control wizard-required" >
										<div class="wizard-form-error"></div>
										</div>									
										</div>
									</div>	
									<div class="col-lg-6">
										<div class="agent-form">
										<div class="form_label">
											<p>   Distance(km) / ದೂರ (ಕಿಮೀ)<sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input type="text"  name="bus_distance"   id="ebus_distance"  class="form-control wizard-required" onpaste="return false">
													<div class="wizard-form-error"></div>
										</div>									
									</div>
									</div>	

								</div>	

								<div class="row">
									<div class="col-lg-6">
										<div class="agent-form">
										<div class="form_label">
											<p>   Nearest Railway Station / ಹತ್ತಿರದ ರೈಲು ನಿಲ್ದಾಣ <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input  type="text" id="enear_rail_station" name="near_rail_station" class="form-control wizard-required">
										<div class="wizard-form-error"></div>
										</div>									
									</div>
									</div>	
									<div class="col-lg-6">
										<div class="agent-form">
										<div class="form_label">
											<p>   Distance(km) /ದೂರ (ಕಿಮೀ)<sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input type="text" name="rail_distance"  id="erail_distance"  class="form-control wizard-required" onpaste="return false">
													<div class="wizard-form-error"></div>
										</div>									
									</div>
									</div>	

								</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="agent-form">
										<div class="form_label">
											<p>   Nearest Airport / ಹತ್ತಿರದ ವಿಮಾನ ನಿಲ್ದಾಣ <sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input type="text" id="enear_airport" name="near_airport"  class="form-control wizard-required">
										<div class="wizard-form-error"></div>
										</div>									
										</div>
									</div>	
									<div class="col-lg-6">
										<div class="agent-form">
										<div class="form_label">
											<p>   Distance(km) /ದೂರ (ಕಿಮೀ)<sup> * </sup></p>
										</div>
										<div class="form_input">
										 <input type="text"   name="air_distance"  id="eair_distance"  class="form-control wizard-required" onpaste="return false">
													<div class="wizard-form-error"></div>
										</div>									
									</div>
									</div>	

								</div>

								<div class="row">
									<div class="col-lg-12">
									<div class="agent-form">
										<div class="form_label">
									 <p>   Pick Up and Drop facility offered ? / ಪಿಕ್ ಅಪ್ ಮತ್ತು ಡ್ರಾಪ್ ಸೌಲಭ್ಯವನ್ನು ನೀಡಲಾಗಿದೆ <sup> * </sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck_hspk" onclick="javascript:yesnoCheck_d1('yesCheck_hspk','ifYes','div_pickup_upload');" name="pickup_facility" value="yes">										
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck_hspk" onclick="javascript:yesnoCheck_d1('noCheck_hspk','ifYes','div_pickup_upload');" name="pickup_facility" value="no">
											<label for="no">No</label>	
											<!-- <input hidden type="text" name="member_recognised_trade_new" id="emember_recognised_trade_new" > -->
										<div class="wizard-form-error"></div>
										</div>									
									</div>
									</div>
								</div>

								<h4><b>4) Nearest Tourist Spots  / ಹತ್ತಿರದ ಪ್ರವಾಸಿ ತಾಣಗಳು </b> </h4>	<br>
									<div class="agent-off-address">

										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Add Tourist Attractions Name in Karnataka / ಕರ್ನಾಟಕದ ಪ್ರವಾಸಿ ಆಕರ್ಷಣೆಗಳ ಹೆಸರನ್ನು ಸೇರಿಸಿ <sup> * </sup></p>

											</div>
											<div class="agent-form-input" style="text-align: center;">
											   <div class="select-box">
												  <input type='button' class= "new-add-button" value='Add' id='addButton'>
												  <input type='button' class= "new-remove-button" value='Remove' id='removeButton'>
												</div>
											 </div>	 
											 

										</div>

										<div id="row-container-title">
											<div class="row">
												<div class="col-lg-6">
												  	<div class="agent-form-text">
														<p style="text-align: center;">Tourist attraction name  / ಪ್ರವಾಸಿ ಆಕರ್ಷಣೆಯ ಹೆಸರು <sup> * </sup></p>
													</div>
												</div>	
												<div class="col-lg-3">
												  	<div class="agent-form-text">
													 	<p style="text-align: center;">  Room Category  / ವರ್ಗ  <sup> * </sup></p>
													</div>
												</div>
												<div class="col-lg-3">
												  	<div class="agent-form-text">
													 <p style="text-align: center;">   Distance (km)  / ದೂರ (ಕಿಮೀ)  <sup> * </sup></p>
													</div>
												</div>
											</div>
										</div>

										<input type="hidden" value="1" id="td_count" name="td_count">
										<div id="row-container">
											<div class="row">
											  <div class="col-lg-6">
											    <div class="form-group">
											      <input  type="text" class="form-control wizard-required" id="etourist_name_1" name="tourist_name_1" >
													<div class="wizard-form-error"></div>
											    </div>
											  </div>
											  <div class="col-lg-3">
											  
											    <div class="form-group">
												    <select name="category_type_1" id="ecategory_type_1" class="form-control wizard-required">
														<option value="">Select Category</option>  
														<option value="Adventure Tourism">Adventure Tourism</option> 
														<option value="Coastal Tourism">Coastal Tourism</option> 
														<option value="Eco Tourism">Eco Tourism</option> 
														<option value="Heritage Tourism">Heritage Tourism</option> 
														<option value="Leisure Tourism">Leisure Tourism</option> 
														<option value="Religious Tourism">Religious Tourism</option> 
														<option value="Theme Park">Theme Park</option> 
														<option value="Wildlife Tourism">Wildlife Tourism</option> 
													</select>
													<div class="wizard-form-error"></div>
											    </div>
											  </div>
											  <div class="col-lg-3">
											  	
											    <div class="form-group">
											      <input type="text"   name="distance_1"   id="edistance_1"  class="form-control wizard-required" onpaste="return false">
													<div class="wizard-form-error"></div>
											    </div>
											  </div>
											  <!-- <div class="col-lg-3">
											    <div class="form-group">
											      <input type="file" class="form-control" name="img" />
											    </div>
											  </div> -->
											 
											</div>
										</div>

										<div id="row-container-new">

										</div>
									</div>
									<br/>

									

								<div class="form-group col-md-12"><hr class="new4"></div>
									
   
							
				<h4><b>5) Activities Available / ಚಟುವಟಿಕೆಗಳು ಲಭ್ಯವಿದೆ </b></h4>	<br>				

							<div class="agent-form">
								<div class="form_label">
								 <p>   Services Available / ಸೇವೆಗಳು ಲಭ್ಯವಿದೆ <sup> * </sup></p>
								</div>
								<div class="form_input">
								 <input  type="text" id="ehs_services_avail" name="hs_services_avail"  class="form-control wizard-required">
								<div class="wizard-form-error"></div>
								</div>									
							</div>
							<div class="agent-form">
								<div class="form_label">
								 <p>  Vegetarian Food Offered / ಸಸ್ಯಾಹಾರಿ ಆಹಾರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ <sup> * </sup></p>
								</div>
								<div class="form_input">
									<input type="radio" id="yesCheck_kts" onclick="javascript:yesnoCheck_d1('yesCheck_kts','ifYes','div_con_upload');" name="hs_veg_food" value="yes">Yes
									<input type="radio" id="noCheck_kts" onclick="javascript:yesnoCheck_d1('noCheck_kts','ifYes','div_con_upload');" name="hs_veg_food" value="yes"> No
									<div class="wizard-form-error"></div>
								</div>	
								<!-- <div class="form_input">
								 <textarea   id="efood_off" name="food_off" class="form-control wizard-required"  style="width: 100%;height: 10%"></textarea> 
								<div class="wizard-form-error"></div>  
								</div> -->									
							</div>
							<div class="agent-form">
								<div class="form_label">
								 <p>   Non-Vegetarian Food Offered / ಮಾಂಸಾಹಾರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ <sup> * </sup></p>
								</div>
								<div class="form_input">
									<input type="radio" id="yesCheck_kts1" onclick="javascript:yesnoCheck_d1('yesCheck_kts1','ifYes','div_con_upload');" name="hs_nonveg_food" value="yes">Yes
									<input type="radio" id="noCheck_kts1" onclick="javascript:yesnoCheck_d1('noCheck_kts1','ifYes','div_con_upload');" name="hs_nonveg_food" value="yes"> No
									<div class="wizard-form-error"></div>
								</div>	<!-- 
								<div class="form_input">
								 <textarea   id="enon_food_off" name="non_food_off" class="form-control wizard-required"  style="width: 100%;height: 10%"></textarea> 
								<div class="wizard-form-error"></div>
								</div>	 -->								
							</div>
 
										 
																				
									 <!-- <div>
										 <input type="hidden" name="remove_ids" id="remove_ids">
								</div> 
							 </div>  -->
							<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">	
								<p>"Data saving please wait"</p>
							</div>
							<div class="form-group clearfix" id="totalbuildnext">
								<!-- <a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a>
								<a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಉಳಿಸಿ</a> -->
							

								<a href="javascript:;" class="form-wizard-next-btn float-right" id="nextpage"  style="display: none;">Next1 / ಮುಂದಿನದು</a>
								<a href="javascript:;" class="form-wizard-next-btn float-right draftdata" id="draftdata">Next/ ಮುಂದಿನದು</a>
										</div>
								</fieldset>							
								<fieldset class="wizard-fieldset comment-section">
									<div class="form-required">
										<div class="form-required-area">
											<h4><b>6) Room and  Tarrif Details  / ಕೊಠಡಿ ಮತ್ತು ಟ್ಯಾರಿಫ್ ವಿವರಗಳು </b></h4>	<br>
							
								

							<div id="agent-form-room" class="agent-form">

 							 	<div class="row">

	 							  	<div class="col-md-6">
	 							  		<div class="agent-form-field">
	 							  			<div class="agent-form-text">
											<p><!-- Room  -->Category / ಕೊಠಡಿ ವರ್ಗ <sup> * </sup></p>
											</div>
										</div>
	 							  	</div>
	 							  	<div class="col-md-6">
	 							  		 <div class="form_input">
												    <select name="hs_accommodation_type" id="ehs_accommodation_type" class="form-control wizard-required">
														<option value="">Select Category</option>  
														<option value="Standard Room (Without AC)">Standard Room (Without AC) / ಸ್ಟ್ಯಾಂಡರ್ಡ್ ರೂಮ್ (ಎಸಿ ಇಲ್ಲದೆ)</option> 
														<option value="Standard Room (With AC)">Standard Room (With AC)/ಸ್ಟ್ಯಾಂಡರ್ಡ್ ರೂಮ್ (ಎಸಿಯೊಂದಿಗೆ)</option> 
														<option value="Deluxe Room">Deluxe Room / ಐಷಾರಾಮಿ ಕೊಠಡಿ</option> 
														<option value="Executive Room">Executive Room / ಕಾರ್ಯನಿರ್ವಾಹಕ ಕೊಠಡಿ</option> 
														<option value="Suite Room">Suite Room / ಸೂಟ್ ರೂಮ್</option> 
														<option value="Dormitory">Dormitory / ವಸತಿ ನಿಲಯ</option> 
													</select>
													<div class="wizard-form-error"></div>
										</div>
										
	 								</div>
	 							</div> 

	 						 <br>

 							  	<div class="row">
	 							  	<div class="col-md-6" >
		 							  	<div class="agent-form-field">

											<div class="agent-form-text">
												<p>No of Rooms   / ಕೊಠಡಿಗಳ ಸಂಖ್ಯೆ  <sup> * </sup></p>
											</div>
										</div>
									</div>

		 							  	<div class="col-md-6">
											<div class="form_input">
												<input type="text" id="eroom_no"  class="form-control wizard-required" name="no_of_rooms" onkeypress="return isNumber(event)" maxlength="4">
												<div class="wizard-form-error"></div>		
											</div>									
										</div>
 							  	</div>

 							  

 							  	<div class="row">
									<div class="col-md-6" >

										<div class="form_label">
									  	<p>   Tariff (Rs.)  / ಸುಂಕ (ರೂ.)  <sup> * </sup></p>
										</div> 
									</div>	
									<div class="col-md-6" >
										<div class="form_input">
										<input type="text" id="etariff_rs"  class="form-control wizard-required" name="hs_tariff_rs" onkeypress="return isNumber(event)">
										<div class="wizard-form-error"></div>
										</div>			
									</div>							
								</div>

								<div class="row">
									<div class="col-md-6" >
										<div class="form_label">
									  	 <p>   Extra Charge Per Person (Rs)  / ಪ್ರತಿ ವ್ಯಕ್ತಿಗೆ ಹೆಚ್ಚುವರಿ ಶುಲ್ಕ (ರೂ.) <sup> * </sup></p>
										</div>
										
									</div>	
									<div class="col-md-6" >
										<div class="form_input">
										<input type="text" id="echarge_rs"  class="form-control wizard-required" name="extra_charge_rs" onkeypress="return isNumber(event)">
										<div class="wizard-form-error"></div>
										</div>			
									</div>							
								</div>
								<div class="row">
									<div class="col-md-6" >
										<div class="form_label">
									  	 <p>  Is there Child Concession ? / ಮಕ್ಕಳ ರಿಯಾಯಿತಿ ಇದೆಯೇ  <sup> * </sup></p>
										</div>
										
									</div>	
									<div class="col-md-6" >
										<div class="form_input">
										<input type="radio" id="yesCheck_hscd" onclick="javascript:yesnoCheck_d1('yesCheck_hscd','ifYes','div_con_upload');" name="hs_child_concession" value="yes" id="ehs_child_concession">Yes
										<input type="radio" id="noCheck_hscd" onclick="javascript:yesnoCheck_d1('noCheck_hscd','ifYes','div_con_upload');" name="hs_child_concession" value="yes" id="ehs_child_concession"> No
										<div class="wizard-form-error"></div>
										</div>			
									</div>							
								</div> 
 							</div> 	 

						  <div id ="agent-form-room-1" class="agent-form-field">
								<div class="row">

			 						<div class="col-md-6" >
										<div class="agent-form-text">
											<p> Room and  Tarrif Details  /ಕೊಠಡಿ ಮತ್ತು ಟ್ಯಾರಿಫ್ ವಿವರಗಳನ್ನು ಸೇರಿಸಿ <sup> * </sup></p>

										</div>
									</div>
									<div class="col-md-6" >
										<div class="agent-form-input" style="text-align: center;">
										   <div class="select-box">
											  	<input type='button' class= "new-add-button" value='Add' id='new-addButton' onclick="addRoomDetails(this);" >
											  		
											</div>
										 </div>	
									</div> 
								</div>	 
							</div>  	

							<br/> 

							  <div id ="agent-form-room-3" class="agent-form-field">
								<div class="agent-form-view"> 
									<table id='' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
									<thead>
									<tr class="success" style="background-color:#495057;color:#fff">
										<th>Sl. No</th> 
										<th>Room Category</th>
										<th>No. of Rooms</th>
										<th>Tariff</th> 
										<th>Exchange charge(Rs.)</th> 
										<th>Action</th> 
									</tr> 
									</thead>
									    <tbody id="userTabletbody">
										     
									       	 
									    </tbody>
									</table> 
								</div>
								<div class="form-group col-md-12"><hr class="new4"></div>
				
											<h4><b>Required Documents / ಅಗತ್ಯವಿರುವ ದಾಖಲೆಗಳು</b></h4>
											<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB)</h5>
										</div>										
									</div>  

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Owner Photo  / ಮಾಲೀಕರ ಫೋಟೋ </h5> 
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_owner_certificate_upload">
												<input onchange="singleFileUpload('eimg_owner_certificate');" name="img_owner_certificate" id="eimg_owner_certificate" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_owner_certificate" style="display: none;">
												<a id="a_owner_certificate" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" value="owner_certificate" name="owner_certificate" Sdivname="div_owner_certificate_upload" hdivname="div_owner_certificate">Remove</button>
											</div>
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Aadhaar  Card / ಆಧಾರ್ ಕಾರ್ಡ್ </h5> 
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_adhaar_permit_upload">
												<input onchange="singleFileUpload('eimg_adhaar_permit');" name="img_adhaar_permit" id="eimg_adhaar_permit" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_adhaar_permit" style="display: none;">
												<a id="a_adhaar_permit" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" docname="eimg_adhaar_permit" value="adhaar_permit" name="adhaar_permit" Sdivname="div_adhaar_permit_upload" hdivname="div_adhaar_permit">Remove</button>
											</div>


										</div>
									</div>
 
									 
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Homestay Interior / ಹೋಂಸ್ಟೇ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the homestay / ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_buildInterior_upload">
														<input onchange="singleFileUpload('eimg_off_buil_interior');" name="img_off_buil_interior" id="eimg_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_interior" style="display:none">
														<a id="a_buildInterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="buil_interior" Sdivname="div_buildInterior_upload" hdivname="div_off_buil_interior">Remove</button>
													</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Homestay Exterior / ಹೋಂಸ್ಟೇ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_builexterior_upload">
														<input onchange="singleFileUpload('eimg_off_buil_exterior');" name="img_off_buil_exterior" id="eimg_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_off_buil_exterior" style="display:none">
														<a id="a_builexterior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="buil_exterior" Sdivname="div_builexterior_upload" hdivname="div_off_buil_exterior">Remove</button>
													</div> 
										</div>
									</div> 
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Homestay Front View/ ಹೋಮ್‌ಸ್ಟೇ ಮುಂಭಾಗದ ನೋಟದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_buil_front_upload">
														<input onchange="singleFileUpload('eimg_built_front_view');" name="img_built_front_view" id="eimg_built_front_view" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_buil_front" style="display:none">
														<a id="a_builfront" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="buil_front_view" Sdivname="div_buil_front_upload" hdivname="div_buil_front">Remove</button>
													</div> 
										</div>
									</div> 

								<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Homestay Room Interiors / ಹೋಮ್‌ಸ್ಟೇ ಕೊಠಡಿಯ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_room_interior_upload">
														<input onchange="singleFileUpload('eimg_room_interior');" name="img_room_interior" id="eimg_room_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
														<div class="wizard-form-error"></div>
													</div>
													<div class="agent-form-file-view1" id="div_room_interior" style="display:none">
														<a id="a_room_interior" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="room_interior" Sdivname="div_room_interior_upload" hdivname="div_room_interior">Remove</button>
													</div> 
										</div>
									</div>

									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of Homestay Bathroom Interiors /ಹೋಮ್‌ಸ್ಟೇ ಬಾತ್‌ರೂಮ್ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup> * </sup></h6>
											<p>All the mandatory features to be captured including the name of the homestay / (ಹೋಂಸ್ಟೇ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_room_exterior_upload">
												<input onchange="singleFileUpload('eimg_room_exterior');" name="img_room_exterior" id="eimg_room_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_room_exterior" style="display:none">
												<a id="a_builexterior" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="room_exterior" Sdivname="div_room_exterior_upload" hdivname="div_room_exterior">Remove</button>
											</div> 
										</div>
									</div>

									
									<div class="field-app-form" >
										<div class="field-appli-form-padd">
											<h6>Homestay Ownership Document (front page of the document carrying name of the owner)
											/ ಹೋಂಸ್ಟೇ ಮಾಲೀಕತ್ವದ ದಾಖಲೆ (ಮಾಲೀಕರ ಹೆಸರನ್ನು ಹೊಂದಿರುವ ಡಾಕ್ಯುಮೆಂಟ್‌ನ ಮೊದಲ ಪುಟ) <sup> * </sup></h6>
										</div>
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_certificate_shops_upload">
												<input onchange="singleFileUpload('eimg_certificate_shops');" id="eimg_certificate_shops" name="img_occupancy_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_certificate_shops" style="display:none">
												<a id="a_certificate_shops" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="certificate_shops" Sdivname="div_certificate_shops_upload" hdivname="div_certificate_shops">Remove</button>
											</div> 
										</div>	 
										</div>


									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>NOC from Police Station /ಪೊಲೀಸ್ ಠಾಣೆಯಿಂದ ಎನ್‌ಒಸಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
													<div class="file-upload-wrapper" data-text="Select your file!" id="div_noobj_upload">
														<input onchange="singleFileUpload('eimg_noobj_certificate');" name="img_noobj_certificate" id="eimg_noobj_certificate" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
														<div class="wizard-form-error"></div>											
													</div>
													<div class="agent-form-file-view1" id="div_noobj_certificate" style="display:none">
														<a id="a_noobj_certificate" href="" target="_blank">View</a>
														<button class="btn btn-danger removebtn" name="noobj_certificate" Sdivname="div_noobj_upload" hdivname="div_noobj_certificate">Remove</button>
													</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>NOC from Local Bodies  / ಸ್ಥಳೀಯ ಸಂಸ್ಥೆಗಳಿಂದ ಎನ್‌ಒಸಿ <sup> * </sup></h6>
										</div>										
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!" id="div_local_certificate_upload">
												<input onchange="singleFileUpload('eimg_local_certificate');" name="img_local_certificate" id="eimg_local_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
											<div class="agent-form-file-view1" id="div_local_certificate" style="display:none">
												<a id="a_local_certificate" href="" target="_blank">View</a>
												<button class="btn btn-danger removebtn" name="pan" Sdivname="div_local_certificate_upload" hdivname="div_local_certificate">Remove</button>
											</div> 
										</div>
									</div>
									   
 
  
									<div class="alert-error" id="savemsg" style="display:none;margin-top: 26px;text-align: center;color:red">	
										<p>"Data saving please wait"</p>
									</div>	
									<style>
									.disabled-link {
									  pointer-events: none;
									  background-color: #d654707a !important;
									}
									</style>								
									<div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous / ಹಿಂದಿನದು</a>
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center draftdata" id="draftdata">Save as draft / ಡ್ರಾಫ್ಟ್ ಆಗಿ ಉಳಿಸಿ </a> -->
										<input type="hidden" id="image_counter" value="0">
										<a href="javascript:;" id="ajaxformsubmit" class="form-wizard-next-btn float-right disabled-link">Application Fee / ಅರ್ಜಿಯ ಶುಲ್ಕ</a>
										<!-- <a href="javascript:;" class="form-wizard-next-btn float-right">Next / ಮುಂದಿನದು</a> -->
									</div>
								</fieldset>							
								</fieldset>	
								
								<fieldset id="payment-det" class="wizard-fieldset payment-det">		
							</form>	
									<div class="other-detail-option">
										<div class="agent-application">				
											<div class="user-payment-details">
												<div class="user-payment">
													<div class="payment-title">
														<h3>Payment</h3>
													</div>
													<div class="payment-details">
														<div class="payment-amount">
															<p>Payable Amount</p>
															<p>Pament Method</p>
														</div>
														<div class="payment-value">
															<p>Rs. 500.00</p>
															<p>Online payment</p>
														</div>
													</div>
													<input type="text" name="insertidd" style="display:none;"  id="insertidd">
													<div class="payment-options">
														
 
													<input type="text" style="display:none;" id="applmob" value=""/>
													<input type="text" style="display:none;" id="applemail" value=""/>
													<input type="text" style="display:none;" id="card_holder_name_ida" value=""/>
													<!--form name="razorpay-form" id="razorpay-form" action="<?php echo $callback_url; ?>" method="POST">
													<input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id" />
													<input type="hidden" name="merchant_order_id" id="merchant_order_id" value="<?php echo $merchant_order_id; ?>"/>
													<input type="hidden" name="merchant_trans_id" id="merchant_trans_id" value="<?php echo $txnid; ?>"/>
													<input type="hidden" name="merchant_product_info_id" id="merchant_product_info_id" value="<?php echo $description; ?>"/>
													<input type="hidden" name="merchant_surl_id" id="merchant_surl_id" value="<?php echo $surl; ?>"/>
													<input type="hidden" name="merchant_furl_id" id="merchant_furl_id" value="<?php echo $furl; ?>"/>
													<input type="hidden" name="card_holder_name_id" id="card_holder_name_id" value=""/>
													<input type="hidden" name="merchant_total" id="merchant_total" value="<?php echo $total; ?>"/>
													<input type="hidden" name="merchant_amount" id="merchant_amount" value="<?php echo $amount; ?>"/>
													</form>
													<input  id="pay-btn" style="float:right;"  onclick="razorpaySubmit(this);" value="Pay Now" class="btn btn-primary" /-->

	<button type="button" style="float:right;" id="JsCheckoutPayment" name="submit" class="btn btn-primary">Pay Now</button>

														<!-- razoor pay ends -->
													</div>
												</div>
											</div>
										</div>
									</div>
							
									<div class="form-group clearfix">
										<!--a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a-->
										<!-- <a href="javascript:;" class="form-wizard-save-btn float-center">Save as draft</a> -->
										<!--input type="submit" name="app_submit" value="Submit" class="form-wizard-submit float-right"--> 										
									</div>
								</fieldset>	


<script type="text/javascript">
	function specifyother(d,id)
	{		
		if ($(d).is(':checked')) 
		{
			// alert("all is well");
			// console.log(d.value);
			$('#'+id).show();
		}
		else
		{
			$('#'+id).hide();
		}
	}
	function society_enable(id)
	{
		console.log(id);
		var val=$('input[id="'+id+'"]:checked').val();
		
			if(val=='yes')
			{
				// $("#"+value).removeClass("disable-click");
				$("#"+id).prop('checked', false);
			}
			else
			{
				// $("#"+value).addClass("disable-click");
				$("#"+id).prop('checked', false);
			}
	}
	$(function(){
		// alert("test123");
    var dtToday = new Date();
    // alert(dtToday);
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;

   	// alert($('#org_commencement_date').val());
    $('#eorg_commencement_date').attr('max', maxDate);
    $('#etrade_lic_date').attr('max', maxDate);
    $('#eorg_registration_date').attr('max', maxDate);
      
});
</script>	
<script>	
function totalroomval(id) 
{
  var x = document.getElementById(id).value;
  //console.log(x);
  if(x < 10){
  	$('#totalbuildnext').hide();
  	$('#totalroom').show();
  }
  else{
  	$('#totalbuildnext').show();
  	$('#totalroom').hide();
  }
}	
function showdropdown(e)
{
	if(e.value=='17')
	{
		$("#eloc_district").show();
		$("#eloc_districtnew").hide();
		$("#eloc_taluk_office").show();
		$("#eloc_taluk_office_new").hide();
		$("#eloc_districtnew").removeClass("wizard-required");
		$("#eloc_taluk_office_new").removeClass("wizard-required");
	}
	else
	{
		$("#eloc_district").hide();
		$("#eloc_districtnew").show();
		$("#eloc_taluk_office").hide();
		$("#eloc_taluk_office_new").show();
		$("#eloc_districtnew").addClass("wizard-required");
		$("#eloc_taluk_office_new").addClass("wizard-required");
	}
}


$(document).on( "change", ".datemax",function( event, ui ) {
 	// alert("Hi");
        var now = new Date();
        var selectedDate = new Date($(this).val());
        if(selectedDate > now) {
            $(this).val(dateControler.currentDate);
           alert("Please check the date");
        } else {
            dateControler.currentDate = $(this).val();
        }
    });
  $(document).on( "change", ".datemin",function( event, ui ) {
 	// alert("Hi");
        var now = new Date();
        var selectedDate = new Date($(this).val());
        if(selectedDate <= now) {
            $(this).val(dateControler.currentDate);
            alert("Please check the date");
        } else {
            dateControler.currentDate = $(this).val();
        }
    });


// $(document).ready(function()
// {	
// 	// console.log($('input[name="Nuumber_offices"]'));
// 	// var maxField=$('.Nuumber_offices').val();
	
//     //var maxField = 10; //Input fields increment limitation
//     var addButton = $('.add_button'); //Add button selector
//     var removeButton = $('.remove_button'); //Add button selector
//     var wrapper = $('.other-off-addre'); //Input field wrapper   
//     var x = 1; //Initial field counter is 1
//     //Once add button is clicked
//     $(addButton).click(function(){
//     	var maxField=$('input[name="Nuumber_offices_new"]').val();
//     	console.log(maxField);
//         //Check maximum number of input fields       
//         var field_type_add="address";
//         var count=$("div[class*='other-off-no']").length;
//         var len=(count+1);
//        	console.log(count);
//         if(count < maxField)
//         {
//             x++; //Increment field counter
//             //<label>Address ' + len +' </label>            
//             $(wrapper).append('<div class="other-off-addre" id="address_'+count+'"><div id="other-off-no" class="other-off-no"></div> '+
// 			'<div class="agent-form-field"><div class="agent-form-text"><p>   Tourist attraction name  / ಪ್ರವಾಸಿ ಆಕರ್ಷಣೆಯ ಹೆಸರು <sup> * </sup></p></div><div class="agent-form-input"><input  type="text" class="form-control wizard-required" id="etourist_name" name="tourist_name" >'+
// 			'<div class="wizard-form-error"></div></div></div>'+
// 			'<div class="agent-form-field"><div class="agent-form-text"> <p>   Category  / ವರ್ಗ  <sup> * </sup></p></div>'+
// 			'<div class="agent-form-input "><select name="category_type" id="ecategory_type" class="form-control wizard-required"><option value="">Select Category</option><option value="1">Adventure Tourism</option> <option value="4">Coastal Tourism</option><option value="2">Eco Tourism</option> <option value="3">Heritage Tourism</option><option value="5">Leisure Tourism</option><option value="6">Religious Tourism</option> <option value="7">Theme Park</option> <option value="8">Wildlife Tourism</option></select>  <?php if($prod_id == 2 || $prod_id == 3){ ?>'+
// 			'<?php }?></div></div>'+
// 			'<div class="agent-form-field"><div class="agent-form-text"><p>Distance (km)  / ದೂರ (ಕಿಮೀ)<sup><?php if($prod_id == 2 || $prod_id == 3){ ?> *<?php }?></sup></p></div>'+
// 			'<div class="agent-form-input"><input type="text" maxlength="6" name="distance" onkeypress="return isNumber(event)" id="edistance"  class="form-control wizard-required" onpaste="return false"><div class="wizard-form-error"></div><?php if($prod_id == 2 || $prod_id == 3){ ?><div class="wizard-form-error"></div><?php }?></div></div>'+
// 			'<button class="btn btn-danger" style="margin-left: 90%;" onclick="removeaddress(\'' + field_type_add + '\',0,'+count+')">Remove</button><br><hr class="new4"></div>');
// 			 //Add field html
// 			//$(".other-off-no").children("label").text("Address " + x);		

//         }
//         else
//         {
// 			//alert('Maximum 10 Address Only Allowed.');
// 			alert('Reached Maximum');
// 		}		
//     });
//     //Once remove button is clicked
//   //   $(removeButton).click(function(){
// 		// if (x > 1) {
// 		// x--;
// 		// $(".other-off-addre" + ":last").remove();
// 		// }
//   //   });
//   $(wrapper).on('click', '.remove_button', function(e)
//   {
//         e.preventDefault();
//         $(this).parent(".other-off-addre").remove(); //Remove field html
//         x--; //Decrement field counter
//     });
// });


// function chkval()
// {
// 	var no_office=$('input[name="Nuumber_offices_new"]').val();
// 	alert(no_office);
// 	if(no_office>0)
// 	{
// 		$("#other_address_div").show();
// 		$(".new_required").addClass("wizard-required");
// 		$(".add_button").removeClass("disable-click");		
// 	}
// 	else
// 	{
// 		$("#other_address_div").hide();
// 		$(".new_required").removeClass("wizard-required");
// 		$(".add_button").addClass("disable-click");
// 	}
// }

</script>							

<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type = "text/javascript" >
var row = $("#row-container .row:eq(0)").clone();
$("#addButton").data("row",row);

$("#addButton").click(function(){
    //$("#row-container").clone().appendTo("#row-container-new");
  // $("#row-container").append($(this).data("row").clone());
   // $("p").clone().appendTo("h3");
   var tdCnt = parseInt($('#td_count').val())+1;
  $('#td_count').val(tdCnt);

  $('#row-container').append('<div class="row" id="row_container_'+tdCnt+'">'+
			'	  <div class="col-lg-6">'+
			'	    <div class="form-group">'+
			'     <input  type="text" class="form-control wizard-required" id="etourist_name_'+tdCnt+'" name="tourist_name_'+tdCnt+'" >'+
			'			<div class="wizard-form-error"></div>'+
			'	    </div>'+
			'	  </div>'+
			'	  <div class="col-lg-3">'+
			'		    <div class="form-group">'+
			'			    <select name="category_type_'+tdCnt+'" id="ecategory_type_'+tdCnt+'" class="form-control wizard-required">'+
			'					<option value="">Select Category</option>  '+
			'					<option value="Adventure Tourism">Adventure Tourism</option> '+
			'					<option value="Coastal Tourism">Coastal Tourism</option> '+
			'					<option value="Eco Tourism">Eco Tourism</option> '+
			'					<option value="Heritage Tourism">Heritage Tourism</option> '+
			'					<option value="Leisure Tourism">Leisure Tourism</option> '+
			'					<option value="Religious Tourism">Religious Tourism</option> '+
			'					<option value="Theme Park">Theme Park</option> '+
			'					<option value="Wildlife Tourism">Wildlife Tourism</option> '+
			'				</select>'+
			'				<div class="wizard-form-error"></div>'+
			'		    </div>'+
			'		  </div>'+
			'		  <div class="col-lg-3">'+
			'		  	'+
			'		    <div class="form-group">'+
			'	      <input type="text" maxlength="6" name="distance_'+tdCnt+'" onkeypress="return isNumber(event)" id="edistance_'+tdCnt+'"  class="form-control wizard-required" onpaste="return false">'+
			'				<div class="wizard-form-error"></div>'+
			'		    </div>'+
			'		  </div>'+ 
			'		</div>');

});

$("#removeButton").click(function(){


	    // alert("hi");
	    // $("#row-container-new").remove();
   //$("#row-container-new .row").eq(  $("#row-container-new .row").length-1 ).remove();

   	let tdCnt1 = parseInt($('#td_count').val());
   $("#row_container_"+tdCnt1).remove();


   	var tdCnt = parseInt($('#td_count').val())-1;
  	$('#td_count').val(tdCnt);

 //  	alert("Do you really want to delete the row ??");
 //  	if(tdCnt<=1){
	// 	$("#removeButton").attr("disabled", true);
		
	// }
  
});

 
$('#ehs-accommodation_type').on('change',function(){
	// alert("hi");
    if( $(this).val()==="other"){
    $("#otherType").show()
    }
    else{
    $("#otherType").hide()
    }
});

</script>
