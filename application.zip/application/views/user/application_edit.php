<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>

<?php
$prod_id = $_GET['apid'];
?>
<?php //print_r($appdetails); ?>
<div class="agent-application">				
			<section class="wizard-section">
				<div class="no-gutters">			
					<div class="col-lg-12 col-md-12">
						<div class="form-wizard">
							<h3>KTTF Application for Travel Agents</h3>
							<br>	<br>

								<!--div class="form-wizard-header">								
									<ul class="list-unstyled form-wizard-steps clearfix">
										<li class="active"><span>1</span><span class="verify">General Info</span></li>
										<li><span>2</span><span class="verify">Documents</span></li>
										<li><span>3</span><span class="verify">Other Details</span></li>
										<li><span>4</span><span class="verify">Payment</span></li>
									</ul>
								</div-->
 <?php foreach($appdetails as $appdet){ ?>

				<form  method="post" role="form" action="<?php echo base_url();?>applications/application_editupdate" enctype="multipart/form-data"  id="formSave123">
								<fieldset id="general-verify" class="wizard-fieldset general-verify1 show">
									<div class="agent-form">
										<div class="form_label">
											<p>Full Name of the Entity<sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)</p>
										</div>
										<div class="form_input">


<input type="hidden" name="product_id" value="<?php echo $appdet->product_id; ?>">
<input type="hidden" name="insid_draft" value="<?php echo $appdet->id; ?>">


											<input type="text" name="applicant_name" class="wizard-required" value="<?php echo $appdet->applicant_name; ?>">
											<div class="wizard-form-error"></div>

											
											
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Entity Type<sup>*</sup></p>
										</div>
										<div class="form_input">
										<select name="org_type_id" id="org_type_id" class="form-control wizard-required">
											<option value="">Select Entity Type</option>
											<?php
											$clients = $this->db->get('m_organization_nature')->result_array();
											foreach ($clients as $row):
											?>
											<option value="<?php echo $row['id']; ?>" <?php if($appdet->org_type_id==$row['id']){echo "selected";}?>>
											<?php echo $row['name']; ?></option>
											<?php endforeach; ?>
										</select>
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Date of Registration/Incorporation of the Entity<sup>*</sup><br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Shops and Establishment Act)</p>
										</div>
										<div class="form_input">
											<input type="date" name="org_commencement_date" class="wizard-required" value="<?php echo $appdet->org_commencement_date; ?>">											
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Registered under Ministry of Tourism, Government of India<sup>*</sup></p>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck" onclick="javascript:yesnoCheck();" name="central_gov_approved" value="yes" <?php if($appdet->central_gov_approved=='yes'){echo "checked";}?> >										
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck" onclick="javascript:yesnoCheck();" name="central_gov_approved" value="no" <?php if($appdet->central_gov_approved='no'){echo "checked";}?> >
											<label for="no">No</label>											
										</div>									
									</div>
				<div class="agent-form"  <?php if($appdet->central_gov_approved=='yes'){echo "style='display:block'";}else{echo "style='display:none'";}?> id="ifYes">
										<div class="form_label">
											<p>Upload Registration Document<sup>*</sup></p>
										</div>
										<div class="form_input_file">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input id="reg_firm" name="img_central_gov_registration" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>		
									</div>									
									<div class="agent-form">
										<div class="form_label">
											<p>Name of Proprietor / Directors / Partners<sup>*</sup></p>
										</div>
										<div class="form_input">
											<input type="text" onkeypress="return isNumbera(event)" name="proprietor_name" class="wizard-required" value="<?php echo $appdet->proprietor_name; ?>">
											<div class="wizard-form-error"></div>
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>GST Identification Number</p>
										</div>
										<div class="form_input">
											<input type="text" name="gst_number" value="<?php echo $appdet->gst_number; ?>">
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>PAN Number</p>
										</div>
										<div class="form_input">
											<input type="text" name="pan_number" value="<?php echo $appdet->pan_number; ?>">
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Website Name & URL</p>
										</div>
										<div class="form_input">
											<input type="text" name="website_name" value="<?php echo $appdet->website_name; ?>">
										</div>									
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Official email id of the Entity<sup>*</sup></p>
										</div>
										<div class="form_input">
											<input type="email" name="official_email" class="wizard-required" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="<?php echo $appdet->official_email; ?>">
											<div class="wizard-form-error"></div>
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Whether a Member of Any Recognised Trade Body?<sup>*</sup></p>
										</div>
										<div class="form_input">
											<select name="member_recognised_trade" onchange='Checktrade(this.value);' id="recognised_trade_body" class="form-control wizard-required" >
											<option value="">Select Recognised Trade Body</option>											
											<option value="The Travel Agents Association of India(TAAI)"  <?php if($appdet->member_recognised_trade=='The Travel Agents Association of India(TAAI)'){echo "selected";}?> >The Travel Agents Association of India(TAAI)</option>
											<option value="Indian Association of Tour Operators(IATO)" <?php if($appdet->member_recognised_trade=='Indian Association of Tour Operators(IATO)'){echo "selected";}?> >Indian Association of Tour Operators(IATO)</option>
											<option value="Travel Agents Federation of India(TAFI)" <?php if($appdet->member_recognised_trade=='Travel Agents Federation of India(TAFI)'){echo "selected";}?> >Travel Agents Federation of India(TAFI)</option>
											<option value="International Air Transport Association(IATA)" <?php if($appdet->member_recognised_trade=='International Air Transport Association(IATA)'){echo "selected";}?> >International Air Transport Association(IATA)</option>
											<option value="Others" <?php if($appdet->member_recognised_trade=='Others'){echo "selected";}?>>Others – Please specify</option>											
										</select>
										<input type="text" <?php if($appdet->member_recognised_trade=='Others'){echo "style='margin-top:10px;display:block;'";}else{echo "style='margin-top:10px;display:none;'";}?> name="member_recognised_trade_details"  onkeypress="return isNumbera(event)" id="othertrade" style='margin-top:10px;display:none;'/>
											<div class="wizard-form-error"></div>
										</div>													
										</div>									
									

									<!--div class="agent-form" style="display:none;" id="ifYes1">
										<div class="form_label">
											<p>Member Recognised Trade Details</p>
										</div>
										<div class="form_input">
											<input id="firm" type="text" onkeypress="return isNumbera(event)" name="member_recognised_trade_details" >
											<div class="wizard-form-error"></div>
										</div>									
									</div-->									

					<div class="form-heading-location">
						<br>
										<h4>Office Address</h4>
										<span>[Applicant to mention only the details of office address for which registration under Department of Tourism is required]</span>
										<!--span><input type="checkbox" name="sameas" id="sameas"/>Same as above</span-->
									</div>
									<div class="agent-loc-off-address">
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Address 1<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_loc_add1" id="loc_addr1" class="wizard-required" value="<?php echo $appdet->org_loc_add1; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Address 2<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_loc_add2" id="loc_addr2" class="wizard-required" value="<?php echo $appdet->org_loc_add2; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>District<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<select name="org_loc_district_id" id="loc_district" class="form-control wizard-required">
													  <option value="">Select District</option>
													  <?php
													  	$this->db->where(array('state_id' => '17'));
														$clients = $this->db->get('m_district')->result_array();
														foreach ($clients as $row):	?>
														<option value="<?php echo $row['id']; ?>" <?php if($appdet->org_loc_district_id==$row['id']){echo "selected";}?> >
														<?php echo $row['name']; ?></option>
													  <?php endforeach; ?>
												</select>
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										
										
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Taluk<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
											

												<select name="org_loc_taluk_id" class="form-control wizard-required" id="loc_taluk">
													  <option value="">Select Taluk</option>
													  <?php
													  	$this->db->where(array('district_id' => $appdet->org_loc_district_id));
														$clients = $this->db->get('m_taluk')->result_array();
														foreach ($clients as $row):	?>
														<option value="<?php echo $row['id']; ?>" <?php if($appdet->org_loc_taluk_id==$row['id']){echo "selected";}?> >
														<?php echo $row['name']; ?></option>
													  <?php endforeach; ?>
												</select>


												<div class="wizard-form-error"></div>
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>City / Town / Village<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text"  id="org_loc_city" name="org_loc_city" class="wizard-required" value="<?php echo $appdet->org_loc_city; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										

										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Nearest Landmark<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text"  id="org_loc_landmark" name="org_loc_landmark" class="wizard-required" value="<?php echo $appdet->org_loc_landmark; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										

										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Pincode<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" maxlength="6" onkeypress="return isNumber(event)" name="org_loc_pincode_id" id="org_loc_pincode_id" class="wizard-required"  onpaste="return false" value="<?php echo $appdet->org_loc_pincode_id; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Mobile Number<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" maxlength="10" name="org_loc_mobile" onkeypress="return isNumber(event)" class="wizard-required" id="loc_mob"  onpaste="return false" value="<?php echo $appdet->org_loc_mobile; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Telephone Number</p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_loc_telephone" onkeypress="return isNumber(event)"  id="loc_tele"  onpaste="return false"  value="<?php echo $appdet->org_loc_telephone; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>

										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Total Build Area(Sq.ft)<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
										<input type="text" id="totalbuildfuna" onkeypress="return isNumberb(event)" onkeyup="totalbuildfun()" name="org_total_build_sqft" class="wizard-required"  onpaste="return false" value="<?php echo $appdet->org_total_build_sqft; ?>">
												<div class="wizard-form-error"></div>
											</div>									
										</div>
<!--
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Location/Area Type <sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="radio" id="yes" name="org_loc_type" value="Commercial" >										
												<label for="yes">Commercial</label>
												<input type="radio" id="no" name="org_loc_type" value="Residential">
												<label for="no">Residential</label>	
											</div>									
										</div>
-->																			
<!--
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Accessibility to Toilet<sup>*</sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text"  onkeypress="return isNumberb(event)" name="org_acc_toilet_mtrs" class="wizard-required">
												<div class="wizard-form-error"></div>
											</div>									
										</div>						
-->				<br>

									</div>
									<div class="form-heading">
										<h4>Other Office Address</h4>
									</div>
									<div class="agent-off-address">
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Address 1<sup></sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_add1" id="org_addr1" class="" value="<?php echo $appdet->org_add1; ?>" >
												
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Address 2<sup></sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_add2" id="org_addr2" class="" value="<?php echo $appdet->org_add2; ?>" >
												
											</div>									
										</div>											
										
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>District<sup></sup></p>
											</div>
											<div class="agent-form-input">
												<select name="org_district_id" id="org_city" class="form-control org_city">
												  <option value="">Select District</option>
												  <?php
													$this->db->where(array('state_id' => '17'));
													$clients = $this->db->get('m_district')->result_array();
													foreach ($clients as $row):
														?>
														<option value="<?php echo $row['id']; ?>" <?php if($appdet->org_district_id==$row['id']){echo "selected";}?>>
														<?php echo $row['name']; ?></option>
													<?php endforeach; ?>
												</select>
												
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Taluk<sup></sup></p>
											</div>
											<div class="agent-form-input">
												



												<select name="org_taluk"  class="org_taluk" id="org_taluk">
													  <option value="">Select Taluk</option>
													  <?php
													  	$this->db->where(array('district_id' => $appdet->org_district_id));
														$clients = $this->db->get('m_taluk')->result_array();
														foreach ($clients as $row):	?>
														<option value="<?php echo $row['id']; ?>" <?php if($appdet->org_taluk==$row['id']){echo "selected";}?> >
														<?php echo $row['name']; ?></option>
													  <?php endforeach; ?>
												</select>


												
											</div>									
										</div>
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>City/Town/Village<sup></sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_city" class="" id="org_town" value="<?php echo $appdet->org_city; ?>">
											
											</div>									
										</div>
										
										
										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Pincode<sup></sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" maxlength="6" name="org_pincode_id" onkeypress="return isNumber(event)" id="org_pincode"  class="" value="<?php echo $appdet->org_pincode_id; ?>">
												
											</div>									
										</div>

										<div class="agent-form-field">
											<div class="agent-form-text">
												<p>Contact Number<sup></sup></p>
											</div>
											<div class="agent-form-input">
												<input type="text" name="org_mobile" onkeypress="return isNumber(event)" class="" id="org_mob" value="<?php echo $appdet->org_mobile; ?>">
												
											</div>									
										</div>


									</div>
									
										
				<div class="alert-error" id="totalbuilderr" style="display:none;margin-top: 26px;text-align: center;">
					<!--span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span--> 
					<?php echo "Since the Total Built Up area is less than 150 sq. ft, the application will not be moved further.";?>
				</div>
										
									<!--div class="form-group clearfix" id="totalbuildnext">
										<a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
									</div-->
							
								<br>

									<div class="form-required">
										<div class="form-required-area">
											<h4>Documents</h4>
											<h5>Allowed Document Type .JPG, .PNG, .PDF(less than 2MB)</h5>
										</div>										
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>1. Registration/Incorporation Certificate<sup>*</sup></h5>
											<p>Documentary proof to be uploaded in compliance with the any one of the below act:
											<br>- should be a Company registered under The Indian Companies Act 1956/2013 or
											<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or 
											<br>-In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished</p>
										</div>									



										<div class="field-comment-sec">
											<?php
	if(!empty($appdet->img_registration_certificate)){

	?>
<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_registration_certificate/<?php echo $appdet->img_registration_certificate; ?>" target="_blank">View</a>
						</div>
						</div>
<?php
}
?>

											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_registration_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>2. Address Proof<sup>*</sup> </h5>
											<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt. </p>
										</div>	
											<?php
	if(!empty($appdet->img_bank_reference)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bank_reference/<?php echo $appdet->img_bank_reference; ?>" target="_blank">View</a>
						</div>
						</div>

<?php
}
?>
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_bank_reference" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>3. Certificate of Statutory Chartered Accountant Certificate of Statutory Chartered<sup>*</sup></h5>
											<p>Documentary proof of turn over in Indian or foreign exchange from tour related activities operations during the previous financial year which should not beless than Rs. 7.5 Lakh“<br>• Certificate of Statutory Chartered Accountant on original letter head<br>• Profit & Loss statement.</p>
										</div>
											<?php
	if(!empty($appdet->img_ca_certificate)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
						</div>
<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_ca_certificate" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>									
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>4. List of Directors/Partners<sup>*</sup></h5>
											<p>List of Directors/Partners or name of the Proprietor.</p>
										</div>	
											<?php
	if(!empty($appdet->img_list_patners)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_list_patners/<?php echo $appdet->img_list_patners; ?>" target="_blank">View</a>
						</div>
						</div>
						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_list_patners" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>5. Brochures or Leaflets<sup>*</sup></h5>
											<p>Brochures or leaflets brought out by the firms having all information about their activities</p>
										</div>
											<?php
	if(!empty($appdet->img_brochures)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_brochures/<?php echo $appdet->img_brochures; ?>" target="_blank">View</a>
						</div>
						</div>
						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_brochures" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>											
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>6. Details of Office Premises<sup>*</sup></h5>
											<p>Rent agreement/Lease Agreement/Sale Deed & Property Tax in the case of owned properties </p>				
										</div>	
											<?php
	if(!empty($appdet->img_off_premises)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_premises/<?php echo $appdet->img_off_premises; ?>" target="_blank">View</a>
						</div>
						</div>
						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_off_premises" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>7. Labour Department Certificate<sup>*</sup></h5>
										</div>	
											<?php
	if(!empty($appdet->img_labour_department)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_labour_department/<?php echo $appdet->img_labour_department; ?>" target="_blank">View</a>
						</div>
						</div>
						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_labour_department" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Attested photograph of Proprietor/Partners/Authorized Representative of the Entity<sup>*</sup></h5>
										</div>	
<?php
	if(!empty($appdet->img_md_photo_attested)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_md_photo_attested/<?php echo $appdet->img_md_photo_attested; ?>" target="_blank">View</a>
						</div>
						</div>	

						<?php
}
?>								
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_md_photo_attested" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>										
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h5>Power of Attorney/ Board Resolution<sup>*</sup></h5>
											<p>(only in case of  Authorized Representative)</p>
										</div>	
<?php
	if(!empty($appdet->img_power_of_attorney)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_power_of_attorney/<?php echo $appdet->img_power_of_attorney; ?>" target="_blank">View</a>
						</div>
						</div>

						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_power_of_attorney" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Exterior<sup>*</sup></h6>											
										</div>	
<?php
	if(!empty($appdet->img_off_buil_exterior)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
						</div>	

														<?php
}
?>
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_off_buil_exterior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Photograph of the Office Building Interior<sup>*</sup></h6>											
										</div>
<?php
	if(!empty($appdet->img_off_buil_interior)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_interior/<?php echo $appdet->img_off_buil_interior; ?>" target="_blank">View</a>
						</div>
						</div>	

						<?php
}
?>									
										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_off_buil_interior" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of GST Registration Certificate</h6>
										</div>
<?php
	if(!empty($appdet->img_gst_regis)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_gst_regis/<?php echo $appdet->img_gst_regis; ?>" target="_blank">View</a>
						</div>
						</div>

						<?php
}
?>


										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_gst_regis" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf" >
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Declaration stating that the travel agent on a monthly basis shall mandatorily share/upload the Tourist Arrival details( Foreign& Domestic) in the Karnataka Tourism Website.<sup>*</sup></h6>
										</div>
<?php
	if(!empty($appdet->img_tourist_arrival_details)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_arrival_details/<?php echo $appdet->img_tourist_arrival_details; ?>" target="_blank">View</a>
						</div>
						</div>

						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_tourist_arrival_details" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>A signed copy of the Pledge of Commitment towards <br>  “Safe & Honorable Tourism”.<sup>*</sup></h6>
										</div>	

										

										<div class="field-comment-sec">
											<div class="pledge-download">
												<a href="<?php echo base_url().'theme/user/images/pledge.jpg';?>" style="margin-left:-50px;" download><i class="fa fa-download" aria-hidden="true"></i></a>
											</div>

<?php
	if(!empty($appdet->img_pledge_commitment)){

	?>
										<div class="allply-form-view" style="margin-left:-20px;">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pledge_commitment/<?php echo $appdet->img_pledge_commitment; ?>" target="_blank" style="margin-left:-20px;">View</a>
						</div>
						</div>

						<?php
}
?>

											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_pledge_commitment" type="file" class="file-upload-field wizard-required" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>
									<div class="field-app-form">
										<div class="field-appli-form-padd">
											<h6>Copy of PAN</h6>
										</div>	
<?php
	if(!empty($appdet->img_pan_copy)){

	?>
										<div class="allply-form-view">
											<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pan_copy/<?php echo $appdet->img_pan_copy; ?>" target="_blank">View</a>
						</div>
						</div>

						<?php
}
?>

										<div class="field-comment-sec">
											<div class="file-upload-wrapper" data-text="Select your file!">
												<input name="img_pan_copy" type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf">
												<div class="wizard-form-error"></div>
											</div>
										</div>
									</div>		
										
									<!--div class="form-group clearfix">
										<a href="javascript:;" class="form-wizard-previous-btn float-left">Previous</a>
										
										<a href="javascript:;" class="form-wizard-next-btn float-right">Next</a>
									</div-->
									
								
									<br>
		<div class="wizard-fieldset agent-other-det show">
									<div class="other-detail-option">
										<div class="other-det">
											<h4>Memberships of International tour<br> associations, if any <sup>*</sup></h4>
										</div>
										<div class="form_input">
											<input type="radio" id="yesCheck2" onclick="javascript:yesnoCheck2();" name="off_international_membership" value="Yes" <?php if($appdet->off_international_membership='Yes'){echo "checked";}?>>							
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck2" onclick="javascript:yesnoCheck2();" name="off_international_membership" value="No" <?php if($appdet->off_international_membership='No'){echo "checked";}?>>
											<label for="no">No</label>											
										</div>										
										<!--div class="other-dept-text">
											<textarea name="off_international_membership" class="wizard-required"></textarea>					<div class="wizard-form-error"></div>				
										</div-->
										<div class="agent-form" <?php if($appdet->off_international_membership=='Yes'){ echo'style="display:block;"';}else{echo'style="display:none;"';} ?> id="ifYes2">
											<div class="form_label">
												<p></p>
											</div>
											<div class="other-dept-text">
												<textarea id="international_member" name="off_international_membership_details"><?php echo $appdet->off_international_membership_details; ?></textarea>
												
											</div>									
										</div>
									</div>

									<div class="other-detail-option">
										<div class="other-det">
											<h4>Steps taken to promote domestic<br> tourists' activity <sup>*</sup></h4>
										</div>										
										<div class="other-dept-text">
											<textarea name="off_promote_domestic_activity" class="wizard-required"><?php echo $appdet->off_promote_domestic_activity; ?></textarea>						
											<div class="wizard-form-error"></div>			
										</div>
									</div>
									<div class="other-detail-option">
										<div class="other-det">
											<h4>Special programmes arranged for<br> Foreign Tourists, if any <sup>*</sup></h4>
										</div>
									<div class="form_input">
											<input type="radio" id="yesCheck3" onclick="javascript:yesnoCheck3();" name="off_prog_arranged_foreign_tourist" value="yes"  <?php if($appdet->off_international_membership='yes'){echo "checked";}?> >				
											<label for="yes">Yes</label>
											<input type="radio" id="noCheck3" onclick="javascript:yesnoCheck3();" name="off_prog_arranged_foreign_tourist" value="no"  <?php if($appdet->off_international_membership='no'){echo "checked";}?> >
											<label for="no">No</label>											
										</div>	

										<div class="agent-form" <?php if($appdet->off_prog_arranged_foreign_tourist=='yes'){ echo'style="display:block;"';}else{echo'style="display:none;"';} ?> id="ifYes3">
										<div class="form_label">
											<p></p>
										</div>
										<div class="other-dept-text">
											<textarea id="special_programe" name="off_prog_arranged_foreign_tourist_details" ><?php echo $appdet->off_international_membership_details; ?></textarea>
											
										</div>									
									</div>
										<!--div class="other-dept-text">
											<textarea name="off_prog_arranged_foreign_tourist" class="wizard-required"></textarea>					<div class="wizard-form-error"></div>				
										</div-->
									</div>	



<div class="other-detail-option">
										

										<div class="agent-form">
										<div class="form_label">
											<p style="font-weight:700;">If any, Clarification</p>
										</div>
										<div class="other-dept-text">
											<textarea name="clarification_comments" class=""></textarea>					<div class="wizard-form-error"></div>				
										</div>									
									</div>
										
									</div>	



															
</div>
									<div class="form-group clearfix">
										

										<button type="submit" class="form-wizard-next-btn float-right">	Update</button>									
										<!-- <a href="javascript:;" class="form-wizard-next-btn float-right">Update</a> -->

										


									</div>
								</fieldset>	
	<br><br>							
														
									</form>	
									<?php } ?>
							
						</div>
					</div>
				</div>
			</section>
		</div>

<style>
.agent-form-file-view {
    width: max-content;
    float: left;
    margin-top: 7px;
}
.agent-form-file-view a {
    background: #ca0127;
    color: #fff;
    padding: 10px;
}
</style>

<script>
$(document).ready(function(){
	


	$(".org_city").on('change',function(){
		var districtid	= $(this).val();
		//alert(countryid);
		  var BASE_URL = "<?php echo base_url();?>";
		var path 		= BASE_URL+'applications/get_taluk';
		//alert(path);
		    $.ajax({
			    type: 'POST',
			    url: path,				
			    data: {districtid : districtid},
			   success:function(html){
                    $('.org_taluk').html(html);
                   
                }
			});
		
	});
});
	
</script>

<script>
$(document).ready(function(){
	


	$("#loc_district").on('change',function(){
		var districtid	= $(this).val();
		//alert(countryid);
		  var BASE_URL = "<?php echo base_url();?>";
		var path 		= BASE_URL+'applications/get_talukloc';
		//alert(path);
		    $.ajax({
			    type: 'POST',
			    url: path,				
			    data: {districtid : districtid},
			   success:function(html){
                    $('#loc_taluk').html(html);
                   
                }
			});
		
	});
});
	
</script>

<script type="text/javascript">

function yesnoCheck() {
    if (document.getElementById('yesCheck').checked) {
        document.getElementById('ifYes').style.display = 'block';
		document.getElementById('reg_firm').classList.add("wizard-required");
    }
    else {
		document.getElementById('ifYes').style.display = 'none';
		document.getElementById('reg_firm').classList.remove("wizard-required");
	}
}



$(".form_input_file").on("change", ".file-upload-field", function(){ 
    $(this).parent(".file-upload-wrapper").attr("data-text",         $(this).val().replace(/.*(\/|\\)/, '') );
});

$(".field-comment-sec").on("change", ".file-upload-field", function(){ 
	//alert(".field-comment-sec");
    $(this).parent(".file-upload-wrapper").attr("data-text", $(this).val().replace(/.*(\/|\\)/, '') );
});
</script>


<script type="text/javascript">

function yesnoCheck1() {
    if (document.getElementById('yesCheck1').checked) {
        document.getElementById('ifYes1').style.display = 'block';
		document.getElementById('firm').classList.add("wizard-required");
    }
    else {
		document.getElementById('ifYes1').style.display = 'none';
		document.getElementById('firm').classList.remove("wizard-required");
	}

}

</script>

<script type="text/javascript">

function yesnoCheck2() {
    if (document.getElementById('yesCheck2').checked) {
        document.getElementById('ifYes2').style.display = 'block';
		document.getElementById('international_member').classList.add("wizard-required");		
    }
    else {
		document.getElementById('ifYes2').style.display = 'none';
		document.getElementById('international_member').classList.remove("wizard-required");
	}
}

</script>
<script type="text/javascript">

function yesnoCheck3() {
    if (document.getElementById('yesCheck3').checked) {
        document.getElementById('ifYes3').style.display = 'block';
		document.getElementById('special_programe').classList.add("wizard-required");
    }
    else {
		document.getElementById('ifYes3').style.display = 'none';
		document.getElementById('special_programe').classList.remove("wizard-required");
	}
}

function Checktrade(val){
 var element=document.getElementById('othertrade');
 if(val=='Others'){
   element.style.display='block';
   document.getElementById('othertrade').classList.add("wizard-required");
 }
 else  {
   element.style.display='none';
   document.getElementById('othertrade').classList.remove("wizard-required");
 }
}


</script>


<script type="text/javascript">

function yesnoCheck5() {
    if (document.getElementById('yesCheck5').checked) {
        document.getElementById('ifYes5').style.display = 'block';
        document.getElementById('firm').classList.add("wizard-required");
    }
    else {
		document.getElementById('ifYes5').style.display = 'none';
		document.getElementById('firm').classList.remove("wizard-required");
	}
}

</script>


<script>
    function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>

<script>
function isNumbera(evt) {
   var regex = new RegExp("^[A-Z a-z]");
        var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    return true;
}

</script>

<script>
function isNumberb(evt) {
   var regex = new RegExp("^[0-9.]");
        var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    return true;
}

</script>


<script>
function totalbuildfun() {
  var x = document.getElementById("totalbuildfuna").value;
  if(x < 150){
  	$('#totalbuildnext').hide();
  	$('#totalbuilderr').show();
  }
  else{
  	$('#totalbuildnext').show();
  	$('#totalbuilderr').hide();
  }

}

</script>


	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
 

<script>



        var razorpay_pay_btn, instance;
        function razorpaySubmit(el) {

var mobilee = document.getElementById("applmob").value;
    	       var emaill = document.getElementById("applemail").value;
    	      var namee = document.getElementById("card_holder_name_ida").value;


        var options = {
            key:            "<?php echo $key_id; ?>",
            amount:         "<?php echo $total; ?>",
            name:           "<?php echo $name; ?>",
            description:    "Order # <?php echo $merchant_order_id; ?>",
            netbanking:     true,
            currency:       "<?php echo $currency_code; ?>", // INR
           prefill: {
                name:       namee,
                email:      emaill,
                contact:    mobilee
            },
            notes: {
                soolegal_order_id: "<?php echo $merchant_order_id; ?>",
            },
            handler: function (transaction) {
                document.getElementById('razorpay_payment_id').value = transaction.razorpay_payment_id;
                document.getElementById('razorpay-form').submit();
            },
            "modal": {
                "ondismiss": function(){
                    location.reload()
                }
            }
        };




            if(typeof Razorpay == 'undefined') {
                setTimeout(razorpaySubmit, 200);
                if(!razorpay_pay_btn && el) {
                    razorpay_pay_btn    = el;
                    el.disabled         = true;
                    el.value            = 'Please wait...';  
                }
            } else {
                if(!instance) {
                    instance = new Razorpay(options);
                    if(razorpay_pay_btn) {
                    razorpay_pay_btn.disabled   = false;
                    razorpay_pay_btn.value      = "Pay Now";
                    }
                }
                instance.open();
            }
        }  



      
    </script>




<script>
$("#ajaxformsubmit").on('click',function(){

	var path 		= "<?php echo base_url();?>applications/application_save";
	var appName = $("#appName").val();


	//alert('testt');


	//var form = $("#formSave123");
//var formData = new FormData('#formSave123');
		var form = $('#formSave123')[0];
        var formData = new FormData(form);
    
    $.ajax({
			    type: 'POST',
			    url: path,
			     //data: form.serialize(),
		processData: false,
            contentType: false,
            data: formData,
			    success: function(data) {
		
		if(data=="Application Not Updated" || data=="Record Not Updated. Please Enter Applicant Name."){
			alert('Applicant details not saved. Please try after some time.');

		}
		else{

		     var dataval=data.split("/");
     sucval= dataval[0]; 
      insid= dataval[1];
      appmob= dataval[2];
      appemail= dataval[3];
      appname= dataval[4];
       document.getElementById("insertidd").value = insid;  
       document.getElementById("applmob").value = appmob;  
       document.getElementById("applemail").value = appemail;       
        document.getElementById("card_holder_name_id").value = appname;  
       document.getElementById("card_holder_name_ida").value = appname;  
        document.getElementById("merchant_product_info_id").value = insid;
        document.getElementById("razorpay_payment_id").value = insid;  
        	
//alert(sucval);
	
		}
		
			    }
			});




});

 </script>
  

<?php include 'include/footer.php';?>
