<html lang="en" class="notranslate" translate="no"> 
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo base_url().'theme/user/';?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'theme/user/';?>css/style.css">
    <title>KTTF</title>
  </head>
<body style="display: flex; background-color: #ececec">
	<div class="login-page-agent" style="height:100%;">
		
		<div class="login-page-form-agent">
			<div class="ka-logo-agent">
				<img src="<?php echo base_url().'theme/user/';?>images/ka-logo.jpg" style="width:100px;">
			</div>
			<div class="kttf-form-agent">
				<h3>Karnataka Tourism Trade (Facilitation and Regulation) Act 2015 <br>ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ (ಸೌಲಭ್ಯ ಮತ್ತು ನಿಯಂತ್ರಣ) ಕಾಯ್ದೆ 2015</h3><br>
				<h4>Login / ನಿರ್ವಹಣೆ ಲಾಗಿನ್</h4>
				<hr align="center" width="30%">

			<?php if($this->session->flashdata('msg')):?>			
				<div class="alert">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg');?>
				</div>
			<?php endif; ?>
			<?php if($this->session->flashdata('msg-error')):	
			if(($this->session->flashdata('msg-error'))=="Your Account Activation link is Expired. Please Click Here."){ ?>
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-errorid');?>
				</div>
			<?php
			}
			else{
			?>
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-error');?>
				</div>
			<?php 
			}
			?>
			<?php endif; ?>
				<form action="<?php echo base_url().'login/auth';?>" method="post">
					<div class="admin-user-name-agent">
						<span class="username-agent">Username  / ಹೆಸರು</span>
						<span class="username-box-agent">
							<input type="email" placeholder="Email" required name="user_name">
						</span>
					</div>
					<div class="admin-user-pass-agent">
						<span class="username-agent">Password / ಪಾಸ್ವರ್ಡ್</span>
						<span class="username-box-agent">							
							<input type="password" id="user_password" name="user_password" placeholder="Password">
							<i class="fa fa-eye-slash" onclick="show('user_password')" id="amin-pass"></i>
						</span>
					</div>
					<div class="admin-submit-agent">
						<div class="log-admin-agent">
							<input type="submit" value="Login" class="admin-login-submit-agent"><br>
							<a href="<?php echo base_url().'login/forget';?>" id="forget1">Forgot Password / ಪಾಸ್ವರ್ಡ್ ಮರೆತಿರಾ</a>
						</div>
						<div class="admin-reg-agent">
							<a href="<?php echo base_url().'register';?>">Create New Account</a>
						</div>
					</div>
				</form>
				<div class="admin-more-info-agent">
					<h5><a href="<?php echo base_url().'theme/user/images/'?>kttf_act_2015.pdf" target="_blank">Act 2015 <!--span style="color:#ffd01a;">- Registration Process</span--></a></h5>
					<span class="kttf-act">Karnataka Tourism Trade (facilitation and Regulation) Act 2015 <br> ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ (ಸೌಲಭ್ಯ ಮತ್ತು ನಿಯಂತ್ರಣ) ಕಾಯ್ದೆ 2015</span> 
				</div>
				
			</div>
			<div class="copyright-agent"><p style="font-style: italic;">© 2021 Deportment of Tourism, Karnataka All Rights Reserved.</p></div>
		</div>
	</div>
	<script>
		function show(id) {
		  var a = document.getElementById(id);
		  if (a.type == "password") {
			a.type = "text";

		  } else {
			a.type = "password";
		  }
		}
	</script>


	 <script>  
 
      $('#forget').click(function(){  
           confirm('Are you Sure Want to change Password ? ');
      });  
  
 </script>
<style>
.kttf-form-agent h3 {
    font-size: 20px!important;
    font-weight: 600;
}
.kttf-form-agent h4 {
    font-size: 20px!important;
}
form .admin-user-name-agent {

    font-size: 16px!important;
}
form .admin-user-pass-agent {
font-size: 16px!important;
}
form .admin-submit-agent {

    margin-top: 0px!important;
}
.admin-more-info-agent {

    padding: 0px!important;
}

.kttf-form-agent form {

    padding: 10px!important;
}


@media only screen and (max-width: 1024px){
.login-charat-agent img {
    height: auto;
}
}
@media only screen and (max-width: 768px){
.login-charat-agent img {
   display: none;
}
}
</style>
<style>
	.login-page-form-agent {
    float: left;
    position: sticky;
    width: 60%;
    padding: 2% 5%;
    text-align: center;
    margin: auto;
    border: 0px solid;
    box-shadow: 0 2px 5px 0 rgb(0 0 0 / 36%), 0 2px 10px 0 rgb(0 0 0 / 32%);
    border-radius: 20px;
    background-color: #ffffff;
}
  .kttf-form-agent .admin-more-info-agent {
    float: left;
    position: relative;
    width: 100%;
    text-align: center;

  }
 .login-page-agent {
    float: left;
    position: relative;
    width: 100%;
    background: #ececec;
    display: flex;
}
.copyright-agent{
	font-size: 10px;
	color: grey;
}

</style>

</body>
</html>
