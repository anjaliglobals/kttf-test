<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<div class="agent-application">				
			<section class="wizard-section">
				<div class="no-gutters">			
					<div class="col-lg-12 col-md-12">
						<div class="form-wizard man3" >
							<h3> Karnataka Tourism Trade (Facilatation and Regulation) Act 2015 User Manual &nbsp; &nbsp;  &nbsp;  &nbsp;   <a class="btn btn-danger" href="<?php echo base_url().'dashboard';?>">Back</a></h3>
								 <?php
									$this->db->where('id', $_SESSION['usrID']);
									$userdata = $this->db->get('usr_register')->row();
								?>
								<br><br>

							<div class="container">

<fieldset id="general-verify" class="wizard-fieldset general-verify show">
									<div class="agent-form">
										<div class="form_label">
											<a href="<?php echo base_url().'theme/user/images/KTTF_user_manual.pdf';?>" target="_blank"><p class="man2"><img src="<?php echo base_url().'theme/user/images/pdf_dn.jpg';?>" style="width: 100px;height: auto;"><b class="man1">ಬಳಕೆದನರರ ಕೆೈಪಿಡ</b> </p></a>
											
										</div>
										<div class="form_input">										
											<a href="<?php echo base_url().'theme/user/images/KTTF_user_manual_english.pdf';?>"target="_blank"><p class="man2"><img src="<?php echo base_url().'theme/user/images/pdf_dn.jpg';?>" style="width: 100px;height: auto;"><b class="man1">User Manual</b> </p></a>									
										</div>										
									</div>
									
									</fieldset>



							</div>



						</div>
					</div>
				</div>
			</section>
		</div>


<style>
a.add_button {background: #0e984c;color: #fff;padding: 10px 20px;border-radius:3px;cursor:pointer;}
.other-off-head h4, .other-off-no label{color: #ca0027;font-size: 25px;}
a.remove_button {float: right;margin: 15px 0 0;background: #ca0027;color: #fff;padding: 10px;border-radius: 3px;cursor:pointer;}
.other-off-addre {float: left;position: relative;width: 100%;margin-bottom: 20px;}
.man1{color: #000;padding: 40px;font-size: 20px;}
.man2{border: 2px solid #adb5bd;width: 75%;padding: 10px 1px 5px 5px;border-radius: 5px}
.man3{height:50%;}
@media only screen and (max-width: 768px){
.man1{color: #000;padding: 20px;font-size: 18px;display: inline-block;}
.man2{border: 2px solid #adb5bd;width: 100%;padding: 10px 1px 5px 5px;border-radius: 5px}
.man3{height:100%;}
}

</style>
<?php include 'include/footer.php';?>
