<html>
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo base_url().'theme/user/';?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'theme/user/';?>css/style.css">
    <title>KTTF - Registration</title>
  </head>
<body style="display: flex;">
	
		<div class="regi-page-form-agent">
			<div class="ka-logo-agent">
				<img src="<?php echo base_url().'theme/user/';?>images/ka-logo.jpg"  style="width:100px;">
			</div>
			<div class="regi-kttf-form-agent">
				<h3>Karnataka Tourism Trade (Facilitation and Regulation) Act 2015 <br>ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ (ಅನುಕೂಲ ಮತ್ತು ನಿಯಂತ್ರಣ) ಕಾಯ್ದೆ 2015</h3><br>
				<h4>New Registration ಹೊಸ ನೋಂದಣಿ</h4>

        <?php if($this->session->flashdata('msg')):?>
        <div class="alert">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
        <?php echo $this->session->flashdata('msg');?>
      </div>

      <?php endif; ?>


				<hr align="center" width="50px">
			<form action="<?php echo base_url().'register/save';?>" method="post">
					<div class="regi-user-name-agent"style=" text-align: center;">					
						<input type="text" placeholder="Name" required name="reg_name" autocomplete="nope">						
					</div>
					<div class="regi-user-name-agent">					
						<input type="email" placeholder="Email" required name="reg_email">						
					</div>
					<div class="regi-user-pass-agent">						
						<input type="password" id="psw" name="reg_password" placeholder="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required autocomplete="nope">
						<i class="fa fa-eye-slash" onclick="show('psw')" id="amin-pass"></i>						
					</div>
					<div class="regi-user-name-agent">					
						<input type="text" placeholder="Mobile" onkeypress="return isNumber(event)" required name="reg_mob" maxlength="10">						
					</div>
					<div class="regi-submit-agent">
						<div class="log-regi-agent">
							<!-- <p>captcha</p> -->
						</div>
						<div class="regi-reg-agent">
							<input type="submit" value="Register Now" class="regi-login-submit-agent">
						</div>

                    <div id="message">
  <h3 style="font-size: 14px;font-weight: 600;text-align: left;">Password must contain the following:</h3>
  <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
  <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
  <p id="number" class="invalid">A <b>number</b></p>
  <p id="length" class="invalid">Minimum <b>8 characters</b></p>
</div>
</div>
</form>




				<div class="regi-more-info-agent">
					<h5>Already have account? <a href="<?php echo base_url().'login';?>"><span style="color:#ca0026;"> Log in Here</span></a></h5>
				</div>
			</div>

      <div class="copyright-agent"><p style="font-style: italic;">© 2021 Deportment of Tourism, Karnataka All Rights Reserved.</p></div>
	

		</div>
	</div>
	<script>
		function show(id) {
		  var a = document.getElementById(id);
		  if (a.type == "password") {
			a.type = "text";

		  } else {
			a.type = "password";
		  }
		}
	</script>



			
<script>
var myInput = document.getElementById("psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>

<style>


/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  /*background: #f1f1f1;*/
  color: #000;
  position: relative;
 /* padding: 20px;
  margin-top: 10px; */
}

#message p {
  padding: 1px 8px;
  font-size: 14px;
    margin-bottom: 0px;
    text-align: left;

}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}

.regi-more-info-agent h5 {
    font-size: 16px;
}
.regi-more-info-agent {
    padding: 0% 13%;
}
.regi-kttf-form-agent form {
    padding: 1px 27px;
}
.regi-kttf-form-agent h4 {
    font-size: 18px!important;
}
.regi-charat-agent {
    width: auto!important;
}

@media only screen and (max-width: 1024px){
.regi-charat-agent img {
    height: auto;
}
}
@media only screen and (max-width: 768px){
.regi-charat-agent img {
   display: none;
}
}
</style>
<style>
  .regi-page-form-agent {
    float: left;
    position: sticky;
    width: 60%;
    padding: 2% 5%;
    text-align: center;
    margin: auto;
    border: 0px solid;
    box-shadow: 0 2px 5px 0 rgb(0 0 0 / 36%), 0 2px 10px 0 rgb(0 0 0 / 32%);
    border-radius: 20px;
    background-color: #ffffff;
}
  .regi-kttf-form-agent{
    float: left;
    position: relative;
    width: 100%;
    text-align: center;

  }
 .regi-page-agent {
    float: left;
    position: relative;
    width: 100%;
    background: #ececec;
    display: flex;
}
.copyright-agent{
  font-size: 10px;
  color: grey;
}
.body{
  display: flex!important;
}

</style>

<script>
    function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>


<style>
.regi-kttf-form-agent h3 {
    font-size: 20px!important;
    font-weight: 600;
}
.regi-kttf-form-agent h4 {
    font-size: 20px!important;
}

</style>
</body>
</html>
