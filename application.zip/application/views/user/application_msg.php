<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>





			<?php if($this->session->flashdata('msg')):?>
				<div class="alert">
			  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
			</div>

			<?php endif; ?>


<div class="manage-pro">
<div class="product-header">
				<div style="overflow-x:auto">
				<table class="pro-table">
					<tbody>
						<tr class="pro-row">
							<th>SI.No</th>
							<th>Date</th>
							<th>Subject</th>
							<th>Comments</th>
							<th>Stage</th>
							<th>Admin</th>

						</tr>
						<?php //print_r($appdetails); ?>
  <?php 
 $counter = 1;
if(empty($appdetails)){
?>

<tr class="pro-col">
						<td colspan='6'> No Message Found</td>
														
						</tr>


<?php
}
else{

  foreach($appdetails as $appdet){ ?>

						<tr class="pro-col">
							<td> <?php echo $counter++;?></td>
							<td><?php echo date("d-m-Y",strtotime($appdet->crtdate)); ?></td>
							<td><?php echo $appdet->subject; ?></td>
							<td><?php echo $appdet->cons_comm; ?></td>
							<td><?php echo $appdet->app_stage+1; ?>
							</td>
							<td>
								<?php echo $this->db->get_where('usr_register', array('id' => $appdet->crtby))->row()->name; ?>
							</td>
														
						</tr>
						<?php }
						} ?>
					</tbody>  
				</table>
			</div>
			</div>	

</div>	







<style>
.manage-pro .product-header {float: left;position: relative;width: 100%;border-radius: 05px;margin-top: 10px;}
.manage-pro .product-header .pro-table {width: 100%;text-align: center;}
.manage-pro .product-header .pro-table th {color: #504d4d;font-weight: 600;font-size: 15px;border:1px solid #333;}
.manage-pro .product-header .pro-table th:nth-child(1){width:;}
.manage-pro .product-header .pro-table th:nth-child(2){width:;}
.manage-pro .product-header .pro-table th:nth-child(3){width:;}
.manage-pro .product-header .pro-table th:nth-child(4){width:;}
.manage-pro .product-header .pro-table th:last-child {background:#efefef;width: 20%;}
.manage-pro .product-header .pro-table .pro-row {height: 60px;box-shadow:0 0 5px 0 #e0e0e0;}
.manage-pro .product-header .pro-table .pro-col {height: 50px;}
.manage-pro .product-header .pro-table .pro-action span {width: 25%;padding: 10px;float: left;font-size:14px;}
.manage-pro .product-header .pro-table .pro-action span .fa{display:block;font-size:25px;}
.manage-pro .product-header .pro-table td {font-size: 16px;border:1px solid #333;}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php include 'include/footer.php';?>
