<html>
<head>    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="<?php echo base_url().'theme/user/';?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url().'theme/user/';?>css/style.css">

    <title>KTTF</title>
  </head>
<body>
	<div class="login-page-agent" style="height:100%;">
		<div class="login-charat-agent">
			<img src="<?php echo base_url().'theme/user/';?>images/stone-chariot.jpg">
		</div>
		<div class="login-page-form-agent" >
			<div class="ka-logo-agent">
				<img src="<?php echo base_url().'theme/user/';?>images/ka-logo.jpg"  style="width:100px;">
			</div>
			<div class="kttf-form-agent">
				<h3>Karnataka Tourism Trade (Facilitation and Regulation) Act 2015 /<br>ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವ್ಯಾಪಾರ (ಅನುಕೂಲ ಮತ್ತು ನಿಯಂತ್ರಣ) ಕಾಯ್ದೆ 2015</h3>
				<h4>Forgot Password ಪಾಸ್ವರ್ಡ್ ಮರೆತಿರಾ</h4>
				<hr align="center" width="50px">

			<?php if($this->session->flashdata('msg')):?>			
				<div class="alert">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg');?>
				</div>
			<?php endif; ?>
			<?php if($this->session->flashdata('msg-error')):?>			
				<div class="alert-error">
					<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
					<?php echo $this->session->flashdata('msg-error');?>
				</div>
			<?php endif; ?>
				<form action="<?php echo base_url().'login/forget_password';?>" method="post">
					<div class="admin-user-name-agent">
						<span class="username-agent" style="width:100%;">Enter the Registered Email ID</span>
						
					</div>

					<div class="admin-user-pass-agent">
						
						<span class="username-box-agent">							
							<input type="email"required placeholder="Enter the Email ID" required name="user_email">
						</span>
					</div>

					
					<div class="admin-submit-agent">
						
						<div class="admin-reg-agent">
							<input type="submit" value="Submit" class="admin-login-submit-agent">
						</div>
					</div>
				</form>
				
			</div>
		</div>
	</div>
	<script>
		function show(id) {
		  var a = document.getElementById(id);
		  if (a.type == "password") {
			a.type = "text";

		  } else {
			a.type = "password";
		  }
		}
	</script>

<style>
.kttf-form-agent h3 {
    font-size: 16px!important;
    font-weight: 600;
}
.kttf-form-agent h4 {
    font-size: 20px!important;
}
.login-charat-agent {
    width: auto!important;
}
@media only screen and (max-width: 1024px){
.login-charat-agent img {
    height: auto;
}
}

@media only screen and (max-width: 768px){
.login-charat-agent img {
   display: none;
}
}
</style>
	 

</body>
</html>
