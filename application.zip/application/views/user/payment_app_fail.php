<?php include 'include/header.php';?>
<?php if($this->session->flashdata('msg')):?>
				<div class="alert">
			  <span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
			</div>

			<?php endif; ?>
		<div class="agent-application">				
			<div class="user-payment-details">
				<div class="user-payment">
					<div class="payment-title">
						<h3>Payment</h3>
					</div>
					<div class="payment-details">
						<div class="payment-amount">
							<p>Payable Amount</p>
							<p>Pament Method</p>
						</div>
						
						<?php
						print_r($appdet);
						?>
						<div class="payment-value">
							<p>Rs. 500.00</p>
							<p>Online payment - Failed</p>
						</div>
					</div>



					<div class="payment-dashboard">
						<a href="<?php echo base_url().'dashboard';?>">Back to Dashboard</a>
					</div>
					<!--div class="payment-history">
						<h3>Payment History</h3>
						<div class="page-content">	
							<div class="tabbed">
								<input type="radio" id="tab1" name="css-tabs" checked>
								<input type="radio" id="tab2" name="css-tabs">							
								
								<ul class="tabs">
									<li class="tab"><label for="tab1">Successful</label></li>
									<li class="tab"><label for="tab2">Failed</label></li>								
								</ul>								
								<div class="tab-content">
									<div class="payment-table">
										<div style="overflow:auto">
											<table>
												<tbody>
													<tr class="app-tn-head">
														<th>SI.No</th>
														<th>Description</th>
														<th>Status</th>
														<th>Payment Channel</th>
														<th>Date</th>
														<th>Amount</th>
														<th>Receipt</th>													
													</tr>
													<tr>
														<td>1</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>01-MD</td>													
														<td><a href="#">View</a></td>
													</tr>
													<tr>
														<td>2</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>Municipality</td>
														<td><a href="#">View</a></td>
													</tr>
												</tbody>
											</table>
										</div>										
									</div>
								</div>								
								<div class="tab-content">
									<div class="payment-table">
										<div style="overflow:auto">
											<table>
												<tbody>
													<tr class="app-tn-head">
														<th>SI.No</th>
														<th>Description</th>
														<th>Status</th>
														<th>Payment Channel</th>
														<th>Date</th>
														<th>Amount</th>
														<th>Receipt</th>													
													</tr>
													<tr>
														<td>1</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>01-MD</td>													
														<td><a href="#">View</a></td>
													</tr>
													<tr>
														<td>2</td>
														<td>VRL Traveles</td>
														<td>125MYS</td>
														<td>MYS</td>
														<td>Municipality</td>
														<td>Municipality</td>
														<td><a href="#">View</a></td>
													</tr>
												</tbody>
											</table>
										</div>										
									</div>
								</div>							
							</div>							
						</div>
					</div-->
				</div>
			</div>
		</div>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        var options = {
            key:            "<?php echo $key_id; ?>",
            amount:         "<?php echo $total; ?>",
            name:           "<?php echo $name; ?>",
            description:    "Order # <?php echo $merchant_order_id; ?>",
            netbanking:     true,
            currency:       "<?php echo $currency_code; ?>", // INR
            prefill: {
                name:       "<?php echo $card_holder_name; ?>",
                email:      "<?php echo $email; ?>",
                contact:    "<?php echo $phone; ?>"
            },
            notes: {
                soolegal_order_id: "<?php echo $merchant_order_id; ?>",
            },
            handler: function (transaction) {
                document.getElementById('razorpay_payment_id').value = transaction.razorpay_payment_id;
                document.getElementById('razorpay-form').submit();
            },
            "modal": {
                "ondismiss": function(){
                    location.reload()
                }
            }
        };

        var razorpay_pay_btn, instance;
        function razorpaySubmit(el) {
            if(typeof Razorpay == 'undefined') {
                setTimeout(razorpaySubmit, 200);
                if(!razorpay_pay_btn && el) {
                    razorpay_pay_btn    = el;
                    el.disabled         = true;
                    el.value            = 'Please wait...';  
                }
            } else {
                if(!instance) {
                    instance = new Razorpay(options);
                    if(razorpay_pay_btn) {
                    razorpay_pay_btn.disabled   = false;
                    razorpay_pay_btn.value      = "Pay Now";
                    }
                }
                instance.open();
            }
        }  
    </script>
<?php include 'include/footer.php';?>
