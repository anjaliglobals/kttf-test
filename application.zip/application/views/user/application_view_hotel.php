<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<?php if($this->session->flashdata('msg')):?>
		<div class="alert">
		<span class="closebtn" onclick="this.parentElement.style.display='none';">×</span> 
			  <?php echo $this->session->flashdata('msg');?>
		</div>
	<?php endif; ?>
<!--NEWW-->
<?php 

if(empty($appnot_det)){

}
else{

	?>

<div class="container-fluid" style="overflow-x:auto;overflow-y:hidden;" >

<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
<thead >
<tr class="success" style="background-color:#495057;color:#fff">
<th style="width:10%;">Sl_No</th> 
<th>Messages</th>
<th>Date</th>
<th>Stage</th>
<th >Updated From</th>
</tr> 
</thead>
<?php 
 	$counter = 1;
    foreach($appnot_det as $noti_det){ 
?>      
<tr>
<td><?php echo $counter++;?></td>  
<td style="text-align:;"><?php echo $noti_det->message; ?></td>
<td style="text-align:;"><?php echo date("d/m/Y H:i:s",strtotime($noti_det->crtdate)); ?></td>
<td style="text-align:;"><?php echo $this->db->get_where('m_stage', array('order_stage' => $noti_det->app_stage))->row()->stage_description; ?></td>
<td style="text-align:;"><?php echo $noti_det->crtname; ?></td>
</tr>
<?php 
}
?>
</table>
</div>
<style>
th {
    color: #fff!important;
}
</style>

<?php
}
?>
<!--end NEWW-->

  <!--  <?php print_r($appdetails);?>  --> 
<!--		   print_r($appdet->product_id);-->
  <?php foreach($appdetails as $appdet){  ?>
  	<div class="form-wizard">

	<div class="agent-form-file-view1">
		<?php if($appdet->licence_issued_date != NULL)
		{ ?>
		<!-- <a href="<?php echo base_url();?>applications/certificate/<?php echo $appdet->application_id;?>" target="_blank">View Certificate</a> -->

		<?php } 
		if($appdet ->dsc_pdf_file != NULL) {?> 

		<a href="<?php echo base_url();?>upload/dsc_pdf_file/<?php echo $appdet->dsc_pdf_file; ?>" target="_blank">View DSC File &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
		<?php } ?>
		
	<!-- </div>

	<div class="agent-form-file-view1"> -->
		<?php if($appdet->is_confirmed == 1)
		{ ?>
		<a href="<?php echo base_url();?>applications/pay_acg/<?php echo $appdet->application_id;?>" target="_blank">View Acknowledgement</a>
		<?php } ?>
	</div></div>
	

<?php if($appdet->is_confirmed==0 && $appdet->status_code==0 && $appdet->isdraft==0){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/application_makepay/<?php echo $appdet->id; ?>">Click Here to Make Payment</a>
</div> 
<?php } ?>

<?php if($appdet->is_confirmed==1 && $appdet->app_status==2 ){ ?>
<div class="agent-form-file-view1">
<!--span style="color:#ca0127;font-weight:700;">If, Any document  or Any Changes ,Please Click Here &nbsp;&nbsp;&nbsp;&nbsp;</span-->
	<!-- <a href="<?php echo base_url();?>applications/application_edit/<?php echo $appdet->id; ?>">EDIT</a> -->
	<!-- <a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a> -->
</div> 
  <?php } ?>

<?php if($appdet->isdraft==1){ ?>
<div class="agent-form-file-view1">
	<a href="<?php echo base_url();?>applications/?apid=0&id=<?php echo $appdet->id;?>&new_id=<?php echo $appdet->product_id?>">EDIT</a>
</div> 
 <?php } ?>
	<div class="admin-dashboard">				
		<div class="agent-application-view">
			<div class="application-view-options">
				<div class="application-info-view">
				<?php if($appdet->licence_no != ''): ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Number / ಪರವಾನಗಿ ಸಂಖ್ಯೆ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->licence_no; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Licence Issued Date / ಪರವಾನಗಿ ನೀಡಿದ ದಿನಾಂಕ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->licence_issued_date)); ?></p>
						</div>										
					</div>
				<?php endif;?>
				<?php if($appdet->iteration > 0 and $appdet->resent_verifi == 0 ): ?>
				<div class="form-heading-view">
					<h4>Resend for clarification</h4>
				</div>
				<form method="post" role="form" enctype="multipart/form-data"  id="refileupload">
					<input type="hidden" name="appid" value=<?php echo $appdet->id?>>
				<div class="agent-form-view" class="col-md-12">
					<table id='dataTableExample_resend' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
							<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th>
								<th>Document Name</th>
								<th>Comments</th>
								<th>Resubmit</th>								
							</tr> 
						</thead> 
					</table><div style="color:green" id="msg">  </div>
					<div style="align-items: center">
						<button class="btn btn-success" onclick="saveupload()">Save</button>
					</div>
				</div>
				</form>
				<?php endif;?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Applicant ID / ಅರ್ಜಿದಾರರ ಐಡಿ <sup> *</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->application_id; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Application Date / ಅರ್ಜಿ ದಿನಾಂಕ <sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y H:i:s",strtotime($appdet->confirmed_date)); ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Category Type / ಪ್ರಕಾರವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->category_type; ?></p>
						</div>										
					</div>

					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name Of The Entity/ಘಟಕದ ಪೂರ್ಣ ಹೆಸರು<sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)/(ಸಂಸ್ಥೆ / ಕಂಪನಿ / ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳು ಸಹಭಾಗಿತ್ವ / ಮಾಲೀಕತ್ವ)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div> -->

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Trade Name / ವ್ಯಾಪಾರ ಹೆಸರು  <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Legal Name / ಕಾನೂನು ಹೆಸರು <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->legal_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>In which name you need a certificate to be printed ? / ಯಾವ ಹೆಸರಿನಲ್ಲಿ ನಿಮಗೆ ಮುದ್ರಿಸಲು ಪ್ರಮಾಣಪತ್ರ ಬೇಕು  <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php if($appdet->certificate_name== '1'){
								echo "Legal Name";
							}?></p>
							<p><?php if($appdet->certificate_name== '2'){
								echo "Trade Name";
							}?></p>
						</div>										
					</div>
					<!-- <div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name Of The Entity / ಘಟಕದ ಪೂರ್ಣ ಹೆಸರು <sup>*</sup><br>(Firm/Company/Limited Liabilities Partnership/Proprietorship)/ ಸಂಸ್ಥೆ/ಕಂಪನಿ/ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ/ಮಾಲೀಕತ್ವ</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->applicant_name; ?></p>
						</div>										
					</div> -->

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Entity Type/ಘಟಕದ  ಪ್ರಕಾರ<sup>*</sup></p>	
						</div>
						<div class="form_input_view">
							<p><?php if($appdet->org_type_id ==1){echo "Proprietary Concern";}
								else if($appdet->org_type_id ==2){echo "Partnership";}
								else if($appdet->org_type_id ==3){echo "Company";}
								else if($appdet->org_type_id ==4){echo "Private Limited Company";}
							  else if($appdet->org_type_id ==5){echo "Public Limited Company";}
								else if($appdet->org_type_id ==6){echo "Limited Liabilities Partnership";}
						?></p>
						</div>										
					</div>						
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of Registration/Incorporation of the Entity <br>(as per the Companies Act 1956 / 2013 or Indian Partnership Act 1932 or Limited Liabilities Partnership Act 2008 or Shops and Establishment Act)/ "ಘಟಕದ ನೋಂದಣಿ/ಸಂಯೋಜನೆಯ ದಿನಾಂಕ (ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956 /2013 ಅಥವಾ ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 1932 ಅಥವಾ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯ್ದೆ 2008 ಅಥವಾ ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ) " <sup>*</sup></p>				
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->org_commencement_date));  ?></p>
						</div>										
					</div>				
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Date of issue of Trade License / ಟ್ರೇಡ್ ಲೈಸೆನ್ಸ್ ನೀಡಲಾದ ದಿನಾಂಕ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo date("d/m/Y",strtotime($appdet->trade_lic_date));  ?></p>
						</div>										
					</div>
					<!--  
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Recognised under Ministry of Tourism, Government of India/ಭಾರತ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಗುರುತಿಸಲ್ಪಟ್ಟಿದೆ <sup> * </sup></p>
								 /ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿಸಲಾಗಿದೆ, ಭಾರತ ಸರ್ಕಾರ 
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->central_gov_approved; ?></p>
						</div>										
					</div>
					<?php if ( $appdet->central_gov_approved == Yes) { ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Details of Registered under Ministry of Tourism, Government of India/ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯ, ಭಾರತ ಸರ್ಕಾರದ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ವಿವರಗಳು<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<a href="<?php echo base_url();?>upload/img_central_gov_registration/<?php echo $appdet->img_central_gov_registration; ?>" target="_blank">View</a>
						</div>										
					</div>
					<?php } ?>-->				
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Full Name of the properator / Directors / Partners/ ಮಾಲೀಕರು / ನಿರ್ದೇಶಕರು / ಪಾಲುದಾರರ ಪೂರ್ಣ ಹೆಸರು <sup> * </sup></p>				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->proprietor_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>GST Identification Number/ಜಿ ಎಸ್ ಟಿ ಗುರುತಿನ ಸಂಖ್ಯೆ: <sup>*</sup>
								<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup> <?php } ?> -->
							</p>						
						</div>
						<div class="form_input_view">
							
							<p><?php echo $appdet->gst_number;?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>PAN Number / ಪ್ಯಾನ್ ಸಂಖ್ಯೆ<sup>*</sup> 
										
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->pan_number; ?></p>
						</div>										
					</div>	
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Website Name & URL / ವೆಬ್‌ಸೈಟ್ ಹೆಸರು ಮತ್ತು URL
								<!-- <?php if($appdet->product_id==1){?><sup>*</sup><?php }?>--></p>		 				
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->website_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Official email id of the Entity / ಸಂಸ್ಥೆಯ ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ
							<!-- <?php if($appdet->product_id==1){?>
								<sup>*</sup><?php }?> --></p>						
						</div> 
						<div class="form_input_view">
							<p><?php echo $appdet->official_email; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Whether the member of Karnataka Tourism Society (KTS)? / ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ಸೊಸೈಟಿಯ (ಕೆಟಿಎಸ್) ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup>*</sup></p>	
							<p>(if yes, please upload the valid KTS license) / (ಹೌದು ಎಂದಾದರೆ, ದಯವಿಟ್ಟು ಮಾನ್ಯವಾದ  KTS ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_kts; ?></p>
							<?php if($appdet->member_kts=='yes'){?>
							<div class="form_input_view">
							<a href="<?php echo base_url();?>upload/img_member_kts/<?php echo $appdet->img_member_kts; ?>" target="_blank">View</a>
							</div>
						<?php }?>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Whether a Member of any recognized Hotel & Restaurant Association? / ಯಾವುದೇ ಮಾನ್ಯತೆ ಪಡೆದ ಹೋಟೆಲ್ ಮತ್ತು ರೆಸ್ಟೋರೆಂಟ್ ಅಸೋಸಿಯೇಶನ್‌ನ ಸದಸ್ಯರಾಗಿದ್ದೀರಾ? <sup>*</sup></p>								
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->member_recognised_trade; ?></p>
						</div>										
					</div>				
				<div class="form-heading-view">
						<h4>Registered Office Address / ನೋಂದಾಯಿತ ಕಚೇರಿ ವಿಳಾಸ</h4>
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1 <sup> * </sup></p>				
									 
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add1; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 2 /ವಿಳಾಸ ಸಾಲು 2 <!--sup> * </sup--></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_add2; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District/ಜಿಲ್ಲೆ  <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $appdet->org_loc_district_id))->row()->name; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk/ತಾಲೂಕು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $appdet->org_loc_taluk_id))->row()->name; ?></p>
						</div>										
					</div>				
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City / Town / Village/ ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_city; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view"> 
							<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್  <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_landmark ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode/ಪಿನ್‌ಕೋಡ್ <sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_mobile; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Telephone Number / ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_telephone; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total built Area(Sq.ft) / ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ) <sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_total_build_sqft; ?></p>
						</div>										
					</div>
					<div class="form-heading-view">
						<h4>Hotel/ Resort Unit Details</h4>
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Name of Hotel/Resort / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಹೆಸರು <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->hotel_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Is the Hotel/Resort star classified under Ministry of Tourism, Government of India /  ಕೇಂದ್ರ  ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಸ್ಟಾರ್ ವರ್ಗೀಕರಿಸಲಾಗಿದೆಯೇ <sup>*</sup></p>
							<p>(If yes, the applicants must upload the valid MoT star classification certificate) / ಹೌದು ಎಂದಾದಲ್ಲಿ ಅರ್ಜಿದಾರರು ಮಾನ್ಯವಾದ MoT ಸ್ಟಾರ್ ವರ್ಗೀಕರಣ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಅಪಲೋಡ್ ಮಾಡಬೇಕು.</p>
						</div>
							<?php if($appdet->img_MoT!=""){?>	
							<div class="form_input_view">
							<p>Yes</p>
							<?php if($appdet->img_MoT==1){?>
							<div class="form_input_view">
							<a href="<?php echo base_url();?>upload/img_MoT/<?php echo $appdet->img_MoT; ?>" target="_blank">View</a>
							</div>
						<?php }?>
							</div>
							<?php }?>
							<?php if($appdet->img_MoT==""){?>	
							<div class="form_input_view">
							<p>No</p>
							</div>
							<?php }?>											
					</div>
					<?php if($appdet->central_gov_approved=='Yes'){ ?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Category of the Hotel/Resort / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ವರ್ಗ<sup>*</sup></p>
							<p>(only applicable, if the hotel/resort is classified under Ministry of Tourism, Government of India)/ (ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಅನ್ನು ಕೇಂದ್ರ ಸರ್ಕಾರದ ಪ್ರವಾಸೋದ್ಯಮ ಸಚಿವಾಲಯದ ಅಡಿಯಲ್ಲಿ ವರ್ಗೀಕರಿಸಿದರೆ ಮಾತ್ರ ಅನ್ವಯವಾಗುತ್ತದೆ.)</p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->cat_restaurant; ?></p>
						</div>										
					</div>
<?php
}
?>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total No. of Rooms in the Hotel/Resort / ಹೋಟೆಲ್/ರಸಾರ್ಟ್ ಒಟ್ಟು  ಕೋಣೆಗಳ ಸಂಖ್ಯೆ <sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->no_rooms; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total No. of Beds in the Hotel/Resort / ಹೋಟೆಲ್/ರಸಾರ್ಟ್ ಒಟ್ಟು  ಬೆಡ್ ಗಳ ಸಂಖ್ಯೆ*<sup>*</sup></p>
						</div>
						<?php if($appdet->no_bed!='') {?>
						<div class="form_input_view">
							<p><?php echo $appdet->no_bed;?></p>
						</div>	
						<?php }?>									
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<h5>Type of Accommodation Provided / ಒದಗಿಸಲಾಗುವ ವಸತಿ ಪ್ರಕಾರ <sup>*</sup></h5>
						</div>
						 <!-- <?php print_r($hotelaccomodation)?>  -->
						<div class="agent-form-view">
								<table id='dataTableExample_acc' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
								<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th> 
								<th>Accommodation</th>	
								<th>Other Facilities</th>	
								</tr> 
								</thead>
								<?php 
									//print_r($addressdet);
								 	$counter = 1;
								    foreach($hotelaccomodation as $hotelacco){ 
								?>      
								<tr>
								<td><?php echo $counter++;?></td>  
								<td style="text-align:;"><?php echo $hotelacco->accommodation_type; ?></td>			<td style="text-align:;"><?php echo $hotelacco->other_facility; ?></td>			
								</tr>
								<?php 
								}
								?>
								</table>
						</div>
					</div>					
							
					<!-- <?php print_r($hotelfacility)?>  -->
					<div class="agent-form-view">
						<div class="form_label_view">
							<h5>Facilities Available in the Hotel & Resort /ಹೋಟೆಲ್ ಮತ್ತು ರೆಸಾರ್ಟ್ ನಲ್ಲಿ ಲಭ್ಯವಿರುವ ಸೌಲಭ್ಯಗಳು <sup>*</sup></h5>
						</div>
						<div class="agent-form-view">
								<table id='dataTableExample_acc' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
								<thead>
								<tr class="success" style="background-color:#495057;color:#fff">
								<th style="width:10%;">Sl_No</th> 
								<th>Facilities</th>		
								<th>Other Facilities</th>					
								</tr> 
								</thead>
								<?php 
									//print_r($addressdet);
								 	$counter = 1;
								    foreach($hotelfacility as $hotel_facility){ 
								?>      
								<tr>
								<td><?php echo $counter++;?></td>  
								<td style="text-align:;"><?php echo $hotel_facility->facility_type; ?></td>
								<td style="text-align:;"><?php echo $hotel_facility->other_facility; ?></td>	
								</tr>
								<?php 
								}
								?>
								</table>
						</div>									
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Name of the Owner/ Manager of the Hotel/Resort / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ಮಾಲೀಕರ/ ಮ್ಯಾನೇಜರ್ ಹೆಸರು <sup> * </sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->owner_name; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number / ಮೊಬೈಲ್ ನಂಬರ್ <sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->owner_mobile; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Email Id of the Owner/Manager of the Hotel/Resort / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ಮಾಲೀಕರು/ ಮ್ಯಾನೇಜರ್ ಇಮೇಲ್ ಐಡಿ<sup>*</sup></p>
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->owner_email; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Number of Permanent Employees / ಖಾಯಂ ನೌಕರರ ಸಂಖ್ಯೆ <sup> *</sup></p>
						</div>
						<div class="form_input_view">
							<p>Male &nbsp;&nbsp;&nbsp;: <?php echo $appdet->permanent_emp_male; ?></p>
							<p>Female  : <?php echo $appdet->permanent_emp_female; ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Number of Outsourced Employees / ಹೊರಗುತ್ತಿಗೆ ನೌಕರರ ಸಂಖ್ಯೆ <sup> *</sup></p>
						</div>
						<div class="form_input_view">
							<p>Male &nbsp;&nbsp;&nbsp;: <?php echo $appdet->outsourced_emp_male; ?></p>
							<p>Female  : <?php echo $appdet->outsourced_emp_female; ?></p>
						</div>										
					</div>
					<div class="form-heading-view">
						<h4>Registered Hotel/ Resort Address / ನೋಂದಾಯಿತ ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ ವಿಳಾಸ</h4>
					</div>
				<!-- 	<?php print_r($addressdet);?> -->
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 1 / ವಿಳಾಸ ಸಾಲು 1  <sup> * </sup></p>				
									 
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_addr1; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Address Line 2 / ವಿಳಾಸ ಸಾಲು 2 <!--sup> * </sup--></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_addr2;  ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>District/ಜಿಲ್ಲೆ  <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_district', array('id' => $addressdet[0]->other_off_district_id))->row()->name; ?></p>
						</div>										
					</div>
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Taluk/ತಾಲೂಕು <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $this->db->get_where('m_taluk', array('id' => $addressdet[0]->other_off_taluk))->row()->name; ?></p>
						</div>										
					</div>				
					
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>City / Town / Village/ ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_city; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view"> 
							<p>Nearest Landmark / ಹತ್ತಿರದ ಲ್ಯಾಂಡ್‌ಮಾರ್ಕ್ <sup> * </sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->org_landmark ?></p>
						</div>										
					</div>

					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Pincode/ಪಿನ್‌ಕೋಡ್ <sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_pincode_id; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Mobile Number/ಮೊಬೈಲ್ ನಂಬರ	<sup>	*	</sup></p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $addressdet[0]->other_off_contact; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Telephone Number/ದೂರವಾಣಿ ಸಂಖ್ಯೆ</p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->org_loc_telephone; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Official Email Id of the Hotel/ Resort / ಹೋಟೆಲ್/ ರೆಸಾರ್ಟ್ಅಧಿಕೃತ ಇಮೇಲ್ ಐಡಿ </p>						
						</div>
						<div class="form_input_view">

							<p><?php echo $appdet->email_id_hotel; ?></p>
						</div>										
					</div>
					<div class="agent-form-view">
						<div class="form_label_view">
							<p>Total Built up Area of the Hotel/Resort (in Sq. Ft) / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್‌ನ ಒಟ್ಟು ನಿರ್ಮಿತ ಪ್ರದೇಶ (ಚದರ ಅಡಿ) </p>						
						</div>
						<div class="form_input_view">
							<p><?php echo $appdet->total_hotel_build_area; ?></p>
						</div>										
					</div>
				<!-- 	<?php if(count($addressdet)>0) { ; ?>
					<div class="form-heading-view">
						<h4>Other Office Address/ಇತರ ಕಚೇರಿ ವಿಳಾಸಗಳು</h4>
					</div>
					<div class="agent-form-view">
						<table id='dataTableExample26' class='table table-striped table-bordered' cellspacing='0' width='100%' style="border: 1px solid black;">
						<thead>
						<tr class="success" style="background-color:#495057;color:#fff">
						<th style="width:10%;">Sl_No</th> 
						<th>Address 1 / ವಿಳಾಸದ 1</th>
						<th>Address 2 / ವಿಳಾಸದ 2</th>
						<th>District / ಜಿಲ್ಲೆ</th>
						<th>Taluk / ತಾಲ್ಲೂಕು</th>	
						<th>City/Town/Village / ನಗರ / ಪಟ್ಟಣ / ಗ್ರಾಮ</th>			
						<th>Pincode / ಪಿನ್ಕೋಡ್</th>
						<th>Contact Number / ಸಂಪರ್ಕ ಸಂಖ್ಯೆ</th>
						</tr> 
						</thead>
						<?php 
							//print_r($addressdet);
						 	$counter = 1;
						    foreach($addressdet as $address_det){ 
						?>      
						<tr>
						<td><?php echo $counter++;?></td>  
						<td style="text-align:;"><?php echo $address_det->other_off_addr1; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_addr2; ?></td>
						<td style="text-align:;"><?php echo $this->db->get_where('m_district', array('id' => $address_det->other_off_district_id))->row()->name;?></td>
						<td style="text-align:;"><?php echo $this->db->get_where('m_taluk', array('id' => $address_det->other_off_taluk))->row()->name; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_city; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_pincode_id; ?></td>
						<td style="text-align:;"><?php echo $address_det->other_off_contact; ?></td></tr>

						<?php 
						}
						?>
						</table>
					</div>
					<?php }?> -->
				</div>
				<div class="agent-application-document-view">
					<div class="form-heading-view">
						<h4>Required Documents / ಅಗತ್ಯವಾದ ದಾಖಲೆಗಳು</h4>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration/Incorporation Certificate/ ನೋಂದಣಿ / ಸಂಯೋಜನೆ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>
							<p>Documentary proof to be uploaded in compliance with the any one of the below act / ಕೆಳಗಿನ ಯಾವುದಾದರೂ ಒಂದು ಕಾಯ್ದೆಗೆ ಅನುಸಾರವಾಗಿ ಡಾಕ್ಯುಮೆಂಟರಿ ಪುರಾವೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು:
								<br>- should be a Company registered under The Indian Companies Act 1956/2013 or / ಭಾರತೀಯ ಕಂಪನಿಗಳ ಕಾಯ್ದೆ 1956/2013 ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಕಂಪನಿಯಾಗಿರಬೇಕು ಅಥವಾ
								<br>- a Partnership Firm under the Indian Partnership Act 1932 or -A Limited Liabilities Partnership under Limited Liabilities Partnership Act 2008 or / ಭಾರತೀಯ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 1932 ರ ಅಡಿಯಲ್ಲಿ ನೋಂದಾಯಿತ ಪಾಲುದಾರಿಕೆ ಸಂಸ್ಥೆ ಅಥವಾ -ಎ ಸೀಮಿತ ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಕಾಯಿದೆ 2008 ರ ಅಡಿಯಲ್ಲಿ ಸೀಮಿತ  ಹೊಣೆಗಾರಿಕೆಗಳ ಪಾಲುದಾರಿಕೆ ಅಥವಾ
								<br>- In the case of Sole Proprietorship, registration under the Shops and Establishment Act or GST Registration Certificate needs to be furnished / "ಏಕ ಮಾಲೀಕತ್ವದ ಸಂದರ್ಭದಲ್ಲಿ, ಕರ್ನಾಟಕ ಅಂಗಡಿ ಮತ್ತು ವಾಣಿಜ್ಯ ಸಂಸ್ಥೆಗಳ  ಕಾಯಿದೆಯ ಪ್ರಕಾರ ನೋಂದಣಿ ಅಥವಾ ಜಿಎಸ್‌ಟಿ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರವನ್ನು ಒದಗಿಸಬೇಕಾಗುತ್ತದೆ."</p>
						</div>	
						<?php if($appdet->img_registration_certificate!=null){?> 
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_registration_certificate/<?php echo $appdet->img_registration_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }  ?>
					</div>
					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Commencement Certificate of the Hotel/Resort <sup>*</sup></h5>							
						</div>
						<?php if($appdet->img_commercial_certificate!="" || $appdet->img_commercial_certificate!=null){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_commercial_certificate/<?php echo $appdet->img_commercial_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div> -->
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Registration certificate under Karnataka shops and Establishment act/ ಕರ್ನಾಟಕ ಮಳಿಗೆಗಳು ಮತ್ತು ಸ್ಥಾಪನೆ ಕಾಯಿದೆ ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ <sup>*</sup></h5>	
							<p>For Hotel/Resort</p>						
						</div>
						<?php if($appdet->img_certificate_shops!="" || $appdet->img_certificate_shops!=null){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_certificate_shops/<?php echo $appdet->img_certificate_shops; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<!-- <div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate of Chartered Accountant / ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್ ಪ್ರಮಾಣಪತ್ರ
								<sup>*</sup></h5>
							<p>Documentary proof of turn over in Indian or foreign exchange from Hotel/Resort related activities operations during the previous financial year 
							<br>• Certificate of Chartered Accountant on original letter head / ಮೂಲ ಅಕ್ಷರದ ತಲೆಯ ಮೇಲೆ ಚಾರ್ಟರ್ಡ್ ಅಕೌಂಟೆಂಟ್‌ನ ಪ್ರಮಾಣಪತ್ರ<br>• Profit &amp; Loss statement/ ಲಾಭ &amp; ನಷ್ಟ ಹೇಳಿಕೆs.</p>
						</div>	
						<?php if($appdet->img_ca_certificate!=null) {?> 
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_ca_certificate/<?php echo $appdet->img_ca_certificate; ?>" target="_blank">View</a>
						</div>
					<?php } ?>
					</div> -->

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Address Proof of the Hotel/Resort / ಹೋಟೆಲ್ ಮತ್ತು ರೆಸಾರ್ಟ್ ವಿಳಾಸ ಪುರಾವೆ <sup>*</sup></h5>
							<p>Utility bill which is not older than two months from the date of application of any service provider (Electricity/telephone/gas/waterbill) / property or municipality tax receipt/ ವಿದ್ಯುತ್/ದೂರವಾಣಿ/ಅನಿಲ/ನೀರಿನ ಬಿಲ್ ಸೇರಿದಂತೆ ಆಸ್ತಿ ಅಥವಾ ಪುರಸಭೆಯ ತೆರಿಗೆ ರಶೀದಿ. ಈ ಬಿಲ್ ಮತ್ತು ರಶೀದಿಗಳು ಎರಡು ತಿಂಗಳುಗಳಿಗಿಂತ ಹಳೆಯದಾಗಿರಬಾರದು </p>
						</div>
						<?php if($appdet->img_bank_reference!=null) {?> 									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bank_reference/<?php echo $appdet->img_bank_reference; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Details of Hotel/Resort Premises / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಸ್ಥಳದ ವಿವರಗಳು <sup>*</sup></h5>							
							<p>Rent agreement/LeaseAgreement in case of rented property. Sale Deed & Property Tax in the case of owned property / ಸ್ಥಳವನ್ನು ಬಾಡಿಗೆ ಪಡೆದ ಸಂದರ್ಭದಲ್ಲಿ ಬಾಡಿಗೆ ಒಪ್ಪಂದ/ಗುತ್ತಿಗೆ ಒಪ್ಪಂದ ಪತ್ರ. ಸ್ಥಳವು ಸ್ವಂತದ್ದಾಗಿದ್ದರೇ, ಮಾರಾಟ ಪತ್ರ ಮತ್ತು ಆಸ್ತಿ ತೆರಿಗೆ ಪತ್ರ ಲಗತ್ತಿಸಬೇಕು</p>
						</div>	
						<?php if($appdet->img_off_premises!=null) {?> 								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_premises/<?php echo $appdet->img_off_premises; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of Hotel/Resort Interior / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಒಳಾಂಗಣದ ಛಾಯಾಚಿತ್ರ <sup>*</sup></h5>	
							<p>All the mandatory features to be captured including the name of the hotel/resort / ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು</p>						
						</div>		
						<?php if($appdet->img_off_buil_interior!=null) {?> 							
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_interior/<?php echo $appdet->img_off_buil_interior; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of Hotel/Resort Exterior / "ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಹೊರಾಂಗಣದ ಛಾಯಾಚಿತ್ರ<sup>*</sup></h5>
							<p>All the mandatory features to be captured including the name of the hotel/resort / (ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಹೆಸರು ಸೇರಿದಂತೆ ಎಲ್ಲಾ ಕಡ್ಡಾಯ ವೈಶಿಷ್ಟ್ಯಗಳನ್ನು ಸೆರೆಹಿಡಿಯಬೇಕು)</p>							
						</div>			
						<?php if($appdet->img_off_buil_exterior!=null) {?>						
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_off_buil_exterior/<?php echo $appdet->img_off_buil_exterior; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>

					<!--div class="allply-form-view">
							<div class="apply-agent-file-view">
								<h5>Copy of Trade License / ವ್ಯಾಪಾರ ಪರವಾನಗಿಯ ಪ್ರತಿ <sup> * </sup></h5>
							</div>
							<?php if($appdet->img_trade_lic!=null) {?>	
							<div class="agent-form-file-view">
								<a href="<?php echo base_url();?>upload/img_trade_lic/<?php echo $appdet->img_trade_lic; ?>" target="_blank">View</a>
							</div>	
							<?php } ?>									
					</div-->

					<div class="allply-form-view">
							<div class="apply-agent-file-view">
								<h5>Sanctioned Building Plans/Occupancy Certificate  / ಮಂಜೂರಾದ ಕಟ್ಟಡ ಯೋಜನೆಗಳು/ಸ್ವಾಧೀನ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>
							</div>
							<?php if($appdet->img_occupancy_certificate!=null) {?>	
							<div class="agent-form-file-view">
								<a href="<?php echo base_url();?>upload/img_occupancy_certificate/<?php echo $appdet->img_occupancy_certificate; ?>" target="_blank">View</a>
							</div>	
							<?php } ?>									
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>GST identification Certificate / GST ನೋಂದಣಿ ಪ್ರಮಾಣಪತ್ರ <sup> *
							 </sup></h5>
						</div>	
						<?php if($appdet->img_gst_regis!=null) {?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_gst_regis/<?php echo $appdet->img_gst_regis; ?>" target="_blank">View</a>
						</div>
						<?php } ?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Copy of PAN / ಪ್ಯಾನ್ ನಕಲು ಪ್ರತಿ <sup> * </sup> </h5>							
						</div>
						<?php if($appdet->img_pan_copy!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pan_copy/<?php echo $appdet->img_pan_copy; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate from FSSAI / FSSAI ನಿಂದ ಪಡೆದ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup> </h5>							
						</div>
						<?php if($appdet->img_fssai_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_fssai_certificate/<?php echo $appdet->img_fssai_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>No-Objection Certificate from Fire department / ಅಗ್ನಿಶಾಮಕ ಇಲಾಖೆಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ</h5>							
						</div>
						<?php if($appdet->img_noobj_certificate!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_noobj_certificate/<?php echo $appdet->img_noobj_certificate; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Certificate/License from Municipality/corporation/ Panchayat to show that your establishment is registered as a Hotel/Resort (Trade License) / "ನಿಮ್ಮ ಸಂಸ್ಥೆಯನ್ನು ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಎಂದು ನೋಂದಾಯಿಸಲಾಗಿದೆ ಎಂದು ತೋರಿಸುವ ಪುರಸಭೆ / ನಿಗಮ / ಪಂಚಾಯಿತಿಯ ಪ್ರಮಾಣಪತ್ರ / ಪರವಾನಗಿ ಪ್ರತಿ"<sup> * </sup></h5>							
						</div>
						<?php if($appdet->img_license!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_license/<?php echo $appdet->img_license; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Pollution Control Board / ಮಾಲಿನ್ಯ ನಿಯಂತ್ರಣ ಮಂಡಳಿಯಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ <sup> * </sup></h5>							
						</div>
						<?php if($appdet->img_pollution_noc!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pollution_noc/<?php echo $appdet->img_pollution_noc; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>
					
					<!--div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Police Department / ಪೊಲೀಸ್ ಇಲಾಖೆಯಿಂದ ಎನ್ಒಸಿ <sup>*</sup></h5>
						</div>
						<?php if($appdet->img_commercial_certificate!="" || $appdet->img_commercial_certificate!=null){?>	
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_commercial_certificate/<?php echo $appdet->img_commercial_certificate; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div-->

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Bar Licence </h5>	
							<p>If applicable / (ಅನ್ವಯಿಸಿದರೆ)</p>						
						</div>
						<?php if($appdet->img_bar_permit!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_bar_permit/<?php echo $appdet->img_bar_permit; ?>" target="_blank">View</a>
						</div>
					<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Declaration stating that the Hotel/Resort operator on a monthly basis shall mandatorily share/upload the Tourist Arrival details (Foreign& Domestic) on the Karnataka Tourism Website / "“ ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಆಪರೇಟರ್ ಕಡ್ಡಾಯವಾಗಿ ಕರ್ನಾಟಕ ಪ್ರವಾಸೋದ್ಯಮ ವೆಬ್‌ಸೈಟ್‌ನಲ್ಲಿ ಪ್ರತಿ ತಿಂಗಳು ಪ್ರವಾಸಿಗರ ಆಗಮನದ ವಿವರಗಳನ್ನು (ವಿದೇಶಿ ಮತ್ತು ದೇಶೀಯ) ಹಂಚಿಕೊಳ್ಳಬೇಕು/ಅಪ್‌ಲೋಡ್ ಮಾಡಬೇಕು ಎಂಬ ಘೋಷಣೆ."<sup> *</sup></h5>							
						</div>		
						<?php if($appdet->img_tourist_arrival_details!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_tourist_arrival_details/<?php echo $appdet->img_tourist_arrival_details; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>Photograph of building with Board name stating name of the entity / ಘಟಕದ ಹೆಸರು (ದಪ್ಪನೆಯ ಅಕ್ಷರಗಳಲ್ಲಿ )ಕಾಣುವಂತೆ  ಕಟ್ಟಡದ ಛಾಯಾಚಿತ್ರ <sup> * </sup></h5>
						</div>		
						<?php if($appdet->img_board_entity!="" || $appdet->img_board_entity!=null){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_board_entity/<?php echo $appdet->img_board_entity; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>

					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>A signed copy of the Pledge of Commitment towards “Safe & Honorable Tourism”/ "ಸುರಕ್ಷಿತ ಮತ್ತು ಗೌರವಾನಿತ್ವ ಪ್ರವಾಸೋದ್ಯಮ” ಬದ್ಧತೆಯ ಪ್ರತಿಜ್ಞಾ ಪತ್ರಕ್ಕೆ ಸಹಿ ಮಾಡಿದ ಪ್ರತಿ <sup> *</sup></h5>							
						</div>	
						<?php if($appdet->img_pledge_commitment!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_pledge_commitment/<?php echo $appdet->img_pledge_commitment; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>				
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Ministry of Environment & Forests (wherever applicable) / "ಪರಿಸರ ಮತ್ತು ಅರಣ್ಯ ಸಚಿವಾಲಯದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ(ಅನ್ವಯವಾಗುವಲ್ಲೆಲ್ಲಾ) " </h5>
						</div>	
						<?php if($appdet->img_noc_environment!=""){?>								
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_noc_environment/<?php echo $appdet->img_noc_environment; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>NOC from Airport Authority of India for Hotel/Resort located near the Airport (wherever applicable) /"ಹೋಟೆಲ್/ರೆಸಾರ್ಟ್ ಏರಪೋರ್ಟ್ ಹತ್ತಿರದಲ್ಲಿದ್ದರೇ, ಭಾರತದ ವಿಮಾನ ನಿಲ್ದಾಣ ಪ್ರಾಧಿಕಾರದಿಂದ ಪಡೆದ ನಿರಾಕ್ಷೇಪಣಾ ಪ್ರಮಾಣಪತ್ರ (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)" </h5>							
						</div>	
						<?php if($appdet->img_noc_airport!=""){?>									
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_noc_airport/<?php echo $appdet->img_noc_airport; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
					<div class="allply-form-view">
						<div class="apply-agent-file-view">
							<h5>CRZ clearance ( Costal Regulation Zone )/ CRZ ಕ್ಲಿಯರೆನ್ಸ್ </h5>
							<p>wherever applicable / (ಅನ್ವಯವಾಗುವ ಸ್ಥಳಗಳಲ್ಲಿ)</p>
						</div>
						<?php if($appdet->img_crz_clearance!=""){?>										
						<div class="agent-form-file-view">
							<a href="<?php echo base_url();?>upload/img_crz_clearance/<?php echo $appdet->img_crz_clearance; ?>" target="_blank">View</a>
						</div>
						<?php }?>
					</div>
			  </div>			
			</div>
		</div>
	</div>
<?php } ?>
<style>
.agent-form-file-view1 {float: left;position: relative;width: 100%;padding: 30px 4%;text-align: right;}
.agent-form-file-view1 a {background: #178597;color: #fff;padding: 10px 20px;border-radius: 3px;}
.admin-dashboard .agent-application-view .application-view-options .application-info-view .agent-form-view .form_input_view a{background: #ca0027;color: #fff;padding: 5px 20px;border-radius: 5px;}
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php include 'include/footer.php';?>
<script type="text/javascript">
$(document).ready( function() 
{
  		//alert("test");
		//alert("loadvehicle data");
		var application_id=<?php echo($appdet->id)?>;
		var BASE_URL = "<?php echo base_url();?>";
		var path = BASE_URL+'applications/vehicledata';		
		var table = $('#dataTableExample_vehicle').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path,
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 
				     	{ data: 'slno' },
				        { data: 'vehicle_type' },
				        { data: 'permit_type'},
				        { data: 'regitration_name' },
				        { data: 'registeration_no' },
				        { data: 'tourist_permit' },
				        { data: 'permitdate' }, 
				        { data: 'enddate' }
				    ]
    	});	
		var path_resend = BASE_URL+'applications/resenddate';
		var tablenew = $('#dataTableExample_resend').DataTable(
		{
			ajax: {
			 			type: 'POST',
				        url: path_resend,
				        //dataType: "json",
				        dataSrc: '',
				        data:{
				             appId:application_id
				        }
				    },
				    searching:false,
				    paging:false,
				    info: false,
				    columns: [ 				   
				     	{ data: 'sno' },
				     	{ data: 'Registration/Incorporation Certificate' },
				     	{ data: 'comments' },
				     	{
                            "data": null,                          
                            render:function(data, type, row)
                            {
                            	//console.log(data.DocumentType);
                                return '<div class="form_input_file">'+
								'<div class="file-upload-wrapper" data-text="Select your file!"><input id="reg_firm" name='+data.DocumentType+' type="file" class="file-upload-field" value="" accept="image/jpeg,image/gif,image/png,application/pdf"></div></div>'+
								   '<input type="hidden" class="tablecount" name="filenames[]" id="filename'+data.sno+'" value='+data.DocumentType+'>'
                            },
                            "targets": -1
                        }                        
				    ]
    	});

		// var table = $('#dataTableExample_resend').DataTable(
		// {
		// 	ajax: {
		// 	 			type: 'POST',
		// 		        url: path,
		// 		        dataSrc: '',
		// 		        data:{
		// 		             appId:application_id
		// 		        }
		// 		    },	

		// 		    searching:false,
		// 		    paging:false,
		// 		    info: false,
		// 		    columns: [ 
		// 		     	{ data: 'slno' },				        
		// 		        {
  //                           "data": null,                          
  //                           render:function(data, type, row)
  //                           {
  //                             if(data.DocumentType)
  //                             {
  //                               return '<input type="checkbox" id="logout_late_'+data.emp_id+'" checked onclick="angular.element(this).scope().activelatelogout('+data.emp_id+')">'  
  //                             }                            
  //                           },
  //                           "targets": -1
  //                       },
		// 		        { data: 'reg_certificate' },				        
		// 		        { data: 'reg_certificate_details' }				        
		// 		    ]
  //   	});
});	
function saveupload()
{
	$("#refileupload").submit(function(e){
        e.preventDefault();
    });
    var path 		= "<?php echo base_url();?>applications/reupload";	
    var form = $('#refileupload')[0];
    var formData = new FormData(form);
    $.ajax({
			type: 'POST',
			url: path,
			 //data: form.serialize(),
			processData: false,
			contentType: false,
			data: formData,
			beforeSend: function() {
		            $('#cover-spin').show(); 
	            setTimeout(function(){ $('#cover-spin').hide();  }, 180000); // 3 min

	        },
			success: function(data) 
			{
				// console.log(data);
				if(data=="Application Not Updated" || data=="Record Not Updated. Please Enter Applicant Name.")
				{
					alert('Applicant details not saved. Please try after some time.');
				}
				else
				{
					//alert("Files are upated successfully") ;
					$('#msg').html('Files are upated successfully');
				}
			},
			 complete:function(defSimilar){
                $('#cover-spin').hide();
            } 

		});

}
</script>

