<?php include 'include/header.php';?>

		<div class="user-agent-dash">	
			<div class="agent-prod">		
			<div class="agent-select-pro">
				<a href="<?php echo base_url().'applications/application_agree';?>">Select New Product / ಹೊಸ ಉತ್ಪನ್ನವನ್ನು ಆಯ್ಕೆಮಾಡಿ</a>
			</div>

			<div class="agent-select-pro-noti">
				<span class="notificount"><?php echo $appnote_count; ?></span> &nbsp;<a href="<?php echo base_url().'applications/notification';?>" style="background: #17a2b8;">Notifications / ಅಧಿಸೂಚನೆಗಳು</a>
			</div>
			</div>
			<div class="user-all-agent">
				<div style="overflow-x:auto;">
					<table id='application-table'>
					 	<thead>
           					<tr class="app-tn-head">
           						<th>Slno</th>
								<th>Product Type / ಉತ್ಪನ್ನ ಪ್ರಕಾರ</th>
								<th>Application Id / ಅಪ್ಲಿಕೇಶನ್ ಐಡಿ</th>
								<th>Entity Name / ಅಸ್ತಿತ್ವದ ಹೆಸರು</th>
								<th>Created On / ಆನ್ ರಚಿಸಲಾಗಿದೆ</th>
								<th>Status / ಸ್ಥಿತಿ</th>
								<th></th>
							</tr>
						</thead>
						<tbody id='app-details'>        
			            </tbody>
					</table>
			</div>			
			</div>			
		</div>
<?php echo $appGetDetails;?> 
<?php include 'include/footer.php';?>
<script>


var applink = '<?php echo base_url().$appViewLink; ?>';
var appPath = '<?php echo base_url().$appGetDetails; ?>';
//console.log(appPath);

var table = $('#application-table').DataTable( {
			        ajax: {
				        url: appPath,
				        dataSrc: ''
				    },
					language : {
				        sLoadingRecords : '<span style="width:100%;"><img src="<?php echo base_url().'theme/user/images/loader_icon.gif'?>"></span>'
				    },
				    columns: [
				     { data: 'slno' }, 
				     { data: 'productName' },
				     { data: 'application_id'},
				     { data: 'orgName' },
				     { data: 'confirmed_date' },
				     { data: 'appStatus' },
				     { data: 'appID' ,
					     "fnCreatedCell": function (nTd, sData, oData, iRow, iCol) 
					     {
					         $(nTd).html("<a class='btn btn-info btn-sm' href='"+applink+oData.appID+"'>"+"view"+"</a>");
					            
					     },
				      }
				    ]
    			});
</script>

<style>

.app-tn-head {
    border-bottom: 1px solid #111;
    color:white;
    background-color: #0a6788;

}
table.dataTable tbody tr {
	background-color: rgba(0,0,0,.05!important);
	}

</style>