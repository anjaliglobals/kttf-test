<?php include 'include/header.php';?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<div class="agent-application">				
			<section class="wizard-section">
				<div class="no-gutters">			
					<div class="col-lg-12 col-md-12">
						<div class="form-wizard">
							<h3>Edit Profile</h3>
								 <?php
									$this->db->where('id', $_SESSION['usrID']);
									$userdata = $this->db->get('usr_register')->row();
								?>
								<fieldset id="general-verify" class="wizard-fieldset general-verify show">
									<div class="agent-form">
										<div class="form_label">
											<p>Name :</p>
										</div>
										<div class="form_input">										
											<input type="text" name="name" id="name" readonly="" class="wizard-required" value="<?php echo $userdata->name?>" >
											<div class="wizard-form-error"></div>											
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Mobile No :</p>
										</div>
										<div class="form_input">										
											<input type="text" name="mobile_no" id="mobile_no" readonly="" class="wizard-required" value="<?php echo $userdata->mobile?>">
											<div class="wizard-form-error"></div>
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>Email Id :</p>
										</div>
										<div class="form_input">										
											<input type="text" name="email_id" id="email_id" readonly="" class="wizard-required" value="<?php echo $userdata->usremail?>">
											<div class="wizard-form-error"></div>
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>GST</p>
										</div>
										<div class="form_input">
											<input type="text" name="gst_number" id="gst_number" class="wizard-required" value="<?php echo $userdata->gst_number?>">
											<div class="wizard-form-error"></div>											
										</div>										
									</div>
									<div class="agent-form">
										<div class="form_label">
											<p>PAN</p>
										</div>
										<div class="form_input">
											<input type="text" name="pan_number" id="pan_number" class="wizard-required" value="<?php echo $userdata->pan_number?>">
											<div class="wizard-form-error"></div>											
										</div>										
									</div>
									<div class="clearfix">
										&nbsp;&nbsp;
									</div>
									<div class="text-center">
										<button class="btn btn-success" onclick="editprofile()">Save</button>
									</div>
									</fieldset>
							
						</div>
					</div>
				</div>
			</section>
		</div>

<script>
$(document).ready(function(){});
function editprofile() 
{
	var userId="<?php echo $_SESSION['usrID']?>";
	var BASE_URL = "<?php echo base_url();?>";
	var path 		= BASE_URL+'applications/putediteddata';
	var gstnumber=$("#gst_number").val();
	var pannumber=$("#pan_number").val();

	$.ajax({
			    type: 'POST',
			    url: path,				
			    data: {gst_number:gstnumber,pan:pannumber,Id:userId},
			   success:function(data){
                    console.log(data);
                }
			});
}
</script>
<style>
a.add_button {background: #0e984c;color: #fff;padding: 10px 20px;border-radius:3px;cursor:pointer;}
.other-off-head h4, .other-off-no label{color: #ca0027;font-size: 25px;}
a.remove_button {float: right;margin: 15px 0 0;background: #ca0027;color: #fff;padding: 10px;border-radius: 3px;cursor:pointer;}
.other-off-addre {float: left;position: relative;width: 100%;margin-bottom: 20px;}
</style>
<?php include 'include/footer.php';?>
